exports.run={usage:["listgroup"],hidden:["listgrup","listgc"],category:"owner",async:async(e,{func:t,mecha:i})=>{var a=Object.values(await i.groupFetchAllParticipating().catch(()=>[]));if(!a.length)return e.reply("Tidak ada grup yang ditemukan.");let r=`乂  *L I S T - G R U P*

Terdapat total *${a.length}* grup.

`;a.forEach((a,e)=>{r+=""+(e+1)+`. ${a.subject}
- ID: ${a.id}
- Total peserta: ${a.participants?Object.keys(a.participants).length:"0"}

`}),r=(r=(r=(r=(r=(r=(r=(r=(r=(r=r+`*Pilihan Opsi:*
_${e.cmd} [nomor] [opsi]_`+`

*Contoh Penggunaan:*`)+`
- \`${e.cmd} 1 detail\` - menampilkan detail grup.`)+`
- \`${e.cmd} 1 profile\` - menampilkan profil grup.`)+`
- \`${e.cmd} 1 desc\` - menampilkan deskripsi grup.`)+`
- \`${e.cmd} 1 link\` - menampilkan tautan grup.`)+`
- \`${e.cmd} 1 leave\` - mengeluarkan bot dari grup.`)+`
- \`${e.cmd} 1 close\` - menutup grup.`)+`
- \`${e.cmd} 1 open\` - membuka grup.`)+`
- \`${e.cmd} 1 admin\` - menampilkan daftar admin.`)+`
- \`${e.cmd} 1 member\` - menampilkan daftar anggota.`;var[n,p]=e.args;if(!n||!p)return e.reply(r);let u=a[parseInt(n)-1];if(!u)return e.reply("Nomor grup tidak valid.");var c=u.id;switch(p.toLowerCase()){case"detail":{var m=await i.groupMetadata(c).catch(()=>{}),s=t.findAdmin(m.participants).includes(e.bot);let a="◦  Nama Grup: "+m.subject;a=(a=(a=(a=(a+=`
◦  ID Grup: `+m.id)+(`
◦  Total Member: `+m.size))+(`
◦  Edit Setelan Grup: `+(m.restrict?"Hanya admin":"Semua peserta")))+(`
◦  Kirim Pesan: `+(m.announce?"Hanya admin":"Semua peserta"))+(`
◦  Bot Admin: `+(s?"Ya":"Tidak")))+(`
◦  Pesan Sementara: `+(m.ephemeralDuration?"Aktif":"Mati")),m.hasOwnProperty("isCommunity")&&(a+=`
◦  isCommunity: `+(m.isCommunity?"Ya":"Tidak")),m.hasOwnProperty("isCommunityAnnounce")&&(a+=`
◦  isCommunityAnnounce: `+(m.isCommunityAnnounce?"Ya":"Tidak")),m.hasOwnProperty("joinApprovalMode")&&(a+=`
◦  Setujui Anggota Baru: `+(m.joinApprovalMode?"Ya":"Tidak")),m.hasOwnProperty("memberAddMode")&&(a+=`
◦  Tambah anggota lain: `+(m.memberAddMode?"Ya":"Tidak")),i.reply(e.chat,a,e,{expiration:e.expiration});break}case"profile":i.sendReact(e.chat,"🕒",e.key);s=await t.getBuffer(await i.profilePictureUrl(c,"image").catch(a=>"https://files.catbox.moe/ifx2y7.png"));i.sendMessage(e.chat,{image:s},{quoted:e,ephemeralExpiration:e.expiration});break;case"desc":m=await i.groupMetadata(c).catch(a=>{});i.reply(e.chat,m.desc,e,{expiration:e.expiration});break;case"link":s=await i.groupInviteCode(c).catch(a=>"");if(!s)return e.reply(global.mess.botAdmin);m=await i.groupMetadata(c).catch(a=>{});e.reply(`Link Group ${m.subject}

https://chat.whatsapp.com/`+s);break;case"leave":await i.reply(c,"Saya diperintahkan untuk keluar dari grup ini. Terima kasih dan maaf atas kesalahan selama di sini."),await i.groupLeave(c).then(()=>e.reply(`Berhasil keluar dari grup "${u.subject}".`)).catch(()=>e.reply(`Gagal keluar dari grup "${u.subject}".`));break;case"close":await i.groupSettingUpdate(c,"announcement").then(()=>e.reply(`Grup "${u.subject}" berhasil ditutup.`)).catch(()=>e.reply(`Gagal menutup grup "${u.subject}".`));break;case"open":await i.groupSettingUpdate(c,"not_announcement").then(()=>e.reply(`Grup "${u.subject}" berhasil dibuka.`)).catch(()=>e.reply(`Gagal membuka grup "${u.subject}".`));break;case"admin":m=await i.groupMetadata(c).catch(()=>{}),s=m.participants.filter(a=>a.admin).map((a,e)=>e+1+". @"+a.id.split("@")[0]).join("\n"),m=`*Daftar Admin Grup "${m.subject}"*

`+s;e.reply(m);break;case"member":s=await i.groupMetadata(c).catch(()=>{}),m=s.participants.map((a,e)=>`${e+1}. @${a.id.split("@")[0]} (${"superadmin"===a.admin?"Owner":"admin"===a.admin?"Admin":"Member"})`).join("\n"),s=`*Daftar Member Grup "${s.subject}"*

`+m;e.reply(s);break;default:i.reply(e.chat,`Opsi "${p}" tidak valid. Pilihan Opsi: detail, profile, desc, link, leave, close, open, admin, member.`,e,{expiration:e.expiration})}},owner:!0};