// nomor owner ubah nomor lu
global.owner = '6283843528448@s.whatsapp.net' // 62882003321562
// nama owner ubah nama lu
global.ownerName = 'Yuliaw'
// nomor pengembang yang bisa akses fitur saveplugin, delplugin, getplugin dan eval
global.developer = [
// ganti nomor lu tapi jangan asal add nomor, nanti bisa curi kode bot
    '6283843528448',
    '6283843528448',
    '6283843528448',
].map(number => number.replace(/[^0-9]/g, '') + '@s.whatsapp.net')
// nama bot lu
global.botName = 'ʜʏᴜ ʙᴏᴛ'
// fake pada beberapa fitur
global.fake = 'ʜʏᴜ ʙᴏᴛ'
// header pada beberapa fitur
global.header = `© ʜʏᴜ ʙᴏᴛ v${require('./package.json').version}`
// footer pada beberapa fitur
global.footer = '© ʜʏᴜ ʙᴏᴛ'
// jeda anti spam / detik
global.cooldown = 1
// ram maksimal untuk auto restart / gb
global.max_ram = 3
// blacklist nomor dengan kode negara tersebut
global.blocks = ['91', '92', '212']
// multi prefix default
global.prefixes = /^[°•π÷×¶∆£¢€¥®™+✓_=|/~!?@#%^&.©^]/i
// setting id channel (cara ambil: ketik .getidch lalu teruskan pesan dari saluranmu ke bot.
global.newsletter = '120363335044339633@newsletter'
// qris url di beberapa fitur seperti donate, buyprem dan sewabot
global.qrisUrl = 'https://files.catbox.moe/esxi4y.jpg'
// audio url yang ada di menu
global.audioUrl = 'https://files.catbox.moe/sfa7iu.mp3';
// setting pairing code
global.pairing = {
    copyFromLink: false, // ubah true jika ingin salin pairing via link https://iyaudah-iya.vercel.app/pairing
    status: true, // ubah false jika ingin menggunaka
    number: '628561420083' // ubah jadi nomor bot lu
}
// setting configuration baileys
global.config = {
    session: 'session',
    online: false,
    version: [2, 3000, 1015901307],
    browser: ['Windows', 'Chrome', '22.04.4']
}
// apikey fitur quickchat
global.quoteApi = 'https://bot.lyo.su/quote/generate'
// url database mongodb (daftar di https://www.mongodb.com/)
global.mongoUrl = ''
// setting message
global.mess = {
    wait: 'Processed . . .',
    ok: 'Successfully.',
    limit: 'Anda telah mencapai limit dan akan disetel ulang pada pukul 00.00\n\n> untuk mendapatkan limit tak terbatas, tingkatkan ke paket premium.',
    premium: 'This feature only for premium user.',
    jadibot: 'This feature only for jadibot user.',
    owner: 'This feature is only for owners.',
    devs: 'This feature is only for developers.',
    group: 'This feature will only work in groups.',
    private: 'Use this feature in private chat.',
    admin: 'This feature only for group admin.',
    botAdmin: 'This feature will work when I become an admin',
    gconly: 'Bot hanya dapat digunakan di dalam grup.',
    bot: 'This feature can only be accessed by bots',
    wrong: 'Wrong format!',
    error: {
        url: 'URL is Invalid!',
        api: 'Sorry an error occurred!'
    },
    block: {
        owner: `This feature is being blocked by owner!`,
        system: `This feature is being blocked by system because an error occurred!`
    },
    query: 'Enter search text',
    search: 'Searching . . .',
    scrap: 'Scrapping . . .',
    wrongFormat: 'Incorrect format, please look at the menu again',
    game: 'Bermain game di obrolan pribadi hanya untuk pengguna premium, tingkatkan ke paket premium hanya Rp. 20.000 selama 1 bulan.'
}

// menghapus cache setelah update
require('./system/functions.js').reloadFile(__filename);