const axios = require('axios');

exports.run = {
usage: ['lirik'],
use: 'judul lagu',
category: 'searching',
async: async (m, { func, mecha }) => {
if (!m.text) return
mecha.sendReact(m.chat, '🕒', m.key)
try {
const apiUrl = `https://api.shannmoderz.xyz/search/cari-lagu?key=free-trial&query=${encodeURIComponent(m.text)}`;
const { data } = await axios.get(apiUrl);
if (!data.status || !data.result) return
const result = data.result;
let txt = `*Judul Lagu:* ${result.title}\n`;
txt += `*Album:* ${result.album}\n\n`;
txt += `*Lirik:*\n${result.lyrics}`;
await mecha.sendMedia(m.chat, result.thumb, m, {
caption: txt,
expiration: m.expiration
});
mecha.sendReact(m.chat, '✅', m.key);
} catch (error) {
mecha.sendReact(m.chat, '❌', m.key);
}
},
restrict: true,
limit: true
}