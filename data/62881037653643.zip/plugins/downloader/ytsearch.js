const yts = require('yt-search');

exports.run = {
usage: ['ytsearch'],
hidden: ['yts'],
use: 'judul lagu',
category: 'downloader',
async: async (m, { func, mecha }) => {
if (!m.text) return m.reply(func.example(m.cmd, 'legends never die'))
mecha.sendReact(m.chat, '🕒', m.key)
let search = await yts(m.text);
if (search.all.length == 0) return m.reply('Data empty.')
let data = search.all.filter(x => x.seconds < 3600);
if (!data) return m.reply('Video is longer than 1 hour!');
mecha.ytsearch = mecha.ytsearch || {};
mecha.ytsearch[m.sender] = {
jid: m.sender,
search: data,
}
let messageId = 'MECHA' + func.makeid(22).toUpperCase() + 'YTSEARCH'
let caption = `*Y O U T U B E - S E A R C H*

Result From : \`${m.text}\`

_reply message with \`1a\` to download audio_.
_reply message with \`1v\` to download video_.\n\n`
data.forEach((item, index) => {
caption += `${index + 1}. ${item.title}\n- Duration: ${item.timestamp}\n- Author: ${item.author.name}\n- Publish: ${item.ago}\n\n`;
});
mecha.sendMessage(m.chat, {
text: caption
},
{
quoted: m,
ephemeralExpiration: m.expiration,
messageId: messageId
});
},
main: async (m, { func, mecha, YT }) => {
mecha.ytsearch = mecha.ytsearch || {};
if (mecha.ytsearch[m.sender] && m.budy && m.quoted && m.quoted.fromMe && m.quoted.id.endsWith('YTSEARCH') && !m.isPrefix) {
let command = m.budy.trim();
let data = mecha.ytsearch[m.sender];
// Tambahin logika untuk ambil audio/video
let index = parseInt(command) - 1; // ambil index dari command
if (index >= 0 && index < data.search.length) {
if (command.endsWith('a')) {
// Logika untuk download audio
mecha.sendReact(m.chat, '🕒', m.key)
const result = await YT.detail(data.search[index].url)
if (!result.status) return m.reply(result.message)
let caption = `乂  *YOUTUBE DOWNLOADER MP3*\n`
caption += `\n◦ VideoId : ${result.id}`
caption += `\n◦ Title : ${result.title}`
caption += `\n◦ Duration : ${result.duration}`
caption += `\n◦ URL Video : ${result.url}`
caption += `\n◦ Key : ${result.access}`
caption += `\n\nPlease wait, the audio file is being sent...`
mecha.sendMessageModify(m.chat, caption, m, {
largeThumb: true,
thumbnail: await func.fetchBuffer(result.thumbnail)
}).then(async () => {
let audio = await YT.media('audio', '128', result.access);
if (!audio.status) return m.reply(audio.message);
mecha.sendMessage(m.chat, {
audio: {
url: audio.url
},
mimetype: 'audio/mpeg', 
}, {quoted: m, ephemeralExpiration: m.expiration})
})
} else if (command.endsWith('v')) {
// Logika untuk download video
mecha.sendReact(m.chat, '🕒', m.key)
const result = await YT.detail(data.search[index].url)
if (!result.status) return m.reply(result.message)
let caption = `乂  *YOUTUBE DOWNLOADER MP4*\n`
caption += `\n◦ VideoId : ${result.id}`
caption += `\n◦ Title : ${result.title}`
caption += `\n◦ Duration : ${result.duration}`
caption += `\n◦ URL Video : ${result.url}`
caption += `\n◦ Key : ${result.access}`
caption += `\n\nPlease wait, the video file is being sent...`
mecha.sendMessageModify(m.chat, caption, m, {
largeThumb: true,
thumbnail: await func.fetchBuffer(result.thumbnail)
}).then(async () => {
let video = await YT.media('video', '720', result.access);
if (!video.status) return m.reply(video.message);
mecha.sendMessage(m.chat, {
video: {
url: video.url
},
mimetype: 'video/mp4',
}, {quoted: m, ephemeralExpiration: m.expiration})
})
} else {
return m.reply('Command tidak valid!');
}
} else {
return m.reply('Index tidak valid!');
}
}
},
restrict: true,
limit: 3
}