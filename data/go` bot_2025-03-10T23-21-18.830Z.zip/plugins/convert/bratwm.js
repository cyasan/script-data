let fetch = require("node-fetch"),
  fs = require("fs"),
  path = require("path"),
  axios = require("axios"),
  execSync = require("child_process").execSync;

async function bratGIF(text) {
  let words = text.split(" "),
    mediaDir = path.resolve("media"),
    frames = [];

  if (!fs.existsSync(mediaDir)) fs.mkdirSync(mediaDir);

  for (let i = 0; i < words.length; i++) {
    let phrase = words.slice(0, i + 1).join(" ");
    let response = await axios
      .get("https://siputzx-bart.hf.space/?q=" + encodeURIComponent(phrase), { responseType: "arraybuffer" })
      .catch(e => e.response);
    let filePath = path.join(mediaDir, `frame${i}.mp4`);
    fs.writeFileSync(filePath, response.data);
    frames.push(filePath);
  }

  let fileListPath = path.join(mediaDir, "filelist.txt"),
    fileContent = "";

  for (let i = 0; i < frames.length; i++) fileContent += `file '${frames[i]}'\n` + `duration 0.5\n`;

  fileContent += `file '${frames[frames.length - 1]}'\n` + `duration 2\n`;
  fs.writeFileSync(fileListPath, fileContent);

  let outputFilePath = path.join(mediaDir, "output.mp4");
  execSync(`ffmpeg -y -f concat -safe 0 -i ${fileListPath} -vf "fps=30" -c:v libx264 -preset ultrafast -pix_fmt yuv420p ${outputFilePath}`);

  frames.forEach(file => fs.existsSync(file) && fs.unlinkSync(file));
  if (fs.existsSync(fileListPath)) fs.unlinkSync(fileListPath);

  return outputFilePath;
}

exports.run = {
  usage: ["bratwm"], // Mengubah command menjadi bratwm
  use: "text|packname|author",
  category: "convert",
  async: async (m, { func, mecha, packname, author }) => {
    let isGif = false, // Hapus bratgif, hanya bratwm
      maxLength = 150,
      textInput = m.text.split("|"),
      text = textInput[0]?.trim(),
      userPackname = textInput[1]?.trim() || packname,
      userAuthor = textInput[2]?.trim() || author;

    if (!text) return m.reply(func.example(m.cmd, "hai|lexy|md"));
    if (text.length > maxLength) return m.reply(`Maksimal ${maxLength} karakter!`);

    mecha.sendReact(m.chat, "🕒", m.key);

    try {
      let media = `https://brat.caliphdev.com/api/brat?text=${encodeURIComponent(text)}`;

      mecha.sendSticker(m.chat, media, m, {
        packname: userPackname,
        author: userAuthor,
        expiration: m.expiration
      });
    } catch (err) {
      mecha.reply(m.chat, `Terjadi kesalahan saat membuat stiker.\n- ${err.message}`, m, { expiration: m.expiration });
    }
  },
  limit: true,
  premium: true,
  location: "plugins/convert/brat.js"
};