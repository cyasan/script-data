exports.run = {
  usage: ['stickermeta'],
  hidden: ['smeta', 'anticolong'],
  use: 'reply image/video',
  category: 'convert',
  async: async (m, { mecha, quoted, packname, author }) => {
    try {
      if (!quoted) {
        return mecha.sendMessage(m.chat, { 
          text: `Harap reply stiker, gambar, atau video dengan caption ${m.cmd}` 
        }, { quoted: m });
      }

      // Cek tipe file yang di-reply
      if (/image\/(jpe?g|png)/.test(quoted.mime)) {
        let media = await quoted.download();
        if (!media) {
          return mecha.sendMessage(m.chat, { text: global.mess.wrong }, { quoted: m });
        }
        return await mecha.sendSticker(m.chat, media, m, {
          packname: packname,
          author: author,
          avatar: true,
          expiration: m.expiration,
        });
      } else if (/video/.test(quoted.mime)) {
        if (quoted.seconds > 9) {
          return mecha.sendMessage(m.chat, { 
            text: 'Durasi maksimal video adalah 9 detik.' 
          }, { quoted: m });
        }
        mecha.sendReact(m.chat, '🕒', m.key);
        let media = await quoted.download();
        if (!media) {
          return mecha.sendMessage(m.chat, { text: global.mess.wrong }, { quoted: m });
        }
        return await mecha.sendSticker(m.chat, media, m, {
          packname: packname,
          author: author,
          avatar: true,
          expiration: m.expiration,
        });
      } else if (/webp/.test(quoted.mime)) {
        let media = await quoted.download();
        if (!media) {
          return mecha.sendMessage(m.chat, { text: global.mess.wrong }, { quoted: m });
        }
        return await mecha.sendSticker(m.chat, media, m, {
          packname: packname,
          author: author,
          avatar: true,
          expiration: m.expiration,
        });
      } else {
        return mecha.sendMessage(m.chat, { 
          text: `Kirim atau reply gambar/video dengan caption ${m.cmd}` 
        }, { quoted: m });
      }
    } catch (error) {
      return mecha.sendMessage(m.chat, { 
        text: `Maaf terjadi kesalahan:\n${error}` 
      }, { quoted: m });
    }
  },
  limit: 2,
};