const fetch = require("node-fetch");

exports.run = {
  main: async (m, { func, mecha, isPrem }) => {
    let mentions = [...new Set(m.mentionedJid || [])]; // Hanya ambil yang mention, tanpa quoted

    // Daftar URL stiker
    const stickerUrls = [
      "https://files.catbox.moe/582m94.webp",
      "https://files.catbox.moe/w5eqh6.webp",
      "https://files.catbox.moe/xk7mrn.webp",
      "https://files.catbox.moe/i83vpw.webp",
      "https://files.catbox.moe/ymi9ny.webp",
      "https://files.catbox.moe/e1if95.webp",
      "https://files.catbox.moe/gm9mjj.webp",
      "https://files.catbox.moe/tgzq1v.webp"
    ];

    // Fungsi untuk memilih URL acak
    const getRandomSticker = () => stickerUrls[Math.floor(Math.random() * stickerUrls.length)];

    for (let jid of mentions) {
      if (global.owner.includes(jid)) {
        // Jika user premium, jangan kirim stiker
        if (!isPrem) {
          const stickerUrl = getRandomSticker(); // Ambil stiker acak
          const packname = `Jangan tag ownerku!`;
          const author = m.pushName || "Unknown";

          try {
            // Fetch stiker dari URL yang dipilih
            const response = await fetch(stickerUrl);
            const buffer = await response.buffer();

            if (response.ok) {
              // Kirim stiker ke grup dengan quoted fstatus
              await mecha.sendSticker(
                m.chat,
                buffer,
                m,
                {
                  packname: packname,
                  author: author,
                  avatar: true,
                },
                { quoted: m }
              );
            } else {
              throw new Error("Gagal mengunduh stiker dari URL.");
            }
          } catch (error) {
            console.error(error);
            await mecha.sendMessage(
              m.chat,
              {
                text: "Maaf, tidak bisa mengirim stiker sekarang.",
              },
              { quoted: m }
            );
          }
        }

        // Kirim pesan ke owner dengan forwarded score 99999 dan meng-reply pesan user
        const teks = `*Someone mentioned you.*\n\n- *User*: @${m.sender.split('@')[0]}\n- *Message*: ${m.text || "Tidak ada teks."}`;
        await mecha.sendMessage(
          global.owner,
          {
            text: teks,
            contextInfo: { 
              mentionedJid: [m.sender, global.owner], 
              forwardingScore: 99999, // Tambahkan forwarded score
              isForwarded: true // Tandai sebagai pesan diteruskan
            },
            ephemeralExpiration: m.expiration, // Pesan tidak hilang
          },
          { quoted: m } // Reply ke pesan user
        );

        break; // Hentikan iterasi setelah menemukan mention ke owner
      }
    }
  },
  group: true,
};