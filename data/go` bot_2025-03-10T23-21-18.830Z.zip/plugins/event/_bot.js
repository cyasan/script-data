exports.run = {
    main: async (m, { mecha }) => {
        let mentions = [...new Set(m.mentionedJid || [])]; // Hanya ambil yang mention, tanpa quoted

        // Cek apakah ada yang mention bot (misalnya, bot menggunakan nomor sendiri)
        for (let jid of mentions) {
            if (jid === mecha.user.jid) {
                // Kirim pesan sebagai forward dengan mention pengirim
                await mecha.sendMessage(
                    m.chat,
                    {
                        forward: {
                            key: { remoteJid: m.chat, fromMe: false },
                            message: {
                                extendedTextMessage: {
                                    text: `Hallo! @${m.sender.split('@')[0]}\nAda yang bisa Lexy bantu?`,
                                },
                            },
                        },
                        contextInfo: {
                            forwardingScore: 99999,
                            isForwarded: true,
                            mentionedJid: [m.sender], // Mention pengirim pesan
                        },
                    },
                    { quoted: m }
                );
                break; // Hentikan iterasi setelah menemukan mention ke bot
            }
        }
    },
    group: true,
};