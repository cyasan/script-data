const cron = require('node-cron');
let resetLimit = true;

exports.run = {
  main: async (m, { func, mecha, setting, errorMessage }) => {
    try {
      /* FUNCTION RESET LIMIT USER */
      cron.schedule('00 00 * * *', async () => {
        let resetedUsers = [];

        Object.values(global.db.users).forEach((user, index) => {
          if (user.limit < setting.limit) {
            let oldLimit = user.limit;
            user.limit = user.premium ? 1000 : setting.limit;
            resetedUsers.push(`${index + 1}. Nomor User: +${user.number} : ${oldLimit} => ${user.limit}`);
          }
        });

        Object.entries(global.db.statistic).forEach(([_, prop]) => prop.hittoday = 0);

        if (resetLimit === true) {
          resetLimit = false;
          setting.lastreset = Date.now();

          // Fetch peserta grup
          let groupMetadata = await mecha.groupMetadata(m.chat);
          let participants = groupMetadata.participants.map(p => p.id); // Ambil semua ID anggota

          mecha.sendMessage('120363385221000216@g.us', { 
            text: 'Users Limit Reseted.', 
            mentions: participants, // Mention tersembunyi
          }, { quoted: func.fstatus("System Notice"), ephemeralExpiration: m.expiration });

          if (resetedUsers.length > 0) {
            let ownerJid = global.owner || '6283878301449@s.whatsapp.net';
            let reportText = `*Limit Reseted.*\n\n${resetedUsers.join("\n")}`;

            mecha.sendMessage(ownerJid, { text: reportText });
          }
        }
      }, { scheduled: true, timezone: 'Asia/Jakarta' });

    } catch (e) {
      return errorMessage(e);
    }
  },
  group: true
};