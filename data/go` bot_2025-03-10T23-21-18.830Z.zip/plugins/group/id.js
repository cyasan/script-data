const PhoneNum = require("awesome-phonenumber");
const axios = require("axios");
const moment = require("moment-timezone");

// Daftar zona waktu berdasarkan kode negara (bisa ditambahkan lebih banyak)
const countryTimezones = {
    US: "America/New_York",
    ID: "Asia/Jakarta",
    MY: "Asia/Kuala_Lumpur",
    IN: "Asia/Kolkata",
    GB: "Europe/London",
    FR: "Europe/Paris",
    DE: "Europe/Berlin",
    CN: "Asia/Shanghai",
    JP: "Asia/Tokyo",
    BR: "America/Sao_Paulo",
    RU: "Europe/Moscow",
    AU: "Australia/Sydney",
    PK: "Asia/Karachi",
    SA: "Asia/Riyadh"
};

exports.run = {
    usage: ["checkcountry"],
    hidden: ["membercountry", "idcek"],
    use: 'mention or reply',
    category: "group",
    async: async (m, { mecha }) => {
        let target;

        // Cek apakah pengguna mereply pesan seseorang
        if (m.quoted) {
            target = m.quoted.sender;
        }
        // Cek apakah pengguna mention seseorang
        else if (Array.isArray(m.mentions) && m.mentions.length > 0) {
            target = m.mentions[0];
        }
        // Alternatif lain jika mention tidak terbaca langsung
        else if (m.message?.extendedTextMessage?.contextInfo?.mentionedJid?.length > 0) {
            target = m.message.extendedTextMessage.contextInfo.mentionedJid[0];
        }
        // Jika tidak ada mention atau reply, tampilkan peringatan
        else {
            return mecha.sendMessage(m.chat, { 
                text: `Reply atau mention seseorang.\n\n*Contoh:* ${m.prefix + m.command} @${m.sender.split('@')[0]}`, 
                contextInfo: { mentionedJid: [m.sender] }
            }, { quoted: m });
        }

        // Mendapatkan nama pengguna
        let targetName = await mecha.getName(target) || "Unknown";

        let rawNumber = target.replace("@s.whatsapp.net", ""); // Ambil nomor tanpa domain
        let phoneNumber = new PhoneNum(`+${rawNumber}`);
        let formattedNumber = phoneNumber.getNumber("international"); // Format nomor menjadi +Kode NNN-NNNN-NNNN
        let regionCode = phoneNumber.getRegionCode();
        let regionNames = new Intl.DisplayNames(["id"], { type: "region" });
        let country = regionCode ? regionNames.of(regionCode) : "Unknown";
        let flag = regionCode ? getCountryFlag(regionCode) : "🏳"; // Default: bendera putih jika tidak diketahui

        // Mendapatkan zona waktu berdasarkan kode negara
        let timezone = countryTimezones[regionCode] || "UTC";
        let localTime = moment().tz(timezone).format("HH:mm:ss");
        let localDate = moment().tz(timezone).format("dddd, DD MMMM YYYY"); // Format Hari, Tanggal Bulan Tahun

        // Mencari foto negara (menggunakan Wikimedia API)
        let countryImage = await getCountryImage(country);

        let caption = `乂 *MEMBER COUNTRY CHECK*\n\n`;
        caption += `◦ *Nama*: ${targetName}\n`;
        caption += `◦ *Nomor HP*: ${formattedNumber}\n`;
        caption += `◦ *Negara*: ${flag} *${country}*\n`;
        caption += `◦ *Waktu Setempat*: ${localTime} (${timezone})\n`;
        caption += `◦ *Hari/Tanggal*: ${localDate}\n`;

        return mecha.sendMessage(m.chat, { 
            text: caption, 
            mentions: [target],
            contextInfo: {
                externalAdReply: {
                    title: `Nama: ${targetName}`,
                    body: `Negara: ${country}`,
                    mediaType: 1,
                    thumbnailUrl: countryImage,
                    mediaUrl: countryImage,
                    sourceUrl: `https://www.google.com/search?q=${encodeURIComponent(country)}`
                }
            }
        }, { quoted: m });
    },
    group: true,
};

// Fungsi untuk mendapatkan emoji bendera dari kode negara
function getCountryFlag(regionCode) {
    return regionCode
        .toUpperCase()
        .split("")
        .map((char) => String.fromCodePoint(0x1F1E6 + char.charCodeAt(0) - 65))
        .join("");
}

// Fungsi untuk mencari gambar negara dari Wikimedia API
async function getCountryImage(countryName) {
    try {
        let response = await axios.get(`https://en.wikipedia.org/w/api.php`, {
            params: {
                action: "query",
                format: "json",
                prop: "pageimages",
                piprop: "original",
                titles: countryName,
                origin: "*"
            }
        });

        let pages = response.data.query.pages;
        let pageId = Object.keys(pages)[0];

        if (pages[pageId].original) {
            return pages[pageId].original.source; // URL gambar negara
        }
    } catch (error) {
        console.error("Gagal mendapatkan gambar negara:", error);
    }

    return "https://upload.wikimedia.org/wikipedia/commons/a/ac/No_image_available.svg"; // Gambar default jika gagal
}