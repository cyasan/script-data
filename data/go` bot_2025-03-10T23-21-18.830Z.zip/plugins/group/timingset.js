exports.run = {
    usage: ['timingset'],
    hidden: ['timing-set'],
    use: '<opsi> <event> <time>',
    category: 'admin tools',
    async: async (m, {
        func,
        mecha,
        groups
    }) => {
        if (groups.timing && Array.isArray(groups.timing)) {
            const [value, ...params] = m.text.split(' ');
            switch (value) {
                case 'check':
                case 'cek': {
                    let events = (event) => {
                        let data = groups.timing.find(item => item.event === event);
                        return data ? `- *Current status*: ${data.status ? '✅' : '❌'}
- *Time*: ${data.time} WIB
- *Text*: ${data.text}\n` : ''
                    };
                    let caption = `*List Timing Saat Ini* :
1. \`maghrib time\`
${events('maghrib_time')}
2. \`maghrib over\`
${events('maghrib_over')}
3. \`notice sleeping time\`
${events('notice_sleeping_time')}
4. \`sleeping time\`
${events('sleeping_time')}
5. \`morning time\`
${events('morning_time')}`
                    mecha.reply(m.chat, caption, m, {
                        expiration: m.expiration
                    })
                }
                break
                case 'time': {
                    if (params.length < 2) return m.reply(isValidFormat(m.cmd))
                    const [event, time] = params;
                    if (!(event && time)) return m.reply(isValidFormat(m.cmd))
                    if (time.split(':').length !== 2) return m.reply(isValidFormat(m.cmd))
                    if (!isValidTime(time)) return m.reply(`Format waktu salah! gunakan format jam \`00-23\` dan format menit \`00-60\``)
                    const [hour, minute] = time.split(':');
                    let events = {
                        '1': 'maghrib_time',
                        '2': 'maghrib_over',
                        '3': 'notice_sleeping_time',
                        '4': 'sleeping_time',
                        '5': 'morning_time'
                    } [event];
                    if (!['1', '2', '3', '4', '5'].includes(event)) return m.reply(isValidFormat(m.cmd));
                    let timingData = groups.timing.find(item => item.event === events);
                    timingData.time = time;
                    mecha.reply(m.chat, `Costum \`time\` automatically pada \`${events.replace(/[^a-zA-Z]/gi, ' ')}\` berhasil diubah menjadi pukul ${time} WIB.`, m, {
                        expiration: m.expiration
                    })
                }
                break
                case 'status': {
                    if (params.length < 2) return m.reply(isValidFormat(m.cmd))
                    const [event, state] = params;
                    if (!(event && state)) return m.reply(isValidFormat(m.cmd))
                    let events = {
                        '1': 'maghrib_time',
                        '2': 'maghrib_over',
                        '3': 'notice_sleeping_time',
                        '4': 'sleeping_time',
                        '5': 'morning_time'
                    } [event];
                    if (!['1', '2', '3', '4', '5'].includes(event)) return m.reply(isValidFormat(m.cmd));
                    if (!['on', 'off'].includes(state)) return m.reply(`${func.example(m.cmd, 'on / off')}`)
                    let status = state === 'on' ? true : false;
                    let timingData = groups.timing.find(item => item.event === events);
                    timingData.status = status;
                    mecha.reply(m.chat, `Costum \`status\` automatically pada \`${events.replace(/[^a-zA-Z]/gi, ' ')}\` berhasil diubah menjadi ${status ? 'active' : 'non-active'}`, m, {
                        expiration: m.expiration
                    })
                }
                break
                case 'text': {
                    if (params.length < 2) return m.reply(isValidFormat(m.cmd))
                    const [event, ...caption] = params;
                    if (!(event && caption)) return m.reply(isValidFormat(m.cmd))
                    let events = {
                        '1': 'maghrib_time',
                        '2': 'maghrib_over',
                        '3': 'notice_sleeping_time',
                        '4': 'sleeping_time',
                        '5': 'morning_time'
                    } [event];
                    if (!['1', '2', '3', '4', '5'].includes(event)) return m.reply(isValidFormat(m.cmd));
                    const captionString = caption.join(' ');
                    let timingData = groups.timing.find(item => item.event === events);
                    timingData.text = captionString;
                    mecha.reply(m.chat, `Costum \`text\` automatically pada \`${events.replace(/[^a-zA-Z]/gi, ' ')}\` berhasil diubah menjadi “${captionString}“`, m, {
                        expiration: m.expiration
                    })
                }
                break
                default: {
                    m.reply(isValidFormat(m.cmd))
                }
            }
        } else m.reply('Maaf grup ini belum terdaftar costum automatically.')
    },
    admin: true,
    group: true
}

function isValidFormat(command) {
    return `Invalid format!

*List Options* :
1. \`time\`
*Example*: _${command} time 1 17:30_
*Desc*: maka waktu pada *maghrib time* akan di setting menjadi 17:30.

2. \`status\`
*Example*: _${command} status 1 off_
*Desc*: maka status pada *maghrib time* akan di matikan.

3. \`text\`
*Example*: _${command} text 1 minimal mandi_
*Desc*: maka text pada *maghrib time* akan di ubah menjadi “minimal mandi“.

4. \`check\`
*Example*: _${command} check_
*Desc*: maka akan menampilkan costum timingset saat ini.`
}

function isValidTime(time) {
    const [hours, minutes] = time.split(':').map(Number);
    return (hours >= 0 && hours <= 23 && minutes >= 0 && minutes <= 60);
}