exports.run = {
usage: ['spamtag'],
use: 'mention or reply',
category: 'group',
async: async (m, { func, mecha, froms }) => {
let amount = 10;
if (!(froms || '').replace(/[^0-9]/gi, '')) return m.reply('Mention or reply chat target.')
for (let i = 0; i < amount; i++) {
mecha.sendMessage(m.chat, {
text: `@${froms.split('@')[0]}`,
mentions: [froms]
}, {ephemeralExpiration: m.expiration})
await func.delay(1000)
}
},
group: true,
premium: true
}