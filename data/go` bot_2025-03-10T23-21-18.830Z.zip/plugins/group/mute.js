exports.run = {
  usage: ['mute', 'unmute'],
  category: 'group',
  async: async (m, { mecha, groups }) => {
    try {
      if (m.command === 'mute') {
        if (groups.mute) {
          await mecha.sendMessage(m.chat, { text: 'This group has been muted previously.' }, { quoted: m });
          return;
        }
        groups.mute = true;
        await mecha.sendReact(m.chat, '✅', m.key);
      } else if (m.command === 'unmute') {
        if (!groups.mute) {
          await mecha.sendMessage(m.chat, { text: 'This group has been unmuted previously.' }, { quoted: m });
          return;
        }
        groups.mute = false;
        await mecha.sendReact(m.chat, '✅', m.key);
      }
    } catch (error) {
      console.error("Error during mute/unmute:", error);
      // Consider adding a fallback message or reaction in case of error.
    }
  },
  admin: true,
  group: true
};