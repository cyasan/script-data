exports.run = {
  usage: ['linkgroup'],
  hidden: ['linkgrup', 'linkgc'],
  category: 'group',
  async: async (m, { func, mecha }) => {
    try {
      // Mendapatkan metadata grup
      let groupMetadata = await mecha.groupMetadata(m.chat);
      let groupName = groupMetadata.subject; // Nama grup
      let groupId = global.db.groups[m.chat]?.jid || m.chat; // ID grup
      let inviteCode = await mecha.groupInviteCode(m.chat); // Kode undangan grup
      let groupLink = 'https://chat.whatsapp.com/' + inviteCode; // Link grup

      // Format pesan
      let response = `${groupName}\n\n- ID: ${groupId}\n- Link grup: ${groupLink}`;

      // Mengirim pesan menggunakan mecha
      await mecha.sendMessage(m.chat, { text: response }, { quoted: m });
    } catch (e) {
      // Menangani error dan mengirimkan pesan kesalahan
      await mecha.sendMessage(m.chat, { text: `Error: ${func.jsonFormat(e)}` }, { quoted: m });
    }
  },
  group: true,
  botAdmin: true
};