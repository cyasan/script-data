const axios = require("axios");

exports.run = {
  usage: ['jadwalsholat'],
  category: 'islamic',
  use: 'nama kota',
  async: async (m, { func, mecha }) => {
    if (!m.text) return mecha.reply(m.chat, func.example(m.cmd, 'Jakarta'), m);

    mecha.sendReact(m.chat, '🕒', m.key); // Tampilkan reaksi loading

    try {
      const url = `https://api.myquran.com/v2/sholat/kota/cari/${encodeURIComponent(m.text)}`;
      let { data } = await axios.get(url);

      if (data.status !== true || data.data.length === 0) {
        return mecha.reply(m.chat, "Kota tidak ditemukan. Coba masukkan nama kota yang lebih spesifik!", m);
      }

      let cityId = data.data[0].id; // Ambil ID kota pertama yang cocok
      let prayerUrl = `https://api.myquran.com/v2/sholat/jadwal/${cityId}/${new Date().getFullYear()}/${new Date().getMonth() + 1}/${new Date().getDate()}`;
      let { data: prayerData } = await axios.get(prayerUrl);

      if (!prayerData.status) {
        return mecha.reply(m.chat, "Gagal mengambil jadwal sholat.", m);
      }

      let jadwal = prayerData.data.jadwal;
      let txt = `乂 *JADWAL SHOLAT - ${prayerData.data.lokasi.toUpperCase()}*\n\n`;
      txt += `Tanggal: ${jadwal.tanggal}\n`;
      txt += `- Subuh: ${jadwal.subuh}\n`;
      txt += `- Dzuhur: ${jadwal.dzuhur}\n`;
      txt += `- Ashar: ${jadwal.ashar}\n`;
      txt += `- Maghrib: ${jadwal.maghrib}\n`;
      txt += `- Isya: ${jadwal.isya}\n\n`;
      txt += `_Data dari API MyQuran_`;

      mecha.reply(m.chat, txt, m);
      mecha.sendReact(m.chat, '✅', m.key); // Tampilkan reaksi sukses
    } catch (err) {
      console.error(err);
      mecha.reply(m.chat, "Gagal mengambil data jadwal sholat. Coba lagi nanti!", m);
    }
  },
};