const fetch = require('node-fetch');

exports.run = {
    usage: ['quotes'],
    hidden: ['quote'],
    category: 'quotes',
    async: async (m, {
        func,
        mecha
    }) => {
        let quotes = await fetch('https://raw.githubusercontent.com/Jabalsurya2105/database/master/data/quotes.json').then(response => response.json())
        let result = quotes.random()
        let caption = `_${result.quotes}_\n`
        caption += `\n_${result.author}_`
        let button = [{
            buttonId: m.cmd,
            buttonText: {
                displayText: 'Next Quotes'
            },
            type: 1
        }]
        mecha.sendMessage(m.chat, {
            text: caption,
            buttons: button,
            footer: 'click button below to next quotes',
            mentions: [m.sender],
            viewOnce: true,
            headerType: 6,
        }, {
            quoted: m,
            ephemeralExpiration: m.expiration
        });
    },
    limit: true
}