const cooldownFree = 1800000; // 30 menit untuk pengguna free
const cooldownPremium = 600000; // 10 menit untuk pengguna premium

exports.run = {
  usage: ['adventure'],
  hidden: ['adv'],
  category: 'rpg',
  async: async (m, { func, mecha }) => {
    let user = global.db.users[m.sender];

    // Cek apakah user ada di database
    if (!user) {
      return mecha.sendMessage(
        m.chat,
        { text: 'User tidak ditemukan di database. Pastikan anda sudah terdaftar!' },
        { quoted: m }
      );
    }

    // Cek stamina
    if (user.stamina < 20) {
      return mecha.sendMessage(
        m.chat,
        { text: `Stamina kamu kurang dari 20. Silakan isi stamina terlebih dahulu dengan command *${m.prefix}heal*.` },
        { quoted: m }
      );
    }

    // Tentukan cooldown berdasarkan status premium
    const cooldown = user.premium ? cooldownPremium : cooldownFree;

    // Cek apakah cooldown masih berlaku
    const lastAdventure = user.lastadventure || 0;
    const timeElapsed = Date.now() - lastAdventure;

    if (timeElapsed < cooldown) {
      const remainingTime = cooldown - timeElapsed;
      return mecha.sendMessage(
        m.chat,
        { text: `Kamu sudah berpetualang, mohon tunggu *${func.msToTime(remainingTime)}* untuk *berpetualang* kembali.` },
        { quoted: m }
      );
    }

    // Perbarui waktu terakhir petualangan dan kurangi stamina
    user.lastadventure = Date.now();
    user.stamina -= 5;

    // Kirim pesan awal
    await mecha.sendMessage(m.chat, { text: "_Petualangan dimulai..._" }, { quoted: m });

    // Tunggu 10 detik sebelum mengirimkan hasil
    await new Promise(resolve => setTimeout(resolve, 10000));

    // Rentang hadiah berdasarkan status premium
    const minRange = user.premium ? 100 : 0;
    const maxRange = user.premium ? 5000 : 200;

    // Hadiah random untuk pengguna
    const rewards = {
      money: Math.floor(Math.random() * (8000 - 2000 + 1)) + 2000,
      exp: Math.floor(Math.random() * (7000 - 1000 + 1)) + 1000,
      plastik: Math.floor(Math.random() * (maxRange - minRange + 1)) + minRange,
      rock: Math.floor(Math.random() * (maxRange - minRange + 1)) + minRange,
      kardus: Math.floor(Math.random() * (maxRange - minRange + 1)) + minRange,
      kaleng: Math.floor(Math.random() * (maxRange - minRange + 1)) + minRange,
      daun: Math.floor(Math.random() * (maxRange - minRange + 1)) + minRange,
      trash: Math.floor(Math.random() * (maxRange - minRange + 1)) + minRange,
      string: Math.floor(Math.random() * (maxRange - minRange + 1)) + minRange
    };

    // Tambahkan hadiah ke user
    user.money += rewards.money;
    user.exp += rewards.exp;
    user.plastik += rewards.plastik;
    user.rock += rewards.rock;
    user.kardus += rewards.kardus;
    user.kaleng += rewards.kaleng;
    user.daun += rewards.daun;
    user.trash += rewards.trash;
    user.string = (user.string || 0) + rewards.string;

    // Kirim pesan hadiah
    let rewardMessage = `乂 *RPG - ADVENTURE*\n\n` +
      `Stamina: ${user.stamina}/100\n` +
      `EXP: ${rewards.exp}\n` +
      `Money: $${rewards.money}\n\n` +
      `Plastik: ${rewards.plastik}\n` +
      `Rock: ${rewards.rock}\n` +
      `Kardus: ${rewards.kardus}\n` +
      `Kaleng: ${rewards.kaleng}\n` +
      `Daun: ${rewards.daun}\n` +
      `Trash: ${rewards.trash}\n` +
      `String: ${rewards.string}`;

    mecha.sendMessage(m.chat, { text: rewardMessage }, { quoted: m });
  },
  restrict: true,
  limit: true,
};