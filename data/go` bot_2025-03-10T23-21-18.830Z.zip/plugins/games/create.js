exports.run = {
  usage: ['create'],
  use: 'item,count',
  category: 'rpg',
  async: async (m, { mecha, users, setting }) => {
    if (!global.db.users) global.db.users = {};
    let user = global.db.users[m.sender];
    if (!user) {
      let teks = 'User tidak ditemukan di database. Pastikan Anda sudah terdaftar!';
      return mecha.sendMessage(m.chat, { text: teks }, { quoted: m });
    }

    // Data premium status
    const isPremium = user.premium || false;

    const items = {
      sword: { materials: { rock: 50, kayu: 100 }, money: 15000 },
      pickaxe: { materials: { rock: 65, kayu: 120 }, money: 15000 },
      bow: { materials: { rock: 55, kayu: 125, string: 80 }, money: 20000 },
      axe: { materials: { rock: 125, kayu: 150 }, money: 15000 },
      armor: { materials: { iron: 10, string: 50 }, money: 20000 },
      fishingrod: { materials: { kayu: 100, string: 60 }, money: 150000 }, // Tambahan item Fishing Rod
      atm: { materials: {}, money: 100000 }, // Item ATM (tanpa bahan, hanya uang)
    };

    const userMoney = user.money || 0;

    const args = m.text.split(/\s+/);
    const itemName = args[0]?.toLowerCase();
    const count = parseInt(args[1], 10) || 1; // Default jumlah adalah 1 jika tidak diberikan

    if (!items[itemName]) {
      const itemList = Object.entries(items)
        .filter(([itemName]) => itemName !== 'atm') // Tidak tampilkan item 'atm' dalam daftar
        .map(([itemName, item]) =>
          `*${itemName.toUpperCase()}*\n` +
          Object.entries(item.materials)
            .map(([mat, qty]) => `  > ${mat} = ${qty}`)
            .join('\n') +
          `\n  > money = ${item.money}`
        )
        .join('\n\n');

      const teks = 
        `Item "${itemName}" tidak ditemukan!\n\n` +
        `乂 *CREATE*\n\n${itemList}\n\n` +
        `> Contoh: ${m.prefix + m.command} sword 1\n> Uang kamu: *$${userMoney}*`;

      return mecha.sendMessage(
        m.chat,
        {
          text: teks,
          contextInfo: {
            externalAdReply: {
              title: 'Daftar Item untuk Dibuat',
              body: 'Silakan pilih item dari daftar di bawah.',
              mediaType: 2,
              thumbnail: null, // Tambahkan thumbnail jika diperlukan
            },
          },
        },
        { quoted: m }
      );
    }

    // Proses pembuatan item ATM (langsung buat tanpa count dan tanpa bahan)
    if (itemName === 'atm') {
      if (user.kuli >= 1) {
        return mecha.sendMessage(m.chat, { text: `Kamu sudah memiliki ATM.` }, { quoted: m });
      }

      if (userMoney < items.atm.money) {
        let teks = 
          `Uang kamu tidak cukup untuk membuat ATM.\n` +
          `> Total uang kamu: *$${userMoney}*\n> Dibutuhkan: *$${items.atm.money}*`;

        return mecha.sendMessage(m.chat, { text: teks }, { quoted: m });
      }

      // Update data user (pengurangan uang dan pembuatan ATM)
      user.money -= items.atm.money;
      user.kuli += 1; // Menambah jumlah ATM yang dimiliki user

      // Menyimpan tanggal pembuatan ATM
      user.atmCreated = new Date().toISOString(); // Menyimpan tanggal dalam format ISO (YYYY-MM-DDTHH:mm:ss.sssZ)

      let teks = `Berhasil membuat ATM!`;
      return mecha.sendMessage(m.chat, { text: teks }, { quoted: m });
    }

    if (count <= 0) {
      let teks = 'Jumlah harus lebih dari 0!';
      return mecha.sendMessage(m.chat, { text: teks }, { quoted: m });
    }

    const foundItem = items[itemName];
    const multiplier = isPremium ? { material: 3, money: 2 } : { material: 1, money: 1 };
    const totalMoneyCost = foundItem.money * count * multiplier.money;

    if (userMoney < totalMoneyCost) {
      let teks = 
        `Uang kamu tidak cukup untuk membuat ${itemName} x${count}.\n` +
        `> Total uang kamu: *$${userMoney}*\n> Dibutuhkan: *$${totalMoneyCost}*`;

      return mecha.sendMessage(m.chat, { text: teks }, { quoted: m });
    }

    for (const [material, qty] of Object.entries(foundItem.materials)) {
      const requiredQty = qty * count * multiplier.material;
      if ((user[material] || 0) < requiredQty) {
        let teks = 
          `Kamu kekurangan bahan *${material}* untuk membuat ${itemName}.\n` +
          `> Dibutuhkan: *${requiredQty}*\n> Kamu punya: *${user[material] || 0}*`;

        return mecha.sendMessage(m.chat, { text: teks }, { quoted: m });
      }
    }

    // Update user data (pengurangan bahan dan uang)
    user.money -= totalMoneyCost;
    for (const [material, qty] of Object.entries(foundItem.materials)) {
      user[material] -= qty * count * multiplier.material;
    }

    // Tambahkan item ke data pengguna
    user[itemName] = (user[itemName] || 0) + count;

    // Menambahkan durabilitas untuk setiap item yang dibuat
    const durability = 100; // Durabilitas default 100 untuk semua item
    if (itemName === 'sword') user.durabilitiesSword += 100 * count;
    if (itemName === 'armor') user.durabilitiesArmor += 100 * count;
    if (itemName === 'bow') user.durabilitiesBow += 100 * count;
    if (itemName === 'axe') user.durabilitiesAxe += 100 * count;
    if (itemName === 'pickaxe') user.durabilitiesPickaxe += 100 * count;
    if (itemName === 'fishingrod') user.durabilitiesFishingrod += 100 * count;

    let teks = `Berhasil membuat *${count} ${itemName.charAt(0).toUpperCase() + itemName.slice(1)}*!`;
    return mecha.sendMessage(m.chat, { text: teks }, { quoted: m });
  },
  restrict: true
};