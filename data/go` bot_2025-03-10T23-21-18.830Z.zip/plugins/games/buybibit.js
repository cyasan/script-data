exports.run = {
    usage: ['buybibit'],
    category: 'rpg',
    async: async (m, { mecha, users }) => {
        let sender = global.db.users[m.sender];
        if (!sender) {
            return mecha.sendMessage(m.chat, { text: 'User tidak ditemukan dalam database. Pastikan Anda sudah terdaftar!' }, { quoted: m });
        }

        const bibitList = [
            { name: 'apel', count: sender.bibitapel, pricePerBibit: 1250 },
            { name: 'anggur', count: sender.bibitanggur, pricePerBibit: 1250 },
            { name: 'mangga', count: sender.bibitmangga, pricePerBibit: 1250 },
            { name: 'jeruk', count: sender.bibitjeruk, pricePerBibit: 1250 },
            { name: 'pisang', count: sender.bibitpisang, pricePerBibit: 1250 },
            { name: 'wortel', count: sender.bibitwortel, pricePerBibit: 1000 },
            { name: 'kentang', count: sender.bibitkentang, pricePerBibit: 1000 },
            { name: 'tomat', count: sender.bibittomat, pricePerBibit: 1000 },
            { name: 'kubis', count: sender.bibitkubis, pricePerBibit: 1000 },
            { name: 'terong', count: sender.bibitterong, pricePerBibit: 1000 },
            { name: 'labu', count: sender.bibitlabu, pricePerBibit: 1000 }
        ];

        let selectedNumber = (m.args[0] || '').replace(/[^0-9]/g, '');
        let optionIndex = Number(selectedNumber) - 1;

        if (!selectedNumber) {
            let options = [
                { title: "1. Beli Bibit Kurang", id: `${m.prefix + m.command} 1` },
                { title: "2. Beli Semua Bibit", id: `${m.prefix + m.command} 2` }
            ];

            let responseMessage = [{
                title: "PILIH OPSI PEMBELIAN BIBIT",
                rows: options
            }];

            let buttonOptions = [["list", "Click Here ⎙", responseMessage]];

            return mecha.sendButton(
                m.chat,
                "BUY - BIBIT",
                "",
                "Silakan pilih opsi pembelian di bawah ini.",
                buttonOptions,
                m
            );
        }

        if (isNaN(optionIndex) || optionIndex < 0 || optionIndex >= 2) {
            return mecha.sendMessage(m.chat, { text: "Nomor opsi tidak valid. Silakan pilih nomor yang tersedia." }, { quoted: m });
        }

        let selectedOption = optionIndex === 0 ? "Beli Bibit Kurang" : "Beli Semua Bibit";

        if (!m.args[1]) {
            let confirmOptions = [
                { title: "YA", id: `${m.prefix + m.command} ${selectedNumber} Y` },
                { title: "TIDAK", id: `${m.prefix + m.command} ${selectedNumber} N` }
            ];

            let confirmMessage = [{
                title: "KONFIRMASI PEMBELIAN",
                rows: confirmOptions
            }];

            let confirmButtons = [["list", "Click Here ⎙", confirmMessage]];

            return mecha.sendButton(
                m.chat,
                "KONFIRMASI PEMBELIAN",
                "Apakah kamu yakin ingin melanjutkan pembelian?",
                `Pilihan: *${selectedOption}*`,
                confirmButtons,
                m
            );
        }

        if (m.args[1] === "N") {
            return mecha.sendMessage(m.chat, { text: "Pembelian dibatalkan." }, { quoted: m });
        }

        // --- PROSES PEMBELIAN SETELAH KONFIRMASI ---
        let totalPrice = 0;
        let purchaseMessage = `Pembelian Berhasil!\n\n`;

        if (optionIndex === 0) {
            for (let bibit of bibitList) {
                if (bibit.count < 100) {
                    let needed = 100 - bibit.count;
                    let price = needed * bibit.pricePerBibit;
                    purchaseMessage += `- bibit ${bibit.name}: +${needed}\n`;
                    totalPrice += price;
                    sender[`bibit${bibit.name}`] += needed;
                }
            }
        } else {
            for (let bibit of bibitList) {
                let needed = 100;
                let price = needed * bibit.pricePerBibit;
                purchaseMessage += `- bibit ${bibit.name}: +${needed}\n`;
                totalPrice += price;
                sender[`bibit${bibit.name}`] += needed;
            }
        }

        if (totalPrice > 0) {
            if (sender.money >= totalPrice) {
                sender.money -= totalPrice;
                purchaseMessage += `\n *Total Harga:* $${totalPrice.toLocaleString('en-US')}`;
                return mecha.sendMessage(m.chat, { text: purchaseMessage }, { quoted: m });
            } else {
                return mecha.sendMessage(m.chat, {
                    text: `Uang kamu tidak cukup!\n\n> Dibutuhkan: $${totalPrice.toLocaleString('en-US')}\n> Uang kamu: $${sender.money.toLocaleString('en-US')}`
                }, { quoted: m });
            }
        } else {
            return mecha.sendMessage(m.chat, { text: 'Semua bibit sudah cukup, tidak ada yang perlu dibeli.' }, { quoted: m });
        }
    }
};