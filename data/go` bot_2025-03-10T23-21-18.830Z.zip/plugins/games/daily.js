const cooldown = 86400000; // 24 hours in milliseconds

exports.run = {
  usage: ['daily'],
  hidden: ['bonus'],
  category: 'rpg',
  async: async (m, { func, mecha, users, setting, froms }) => {
    let user = global.db.users[m.sender];

    // Check if user exists
    if (!user) {
      let teks = 'User tidak ditemukan di database. Pastikan anda sudah terdaftar!';
      return mecha.sendMessage(m.chat, { text: teks }, { quoted: m });
    }

    // Check cooldown
    if (Date.now() - user.lastdaily < cooldown) {
      let teks = `Kamu sudah mengambil bonus harian, mohon tunggu *${func.msToTime(cooldown - (Date.now() - user.lastdaily))}* untuk mengambilnya kembali.`;
      return mecha.sendMessage(m.chat, { text: teks }, { quoted: m });
    }

    // Update cooldown
    user.lastdaily = Date.now();

    // Generate random rewards
    let limitReward = Math.floor(Math.random() * 10) + 1; // 1-10
    let balanceReward = Math.floor(Math.random() * 9000) + 1000; // 1000-10000
    let expReward = Math.floor(Math.random() * 29000) + 1000; // 1000-30000
    let moneyReward = Math.floor(Math.random() * 19000) + 1000; // 1000-20000

    // Update user inventory
    user.limit += limitReward;
    user.balance += balanceReward;
    user.exp += expReward;
    user.money += moneyReward;

    // Reply with results
    let teks = `乂 *RPG - BONUS HARIAN*

+ ${limitReward} Limit
+ ${balanceReward} Balance
+ ${expReward} EXP
+ ${moneyReward} Money

> Bonus harianmu sudah ditambahkan ke inventarimu!`;

    mecha.sendMessage(m.chat, { text: teks }, { quoted: m });
  },
  limit: true,
  restrict: true,
};