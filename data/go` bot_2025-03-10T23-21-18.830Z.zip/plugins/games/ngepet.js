const cooldownFree = 900000; // 15 menit untuk pengguna free
const cooldownPremium = 300000; // 5 menit untuk pengguna premium

exports.run = {
  usage: ['ngepet'],
  category: 'rpg',
  async: async (m, { func, mecha, users }) => {
    let user = global.db.users[m.sender];

    if (!user) {
      return mecha.sendMessage(
        m.chat, 
        { text: 'User tidak ditemukan di database. Pastikan anda sudah terdaftar!' }, 
        { quoted: m }
      );
    }

    const cooldown = user.premium ? cooldownPremium : cooldownFree;

    if (Date.now() - user.lastNgepet < cooldown) {
      const remainingTime = cooldown - (Date.now() - user.lastNgepet);
      return mecha.sendMessage(
        m.chat, 
        { text: `Kamu sudah ngepet, mohon tunggu *${func.msToTime(remainingTime)}* untuk ngepet kembali.` }, 
        { quoted: m }
      );
    }

    user.lastNgepet = Date.now();
    await mecha.sendMessage(
      m.chat, 
      { text: "_Kamu memulai ritual ngepet..._" }, 
      { quoted: m }
    );
    await new Promise(resolve => setTimeout(resolve, 5000));

    const chance = Math.random();
    if (chance < 0.2) {
      const lostMoney = user.premium ? 5000 : 2000;
      const lostExp = user.premium ? 2000 : 1000;
      const lostLimit = user.premium ? 25 : 5;

      user.money = Math.max(0, user.money - lostMoney);
      user.exp = Math.max(0, user.exp - lostExp);
      user.limit = Math.max(0, user.limit - lostLimit);

      return mecha.sendMessage(
        m.chat, 
        { 
          text: `乂 *RPG - NGEPET*\n\nNgepet gagal! Kamu kehilangan:\n` +
          `Money: $${lostMoney}\n` +
          `Exp: ${lostExp}\n` +
          `Limit: ${lostLimit}`
        }, 
        { quoted: m }
      );
    }

    const earnedMoney = user.premium
      ? Math.floor(Math.random() * (50000 - 1000 + 1)) + 1000
      : Math.floor(Math.random() * (5000 - 100 + 1)) + 100;
    const earnedExp = user.premium
      ? Math.floor(Math.random() * (8000 - 100 + 1)) + 100
      : Math.floor(Math.random() * (5000 - 0 + 1));
    const earnedLimit = user.premium ? 50 : 15;

    user.money += earnedMoney;
    user.exp += earnedExp;
    user.limit += earnedLimit;

    return mecha.sendMessage(
      m.chat, 
      { 
        text: `乂 *RPG - NGEPET*\n\nRitual ngepet kamu berhasil dan mendapatkan:\n` +
        `Money: $${earnedMoney}\n` +
        `Exp: ${earnedExp}\n` +
        `Limit: ${earnedLimit}`
      }, 
      { quoted: m }
    );
  },
  restrict: true,
  limit: true,
};