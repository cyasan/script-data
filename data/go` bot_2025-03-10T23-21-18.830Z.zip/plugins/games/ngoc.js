const cooldown = 1800000; // 30 menit dalam milidetik

exports.run = {
  usage: ['ngocok'],
  use: 'mention or reply (optional)',
  category: 'rpg',
  async: async (m, { mecha, users, func, setting }) => {
    let sender = global.db.users[m.sender];

    if (!sender) {
      return mecha.sendMessage(m.chat, { text: 'User tidak ditemukan dalam database. Pastikan Anda sudah terdaftar!' }, { quoted: m });
    }

    // Menangani mention atau reply (target user)
    let who = m.mentionedJid && m.mentionedJid[0] 
      ? m.mentionedJid[0] 
      : (m.quoted && m.quoted.sender ? m.quoted.sender : null);

    // **Jika user tidak mention siapa pun, dia menjaga anak sendirian**
    if (!who) {
      const totalAnak = Math.floor(Math.random() * 250) + 1; // 1 - 2 anak

      // Pastikan sender memiliki properti 'anak'
      if (!sender.anak) sender.anak = 0;

      // Kirim pesan awal
      await mecha.sendMessage(m.chat, { 
        text: `@${m.sender.split('@')[0]} sedang ngocok...`,
        contextInfo: { mentionedJid: [m.sender] } 
      }, { quoted: m });

      // Tunggu 20 detik sebelum mengirimkan hasil
      await new Promise(resolve => setTimeout(resolve, 20000));

      // Tambahkan jumlah anak
      sender.ser += totalAnak;

      return mecha.sendMessage(m.chat, { 
        text: `@${m.sender.split('@')[0]} telah ngocok dan mendapatkan ${totalAnak} sperma.`,
        contextInfo: { mentionedJid: [m.sender] }
      }, { quoted: m });
    }

    // **Jika user mention seseorang, lakukan pengecekan lebih lanjut**
    let targetUser = global.db.users[who];
    if (!targetUser) {
      return mecha.sendMessage(m.chat, { 
        text: 'User yang disebutkan tidak ditemukan dalam database.', 
        contextInfo: { mentionedJid: [who] }
      }, { quoted: m });
    }

    const totalAnak = Math.floor(Math.random() * 500) + 2; // 2 - 5 anak

    // Pastikan sender dan targetUser memiliki properti 'anak'
    if (!sender.anak) sender.anak = 0;
    if (!targetUser.anak) targetUser.anak = 0;

    // Kirim pesan awal
    await mecha.sendMessage(m.chat, { 
      text: `@${m.sender.split('@')[0]} dan @${who.split('@')[0]} sedang ngocok bersama...`,
      contextInfo: { mentionedJid: [m.sender, who] } 
    }, { quoted: m });

    // Tunggu 20 detik sebelum mengirimkan hasil
    await new Promise(resolve => setTimeout(resolve, 20000));

    // Tambahkan jumlah anak
    sender.ser += totalAnak;
    targetUser.ser += totalAnak;

    return mecha.sendMessage(m.chat, { 
      text: `@${m.sender.split('@')[0]} dan @${who.split('@')[0]} telah selesai ngocok dan mendapatkan ${totalAnak} sperma.`,
      contextInfo: { mentionedJid: [m.sender, who] }
    }, { quoted: m });
  },
  limit: true,
};

// Fungsi untuk format cooldown dalam bentuk HH:MM:SS
function formatCooldown(ms) {
  const hours = Math.floor(ms / 3600000);
  const minutes = Math.floor((ms % 3600000) / 60000);
  const seconds = Math.floor((ms % 60000) / 1000);
  return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
}