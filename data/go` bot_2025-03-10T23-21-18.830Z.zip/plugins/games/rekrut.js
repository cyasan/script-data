exports.run = {
  usage: ['rekrut'],
  use: 'user|nomor',
  category: 'rpg',
  async: async (m, { mecha, users, prefix }) => {
    let user = global.db.users[m.sender];
    if (!user) {
      return mecha.sendMessage(m.chat, { text: 'User tidak ditemukan di database. Pastikan Anda sudah terdaftar!' }, { quoted: m });
    }

    // Mengecek apakah pengguna memiliki bangunan
    const ownedBuildings = [
      { name: 'Rumah Sakit', key: 'rumahsakit' },
      { name: 'Restoran', key: 'restoran' },
      { name: 'Sekolah', key: 'sekolah' },
      { name: 'Hotel', key: 'hotel' },
      { name: 'Bengkel', key: 'bengkel' }
    ].filter(building => user[building.key] && user[building.key] > 0); // Filter bangunan yang dimiliki

    if (ownedBuildings.length === 0) {
      return mecha.sendMessage(m.chat, { text: 'Kamu tidak memiliki bangunan, silahkan bangun terlebih dahulu.' }, { quoted: m });
    }

    // Menampilkan bangunan yang dimiliki oleh user
    let buildingList = ownedBuildings.map((building, index) => `${index + 1}. ${building.name}`).join('\n');
    
    // Pesan untuk memilih bangunan yang akan membuka lowongan pegawai
    await mecha.sendMessage(m.chat, {
      text: `乂 REKRUT\n\nPilih bangunan yang akan dibuka untuk menerima pegawai:\n\n${buildingList}\n\nPilih nomor di atas untuk meng-rekrut dengan format:\n${prefix}rekrut @tag|nomor\nContoh:\n${prefix}rekrut @${m.sender.split('@')[0]}|1`
    }, { quoted: m });

    // Mengambil nomor bangunan yang dipilih dari args
    let option = (m.args[1] || '').replace(/[^\d]/g, ''); // Menghapus semua karakter selain angka
    option = parseInt(option);

    if (!option || option < 1 || option > ownedBuildings.length) {
      return;
    }

    const tag = m.args[0].replace('@', ''); // Mengambil username dari tag
    const pegawai = global.db.users[tag];
    if (!pegawai) {
      return mecha.sendMessage(m.chat, { text: `Pengguna ${tag} tidak ditemukan.` }, { quoted: m });
    }

    // Kirim pesan persetujuan ke grup
    await mecha.sendMessage(m.chat, {
      text: `乂 REKRUT\n\n@${m.sender.split('@')[0]} memilih untuk merekrut @${tag} pada bangunan ${ownedBuildings[option - 1].name}. \n\nBalas dengan 'Y' untuk menerima atau 'N' untuk menolak.`,
      contextInfo: {
        mentionedJid: [m.sender, pegawai.jid] // Mention user yang merekrut dan pegawai yang direkrut
      }
    }, { quoted: m });

    // Kirim pesan persetujuan ke pegawai (pribadi)
    await mecha.sendMessage(pegawai.jid, {
      text: `乂 REKRUT\n\n@${m.sender.split('@')[0]} ingin merekrut kamu untuk bekerja di ${ownedBuildings[option - 1].name}. \nBalas dengan 'Y' untuk menerima atau 'N' untuk menolak.`,
      contextInfo: {
        mentionedJid: [m.sender, pegawai.jid] // Mention pengirim dan pegawai
      }
    });

    // Menunggu respons dari pegawai yang direkrut
    mecha.ev.on('messages.upsert', async (msg) => {
      // Memeriksa apakah pesan adalah dari pegawai yang direkrut
      if (msg.messages[0].key.remoteJid === pegawai.jid && msg.messages[0].key.fromMe === false) {
        const response = msg.messages[0].text.trim().toUpperCase();

        if (response === 'Y') {
          // Pegawai menerima tawaran rekrut
          user[ownedBuildings[option - 1].key] = 1; // Mengassign pegawai ke bangunan
          return mecha.sendMessage(m.chat, {
            text: `乂 REKRUT\n\n@${pegawai.jid.split('@')[0]} menerima tawaran rekrut dan sekarang bekerja di ${ownedBuildings[option - 1].name} milik @${m.sender.split('@')[0]}.`,
            contextInfo: {
              mentionedJid: [m.sender, pegawai.jid] // Mention pengguna yang merekrut dan pegawai yang diterima
            }
          }, { quoted: m });
        } else if (response === 'N') {
          // Pegawai menolak tawaran rekrut
          return mecha.sendMessage(m.chat, {
            text: `乂 REKRUT\n\n@${pegawai.jid.split('@')[0]} menolak tawaran rekrut dari @${m.sender.split('@')[0]}.`,
            contextInfo: {
              mentionedJid: [m.sender, pegawai.jid] // Mention pengguna yang merekrut dan pegawai yang menolak
            }
          }, { quoted: m });
        } else {
          // Jika balasan bukan 'Y' atau 'N'
          return mecha.sendMessage(m.chat, {
            text: `乂 REKRUT\n\nBalasan tidak dikenali, silakan balas dengan 'Y' untuk menerima atau 'N' untuk menolak.`,
            contextInfo: {
              mentionedJid: [m.sender, pegawai.jid] // Mention pengguna yang merekrut dan pegawai yang merespons
            }
          }, { quoted: m });
        }
      }
    });
  },

  restrict: true
};