exports.run = {
  usage: ['aquarium'],
  hidden: ['kolam'],
  category: 'rpg',
  async: async (m, { func, mecha, users, setting, froms }) => {
    const user = global.db.users[m.sender];
    const { tongkol = 0, buntal = 0, pausmini = 0, udang = 0, gurita = 0, nila = 0, cumi = 0, langka = 0, kepiting = 0, kerang = 0 } = user;

    const teks = `乂 *AQUARIUM*
    
    🐟 Tongkol = *[ ${tongkol} ]* Ekor Tongkol
    🐡 Buntal = *[ ${buntal} ]* Ekor Buntal
    🐋 Pausmini = *[ ${pausmini} ]* Ekor Pausmini
    🦐 Udang = *[ ${udang} ]* Ekor Udang
    🐙 Gurita = *[ ${gurita} ]* Ekor Gurita
    🐠 Nila = *[ ${nila} ]* Ekor Nila
    🦑 Cumi = *[ ${cumi} ]* Ekor Cumi
    🐳 Langka = *[ ${langka} ]* Ekor Langka
    🦀 Kepiting = *[ ${kepiting} ]* Ekor Kepiting
    🐚 Kerang = *[ ${kerang} ]* Ekor Kerang

> Ketik ${m.prefix}sell item,count untuk menjual hewan.
> Contoh: ${m.prefix}sell buntal 50`;

    mecha.sendMessage(m.chat, { text: teks }, { quoted: m });
  },
  restrict: true
};