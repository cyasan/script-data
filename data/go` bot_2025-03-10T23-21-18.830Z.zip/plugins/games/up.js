const { createCanvas } = require('canvas');

exports.run = {
  usage: ['upgrade'],
  hidden: ['upg'],
  use: 'item count',
  category: 'rpg',
  async: async (m, { mecha, users, setting }) => {
    if (!global.db.users) global.db.users = {};
    let user = global.db.users[m.sender];

    if (!user) {
      return mecha.sendMessage(m.chat, { text: 'User tidak ditemukan di database. Pastikan Anda sudah terdaftar!' }, { quoted: m });
    }

    const args = m.text.split(/\s+/);
    const itemName = args[0]?.toLowerCase();
    const upgradeTimes = parseInt(args[1]?.replace(/x/g, ''), 10) || 1; // Ambil angka dari "1x, 2x, dst."

    // Daftar item yang bisa di-upgrade
    const upgradeableItems = {
      sword: 'durabilitiesSword',
      armor: 'durabilitiesArmor',
      bow: 'durabilitiesBow',
      axe: 'durabilitiesAxe',
      pickaxe: 'durabilitiesPickaxe',
      fishingrod: 'durabilitiesFishingrod'
    };

    if (!upgradeableItems[itemName]) {
      const itemList = Object.keys(upgradeableItems)
        .map((item) => `- *${item}*`)
        .join('\n');

      return mecha.sendMessage(m.chat, { text: `乂 *UPGRADE*\n\nBerikut adalah item yang bisa di-upgrade:\n\n${itemList}\n\n` +
              `> Contoh: ${m.prefix + m.command} sword 2x` }, { quoted: m });
    }

    // Dapatkan properti durability dari user
    const durabilityKey = upgradeableItems[itemName];
    let currentDurability = user[durabilityKey] || 0;
    let money = user.money || 0;

    // **Pengecekan apakah user memiliki item**
    let ownedItems = user.items || {};
    if (!ownedItems[itemName] || ownedItems[itemName] <= 0) {
      return mecha.sendMessage(m.chat, { text: `Kamu tidak memiliki *${itemName}*!` }, { quoted: m });
    }

    if (currentDurability >= 500) {
      return mecha.sendMessage(m.chat, { text: `Durabilitas *${itemName}* sudah mencapai batas maksimal (500). Tidak bisa di-upgrade lebih lanjut!` }, { quoted: m });
    }

    const upgradeCostPerStep = 100000; // Biaya per +5 durability
    const durabilityIncreasePerStep = 5; // Jumlah durability yang bertambah setiap upgrade

    // Maksimal upgrade yang bisa dilakukan agar tidak melebihi 500 durability
    const maxUpgradePossible = Math.min(upgradeTimes, Math.floor((500 - currentDurability) / durabilityIncreasePerStep));

    if (maxUpgradePossible <= 0) {
      return mecha.sendMessage(m.chat, { text: `Durability *${itemName}* sudah mendekati batas maksimal dan tidak bisa di-upgrade lebih lanjut!` }, { quoted: m });
    }

    const totalUpgradeCost = maxUpgradePossible * upgradeCostPerStep;

    if (money < totalUpgradeCost) {
      return mecha.sendMessage(m.chat, { text: `Uang kamu tidak cukup untuk upgrade *${itemName}* ${maxUpgradePossible}x!\n\n` +
              `> Dibutuhkan: *$${totalUpgradeCost}*\n> Uang kamu: *$${money.toLocaleString('en-US')}*` }, { quoted: m });
    }

    // Lakukan upgrade
    user.money -= totalUpgradeCost;
    user[durabilityKey] += durabilityIncreasePerStep * maxUpgradePossible;

    // Buat teks untuk canvas
    let upgradeText = `Durability ${itemName}: ${currentDurability} => ${user[durabilityKey]}`;

    // Buat gambar menggunakan canvas
    const canvas = createCanvas(1280, 720); // Ukuran 16:9
    const ctx = canvas.getContext('2d');

    // Latar belakang hitam
    ctx.fillStyle = '#000';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Teks putih dengan ukuran lebih kecil agar muat
    ctx.fillStyle = '#fff';
    ctx.font = 'bold 70px Arial'; // Ukuran font dikurangi dari 100px ke 60px
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';

    ctx.fillText(upgradeText, canvas.width / 2, canvas.height / 2);

    // Simpan gambar
    let buffer = canvas.toBuffer();

    // Buat caption
    let caption = `乂 *UPGRADE*\n\n` +
                  `Item: ${itemName}\n` +
                  `Harga: $${totalUpgradeCost.toLocaleString('en-US')}\n` +
                  `Sisa uang: $${user.money.toLocaleString('en-US')}`;

    // Kirim pesan gambar
    let msg = await mecha.sendMessage(m.chat, { image: buffer, caption: caption }, { quoted: m });

    // Hapus pesan setelah 10 detik
    setTimeout(() => {
      mecha.sendMessage(m.chat, { delete: msg.key });
    }, 10000);
  },
  restrict: true
};