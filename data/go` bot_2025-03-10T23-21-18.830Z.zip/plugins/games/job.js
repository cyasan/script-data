const cooldownFree = 1800000; // 30 menit untuk pengguna gratis
const cooldownPremium = 600000; // 10 menit untuk pengguna premium

exports.run = {
  usage: ['dokter', 'kuli', 'guru', 'montir', 'ojek', 'kurir', 'petani', 'nelayan', 'polisi', 'tentara', 'pemadam', 'chef', 'seniman'],
  category: 'rpg',
  async: async (m, { func, mecha, users, setting, command }) => {
    let user = global.db.users[m.sender];

    // Cek apakah user ada di database
    if (!user) {
      return mecha.sendMessage(
        m.chat, 
        { text: 'User tidak ditemukan di database. Pastikan anda sudah terdaftar!' }, 
        { quoted: m }
      );
    }

    // Tentukan teks pekerjaan berdasarkan input
    let jobTask;
    if (func.somematch(['dokter'], m.command)) jobTask = 'mengobati pasien';
    else if (func.somematch(['kurir'], m.command)) jobTask = 'mengantar paket';
    else if (func.somematch(['kuli'], m.command)) jobTask = 'bekerja sebagai kuli';
    else if (func.somematch(['guru'], m.command)) jobTask = 'mengajar';
    else if (func.somematch(['montir'], m.command)) jobTask = 'memperbaiki kendaraan';
    else if (func.somematch(['ojek'], m.command)) jobTask = 'ngojek';
    else if (func.somematch(['petani'], m.command)) jobTask = 'menanam dan memanen hasil pertanian';
    else if (func.somematch(['nelayan'], m.command)) jobTask = 'menangkap ikan di laut';
    else if (func.somematch(['polisi'], m.command)) jobTask = 'menjaga keamanan kota';
    else if (func.somematch(['tentara'], m.command)) jobTask = 'melindungi negara dari ancaman';
    else if (func.somematch(['pemadam'], m.command)) jobTask = 'memadamkan kebakaran';
    else if (func.somematch(['chef'], m.command)) jobTask = 'memasak makanan lezat';
    else if (func.somematch(['seniman'], m.command)) jobTask = 'membuat karya seni';
    else return;

    const dbKey = m.command.charAt(0).toUpperCase() + m.command.slice(1); // Capitalize untuk key database

    // Tentukan cooldown berdasarkan status premium
    const cooldown = user.premium ? cooldownPremium : cooldownFree;

    // Cek apakah cooldown masih berlaku
    if (Date.now() - (user[`last${dbKey}`] || 0) < cooldown) {
      const remainingTime = cooldown - (Date.now() - user[`last${dbKey}`]);
      return mecha.sendMessage(
        m.chat, 
        { text: `Kamu baru saja ${jobTask}, mohon tunggu *${func.msToTime(remainingTime)}* untuk ${jobTask} kembali.` }, 
        { quoted: m }
      );
    }

    // Perbarui waktu terakhir pekerjaan
    user[`last${dbKey}`] = Date.now();

    // Kirim pesan sebelum pekerjaan dimulai
    mecha.sendMessage(
      m.chat, 
      { text: `_${jobTask.charAt(0).toUpperCase() + jobTask.slice(1)} dimulai. . ._` }, 
      { quoted: m }
    );

    // Delay 10 detik sebelum hadiah diberikan
    await new Promise(resolve => setTimeout(resolve, 10000)); // Tunggu selama 10 detik

    // Hadiah random untuk pengguna
    const rewards = {
      money: Math.floor(Math.random() * (7000 - 1000 + 1)) + 1000, // Rentang 1000 - 7000
      exp: Math.floor(Math.random() * (5000 - 1000 + 1)) + 1000,   // Rentang 1000 - 5000
      balance: Math.floor(Math.random() * (8000 - 2000 + 1)) + 2000, // Rentang 2000 - 8000
      order: 1, // Menambahkan order +1
    };

    // Menambah hadiah ke user
    user.money += rewards.money;
    user.exp += rewards.exp;
    user.balance += rewards.balance;
    user[`order${dbKey}`] = (user[`order${dbKey}`] || 0) + rewards.order; // Tambahkan ke total pekerjaan

    // Kirim pesan hasil pekerjaan sesuai format
    let jobMessage = `乂 *RPG - ${m.command.toUpperCase()}*\n\n` +
      `Money: $${rewards.money}\n` +
      `EXP: ${rewards.exp}\n` +
      `Balance: $${rewards.balance}\n` +
      `Order: +${rewards.order}`;

    mecha.sendMessage(
      m.chat, 
      { text: jobMessage }, 
      { quoted: m }
    );
  },
  restrict: true,
  limit: true,
};