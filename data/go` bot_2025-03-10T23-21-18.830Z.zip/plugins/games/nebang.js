exports.run = {
  usage: ['nebang'],
  category: 'rpg',
  async: async (m, { func, mecha, users, setting, froms }) => {
    const user = global.db.users[m.sender] || {};

    // Pastikan data default
    user.lastnebang = user.lastnebang || 0;
    user.kayu = user.kayu || 0;
    user.string = user.string || 0;
    user.stamina = user.stamina || 100; // Default stamina
    user.durabilitiesAxe = user.durabilitiesAxe || 0; // Durabilitas Axe
    user.axe = user.axe || 0; // Jumlah Axe

    // Cek stamina
    if (user.stamina < 10) {
      return mecha.sendMessage(m.chat, {
        text: `Stamina kamu kurang dari 10. Silakan isi stamina terlebih dahulu dengan perintah: *${m.prefix}heal*`
      }, { quoted: m });
    }

    // Cek apakah pengguna memiliki Axe dan durabilitasnya
    if (!user.axe || user.axe <= 0 || user.durabilitiesAxe <= 0) {
      return mecha.sendMessage(m.chat, {
        text: `Kamu tidak memiliki *Axe* untuk menebang pohon.\nSilakan buat Axe terlebih dahulu dengan perintah:\n *${m.prefix}create axe 1*`
      }, { quoted: m });
    }

    // Cooldown
    const cooldownFree = 600000; // 10 menit
    const cooldownPremium = 300000; // 5 menit
    const cooldown = user.premium ? cooldownPremium : cooldownFree;

    if (Date.now() - user.lastnebang < cooldown) {
      const remaining = cooldown - (Date.now() - user.lastnebang);
      return mecha.sendMessage(m.chat, {
        text: `Kamu sudah menebang pohon, tunggu *${func.msToTime(remaining)}* lagi untuk menebang kembali!`
      }, { quoted: m });
    }

    // Tandai waktu terakhir menebang
    user.lastnebang = Date.now();

    // Kirim pesan awal
    await mecha.sendMessage(m.chat, {
      text: `_Mulai menebang. . ._`
    }, { quoted: m });

    // Tunggu 10 detik sebelum mengirim hasil
    await new Promise(resolve => setTimeout(resolve, 10000));

    // Hadiah berdasarkan status premium
    const rewards = {
      kayu: Math.floor(Math.random() * (user.premium ? 201 : 101)), // 0-200 (premium), 0-100 (free)
      string: Math.floor(Math.random() * (user.premium ? 101 : 51)), // 0-100 (premium), 0-50 (free)
    };

    // Tambahkan hadiah ke data user
    user.kayu += rewards.kayu;
    user.string += rewards.string;

    // Kurangi stamina dan durabilitas Axe
    user.stamina -= 2; // Misalnya setiap nebang mengurangi stamina 10
    user.durabilitiesAxe -= 5; // Durabilitas Axe berkurang 10

    // Format hasil
    const resultMessage = `
乂 *RPG - NEBANG*

Kamu berhasil menebang pohon dan mendapatkan:
  > *Kayu*: ${rewards.kayu}
  > *String*: ${rewards.string}

Stamina kamu sekarang: *${user.stamina}*
Durabilitas Axe: *${user.durabilitiesAxe}*

> Gunakan *${m.prefix}inventory* untuk melihat koleksi hasil tebanganmu!`;

    // Kirim hasil menebang dengan externalAdReply
    await mecha.sendMessage(m.chat, {
      text: resultMessage,
      contextInfo: {
        externalAdReply: {
          title: 'M E N E B A N G',
          body: global.header,
          thumbnailUrl: 'https://files.catbox.moe/ii9t8t.jpg',
          mediaType: 1,
          sourceUrl: '',
          renderLargerThumbnail: true
        }
      }
    }, { quoted: m });
  },
  limit: true,
  restrict: true,
};