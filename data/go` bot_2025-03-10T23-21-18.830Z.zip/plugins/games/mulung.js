exports.run = {
  usage: ['mulung'],
  category: 'rpg',
  async: async (m, { func, mecha, users, setting, froms }) => {
    let user = global.db.users[m.sender];

    // Cek apakah user ada di database
    if (!user) {
      return m.reply('User tidak ditemukan di database. Pastikan anda sudah terdaftar!');
    }

    // Tentukan cooldown berdasarkan status premium
    const cooldownPremium = 10 * 60 * 1000; // 10 menit
    const cooldownFree = 30 * 60 * 1000; // 30 menit
    const cooldown = user.premium ? cooldownPremium : cooldownFree;

    // Cek apakah cooldown masih berlaku
    if (Date.now() - user.lastmulung < cooldown) {
      const remainingTime = cooldown - (Date.now() - user.lastmulung);

      // Fungsi untuk mengubah ms ke format HH:MM:SS
      function msToTime(duration) {
        let seconds = Math.floor((duration / 1000) % 60),
            minutes = Math.floor((duration / (1000 * 60)) % 60),
            hours = Math.floor((duration / (1000 * 60 * 60)) % 24);

        return [hours, minutes, seconds]
          .map(v => String(v).padStart(2, '0')) // Menambahkan leading zero
          .join(':'); // Format HH:MM:SS
      }

      return mecha.sendMessage(m.chat, { text: `Kamu baru saja mulung, tunggu ${msToTime(remainingTime)} untuk bisa mulung lagi.`}, { quoted: m});
    }

    // Tandai waktu terakhir mulung
    user.lastmulung = Date.now();

    // Generate hadiah secara acak
    let items = ['trash', 'kaleng', 'kardus', 'plastik'];
    let rewardsFree = items.map(item => Math.floor(Math.random() * 500) + 1);

    if (user.premium) {
      let premiumItems = ['daun', 'string', 'kayu', 'rock'];
      items = items.concat(premiumItems);
      rewardsFree = rewardsFree.concat(premiumItems.map(item => Math.floor(Math.random() * 500) + 1));
    }

    // Format hasil mulung
    let hsl = `乂 *RPG - MULUNG*\n\nKamu mendapatkan:\n` +
      items.map((item, idx) => `- ${item.charAt(0).toUpperCase() + item.slice(1)} = ${rewardsFree[idx]}`).join('\n');

    // Tambahkan hasil mulung ke data user
    items.forEach((item, idx) => {
      if (!user[item]) user[item] = 0;
      user[item] += rewardsFree[idx];
    });

    // Kirim hasil mulung ke pengguna
    mecha.reply(m.chat, hsl, m);
  },
  limit: true,
};