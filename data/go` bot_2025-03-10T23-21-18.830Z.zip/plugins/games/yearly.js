const cooldown = 31536000000; // 1 year in milliseconds (365 days)

exports.run = {
  usage: ['yearly'],
  hidden: ['bonusyearly'],
  category: 'rpg',
  async: async (m, { func, mecha, users, setting, froms }) => {
    let user = global.db.users[m.sender];

    // Check if user exists
    if (!user) {
      let teks = 'User tidak ditemukan di database. Pastikan anda sudah terdaftar!';
      return mecha.sendMessage(m.chat, { text: teks }, { quoted: m });
    }

    // Check cooldown
    if (Date.now() - user.lastyearly < cooldown) {
      let teks = `Kamu sudah mengambil bonus tahunan, mohon tunggu *${func.msToTime(cooldown - (Date.now() - user.lastyearly))}* untuk mengambilnya kembali.`;
      return mecha.sendMessage(m.chat, { text: teks }, { quoted: m });
    }

    // Update cooldown
    user.lastyearly = Date.now();

    // Define rewards, 5x the weekly rewards
    let limitReward = 20 * 5; // Limit is fixed to 100
    let balanceReward = (Math.floor(Math.random() * (50000 - 20000 + 1)) + 20000) * 5; // 5x the weekly range
    let expReward = (Math.floor(Math.random() * (10000 - 5000 + 1)) + 5000) * 5; // 5x the weekly range
    let moneyReward = (Math.floor(Math.random() * (200000 - 100000 + 1)) + 100000) * 5; // 5x the weekly range

    // Update user inventory
    user.limit += limitReward;
    user.balance += balanceReward;
    user.exp += expReward;
    user.money += moneyReward;

    // Reply with results
    let teks = `乂 *RPG - BONUS TAHUNAN*

+ ${limitReward} Limit
+ ${balanceReward} Balance
+ ${expReward} EXP
+ ${moneyReward} Money

> Bonus tahunanmu sudah ditambahkan ke inventarimu!`;

    mecha.sendMessage(m.chat, { text: teks }, { quoted: m });
  },
  limit: true,
  restrict: true,
};