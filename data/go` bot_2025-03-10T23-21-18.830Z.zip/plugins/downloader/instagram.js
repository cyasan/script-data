exports.run = {
    usage: ['instagram'],
    hidden: ['igdl', 'ig'],
    use: 'link instagram',
    category: 'downloader',
    async: async (m, { func, mecha }) => {
        if (!m.text) {
            return m.reply(func.example(m.cmd, 'https://www.instagram.com/reel/DBLzn9RvK_K/?igsh=MTh3YTByMjhnZXJ0aA=='));
        }

        if (!m.args[0].match(/https:\/\/www.instagram.com\/(p|reel|tv)/gi)) {
            return mecha.sendMessage(m.chat, {
                text: `*Link salah!* Perintah ini untuk mengunduh postingan IG (reel, post, atau TV), bukan untuk highlight/story!\n\nContoh:\n${m.cmd} https://www.instagram.com/reel/DBLzn9RvK_K/?igsh=MTh3YTByMjhnZXJ0aA==`
            }, { quoted: m });
        }

        await mecha.sendReact(m.chat, '🕒', m.key);

        try {
            const result = await func.fetchJson(`https://api.siputzx.my.id/api/d/igdl?url=${m.args[0]}`);

            if (!result || !result.status) {
                return m.reply('Terjadi kesalahan saat mengambil data dari API.');
            }

            if (!result.data || !Array.isArray(result.data) || result.data.length < 1) {
                return m.reply('Tidak ada media yang ditemukan.');
            }

            // Hilangkan URL yang duplikat dengan Set()
            let uniqueMedia = [...new Set(result.data.map(item => item.url))];

            for (let [index, url] of uniqueMedia.entries()) {
                let message = index === 0 ? m : null;
                await mecha.sendMedia(m.chat, url, message, {
                    caption: uniqueMedia.length === 1 ? global.mess.ok : '',
                    expiration: m.expiration
                });
            }

            await mecha.sendReact(m.chat, '✅', m.key);

        } catch (error) {
            console.error(error);
            return m.reply('Terjadi kesalahan saat memproses permintaan.');
        }
    },
    premium: false,
    limit: 5
};