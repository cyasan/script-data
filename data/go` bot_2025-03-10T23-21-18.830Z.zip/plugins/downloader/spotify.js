const fetch = require("node-fetch");
const axios = require("axios");

const client_id = "acc6302297e040aeb6e4ac1fbdfd62c3";
const client_secret = "0e8439a1280a43aba9a5bc0a16f3f009";
const basic = Buffer.from(`${client_id}:${client_secret}`).toString("base64");
const TOKEN_ENDPOINT = "https://accounts.spotify.com/api/token";

async function getSpotifyToken() {
    try {
        const response = await axios.post(
            TOKEN_ENDPOINT,
            "grant_type=client_credentials", {
                headers: {
                    Authorization: "Basic " + basic,
                    "Content-Type": "application/x-www-form-urlencoded"
                },
            },
        );
        return response.data.access_token;
    } catch (error) {
        console.error("Failed to retrieve Spotify token:", error);
        return null;
    }
}

function formatDuration(ms) {
    let minutes = Math.floor(ms / 60000);
    let seconds = ((ms % 60000) / 1000).toFixed(0);
    return `${minutes}:${seconds.padStart(2, "0")}`;
}

exports.run = {
  usage: ["spotify"],
  category: "downloader",
  use: "judul lagu",
  async: async (m, { func, mecha, setting }) => {
    if (!m.text) return mecha.reply(m.chat, func.example(m.cmd, "Imagine Dragons"), m);

    mecha.sendReact(m.chat, "🕒", m.key); // Tampilkan reaksi loading

    try {
      const token = await getSpotifyToken();
      if (!token) return mecha.reply(m.chat, "Gagal mendapatkan token Spotify.", m);

      const query = encodeURIComponent(m.text);
      const spotifyApiUrl = `https://api.spotify.com/v1/search?q=${query}&type=track&limit=10`;
      
      const { data } = await axios.get(spotifyApiUrl, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      if (!data.tracks.items.length) {
        return mecha.reply(m.chat, "Lagu tidak ditemukan. Coba masukkan judul lain!", m);
      }

      let caption = `*S P O T I F Y - S E A R C H I N G*\n\nResult From: \`${m.text}\`\n\n`;
      for (let i = 0; i < data.tracks.items.length; i++) {
        const track = data.tracks.items[i];
        const title = track.name;
        const artist = track.artists.map(artist => artist.name).join(", ");
        const album = track.album.name;
        const songUrl = track.external_urls.spotify;
        const duration = formatDuration(track.duration_ms);
        const cover = track.album.images.length ? track.album.images[0].url : null;

        caption += `*${i + 1}.* ${title}\n`;
        caption += `- *Artis:* ${artist}\n`;
        caption += `- *Album:* ${album}\n`;
        caption += `- *Duration:* ${duration}\n`;
        caption += `*Dengarkan di:* ${songUrl}\n\n`;
      }

      let sentMessage = await (setting.fakereply ? 
        mecha.sendMessageModify(m.chat, caption, m, {
          title: `SPOTIFY`,
          body: global.header,
          thumbnail: await (await fetch(data.tracks.items[0].album.images[0].url)).buffer(),
          largeThumb: true,
          expiration: m.expiration,
        }) : mecha.reply(m.chat, caption, m, { expiration: m.expiration })
      );

      mecha.sendReact(m.chat, "✅", m.key);
    } catch (err) {
      console.error("Error fetching Spotify data:", err);
      mecha.reply(m.chat, "Terjadi kesalahan saat mengambil data dari Spotify.", m);
    }
  },
  premium: true, // Hanya untuk pengguna premium
};