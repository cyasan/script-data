const axios = require("axios");
const cheerio = require("cheerio");

exports.run = {
  usage: ["applemusicdl"],
  hidden: ["appledl"],
  category: "downloader",
  use: "link Apple Music",
  async: async (m, { func, mecha }) => {
    if (!m.text) return mecha.reply(m.chat, func.example(m.cmd, "https://music.apple.com/id/album/song-title/123456789"), m);

    mecha.sendReact(m.chat, "🕒", m.key);

    try {
      const baseurl = "https://aaplmusicdownloader.com";
      const detail = await axios.get(`${baseurl}/api/applesearch.php`, {
        params: { url: m.text },
      });

      if (!detail.data.url) {
        return mecha.reply(m.chat, "Gagal mengambil data. Pastikan link Apple Music valid!", m);
      }

      const { name, albumname, url } = detail.data;

      // Ambil cover, artis, dan durasi dari API iTunes
      const query = encodeURIComponent(name);
      const itunesResponse = await axios.get(`https://itunes.apple.com/search?term=${query}&entity=song&limit=1`);
      const music = itunesResponse.data.results[0];
      const cover = music ? music.artworkUrl100.replace("100x100bb", "600x600bb") : null;
      const artist = music ? music.artistName : albumname; // Jika artis tidak ditemukan, gunakan nama album
      const trackTimeMillis = music ? music.trackTimeMillis : 0;

      // Konversi durasi ke format mm:ss
      const minutes = Math.floor(trackTimeMillis / 60000);
      const seconds = ((trackTimeMillis % 60000) / 1000).toFixed(0);
      const duration = minutes + ":" + (seconds < 10 ? "0" : "") + seconds;

      // Ambil token untuk download
      const restk = await axios.get(`${baseurl}/song.php`);
      const $ = cheerio.load(restk.data);
      const token = $("div.media-info").find('a[href="#"]').attr("token");

      const data = new URLSearchParams();
      data.append("song_name", name);
      data.append("artist_name", albumname);
      data.append("url", url);
      data.append("token", token);

      const dlrespon = await axios.post(`${baseurl}/api/composer/swd.php`, data, {
        headers: {
          "Accept": "application/json, text/javascript, */*; q=0.01",
          "Cache-Control": "no-cache",
          "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
          "Origin": baseurl,
          "Referer": `${baseurl}/track.php`,
          "User-Agent": "Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36",
          "X-Requested-With": "XMLHttpRequest",
        },
      });

      const downloadLink = encodeURI(dlrespon.data.dlink);

      if (!downloadLink) {
        return mecha.reply(m.chat, "Gagal mendapatkan link unduhan.", m);
      }

      let caption = `乂 *APPLE MUSIC DOWNLOADER*\n\n`;
      caption += `- *Judul:* ${name}\n`;
      caption += `- *Artis:* ${artist}\n`;
      caption += `- *Album:* ${albumname}\n`;
      caption += `- *Durasi:* ${duration}\n\n`;
      caption += `_Please wait audio is being sent..._`;

      const msg = await mecha.sendMessage(m.chat, {
        text: caption,
        contextInfo: {
          externalAdReply: {
            title: name,
            body: global.header,
            thumbnailUrl: cover,
            sourceUrl: '',
            mediaType: 1,
            showAdAttribution: false,
            renderLargerThumbnail: true,
          },
        },
      }, { quoted: m });

      // Kirim audio full jika tersedia
      await mecha.sendMessage(m.chat, {
        audio: { url: downloadLink },
        mimetype: "audio/mp4",
        ptt: false,
      }, { quoted: msg });

      mecha.sendReact(m.chat, "✅", m.key);
    } catch (err) {
      console.error("Error fetching Apple Music download:", err);
      mecha.reply(m.chat, "Terjadi kesalahan saat mengambil data dari Apple Music.", m);
    }
  },
  premium: true,
};