const axios = require('axios');

async function ttSearch(query) {
    try {
        const response = await axios.post("https://tikwm.com/api/feed/search", {
            keywords: query,
            count: 12,
            cursor: 0,
            web: 1,
            hd: 1
        }, {
            headers: {
                "content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                cookie: "current_language=en",
                "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36",
            }
        });
        return response.data.data || [];
    } catch (error) {
        console.error('Error fetching TikTok search:', error);
        return [];
    }
}

exports.run = {
    usage: ['tiktokplay'],
    hidden: ['ttplay'],
    use: 'query',
    category: 'downloader',
    async: async (m, { func, mecha, errorMessage }) => {
        if (!m.text) return m.reply(func.example(m.cmd, 'story coding'));
        mecha.sendReact(m.chat, '🕒', m.key);

        try {
            if (/^(--audio)$/i.test(m.args[0])) {
                return mecha.sendMessage(m.chat, {
                    audio: { url: m.args[1] },
                    mimetype: 'audio/mpeg',
                    ptt: false
                }, { quoted: m, ephemeralExpiration: m.expiration });
            } else {
                let search = await ttSearch(m.text);
                if (!search.videos || search.videos.length === 0) {
                    return m.reply('Maaf, tidak ada video yang ditemukan untuk pencarian ini.');
                }

                let random = search.videos[Math.floor(Math.random() * search.videos.length)];
                let title = '*T I K T O K - P L A Y*';
                let body = `*T I K T O K - P L A Y*\n\n*• Title :* ${random.title}
*• Region :* ${random.region}
*• Duration :* ${random.duration} seconds
*• Total Views :* ${func.formatNumber(random.play_count)}
*• Total Likes :* ${func.formatNumber(random.digg_count)}
*• Author :* ${random.author.nickname}`;

                let button = [
                    {
                        buttonId: `${m.prefix}tiktokplay --audio ${'https://tikwm.com' + random.music}`,
                        buttonText: { displayText: 'Download Audio' },
                        type: 1
                    },
                    {
                        buttonId: `${m.prefix}tiktokplay ${m.text}`,
                        buttonText: { displayText: 'Next Video' },
                        type: 1
                    }
                ];

                await mecha.sendMessage(m.chat, {
                    text: body,
                    footer: 'Click the button below to download audio or find another video',
                    buttons: button,
                    headerType: 1,
                    mentions: [m.sender],
                    viewOnce: true
                }, { quoted: m });

                await mecha.sendMessage(m.chat, {
                    video: { url: 'https://tikwm.com' + random.play },
                    mimetype: 'video/mp4'
                }, { quoted: m, ephemeralExpiration: m.expiration });
            }
        } catch (e) {
            mecha.reply(m.chat, e.message, m, { expiration: m.expiration });
        }
    },
    limit: 3,
    location: 'plugins/downloader/tiktokplay.js'
};