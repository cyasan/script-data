const cheerio = require('cheerio')
const axios = require('axios')

async function tiktok(url) {
    try {
        const data = new URLSearchParams({
            'id': url,
            'locale': 'id',
            'tt': 'RFBiZ3Bi'
        });

        const headers = {
            'HX-Request': true,
            'HX-Trigger': '_gcaptcha_pt',
            'HX-Target': 'target',
            'HX-Current-URL': 'https://ssstik.io/id',
            'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
            'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Mobile Safari/537.36',
            'Referer': 'https://ssstik.io/id'
        };

        const response = await axios.post('https://ssstik.io/abc?url=dl', data, {
            headers
        });
        const html = response.data;

        const $ = cheerio.load(html);

        const author = $('#avatarAndTextUsual h2').text().trim();
        const title = $('#avatarAndTextUsual p').text().trim();
        const video = $('.result_overlay_buttons a.download_link').attr('href');
        const audio = $('.result_overlay_buttons a.download_link.music').attr('href');
        const imgLinks = [];
        $('img[data-splide-lazy]').each((index, element) => {
            const imgLink = $(element).attr('data-splide-lazy');
            imgLinks.push(imgLink);
        });

        const result = {
            status: true,
            isSlide: video ? false : true,
            author,
            title,
            result: video || imgLinks,
            audio
        };
        return result
    } catch (error) {
        console.error('Error:', error);
        return {
            status: false,
            message: error.message
        };
    }
}

exports.run = {
    usage: ['tiktok5'],
    hidden: ['tiktokslide2', 'ttslide2'],
    use: 'link tiktok',
    category: 'downloader',
    async: async (m, {
        func,
        mecha
    }) => {
        if (!m.text) return m.reply(func.example(m.cmd, 'https://vt.tiktok.com/ZS6tejpuf/'))
        if (!/^(?:https?:\/\/)?(?:www\.|vt\.|vm\.|t\.)?(?:tiktok\.com\/)(?:\S+)?$/.test(m.args[0])) return m.reply(global.mess.error.url)
        mecha.sendReact(m.chat, '🕒', m.key);
        try {
            const data = await tiktok(m.args[0]);
            if (!data.status) return m.reply(data.message)
            if (data.isSlide) {
                for (let [index, item] of data.result.entries()) {
                    let message = index == 0 ? m : null;
                    await mecha.sendMedia(m.chat, item, message, {
                        caption: index == 0 ? `Total Images : ${data.result.length}` : '',
                        expiration: m.expiration
                    })
                    await func.delay(2000)
                }
            } else {
                let caption = `乂  *TIKTOK - DOWNLOADER*\n`
                caption += `\n- Title : ${data.title}`
                caption += `\n- Author : ${data.author}`
                caption += `\n- Total Images : ${data.result.length}`
                caption += `\n\n_Please wait image is being sent..._`
                await mecha.sendMedia(m.chat, data.result, m, {
                    caption: caption,
                    expiration: m.expiration
                })
            }
            mecha.sendMessage(m.chat, {
                audio: {
                    url: data.audio
                },
                mimetype: 'audio/mpeg',
                ptt: false
            }, {
                quoted: m,
                ephemeralExpiration: m.expiration
            })
        } catch (error) {
            console.log(error)
            mecha.reply(m.chat, error.message, m, {
                expiration: m.expiration
            })
        }
    },
    location: 'plugins/downloader/tiktokslide2.js'
}