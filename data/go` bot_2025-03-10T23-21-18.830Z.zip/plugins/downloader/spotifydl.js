const axios = require('axios');

const toTime = (ms) => {
    let m = Math.floor(ms / 60000) % 60;
    let s = Math.floor(ms / 1000) % 60;
    return [m, s].map((v) => v.toString().padStart(2, "0")).join(":");
};

async function fabdlsp(url) {
    try {
        const response = await axios.get(`https://api.fabdl.com/spotify/get?url=${url}`, {
            headers: {
                Accept: "application/json, text/plain, */*",
                "Content-Type": "application/json",
                "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Mobile Safari/537.36",
            },
        });

        if (!response.data.result) {
            return { msg: "Failed to get track info" };
        }

        const { data } = await axios.get(
            `https://api.fabdl.com/spotify/mp3-convert-task/${response.data.result.gid}/${response.data.result.id}`
        );

        if (!data?.result?.download_url) {
            return { msg: "Link download not found!" };
        }

        return {
            title: response.data.result.name,
            duration: toTime(response.data.result.duration_ms),
            cover: response.data.result.image,
            download: "https://api.fabdl.com" + data?.result?.download_url,
        };
    } catch (error) {
        return { msg: "Error Detected", err: error.message };
    }
}

exports.run = {
    usage: ["spotifydl"],
    hidden: ["spdl"],
    category: "downloader",
    use: "Spotify link",
    async: async (m, { mecha }) => {
        if (!m.text) return mecha.reply(m.chat, "Masukkan URL Spotify yang valid!", m);

        mecha.sendReact(m.chat, "🕒", m.key);

        try {
            const trackInfo = await fabdlsp(m.text);
            if (trackInfo.msg) throw new Error(trackInfo.msg);

            let caption = `乂 *SPOTIFY MUSIC DOWNLOADER*\n\n`;
            caption += `- *Title:* ${trackInfo.title}\n`;
            caption += `- *Duration:* ${trackInfo.duration}\n\n`;
            caption += `_Please wait, the audio is being sent..._`;

            const msg = await mecha.sendMessage(m.chat, {
                text: caption,
                contextInfo: {
                    externalAdReply: {
                        title: `SPOTIFY`,
                        body: global.header,
                        thumbnailUrl: trackInfo.cover,
                        mediaType: 1,
                        renderLargerThumbnail: true,
                    },
                },
            }, { quoted: m });

            // Kirim audio
            await mecha.sendMessage(m.chat, {
                audio: { url: trackInfo.download },
                mimetype: "audio/mp4",
                ptt: false,
            }, { quoted: msg });

            mecha.sendReact(m.chat, "✅", m.key);
        } catch (err) {
            console.error("Error fetching Spotify download:", err);
            mecha.reply(m.chat, `Terjadi kesalahan saat mengambil data dari Spotify.\nError: ${err.message}`, m);
        }
    },
    premium: true,
};