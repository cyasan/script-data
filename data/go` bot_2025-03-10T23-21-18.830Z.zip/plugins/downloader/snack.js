const axios = require("axios");

exports.run = {
  usage: ["snackdownload"],
  category: "downloader",
  use: "link video SnackVideo",
  async: async (m, { func, mecha }) => {
    if (!m.text) return mecha.reply(m.chat, func.example(m.cmd, "https://www.snackvideo.com/s/uabcd1234"), m);

    mecha.sendReact(m.chat, "🕒", m.key); // Reaksi loading

    try {
      let url = m.text;

      // Cek validitas URL
      const urlPattern = /https:\/\/www\.snackvideo\.com\/s\/[a-zA-Z0-9]+/;
      if (!urlPattern.test(url)) {
        return mecha.reply(m.chat, "URL tidak valid. Pastikan itu adalah URL SnackVideo.", m);
      }

      // Menggunakan API eksternal untuk mendapatkan URL video tanpa watermark
      const api_url = `https://api.snackvideo.com/download?url=${encodeURIComponent(url)}`;

      let { data, status } = await axios.get(api_url);

      // Cek status respons HTTP
      if (status !== 200) {
        return mecha.reply(m.chat, `Gagal mengambil data dari SnackVideo. Status HTTP: ${status}`, m);
      }

      console.log("Data dari API:", data); // Log data dari API

      // Periksa apakah data download ada
      if (!data || !data.download_url) {
        return mecha.reply(m.chat, "Gagal mendapatkan video. Coba lagi nanti!", m);
      }

      let result = {
        metadata: {
          title: data.title || "Tidak Diketahui",
          thumbnail: data.thumbnail || "",
          author: data.author || "Tidak Diketahui",
        },
        download: data.download_url,
      };

      // Kirim video langsung tanpa caption
      try {
        await mecha.sendMessage(
          m.chat,
          {
            video: { url: result.download },
            mimetype: "video/mp4",
          },
          { quoted: m }
        );
      } catch (error) {
        console.error("Error sending message:", error);
        return mecha.reply(m.chat, "Terjadi kesalahan saat mengirim video.", m);
      }

      mecha.sendReact(m.chat, "✅", m.key); // Reaksi sukses
    } catch (err) {
      console.error("Error fetching SnackVideo data:", err);
      mecha.reply(m.chat, "Terjadi kesalahan saat mengambil data dari SnackVideo.", m);
    }
  },
  premium: false, // Tidak perlu premium
  limit: 5
};