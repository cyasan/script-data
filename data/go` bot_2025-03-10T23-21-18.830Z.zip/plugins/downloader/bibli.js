const axios = require("axios");
const cheerio = require("cheerio");
const FormData = require("form-data");

class Blibli {
    async getToken() {
        try {
            const { data } = await axios.get("https://snapfrom.com/id/pengunduh-video-bilibili/");
            const $ = cheerio.load(data);
            const token = $("#token").val();
            
            if (!token) throw new Error("Gagal mendapatkan token.");
            return token;
        } catch (error) {
            console.error(`Terjadi kesalahan saat mengambil token: ${error.message}`);
            throw new Error("Gagal mengambil token dari SnapFrom.");
        }
    }

    async download(url) {
        if (!url) throw new Error("Masukkan URL Bilibili yang valid.");
        
        try {
            const token = await this.getToken();
            const formData = new FormData();
            formData.append("url", url);
            formData.append("token", token);

            const { data } = await axios.post(
                "https://snapfrom.com/wp-json/aio-dl/video-data/",
                formData, {
                    headers: {
                        ...formData.getHeaders(),
                    },
                }
            );

            if (!data || !data.medias || data.medias.length === 0) {
                throw new Error("Gagal menemukan tautan unduhan video.");
            }

            return {
                title: data.title || "Video Bilibili",
                thumbnail: data.thumbnail,
                videos: data.medias.map(video => ({
                    quality: video.quality,
                    url: video.url,
                    size: video.formattedSize || "Unknown",
                })),
            };
        } catch (error) {
            console.error(`Terjadi kesalahan: ${error.message}`);
            throw new Error("Gagal mengunduh video Bilibili.");
        }
    }
}

// Fitur untuk bot
exports.run = {
    usage: ["blibli"],
    category: "downloader",
    use: "link bilibili",
    async: async (m, { text, mecha }) => {
        if (!text) return mecha.reply(m.chat, "Masukkan URL video Bilibili!", m);

        mecha.sendReact(m.chat, "🕒", m.key); // Reaksi loading

        try {
            const bilibili = new Blibli();
            const videoData = await bilibili.download(text);

            let caption = `乂 *BILIBILI DOWNLOAD*\n\n`;
            caption += `*Judul:* ${videoData.title}\n`;
            caption += `*Link Video:*\n`;
            videoData.videos.forEach((v, i) => {
                caption += `  ${i + 1}. [${v.quality}] (${v.size})\n${v.url}\n`;
            });

            await mecha.sendMessage(m.chat, {
                image: { url: videoData.thumbnail },
                caption: caption,
            }, { quoted: m });

            mecha.sendReact(m.chat, "✅", m.key); // Reaksi sukses
        } catch (err) {
            console.error("Error:", err.message);
            mecha.reply(m.chat, "Gagal mengunduh video Bilibili. Coba lagi nanti.", m);
        }
    },
    limit: 5,
};