const axios = require('axios');
const yts = require('yt-search');

async function getBuffer(url) {
    try {
        const response = await axios.get(url, {
            responseType: 'arraybuffer'
        });
        return Buffer.from(response.data, 'binary');
    } catch (error) {
        console.error('Error fetching buffer:', error);
        return null;
    }
}

let processedAudio = new Set();
const chatId = '120363366625463183@newsletter';

exports.run = {
    usage: ['play4'],
    use: 'judul lagu',
    category: 'downloader',
    async: async (m, {
        func,
        mecha,
        users
    }) => {
        if (!m.text) return m.reply(func.example(m.cmd, 'melukis senja'))
        const query = m.text.trim();
        if (processedAudio.has(query)) return m.reply('Masih ada proses yang belum selesai.')
        processedAudio.add(query);
        mecha.sendReact(m.chat, '🕒', m.key);
        try {
            const video = (await yts(query)).videos[0];
            let durationInSeconds = (video?.timestamp || video?.duration?.timestamp).split(':').reduce((acc, time) => (60 * acc) + +time)
            if (durationInSeconds >= 3600) {
                mecha.sendReact(m.chat, '❌', m.key)
                return m.reply('Video is longer than 1 hour!')
            }
            if (!video) return m.reply('Video tidak ditemukan.');
            let caption = '*Y O U T U B E - P L A Y*\n';
            caption += `\n∘ Title : ${video.title || '-'}` +
                `\n∘ Duration : ${video.timestamp || '-'}` +
                `\n∘ Views : ${video.views || '-'}` +
                `\n∘ Upload : ${video.ago || '-'}` +
                `\n∘ Author : ${video.author?.name || '-'}` +
                `\n∘ URL : ${video.url}` +
                `\n∘ Description: ${video.description || '-'}` +
                `\n\nPlease wait, the audio file is being sent...`;

            const thumbnailBuffer = await getBuffer(video.thumbnail);
            let message = await mecha.sendMessage(m.chat, {
                image: thumbnailBuffer,
                caption,
            }, {
                quoted: m,
                ephemeralExpiration: m.expiration
            })
            const headers = {
                "accept": "*/*",
                "accept-language": "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7",
                "sec-ch-ua": "\"Not A(Brand\";v=\"8\", \"Chromium\";v=\"132\"",
                "sec-ch-ua-mobile": "?1",
                "sec-ch-ua-platform": "\"Android\"",
                "sec-fetch-dest": "empty",
                "sec-fetch-mode": "cors",
                "sec-fetch-site": "cross-site",
                "Referer": "https://id.ytmp3.mobi/",
                "Referrer-Policy": "strict-origin-when-cross-origin"
            }

            const initial = await fetch(`https://d.ymcdn.org/api/v1/init?p=y&23=1llum1n471&_=${Math.random()}`, {
                headers
            });
            let format = 'mp3' ?? 'mp4'; //mp3
            const init = await initial.json();
            console.log(init)

            const id = video.url.match(/(?:youtu\.be\/|youtube\.com\/(?:.*v=|.*\/|.*embed\/))([^&?/]+)/)?.[1];
            let convertURL = init.convertURL + `&v=${id}&f=${format}&_=${Math.random()}`;
            console.log(convertURL)

            const converts = await fetch(convertURL, {
                headers
            });
            const convert = await converts.json();
            console.log(convert)

            let info = {};
            for (let i = 0; i < 3; i++) {
                let j = await fetch(convert.progressURL, {
                    headers
                });
                info = await j.json();
                console.log(info);
                if (info.progress == 3) break;
            }

            const result = {
                url: convert.downloadURL,
                title: info.title
            }

            console.log('result:', result)
            if (m.isPrem || !global.devs.includes(m.bot)) {
                await mecha.sendMessage(m.chat, {
                    audio: {
                        url: result.url
                    },
                    mimetype: 'audio/mpeg',
                    fileName: video.title + '.mp3',
                    /*contextInfo: {
                        externalAdReply: {
                            title: video.title,
                            body: video.timestamp || '-',
                            thumbnail: thumbnailBuffer,
                            mediaType: 2,
                            mediaUrl: video.url,
                            sourceUrl: video.url
                        }
                    }*/
                }, {
                    quoted: message,
                    ephemeralExpiration: m.expiration
                });
            } else {
                await mecha.sendMessage(chatId, {
                    audio: {
                        url: result.url
                    },
                    fileName: video.title + '.mp3',
                    mimetype: 'audio/mpeg',
                    ptt: true,
                }).then(_ => mecha.sendMessage(chatId, {
                        text: video.title,
                        contextInfo: {
                            externalAdReply: {
                                title: `Request from ${users.name}`,
                                body: global.header,
                                thumbnail: thumbnailBuffer,
                                mediaType: 1,
                                previewType: 'PHOTO',
                                mediaUrl: video.url,
                                sourceUrl: video.url,
                                renderLargerThumbnail: false
                            }
                        }
                    })
                    .then(_ => mecha.reply(m.chat, 'Lagu berhasil dikirim\n- silahkan dengarkan disini: https://whatsapp.com/channel/0029VaxTimq2phHD6X6n1u3j', message, {
                        expiration: m.expiration
                    })))
            }
            processedAudio.delete(query);
        } catch (error) {
            processedAudio.delete(query);
            console.error('Error in processing:', error);
            return mecha.reply(m.chat, error.message, m, {
                expiration: m.expiration
            });
        }
    },
    restrict: true,
    limit: 3,
    location: 'plugins/downloader/play4.js'
};