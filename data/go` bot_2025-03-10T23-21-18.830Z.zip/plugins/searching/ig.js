const axios = require("axios");

class Instagram {
  search = async (q) => {
    const maxRetries = 10;
    let attempt = 0;
    let response;

    while (attempt < maxRetries) {
      try {
        const config = {
          method: "get",
          url: `https://www.instagram.com/web/search/topsearch/?query=${encodeURIComponent(q)}`,
          headers: {
            "User-Agent":
              "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36",
          },
        };

        response = await axios(config);

        if (response.data && response.data.users.length > 0) {
          return response.data.users.map((user) => ({
            username: user.user.username,
            full_name: user.user.full_name,
            profile_pic: user.user.profile_pic_url,
            is_verified: user.user.is_verified ? "✅ Verified" : "❌ Not Verified",
            follower_count: user.user.follower_count.toLocaleString(),
            link: `https://www.instagram.com/${user.user.username}/`,
          }));
        } else {
          attempt++;
          await new Promise((resolve) => setTimeout(resolve, 2000));
        }
      } catch (error) {
        attempt++;
        await new Promise((resolve) => setTimeout(resolve, 2000));
      }
    }
    return "Kebanyakan spam ini kasih delay dong";
  };
}

exports.run = {
  usage: ["instagramsearch"],
  hidden: ["igsearch"],
  category: "searching",
  use: "kata kunci",
  async: async (m, { mecha, isPrem }) => {
    let text = m.text ? m.text.trim() : "";

    if (!text) {
      return mecha.sendMessage(m.chat, { text: `Masukkan kata kunci untuk pencarian Instagram.\n\n_Example :_ ${m.prefix + m.command} jkt48` }, { quoted: m });
    }

    mecha.sendReact(m.chat, "🕒", m.key);

    try {
      const instagram = new Instagram();
      const searchResults = await instagram.search(text);

      if (searchResults === "Kebanyakan spam ini kasih delay dong") {
        return mecha.sendMessage(m.chat, { text: "Terlalu sering mencoba! Tunggu beberapa saat sebelum mencoba lagi." }, { quoted: m });
      }

      if (!Array.isArray(searchResults) || searchResults.length === 0) {
        return mecha.sendMessage(m.chat, { text: "Tidak ditemukan akun Instagram dengan kata kunci tersebut." }, { quoted: m });
      }

      if (!isPrem) {
        // Pengguna Gratis - Menampilkan daftar akun
        let firstUser = searchResults[0];
        let message = `乂 INSTAGRAM SEARCH\n\n`;

        message += `- Username: @${firstUser.username}\n`;
        message += `- Full Name: ${firstUser.full_name}\n`;
        message += `- Verified: ${firstUser.is_verified}\n`;
        message += `- Followers: ${firstUser.follower_count}\n`;
        message += `- Profile Link: ${firstUser.link}\n\n`;

        message += `Hasil Pencarian Lainnya:\n`;
        searchResults.slice(0, 10).forEach((result, index) => {
          message += `- ${index + 1}. @${result.username} (${result.full_name})\n`;
          message += `  - Verified: ${result.is_verified}\n`;
          message += `  - Followers: ${result.follower_count}\n`;
          message += `  - Profile Link: ${result.link}\n\n`;
        });

        await mecha.sendMessage(m.chat, {
          image: { url: firstUser.profile_pic },
          caption: message,
        }, { quoted: m });

      } else {
        // Pengguna Premium - Kirim hasil satu per satu
        for (let i = 0; i < Math.min(searchResults.length, 10); i++) {
          let result = searchResults[i];

          await new Promise(resolve => setTimeout(resolve, 2000));

          let premiumMessage = `乂 INSTAGRAM SEARCH\n\n`;
          premiumMessage += `- Username: @${result.username}\n`;
          premiumMessage += `- Full Name: ${result.full_name}\n`;
          premiumMessage += `- Verified: ${result.is_verified}\n`;
          premiumMessage += `- Followers: ${result.follower_count}\n`;
          premiumMessage += `- Profile Link: ${result.link}`;

          await mecha.sendMessage(m.chat, {
            image: { url: result.profile_pic },
            caption: premiumMessage,
          }, { quoted: m });
        }

        // Kirim teks "Successfully." setelah semua akun dikirim
        await mecha.sendMessage(m.chat, { text: "Successfully." }, { quoted: m });
      }

      mecha.sendReact(m.chat, "✅", m.key);

    } catch (err) {
      mecha.sendMessage(m.chat, { text: "Terjadi kesalahan dalam pencarian Instagram. Coba lagi nanti." }, { quoted: m });
    }
  },
  limit: 5,
};