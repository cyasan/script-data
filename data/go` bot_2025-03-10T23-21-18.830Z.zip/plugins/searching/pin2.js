exports.run = {
usage: ['pinterest2'],
hidden: ['pin2'],
use: 'text',
category: 'searching',
async: async (m, { func, mecha, isPrem }) => {
if (!m.text) return m.reply(func.example(m.prefix + m.command, 'nakano miku'))
if (m.text.startsWith('@62')) return m.reply('Stress ??')
if (m.text.includes(' --') && !isPrem) return m.reply(global.mess.premium)
mecha.sendReact(m.chat, '🕒', m.key)
let jumlah;
if (m.text.includes(' --')) jumlah = m.text.split(' --')[1]
let data = await func.fetchJson('https://aemt.me/pinterest?query=' + m.text.split(' --')[0])
if (data.result.length == 0) return m.reply('Tidak ditemukan.')
if (m.text.includes(' --')) {
if (data.result.length < jumlah) {
jumlah = data.result.length;
m.reply(`Hanya ditemukan ${data.result.length}, foto segera dikirim`)
}
for (let i = 0; i < jumlah; i++) {
mecha.sendMessage(m.chat, {image: {url: data.result[i]}, caption: `Hasil dari *${m.text.split(' --')[0]}*`, mentions: mecha.ments(m.text)}, {quoted: m, ephemeralExpiration: m.expiration})
}
} else {
let result = data.result[Math.floor(Math.random() * data.result.length)]
mecha.sendMessage(m.chat, {image: {url: result}, caption: `Hasil dari *${m.text}*`, mentions: mecha.ments(m.text)}, {quoted: m, ephemeralExpiration: m.expiration})
}
},
//premium: true,
restrict: true,
limit: 5
}