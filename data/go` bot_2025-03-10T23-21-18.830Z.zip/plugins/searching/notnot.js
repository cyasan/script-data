async function getRandomAnime() {
  const animeList = [
  "https://k.top4top.io/m_2442ag1hz0.mp4",
  "https://e.top4top.io/m_2442zoq1q0.mp4",
  "https://d.top4top.io/m_2442fhuc30.mp4",
  "https://j.top4top.io/m_24422gftd0.mp4",
  "https://b.top4top.io/m_2443t8ab30.mp4",
  "https://a.top4top.io/m_2443wc3wp0.mp4",
  "https://b.top4top.io/m_2443mcw8l0.mp4",
  "https://e.top4top.io/m_2444w606q1.mp4",
  "https://d.top4top.io/m_24441r8490.mp4",
  "https://g.top4top.io/m_2442x0pz10.mp4"
];

  const randomIndex = Math.floor(Math.random() * animeList.length);
  const randomAnime = animeList[randomIndex];

  return randomAnime;
}

// Helper function to generate random source and date
function getRandomSource() {
  const sources = ['Twitter', 'Telegram', 'TikTok'];
  return sources[Math.floor(Math.random() * sources.length)];
}

function getRandomDate() {
  const startDate = new Date('2023-10-13');
  const endDate = new Date('2024-01-06');
  const randomDate = new Date(startDate.getTime() + Math.random() * (endDate - startDate));
  return randomDate.toLocaleDateString('id-ID');
}

exports.run = {
  usage: ['notnot'],
  category: 'asupan',
  async: async (m, { func, mecha, users, setting, froms }) => {
    if (users.age < 28) {
      mecha.sendMessage(m.chat, { text: `Kamu masih di bawah umur untuk menggunakan fitur ini.` }, { quoted: m });
      return;
    }

    try {
      mecha.sendReact(m.chat, '🕒', m.key); // Send loading indicator
      const animeUrl = await getRandomAnime();

      if (isValidVideoUrl(animeUrl) && isAppropriateContent(animeUrl)) {
        const caption = `*ASUPAN - NOTNOT*\n\nSumber: ${getRandomSource()}\nPublished on: ${getRandomDate()}`;
        
        mecha.sendMessage(
          m.chat,
          {
            video: {
              url: animeUrl,
            },
            mimetype: 'video/mp4',
              caption: caption,
          },
          { quoted: m, ephemeralExpiration: 86400 }
        );
      } else {
        m.reply(`Maaf, terjadi kesalahan saat mengambil video Notnot.`);
      }
    } catch (error) {
      console.error('Error fetching anime:', error);
      mecha.sendReact(m.chat, '❌', m.key); // Error indicator
    }
  },
  limit: true,
  premium: true,
  private: true,
};

function isValidVideoUrl(url) {
  return true; // Replace with actual validation logic
}

function isAppropriateContent(url) {
  return true; // Replace with actual content filtering logic
}