const axios = require('axios');
const cheerio = require('cheerio');

class emotecraft {
  // Fungsi untuk mencari emote berdasarkan emoteId atau nama
  static async Minecraft_Emote(emoteId) {
    try {
      const response = await axios.get(`https://emotes.kosmx.dev/emotes?s=${emoteId}`);
      const $ = cheerio.load(response.data);
      const emotes = [];

      $('.card').each((index, element) => {
        const title = $(element).find('.card-title').text().trim();
        const description = $(element).find('.card-text').text().trim();
        const uploader = $(element).find('.card-footer').text().trim();
        const downloadUrl = 'https://emotes.kosmx.dev' + $(element).find('a').first().attr('href');
        const imageUrl = 'https://emotes.kosmx.dev' + $(element).find('img').attr('src');

        emotes.push({
          title,
          description,
          uploader,
          downloadUrl,
          imageUrl
        });
      });

      return {
        success: true,
        author: "@selxyz",
        result: emotes
      };
    } catch (error) {
      console.error('Error fetching emote details:', error.message);
      return {
        success: false,
        author: "@lexy-bot",
        result: []
      };
    }
  }

  // Fungsi untuk mengambil detail emote berdasarkan URL
  static async GET_EMOTE_DETAIL(emoteUrl) {
    try {
      const response = await axios.get(emoteUrl);
      const $ = cheerio.load(response.data);

      const title = $('h1').text().trim();
      const author = $('h3').text().replace('Author:', '').trim();
      const description = $('h5').text().trim();
      const owner = $('a[href^="/u/"]').first().attr('href') ? 'https://emotes.kosmx.dev' + $('a[href^="/u/"]').first().attr('href') : null;
      const iconUrl = 'https://emotes.kosmx.dev' + $('img').attr('src');
      const downloadUrl = 'https://emotes.kosmx.dev' + $('a.btn-success').attr('href');
      const jsonDownloadUrl = 'https://emotes.kosmx.dev' + $('a.btn-light').attr('href');
      const stars = $('span.text-muted').text().trim();

      return {
        success: true,
        author: "@lexy-bot",
        result: {
          title,
          author,
          description,
          owner,
          iconUrl,
          downloadUrl,
          jsonDownloadUrl,
          stars
        }
      };
    } catch (error) {
      console.error('Error fetching emote details:', error.message);
      return {
        success: false,
        author: "@lexy-bot",
        result: null
      };
    }
  }

  // Fungsi untuk mengambil emote secara acak
  static async RANDOM_EMOTES() {
    try {
      const randomPage = Math.floor(Math.random() * 12) + 1;
      const response = await axios.get(`https://emotes.kosmx.dev/emotes?p=${randomPage}`);
      const $ = cheerio.load(response.data);
      const randomEmotes = [];

      $('.card').each((index, element) => {
        const title = $(element).find('.card-title').text().trim();
        const description = $(element).find('.card-text').text().trim();
        const author = $(element).find('.card-footer').text().trim();
        const downloadLink = 'https://emotes.kosmx.dev' + $(element).find('a').first().attr('href');
        const imageSrc = 'https://emotes.kosmx.dev' + $(element).find('img').attr('src');

        randomEmotes.push({
          title,
          description,
          author,
          downloadLink,
          imageSrc
        });
      });

      return {
        success: true,
        author: "@selxyz",
        result: randomEmotes
      };
    } catch (error) {
      console.error('Error fetching random emotes:', error.message);
      return {
        success: false,
        author: "@lexy-bot",
        result: []
      };
    }
  }

  // Fungsi untuk pencarian emote berdasarkan kata kunci
  static async SEARCH_EMOTES(query) {
    try {
      const response = await axios.get(`https://emotes.kosmx.dev/emotes?s=${query}`);
      const $ = cheerio.load(response.data);
      const searchResults = [];

      // Mengambil emotes berdasarkan kata kunci pencarian
      $('.card').each((index, element) => {
        const title = $(element).find('.card-title').text().trim();
        const description = $(element).find('.card-text').text().trim();
        const uploader = $(element).find('.card-footer').text().trim();
        const downloadUrl = 'https://emotes.kosmx.dev' + $(element).find('a').first().attr('href');
        const imageUrl = 'https://emotes.kosmx.dev' + $(element).find('img').attr('src');

        searchResults.push({
          title,
          description,
          uploader,
          downloadUrl,
          imageUrl
        });
      });

      return {
        success: true,
        author: "@selxyz",
        result: searchResults
      };
    } catch (error) {
      console.error('Error searching emotes:', error.message);
      return {
        success: false,
        author: "@lexy-bot",
        result: []
      };
    }
  }
}

// Implementasi pencarian emot Minecraft
exports.run = {
  usage: ["mcemote"],
  category: "searching",
  use: "query", // Penggunaan query pencarian emote
  async: async (m, { func, mecha }) => {
    if (!m.text) return mecha.reply(m.chat, func.example(m.cmd, "dance"), m);

    mecha.sendReact(m.chat, "🕒", m.key); // Reaksi loading

    try {
      const query = m.text; // Kata kunci pencarian emote
      const result = await emotecraft.SEARCH_EMOTES(query);

      if (result.result.length === 0) {
        return mecha.reply(m.chat, "Emote tidak ditemukan. Coba kata kunci lain.", m);
      }

      let message = `乂 EMOTE SEARCH\n\nHasil pencarian emote untuk: *${query}*\n\n`;

      // Menampilkan hasil pencarian emote
      result.result.forEach((emote, index) => {
        message += `${index + 1}. **${emote.title}**\n`;
        message += `- Deskripsi: ${emote.description.slice(0, 100)}...\n`;
        message += `- Diupload oleh: ${emote.uploader}\n`;
        message += `- ${emote.downloadUrl}\n`;
        message += `   ![Image](${emote.imageUrl})\n\n`;
      });

      // Mengirimkan pesan dengan daftar emote
      await mecha.reply(m.chat, message, m);

      mecha.sendReact(m.chat, "✅", m.key); // Reaksi sukses
    } catch (error) {
      console.error('Error during emote search:', error);
      mecha.reply(m.chat, "Terjadi kesalahan saat mencari emote.", m);
    }
  },
  premium: false, // Tidak perlu premium
  limit: 5
};