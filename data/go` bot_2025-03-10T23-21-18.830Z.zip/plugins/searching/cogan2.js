async function getRandomAnime() {
  const animeList = [
'https://files.catbox.moe/9jqspo.mp4',
'https://files.catbox.moe/1bx84d.mp4',
'https://files.catbox.moe/9jqspo.mp4',
'https://files.catbox.moe/njdw56.mp4',
'https://files.catbox.moe/7nny7m.mp4',
'https://files.catbox.moe/mqlnxu.mp4',
'https://files.catbox.moe/j57g1h.mp4',
'https://files.catbox.moe/sid5zm.mp4',
'https://files.catbox.moe/a6b613.mp4',
'https://files.catbox.moe/rrvbxh.mp4',
'https://files.catbox.moe/pidxnv.mp4',
'https://files.catbox.moe/1xrd8q.mp4',
'https://files.catbox.moe/wfswhj.mp4',
'https://files.catbox.moe/vbngwc.mp4',
'https://files.catbox.moe/t29j6w.mp4',
'https://files.catbox.moe/lpfwq3.mp4',
'https://files.catbox.moe/6n2x6l.mp4',
'https://files.catbox.moe/moam3x.mp4',
'https://files.catbox.moe/fy4m4z.mp4',
'https://files.catbox.moe/pa89ws.mp4',
'https://files.catbox.moe/w3hq21.mp4',
'https://files.catbox.moe/w3hq21.mp4',
'https://files.catbox.moe/3zuk8i.mp4',
'https://files.catbox.moe/b2mfwd.mp4',
'https://files.catbox.moe/8zfde8.mp4',
'https://files.catbox.moe/9em8du.mp4',
'https://files.catbox.moe/rrb64h.mp4',
'https://files.catbox.moe/5otkvl.mp4',
'https://files.catbox.moe/msh1s2.mp4',
  ];

  const randomIndex = Math.floor(Math.random() * animeList.length);
  const randomAnime = animeList[randomIndex];

  return randomAnime;
}

exports.run = {
  usage: ['cogan2'], // Use a more descriptive command name
  category: 'asupan', // More appropriate category
  async: async (m, { func, mecha, users, setting, froms }) => {

    try {
      mecha.sendReact(m.chat, '🕒', m.key); // Send a loading indicator
      const animeUrl = await getRandomAnime();

      // Send the video only if the URL is valid and appropriate (consider adding content filtering)
      if (isValidVideoUrl(animeUrl) && isAppropriateContent(animeUrl)) {
        mecha.sendMessage(m.chat, {
          video: {
            url: animeUrl,
          },
          mimetype: 'video/mp4', // Assuming MP4 format, adjust if needed
        }, { quoted: m, ephemeralExpiration: 86400 }); // Send the video ephemerally
      } else {
        m.reply(`Maaf, terjadi kesalahan saat mengambil video anime.`); // Informative error message
      }
    } catch (error) {
      console.error('Error fetching anime:', error);
      mecha.sendReact(m.chat, '❌', m.key); // Send an error indicator
    }
  },
  limit: 2, // Consider adjusting rate limits based on usage patterns
  premium: true, // Adjust premium status as needed
};

// Helper functions (optional, depending on complexity)
function isValidVideoUrl(url) {
  // Implement logic to validate video URL format and existence
  return true; // Replace with actual validation logic
}

function isAppropriateContent(url) {
  // Implement logic to filter out inappropriate content
  return true; // Replace with actual content filtering logic
}