const axios = require("axios");
const cheerio = require("cheerio");

exports.run = {
  usage: ["bukalapak"],
  category: "searching",
  use: "nama produk",
  async: async (m, { func, mecha }) => {
    if (!m.text) return mecha.reply(m.chat, func.example(m.cmd, "Laptop"), m);

    mecha.sendReact(m.chat, "🕒", m.key); // Reaksi loading

    try {
      const { data } = await axios.get(
        `https://www.bukalapak.com/products?from=omnisearch&from_keyword_history=false&search[keywords]=${encodeURIComponent(
          m.text
        )}&search_source=omnisearch_keyword&source=navbar`,
        {
          headers: {
            "user-agent":
              "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:108.0) Gecko/20100101 Firefox/108.0",
          },
        }
      );

      const $ = cheerio.load(data);
      let hasil = [];

      $("div.bl-flex-item.mb-8").each((i, u) => {
        const a = $(u).find("observer-tracker > div > div");
        const img =
          $(a).find("div > a > img").attr("data-src") ||
          $(a).find("div > a > img").attr("src");

        if (!img) return;

        const link = $(a)
          .find(".bl-thumbnail--slider > div > a")
          .attr("href");
        const title = $(a)
          .find(".bl-product-card__description-name > p > a")
          .text()
          .trim();
        const harga = $(a)
          .find("div.bl-product-card__description-price > p")
          .text()
          .trim();
        const rating = $(a)
          .find("div.bl-product-card__description-rating > p")
          .text()
          .trim();
        const terjual = $(a)
          .find("div.bl-product-card__description-rating-and-sold > p")
          .text()
          .trim();
        const dari = $(a)
          .find("div.bl-product-card__description-store > span:nth-child(1)")
          .text()
          .trim();
        const seller = $(a)
          .find("div.bl-product-card__description-store > span > a")
          .text()
          .trim();
        const link_sel = $(a)
          .find("div.bl-product-card__description-store > span > a")
          .attr("href");

        hasil.push({
          title,
          harga,
          rating: rating || "No rating yet",
          terjual: terjual || "Not yet bought",
          image: img.startsWith("http") ? img : `https:${img}`, // Pastikan URL gambar absolut
          link: `https://www.bukalapak.com${link}`,
          store: {
            lokasi: dari,
            nama: seller,
            link: `https://www.bukalapak.com${link_sel}`,
          },
        });
      });

      if (hasil.length === 0) {
        return mecha.reply(m.chat, "Produk tidak ditemukan. Coba kata kunci lain!", m);
      }

      let produk = hasil[0]; // Ambil hasil pertama
      let caption = `乂 *SEARCHING BUKALAPAK*\n\n`;
      caption += `- *Nama Produk:* ${produk.title}\n`;
      caption += `- *Harga:* ${produk.harga}\n`;
      caption += `- *Rating:* ${produk.rating}\n`;
      caption += `- *Terjual:* ${produk.terjual}\n`;
      caption += `- *Toko:* ${produk.store.nama} (${produk.store.lokasi})\n`;
      caption += `- *Link:* ${produk.link}\n\n`;
      caption += `_Data dari Bukalapak_`;

      await mecha.sendMessage(m.chat, {
        image: { url: produk.image },
        caption,
      }, { quoted: m });

      mecha.sendReact(m.chat, "✅", m.key); // Reaksi sukses
    } catch (err) {
      console.error("Error fetching Bukalapak data:", err);
      mecha.reply(m.chat, "Terjadi kesalahan saat mencari produk di Bukalapak.", m);
    }
  },
  limit: true,
};