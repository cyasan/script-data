const axios = require('axios');
const cheerio = require('cheerio');

exports.run = {
  usage: ['otakudesu'],
  category: 'searching',
  use: 'judul anime',
  async: async (m, { func, mecha }) => {
    if (!m.text) return mecha.reply(m.chat, func.example(m.cmd, 'Naruto'), m);

    mecha.sendReact(m.chat, '🕒', m.key); // Reaksi loading

    try {
      const searchUrl = `https://otakudesu.cloud/?s=${encodeURIComponent(m.text)}&post_type=anime`;
      const { data } = await axios.get(searchUrl);
      const $ = cheerio.load(data);

      let animeList = [];
      $('.chivsrc li').each((index, element) => {
        let title = $(element).find('h2 a').text().trim();
        let link = $(element).find('h2 a').attr('href');
        let imageUrl = $(element).find('img').attr('src');
        let genres = $(element).find('.set').first().text().replace('Genres : ', '').trim();
        let status = $(element).find('.set').eq(1).text().replace('Status : ', '').trim();
        let rating = $(element).find('.set').eq(2).text().replace('Rating : ', '').trim() || 'N/A';

        animeList.push({ title, link, imageUrl, genres, status, rating });
      });

      if (animeList.length === 0) {
        return mecha.reply(m.chat, "Anime tidak ditemukan. Pastikan judul benar!", m);
      }

      let anime = animeList[0]; // Ambil hasil pertama
      let caption = `乂 *SEARCHING ANIME*\n\n`;
      caption += `- *Judul:* ${anime.title}\n`;
      caption += `- *Genre:* ${anime.genres}\n`;
      caption += `- *Status:* ${anime.status}\n`;
      caption += `- *Rating:* ${anime.rating}\n`;
      caption += `- *Link:*${anime.link}\n\n`;
      caption += `_Data dari Otakudesu_`;

      await mecha.sendMessage(m.chat, {
        image: { url: anime.imageUrl },
        caption
      }, { quoted: m });

      mecha.sendReact(m.chat, '✅', m.key); // Reaksi sukses
    } catch (err) {
      console.error(err);
      mecha.reply(m.chat, "Terjadi kesalahan saat mencari anime.", m);
    }
  },
  limit: true
};