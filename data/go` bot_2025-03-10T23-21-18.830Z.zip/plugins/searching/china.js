async function getRandomAnime() {
  const animeList = [
'https://files.catbox.moe/fry43i.jpg',
'https://files.catbox.moe/nh0877.jpg',
'https://files.catbox.moe/pm2pc3.png',
'https://files.catbox.moe/9dame6.jpg',
'https://files.catbox.moe/7hc8vf.jpg',
'https://files.catbox.moe/9268d2.jpg',
'https://files.catbox.moe/x2nr5l.jpg',
'https://files.catbox.moe/r0r7xe.jpg',
'https://files.catbox.moe/a3sm0x.jpg',
  ];

  const randomIndex = Math.floor(Math.random() * animeList.length);
  const randomAnime = animeList[randomIndex];

  return randomAnime;
}

exports.run = {
  usage: ['china'], // Change command to 'anime'
  category: 'asupan', // Change category for broader scope
  async: async (m, { func, mecha, users, setting, froms }) => {

    try {
      mecha.sendReact(m.chat, '🕒', m.key);
      const animeUrl = await getRandomAnime();
      // Send the image only if the user is an adult
      mecha.sendMessage(m.chat, {
        image: {
          url: animeUrl,
        },
        mimetype: 'image/jpeg',
      }, { quoted: m, ephemeralExpiration: 86400 });
    } catch (error) {
      console.error('Error fetching anime:', error);
      mecha.sendReact(m.chat, '❌', m.key);
    }
  },
limit: 3,
};