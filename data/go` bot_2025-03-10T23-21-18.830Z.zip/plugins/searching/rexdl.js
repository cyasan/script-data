const axios = require("axios");
const cheerio = require("cheerio");

exports.run = {
  usage: ["rexdl"],
  category: "searching",
  use: "query",
  async: async (m, { func, mecha }) => {
    if (!m.text) return mecha.reply(m.chat, func.example(m.cmd, "Minecraft"), m);

    mecha.sendReact(m.chat, "🕒", m.key); // Tampilkan reaksi loading

    try {
      const query = encodeURIComponent(m.text);
      const url = `https://rexdl.com/?s=${query}`;

      const { data } = await axios.get(url);
      const $ = cheerio.load(data);

      let result = [];

      $("div > div.post-content").each((index, element) => {
        const judul = $(element).find("h2.post-title > a").attr("title");
        const kategori = $(element).find("p.post-category").text().trim();
        const upload_date = $(element).find("p.post-date").text().trim();
        const deskripsi = $(element).find("div.entry.excerpt").text().trim();
        const link = $(element).find("h2.post-title > a").attr("href");
        const thumb = $("div > div.post-thumbnail > a > img").eq(index).attr("data-src");

        if (judul) {
          result.push({
            judul,
            kategori,
            upload_date,
            deskripsi,
            link,
            thumb,
          });
        }
      });

      // Jika tidak ada hasil
      if (result.length === 0) {
        return mecha.reply(m.chat, "Game atau aplikasi tidak ditemukan. Coba masukkan nama lain!", m);
      }

      // Ambil hasil pertama
      let game = result[0];

      let caption = `乂 *REXDL SEARCH*\n\n`;
      caption += `- *Judul:* ${game.judul}\n`;
      caption += `- *Kategori:* ${game.kategori}\n`;
      caption += `- *Tanggal Upload:* ${game.upload_date}\n`;
      caption += `- *Deskripsi:* ${game.deskripsi}\n\n`;
      caption += `*Download:* ${game.link}`;

      // Kirim dengan gambar jika tersedia
      if (game.thumb) {
        await mecha.sendMessage(
          m.chat,
          {
            image: { url: game.thumb },
            caption,
          },
          { quoted: m }
        );
      } else {
        mecha.reply(m.chat, caption, m);
      }

      mecha.sendReact(m.chat, "✅", m.key); // Tampilkan reaksi sukses
    } catch (error) {
      console.error("Error fetching Rexdl data:", error);
      mecha.reply(m.chat, "Terjadi kesalahan saat mengambil data dari Rexdl.", m);
    }
  },
  limit: true,
};