async function getRandomAnime() {
      const animeList = [
'https://telegra.ph/file/75193a893e38fc580afe6.jpg',
	'https://telegra.ph/file/217aa0f4ec76273808aa4.jpg',
	'https://telegra.ph/file/8a35d3446b97ae22c7b23.jpg',
	'https://telegra.ph/file/092df720701575a7ceaaa.jpg',
	'https://telegra.ph/file/a65184a676cd648de34c3.jpg',
	'https://telegra.ph/file/180e28807e78419d45537.jpg',
	'https://telegra.ph/file/140eff27be983e0cd6781.jpg',
	'https://telegra.ph/file/1581b791e16d0029e16b5.jpg',
	'https://telegra.ph/file/6a4b36372b4f265bae3bc.jpg',
	'https://telegra.ph/file/093caff422f194f00bc6c.jpg',
	'https://telegra.ph/file/2294b7ab49eca8a8046b2.jpg',
	'https://telegra.ph/file/869224d1c417e8b5c8ff1.jpg',
	'https://telegra.ph/file/a78443f0ee887f46808d7.jpg',
	'https://telegra.ph/file/1889878933264d16c58bf.jpg',
	'https://telegra.ph/file/735aeb47d9c4aa87aaaf3.jpg',
	'https://telegra.ph/file/fcf861516db09dda164e0.jpg',
	'https://telegra.ph/file/355d96d7e06d109435f67.jpg',
	'https://telegra.ph/file/f1db29ed188159d14fc44.jpg',
	'https://telegra.ph/file/d2f5e2aca7f2c8ec732f6.jpg',
	'https://telegra.ph/file/8d20d271911c64d1c4acf.jpg',
	'https://telegra.ph/file/ee5faa155d540e189687f.jpg',
	'https://telegra.ph/file/305301b1bc211a02bffce.jpg',
	'https://telegra.ph/file/d56bfca798e704148c592.jpg',
	'https://telegra.ph/file/433f5544a8de58b766248.jpg',
	'https://telegra.ph/file/adf02aabeeac135c40333.jpg',
	'https://telegra.ph/file/22fc7baa39472b570c23c.jpg',
	'https://telegra.ph/file/22fc7baa39472b570c23c.jpg',
	'https://telegra.ph/file/ac28e289077fa9bea1d72.jpg',
	'https://telegra.ph/file/cf387acdc48d2d65035b9.jpg',
	'https://telegra.ph/file/7a551521c4a620e6e2448.jpg',
	'https://telegra.ph/file/17d77676cafe1adb22951.jpg',
	'https://telegra.ph/file/6afbd19d5c5b61e715467.jpg',
	'https://telegra.ph/file/c32176197b2809065004f.jpg',
	'https://telegra.ph/file/496995500a75fcbbeec9d.jpg',
	'https://telegra.ph/file/ac05c193e77dc1eb42536.jpg',
	'https://telegra.ph/file/a43afff9eb761b45c7a44.jpg',
  ];

  const randomIndex = Math.floor(Math.random() * animeList.length);
  const randomAnime = animeList[randomIndex];

  return randomAnime;
}

exports.run = {
  usage: ['simpown'], // Change command to 'anime'
  category: 'anime', // Change category for broader scope
  async: async (m, { func, mecha, users, setting, froms }) => {
    let { age } = global.db.users[m.sender];
    if (users.age < 25) {
      mecha.sendMessage(m.chat, { text: `Kamu masih dibawah umur untuk menggunakan fitur ini`}, { quoted: m});
      // Exit the function immediately to prevent further execution
      return;
    }

    try {
      mecha.sendReact(m.chat, '🕒', m.key);
      const animeUrl = await getRandomAnime();
      // Send the image only if the user is an adult
      mecha.sendMessage(m.chat, {
        image: {
          url: animeUrl,
        },
        mimetype: 'image/jpeg',
      }, { quoted: m, ephemeralExpiration: 86400 });
    } catch (error) {
      console.error('Error fetching anime:', error);
      mecha.sendReact(m.chat, '❌', m.key);
    }
  },
limit: true,
premium: true,
private: true,
};