const axios = require('axios');
const cheerio = require('cheerio');

/* 
Created By Miftah 
Don't claim, okey 
*/

async function InstagramStalk(name) {
try {
const response = await axios.get(`https://dumpoir.com/v/${name}`);
const html = response.data;
const $ = cheerio.load(html);

const profile = $('img.skeleton.rounded-full').attr('src');
const username = $('h1.text-4xl.font-serif.text-stone-700.mb-1.w-full.inline.relative').text().trim();
const fullName = $('h2.text-2xl.font-serif.text-stone-500.mb-3').text().trim();
const bio = $('div.text-sm.font-serif').html().replace(/<br>/g, '\n').replace(/<\/?[^>]+(>|$)/g, "").trim();
const posts = $('div.stats .stat').eq(0).find('.stat-value').text().trim();
const followers = $('div.stats .stat').eq(1).find('.stat-value').text().trim();
const following = $('div.stats .stat').eq(2).find('.stat-value').text().trim();

const profileData = {
profile,
username,
fullName,
bio,
posts,
followers,
following
};

console.log(profileData);
return profileData;
} catch (error) {
console.log(error);
return null;
}
}

exports.run = {
usage: ['igstalk'],
use: 'username',
category: 'searching',
async: async (m, { func, mecha }) => {
// instagram stalk by SuryaDev
if (!m.text) return m.reply('Mohon input username Instagram yang akan di-stalk.');
mecha.sendReact(m.chat, '🕒', m.key);
try {
// stalking profil Instagram
const result = await InstagramStalk(m.text);
// menyusun dan mengirim informasi profil
const stalkMessage = `*INSTAGRAM STALK*

- *Username:* ${result.username}
- *Full Name:* ${result.fullName}
- *Followers:* ${result.followers}
- *Following:* ${result.following}
- *Total Posts:* ${result.posts}
- *Bio:* ${result.bio}`;
// mengirim gambar profil bersama dengan pesan teks
mecha.sendMessage(m.chat, {image: {url: result.profile}, caption: stalkMessage}, {quoted: m, ephemeralExpiration: m.expiration});
} catch (error) {
console.error('Error stalking Instagram profile:', error);
mecha.reply(m.chat, 'Terjadi kesalahan saat menyelidiki profil Instagram. Pastikan username yang dimasukkan benar dan coba lagi.', m);
}
},
limit: 3
}