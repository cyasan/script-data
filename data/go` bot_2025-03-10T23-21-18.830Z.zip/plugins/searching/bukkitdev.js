const axios = require("axios");
const cheerio = require("cheerio");

class BukkitDev {
    async getPopular() {
        try {
            const { data } = await axios.get("https://dev.bukkit.org/bukkit-plugins?page=1");
            const $ = cheerio.load(data);
            const plugins = [];

            $("li.project-list-item").each((index, element) => {
                const name = $(element).find(".info.name .name-wrapper a").text();
                const author = $(element).find(".info.name .byline a").text();
                const downloads = $(element).find(".info.stats .e-download-count").text();
                const updateDate = $(element).find(".info.stats .e-update-date abbr").attr("title");
                const description = $(element).find(".description p").text();
                const imageUrl = $(element).find(".avatar img").attr("src");
                const projectUrl = $(element).find(".avatar a").attr("href");
                const categories = [];

                $(element).find(".categories-box .category-icons a").each((i, catElement) => {
                    const categoryTitle = $(catElement).attr("title");
                    categories.push(categoryTitle);
                });

                plugins.push({
                    name,
                    author,
                    downloads,
                    updateDate,
                    description,
                    imageUrl,
                    projectUrl,
                    categories
                });
            });

            return plugins.length ? plugins : { error: "Tidak ada plugin populer yang ditemukan." };
        } catch (error) {
            return { error: error.message };
        }
    }
}

// **Fitur untuk Bot**
exports.run = {
    usage: ["bukkitdev"],
    category: "searching",
    async: async (m, { mecha }) => {
        mecha.sendReact(m.chat, "🕒", m.key); // Reaksi loading

        try {
            const bukkitdev = new BukkitDev();
            const popularPlugins = await bukkitdev.getPopular();
            if (popularPlugins.error) throw new Error(popularPlugins.error);

            let caption = "乂 BUKKITDEV POPULAR PLUGINS\n\n";
            popularPlugins.slice(0, 5).forEach((plugin, i) => {
                caption += `${i + 1}. ${plugin.name}\n`;
                caption += `- Author: ${plugin.author}\n`;
                caption += `- Downloads: ${plugin.downloads}\n`;
                caption += `- Update: ${plugin.updateDate}\n`;
                caption += `- Deskripsi: ${plugin.description}\n`;
                caption += `- Link: ${plugin.projectUrl}\n\n`;
            });

            return mecha.sendMessage(m.chat, { text: caption }, { quoted: m });
        } catch (err) {
            console.error("Error:", err.message);
            mecha.reply(m.chat, "Gagal mengambil daftar plugin populer di BukkitDev.", m);
        }

        mecha.sendReact(m.chat, "✅", m.key); // Reaksi sukses
    },
    limit: 3,
};