const axios = require('axios');
const cheerio = require('cheerio');

class mcaddon {
  // Fungsi untuk mencari modpack berdasarkan nama
  static async addons(name) {
    const { data } = await axios.get(`https://mmcreviews.com/?s=${name}&id=1274&post_type=post`);
    const $ = cheerio.load(data);

    const modpacks = [];

    // Mengambil data modpack dari hasil pencarian
    $('.post').each((i, element) => {
      const title = $(element).find('.entry-title a').text().trim();
      const link = $(element).find('.entry-title a').attr('href');
      const description = $(element).find('.ast-excerpt-container p').text().trim();

      // Memperbaiki pengambilan rating, jika tidak ada tampilkan "Tidak tersedia"
      const rating = $(element).find('.glsr-summary-rating .glsr-tag-value').text().trim();
      const validRating = rating && !isNaN(rating) ? rating : "Tidak tersedia";

      const tags = [];
      
      // Mengambil tag dari modpack
      $(element).find('.taxonomy-tag a').each((i, tag) => {
        tags.push($(tag).text().trim());
      });

      modpacks.push({
        title,
        link,
        description,
        rating: validRating,
        tags
      });
    });

    return modpacks; // Mengembalikan daftar modpacks
  }

  // Fungsi untuk mengambil detail modpack dari URL
  static async detailAddons(url) {
    const { data } = await axios.get(url);
    const $ = cheerio.load(data);

    const image = $('figure img').attr('src');
    const title = $('h1').text();
    const subtitle = $('h4').text();
    const gameplay = $('.stk-block-text__text').text();

    return {
      image,
      title,
      subtitle,
      gameplay
    };
  }
}

exports.run = {
  usage: ["mcaddon"],
  category: "searching",
  use: "query", // Penggunaan query pencarian modpack
  async: async (m, { func, mecha }) => {
    if (!m.text) return mecha.reply(m.chat, func.example(m.cmd, "shaders"), m);

    mecha.sendReact(m.chat, "🕒", m.key); // Reaksi loading

    try {
      const searchName = m.text; // Nama modpack yang dicari
      const modpacks = await mcaddon.addons(searchName);

      if (modpacks.length === 0) {
        return mecha.reply(m.chat, "Modpack tidak ditemukan. Coba kata kunci lain.", m);
      }

      let message = `乂 ADDON SEARCH\n\nHasil pencarian modpack untuk: *${searchName}*\n\n`;

      // Menampilkan hasil pencarian modpacks
      modpacks.forEach((mod, index) => {
        message += `${index + 1}. **${mod.title}**\n`;
        message += `- Rating: ${mod.rating || "Tidak tersedia"}\n`;
        message += `- Tags: ${mod.tags.join(", ") || "Tidak tersedia"}\n`;
        message += `- Deskripsi: ${mod.description.slice(0, 100)}...\n`;
        message += `- Link: (${mod.link})\n\n`;
      });

      // Mengirimkan pesan dengan daftar modpacks
      await mecha.reply(m.chat, message, m);

      mecha.sendReact(m.chat, "✅", m.key); // Reaksi sukses
    } catch (error) {
      console.error('Error fetching Minecraft modpacks:', error);
      mecha.reply(m.chat, "Terjadi kesalahan saat mengambil data modpack.", m);
    }
  },
  premium: false, // Tidak perlu premium
  limit: 5
};