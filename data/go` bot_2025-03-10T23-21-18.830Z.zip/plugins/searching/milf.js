async function getRandomAnime() {
  const animeList = [
  "https://i.pinimg.com/236x/3c/03/c1/3c03c1a091ac6b6800ec9c16989ef796.jpg",
  "https://i.pinimg.com/236x/c1/d7/d8/c1d7d8e3190475a49805f08ab1374616.jpg",
  "https://i.pinimg.com/236x/01/c0/4b/01c04bb565a22964d40a0dabe5125bc5.jpg",
  "https://i.pinimg.com/236x/a7/d0/b7/a7d0b7018e68befe4d55a991c64c7a4a.jpg",
  "https://i.pinimg.com/236x/bf/7c/4d/bf7c4dcc62230bf25a9fee37d8eecc44.jpg",
  "https://i.pinimg.com/236x/89/3d/d9/893dd90d89d908d4dc87421f1c34c582.jpg",
  "https://i.pinimg.com/236x/be/bb/11/bebb111a12f7d7f4582f83a9951d17fb--cartoon-girls-anime-girls.jpg",
  "https://i.pinimg.com/474x/ec/3f/bb/ec3fbb0e9474635531a1ec92f278bcbe.jpg",
  "https://i.pinimg.com/236x/d5/3e/6e/d53e6eb1943770b6aab2d9af11d7da90.jpg",
  "https://i.pinimg.com/474x/9b/3b/a1/9b3ba119c7dad7f8c0699e4aaeaeaaf3.jpg",
  "https://i.pinimg.com/236x/c7/40/7e/c7407e396dafc82c990e8edfb1762c45--anime.jpg",
  "https://i.pinimg.com/474x/79/76/d0/7976d0e1d79a79981982039eccdb6ee0.jpg",
  "https://i.pinimg.com/originals/72/cc/56/72cc5683fc24a2ea09fac0f058287ecc.jpg",
  "https://i.pinimg.com/736x/c0/54/30/c05430d7980495c9722b7832a6f8d57f.jpg",
  "https://i.pinimg.com/236x/d0/85/d7/d085d73ca48e144cc129779127efe039--anime-hot-manga-anime.jpg",
  "https://i.pinimg.com/236x/5b/d5/92/5bd5920d0f0261ad820c4ec03feb2606.jpg",
  "https://i.pinimg.com/originals/ea/63/ea/ea63ea90a0ef21b660ce3cc3307ec9c2.png",
  "https://i.pinimg.com/originals/ed/ef/b4/edefb45a89adc0703faabd46a103aa8a.jpg",
  "https://i.pinimg.com/originals/cd/ab/11/cdab11151d190db3ab961a38cf8c6a3d.jpg",
  "https://i.pinimg.com/236x/50/33/c0/5033c09feaabe352b01b5ea776a7c33f.jpg",
  "https://i.pinimg.com/474x/1a/c6/f0/1ac6f037012c89c11e536dec800566e1--hot-anime-anime-girls.jpg",
  "https://i.pinimg.com/originals/91/70/d0/9170d099128a8d9eba606f2f7dc4cce7.png",
  "https://i.pinimg.com/280x280_RS/06/b1/4f/06b14ffb720e9afcd3894334467fbbe5.jpg",
  "https://i.pinimg.com/564x/78/e7/4d/78e74d5380f1f4fa072423515c250902.jpg",
  "https://i.pinimg.com/474x/21/88/78/2188786d9f6782175b63eda6d9f6e7ee.jpg",
  "https://i.pinimg.com/originals/5d/91/d4/5d91d44fbdfac4db3ce1924f202a9d5e.jpg",
  "https://i.pinimg.com/564x/10/ee/e2/10eee28cb5bd29a8edba43ba9a7ceee6.jpg",
  "https://i.pinimg.com/originals/1d/7c/46/1d7c462373bf395dfcce401e2de155a9.jpg",
  "https://i.pinimg.com/originals/08/49/21/08492107aba5784c15326c86e93eede7.jpg",
  "https://i.pinimg.com/474x/2c/80/cc/2c80ccaefbfe76e064d468b27e943eb1.jpg",
  "https://i.pinimg.com/736x/f1/50/85/f15085cd3e9ccbb02e181564f3522871.jpg",
  "https://i.pinimg.com/originals/c4/6a/1e/c46a1ef1caafea1e9072003a50004dcc.jpg",
  "https://i.pinimg.com/236x/3c/b4/db/3cb4db66cb8417a505c6f8541509839f.jpg",
  "https://i.pinimg.com/originals/57/27/96/5727967a6eacd7e31da3fb8c7fb61312.jpg",
  "https://i.pinimg.com/236x/d8/b6/17/d8b617d4945149166eca4619ae68bb16--ecchi-girl-milk.jpg",
  "https://i.pinimg.com/originals/bd/13/4e/bd134e3ec32c16fbc729e098f1829d69.png",
  "https://i.pinimg.com/originals/14/af/a3/14afa3aa51ea205722e3a8bf2a2f29da.jpg",
  "https://i.pinimg.com/originals/df/bb/4a/dfbb4ac1a8ae03cd3cd435391f463925.jpg",
  "https://i.pinimg.com/736x/96/1e/04/961e04b899a53ee8a26f6d409998ac24.jpg",
  "https://i.pinimg.com/236x/1d/18/a8/1d18a80e4ba325093ae6cad3d44a7679.jpg",
  "https://i.pinimg.com/236x/55/98/41/559841380e4436f4423aeaf9749cf876--anime-hot-anime-sexy.jpg",
  "https://i.pinimg.com/originals/76/74/14/767414880d6b439dde034d8e71313be2.jpg",
  "https://i.pinimg.com/originals/fb/5b/27/fb5b27c4da3304222289bf065b82fd16.jpg",
  "https://i.pinimg.com/564x/91/3b/f5/913bf5ba9c5caca5387b4e575d456f65.jpg",
  "https://i.pinimg.com/474x/e2/02/fd/e202fdf9a9c4833cd9582bafc8d8b820.jpg",
  "https://i.pinimg.com/236x/4a/2a/b7/4a2ab78e2ad5f4753ad3235306b5b7d9--anime-hot-manga-anime.jpg"
];

  const randomIndex = Math.floor(Math.random() * animeList.length);
  return animeList[randomIndex];
}

exports.run = {
  usage: ['milf'], // Change command to 'anime'
  category: 'nsfw', // Change category for broader scope
  async: async (m, { func, mecha, users, setting, froms }) => {
    let { age } = global.db.users[m.sender];
    if (users.age < 20) {
      mecha.sendMessage(m.chat, { text: `Kamu masih dibawah umur untuk menggunakan fitur ini` }, { quoted: m });
      return; // Exit the function immediately
    }

    try {
      mecha.sendReact(m.chat, '🕒', m.key);
      const animeUrl = await getRandomAnime();

      // Send the image and store the sent message
      const sentMessage = await mecha.sendMessage(m.chat, {
        image: {
          url: animeUrl,
        },
        mimetype: 'image/jpeg',
      }, { quoted: m, ephemeralExpiration: 86400 });

      // Set a timeout to delete the message after 5 minutes
      setTimeout(() => {
        mecha.sendMessage(m.chat, { delete: sentMessage.key });
      }, 60000); // 5 minutes in milliseconds
    } catch (error) {
      console.error('Error fetching anime:', error);
      mecha.sendReact(m.chat, '❌', m.key);
    }
  },
  limit: true,
  premium: true,
  private: false,
};