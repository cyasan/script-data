const axios = require("axios");
const cheerio = require("cheerio");

exports.run = {
  usage: ["resep"],
  category: "searching",
  use: "nama makanan",
  async: async (m, { func, mecha }) => {
    if (!m.text) return mecha.reply(m.chat, func.example(m.cmd, "nasi goreng"), m);

    mecha.sendReact(m.chat, "🕒", m.key); // Tampilkan reaksi loading

    try {
      const query = encodeURIComponent(m.text);
      const url = `https://resepkoki.id/?s=${query}`; // Sesuaikan dengan sumber yang digunakan

      const { data } = await axios.get(url);
      const $ = cheerio.load(data);

      // Cek apakah ada hasil pencarian
      const firstResult = $("div.archive-post > a").attr("href");
      if (!firstResult) {
        return mecha.reply(m.chat, "Resep tidak ditemukan. Coba masukkan nama makanan lain!", m);
      }

      // Ambil halaman detail resep
      const { data: recipePage } = await axios.get(firstResult);
      const $$ = cheerio.load(recipePage);

      const judul = $$("h1").text().trim();
      const waktu = $$("li:contains('Waktu')").text().replace("Waktu:", "").trim();
      const tingkatKesulitan = $$("li:contains('Tingkat')").text().replace("Tingkat kesulitan:", "").trim();
      const thumb = $$("div.featured-image img").attr("src");

      // Ambil bahan-bahan
      let bahan = "";
      $$(".ingredient-list li").each((i, el) => {
        bahan += `- ${$$(el).text().trim()}\n`;
      });

      // Ambil langkah-langkah
      let langkah = "";
      $$(".step-list li").each((i, el) => {
        langkah += `${i + 1}. ${$$(el).text().trim()}\n\n`;
      });

      // Jika data kosong, tampilkan pesan error
      if (!judul || !bahan || !langkah) {
        return mecha.reply(m.chat, "Resep tidak ditemukan. Coba masukkan nama makanan lain!", m);
      }

      let caption = `乂 *RESEP MASAKAN*\n\n`;
      caption += `- *Nama:* ${judul}\n`;
      caption += `- *Waktu:* ${waktu}\n`;
      caption += `- *Tingkat Kesulitan:* ${tingkatKesulitan}\n\n`;
      caption += `*Bahan-bahan:*\n${bahan}\n`;
      caption += `*Langkah-langkah:*\n${langkah}`;
      caption += `- *Sumber:* [Klik Disini](${firstResult})\n`;

      // Kirim dengan gambar jika tersedia
      if (thumb) {
        await mecha.sendMessage(
          m.chat,
          {
            image: { url: thumb },
            caption,
          },
          { quoted: m }
        );
      } else {
        mecha.reply(m.chat, caption, m);
      }

      mecha.sendReact(m.chat, "✅", m.key); // Tampilkan reaksi sukses
    } catch (err) {
      console.error("Error fetching recipe data:", err);
      mecha.reply(m.chat, "Terjadi kesalahan saat mengambil data resep.", m);
    }
  },
  limit: true,
};