const axios = require("axios");

class Bstation {
    async search(query, page = 1) {
        if (!query) throw new Error("Masukkan kata kunci untuk pencarian Bstation.");

        try {
            const res = await axios.get("https://api.bilibili.tv/intl/gateway/web/v2/search_v2", {
                params: {
                    's_locale': 'id_ID',
                    'platform': 'web',
                    keyword: query,
                    highlight: 1,
                    pn: page,
                    ps: 10, // Menampilkan 10 hasil per halaman
                }
            });

            const modules = res.data.data.modules;
            if (!modules || modules.length === 0) {
                throw new Error("Hasil pencarian tidak ditemukan.");
            }

            const results = modules[0].items.map((item, index) => ({
                index: index + 1,
                title: item.title,
                url: `https://bilibili.tv/video/${item.aid}`,
                id: item.aid,
                author: item.author,
                thumbnail: item.cover,
                views: item.view,
                duration: item.duration,
            }));

            return {
                status: true,
                results
            };
        } catch (error) {
            console.error(`Terjadi kesalahan: ${error.message}`);
            return {
                status: false,
                message: "Pencarian tidak ditemukan atau terjadi kesalahan."
            };
        }
    }
}

// Fitur untuk bot
exports.run = {
    usage: ["bstationsearch"],
    hidden: ["bsearch"],
    category: "searching",
    use: "kata kunci",
    async: async (m, { text, mecha }) => {
        if (!text) return mecha.reply(m.chat, "Masukkan kata kunci untuk pencarian Bstation.", m);

        mecha.sendReact(m.chat, "🕒", m.key); // Reaksi loading

        try {
            const bstation = new Bstation();
            const searchData = await bstation.search(text);

            if (!searchData.status) {
                throw new Error(searchData.message);
            }

            let caption = `乂 BSTATION SEARCH\n\nKata Kunci: ${text}\n\n`;
            searchData.results.forEach((video) => {
                caption += `${video.index}. ${video.title}\n`;
                caption += `- Author: ${video.author}\n`;
                caption += `- Views: ${video.views}\n`;
                caption += `- Durasi: ${video.duration} detik\n`;
                caption += `- Link: ${video.url}\n\n`;
            });

            await mecha.sendMessage(m.chat, {
                image: { url: searchData.results[0].thumbnail },
                caption: caption,
            }, { quoted: m });

            mecha.sendReact(m.chat, "✅", m.key); // Reaksi sukses
        } catch (err) {
            console.error("Error:", err.message);
            mecha.reply(m.chat, "Gagal mencari video Bstation. Coba lagi nanti.", m);
        }
    },
    limit: 5,
};