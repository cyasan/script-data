async function getRandomAnime() {
  const animeList = [
  "https://b.top4top.io/m_1930thxw90.mp4",
  "https://d.top4top.io/m_1930pezhp0.mp4",
  "https://c.top4top.io/m_1930cjgbx0.mp4",
  "https://b.top4top.io/m_1930v6vhg0.mp4",
  "https://f.top4top.io/m_1930uh7ud0.mp4",
  "https://a.top4top.io/m_1930c9cpb0.mp4",
  "https://k.top4top.io/m_19308amkf0.mp4",
  "https://d.top4top.io/m_1930wjaq60.mp4",
  "https://i.top4top.io/m_1930n2um40.mp4",
  "https://i.top4top.io/m_1930e14pi0.mp4",
  "https://i.top4top.io/m_1930w6lwf0.mp4",
  "https://e.top4top.io/m_19307autl0.mp4",
  "https://d.top4top.io/m_1930i6tfc0.mp4",
  "https://c.top4top.io/m_1930qmr7u0.mp4",
  "https://d.top4top.io/m_1930itbte1.mp4",
  "https://i.top4top.io/m_1930ze4oq0.mp4",
  "https://j.top4top.io/m_1930kkqyh1.mp4",
  "https://f.top4top.io/m_1930zevlz0.mp4",
  "https://g.top4top.io/m_1930q0apu1.mp4",
  "https://h.top4top.io/m_1930trfsv2.mp4"
];

  const randomIndex = Math.floor(Math.random() * animeList.length);
  return animeList[randomIndex];
}

exports.run = {
  usage: ['panrika'], // Change command to 'anime'
  category: 'asupan', // Change category for broader scope
  async: async (m, { func, mecha, users, setting, froms }) => {
    let { age } = global.db.users[m.sender];
    if (users.age < 20) {
      mecha.sendMessage(m.chat, { text: `Kamu masih dibawah umur untuk menggunakan fitur ini` }, { quoted: m });
      return; // Exit the function immediately
    }

    try {
      mecha.sendReact(m.chat, '🕒', m.key);
      const animeUrl = await getRandomAnime();

      // Send the image and store the sent message
      const sentMessage = await mecha.sendMessage(m.chat, {
        video: {
          url: animeUrl,
        },
        mimetype: 'video/mp4',
      }, { quoted: m, ephemeralExpiration: 86400 });

      // Set a timeout to delete the message after 5 minutes
      setTimeout(() => {
        mecha.sendMessage(m.chat, { delete: sentMessage.key });
      }, 60000); // 5 minutes in milliseconds
    } catch (error) {
      console.error('Error fetching anime:', error);
      mecha.sendReact(m.chat, '❌', m.key);
    }
  },
  limit: true,
  premium: true,
  private: false,
};