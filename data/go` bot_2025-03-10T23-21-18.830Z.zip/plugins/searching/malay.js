async function getRandomAnime() {
  const animeList = [
'https://files.catbox.moe/kjte2y.jpg',
'https://files.catbox.moe/zjbzjv.jpg',
'https://files.catbox.moe/42r9bu.jpg',
'https://files.catbox.moe/3v8bwb.jpg',
'https://files.catbox.moe/y595f9.jpg',
'https://files.catbox.moe/25jcu1.jpg',
'https://files.catbox.moe/iy537g.jpg',
'https://files.catbox.moe/1jsv47.jpg',
'https://files.catbox.moe/kq2etc.jpg',
  ];

  const randomIndex = Math.floor(Math.random() * animeList.length);
  const randomAnime = animeList[randomIndex];

  return randomAnime;
}

exports.run = {
  usage: ['malaysia'],
  category: 'asupan', // Change category for broader scope
  async: async (m, { func, mecha, users, setting, froms }) => {

    try {
      mecha.sendReact(m.chat, '🕒', m.key);
      const animeUrl = await getRandomAnime();
      // Send the image only if the user is an adult
      mecha.sendMessage(m.chat, {
        image: {
          url: animeUrl,
        },
        mimetype: 'image/jpeg',
      }, { quoted: m, ephemeralExpiration: 86400 });
    } catch (error) {
      console.error('Error fetching anime:', error);
      mecha.sendReact(m.chat, '❌', m.key);
    }
  },
limit: 3,
};