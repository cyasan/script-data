const axios = require('axios');
const cheerio = require('cheerio');

const igstalk2 = async (user) => {
try {
const {data} = await axios.get('https://i.instagram.com/api/v1/users/web_profile_info/?username=' + user, {
headers: {
"cookie": 'sessionid=54783047583%3Ai4JciXYggGKxDb%3A17%3AAYfjd_uYP5UXrpXdXRbG0EJ-0acF4r7lMEZNaCXIcQ',
"user-agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.5005.61 Safari/537.36",
"x-asbd-id": "198387",
"x-csrftoken": "VXLPx1sgRb8OCHg9c2NKXbfDndz913Yp",
"x-ig-app-id": "936619743392459",
"x-ig-www-claim": "0"
}
})
return(data.status == 'ok' ? {
status: true,
profile: {
low: data.data.user.profile_pic_url,
high: data.data.user.profile_pic_url_hd,
},
data: {
url: data.data.user.external_url,
id: data.data.user.id,
fullname: data.data.user.full_name,
private: data.data.user.is_private,
verified: data.data.user.is_verified,
bio: data.data.user.biography,
follower: data.data.user.edge_followed_by.count,
following: data.data.user.edge_follow.count,
conneted_fb: data.data.user.connected_fb_page,
videotimeline: data.data.user.edge_felix_video_timeline.count,
timeline: data.data.user.edge_owner_to_timeline_media.count,
savedmedia: data.data.user.edge_saved_media.count,
collections: data.data.user.edge_media_collections.count,
}
} : {status: false, message: 'user not found'})
} catch {
return ({
status: false,
message: 'user not found'
})
}
}

exports.run = {
usage: ['igstalk2'],
use: 'username',
category: 'searching',
async: async (m, { func, mecha, comand }) => {
if (!m.text) return m.reply(func.example(comand, 'surya_skylark05'))
m.reply(global.mess.wait)
await igstalk2(m.text).then(res => {
if (!res.status) return m.reply(global.mess.error.api)
let txt = `乂  *STALKER INSTAGRAM*\n`
txt += `\n◦  Fullname : ${res.data.fullname ? res.data.fullname : '-'}`
txt += `\n◦  ID : ${res.data.id}`
txt += `\n◦  Followers : ${res.data.follower}`
txt += `\n◦  Following : ${res.data.following}`
txt += `\n◦  Private : ${res.data.private ? 'Yes' : 'No'}`
txt += `\n◦  Verified : ${res.data.verified ? 'Yes' : 'No'}`
txt += `\n◦  Conneted FB : ${res.data.conneted_fb !== null ? 'Yes' : 'No'}`
txt += `\n◦  Video Timeline : ${res.data.videotimeline}`
txt += `\n◦  Timeline : ${res.data.timeline}`
txt += `\n◦  Saved Media : ${res.data.savedmedia}`
txt += `\n◦  Collections : ${res.data.collections}`
txt += `\n◦  Bio : ${res.data.bio ? res.data.bio : '-'}`
txt += `\n◦  Url : ${res.data.url ? res.data.url : '-'}`
mecha.sendMessage(m.chat, {image: {url : res.profile.high}, caption: txt}, {quoted: m, ephemeralExpiration: m.expiration})
}).catch((e) => m.reply('Username tidak ditemukan!'))
},
limit: true
}