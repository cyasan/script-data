async function getRandomAnime() {
  const animeList = [
'https://files.catbox.moe/3jswsn.jpg',
'https://files.catbox.moe/oowlu3.jpg',
'https://files.catbox.moe/engpeb.jpg',
'https://files.catbox.moe/om2jej.jpg',
'https://files.catbox.moe/kw0by5.jpg',
'https://files.catbox.moe/kxwhdl.jpg',
'https://files.catbox.moe/03562t.jpg',
'https://files.catbox.moe/wdph46.jpg',
'https://files.catbox.moe/fha4ab.jpg',
'https://files.catbox.moe/2new0u.jpg',
  ];

  const randomIndex = Math.floor(Math.random() * animeList.length);
  const randomAnime = animeList[randomIndex];

  return randomAnime;
}

exports.run = {
  usage: ['cosplaygirl'],
hidden: ['cpgirl'], 
  category: 'asupan', // Change category for broader scope
  async: async (m, { func, mecha, users, setting, froms }) => {

    try {
      mecha.sendReact(m.chat, '🕒', m.key);
      const animeUrl = await getRandomAnime();
      // Send the image only if the user is an adult
      mecha.sendMessage(m.chat, {
        image: {
          url: animeUrl,
        },
        mimetype: 'image/jpeg',
      }, { quoted: m, ephemeralExpiration: 86400 });
    } catch (error) {
      console.error('Error fetching anime:', error);
      mecha.sendReact(m.chat, '❌', m.key);
    }
  },
limit: 3,
};