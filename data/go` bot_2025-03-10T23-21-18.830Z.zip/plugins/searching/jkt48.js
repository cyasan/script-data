const axios = require("axios");
const cheerio = require("cheerio");

exports.run = {
  usage: ["jkt48"],
  category: "searching",
  use: "nama member",
  async: async (m, { func, mecha }) => {
    if (!m.text) return mecha.reply(m.chat, func.example(m.cmd, "Freya"), m);

    mecha.sendReact(m.chat, "🕒", m.key); // Reaksi loading

    try {
      const { data } = await axios.get("https://jkt48.com/member/list?lang=id");
      const $ = cheerio.load(data);

      let members = [];
      $(".member-item").each((index, element) => {
        let name = $(element).find(".member-item-name").text().trim();
        let position = $(element).find(".member-item-position").text().trim();
        let image = $(element).find("img").attr("src");

        // Jika URL gambar tidak lengkap, tambahkan domain
        if (image && !image.startsWith("http")) {
          image = "https://jkt48.com" + image;
        }

        members.push({ name, position, image });
      });

      // Debugging: Cek apakah data terambil dengan benar
      console.log("Daftar Member:", members);

      // Cari member berdasarkan input pengguna
      let member = members.find(mb => mb.name.toLowerCase().includes(m.text.toLowerCase()));

      if (!member) {
        return mecha.reply(m.chat, "Member tidak ditemukan. Pastikan nama benar!", m);
      }

      let caption = `乂 *JKT48 MEMBER*\n\n`;
      caption += `- *Nama:* ${member.name}\n`;
      caption += `- *Posisi:* ${member.position}\n\n`;
      caption += `_Data dari JKT48 Official_`;

      await mecha.sendMessage(m.chat, {
        image: { url: member.image },
        caption
      }, { quoted: m });

      mecha.sendReact(m.chat, "✅", m.key); // Reaksi sukses
    } catch (err) {
      console.error("Error fetching JKT48 members:", err);
      mecha.reply(m.chat, "Terjadi kesalahan saat mencari member JKT48.", m);
    }
  },
  limit: true
};