async function getRandomAnime(command) {
    if (!command) {
        console.error('Command tidak tersedia!');
        return null;
    }

    const animeUrl = `https://raw.githubusercontent.com/aerovoid4/Media/master/${command}.json`;
    console.log(`Fetching data from: ${animeUrl}`); // Debugging URL

    try {
        const response = await fetch(animeUrl);
        if (!response.ok) {
            console.error(`Error: ${response.status} - ${response.statusText}`);
            return null;
        }

        const data = await response.json();
        console.log(`Data received for ${command}:`, data); // Debugging data

        // Pastikan data adalah array sebelum mengambil gambar secara acak
        if (Array.isArray(data) && data.length > 0) {
            const randomIndex = Math.floor(Math.random() * data.length);
            return data[randomIndex]; // Mengembalikan URL gambar
        } else {
            console.error(`Data tidak valid untuk ${command}`);
        }
    } catch (error) {
        console.error(`Error fetching data for ${command}:`, error);
    }

    return null; // Jika terjadi error atau data tidak ditemukan
}

exports.run = {
    usage: [
        'akira', 'akiyama', 'ana', 'asuna', 'boruto', 'chiho', 'chitoge', 'cyber', 'deidara',
        'doraemon', 'elaina', 'emilia', 'erza', 'exo', 'gremory', 'hestia', 'Husbu', 'inori',
        'isuzu', 'itachi', 'itori', 'jennie', 'jiso', 'justina', 'kaga', 'kagura', 'kakasih',
        'kaori', 'shortquote', 'keneki', 'kotori', 'kurumi', 'lisa', 'loli2', 'madara', 'megumin',
        'mikasa', 'mikey', 'minato', 'naruto', 'nekonime', 'nezuko', 'onepiece', 'randomnime',
        'randomnime2', 'rize', 'rose', 'sagiri', 'sakura', 'sasuke', 'satanic', 'shina', 'shinka',
        'shinomiya', 'shizuka', 'shota', 'tejina', 'toukachan', 'tsunade', 'waifu2', 'yotsuba',
        'yuki', 'yulibocil', 'yumeko'
    ],
    category: 'anime',
    async: async (m, { func, mecha, users, setting, froms }) => {
        const command = m.command; // Ambil perintah pengguna
        console.log(`Command received: ${command}`); // Debugging

        if (!command) {
            mecha.sendMessage(m.chat, { text: '⚠ Command tidak ditemukan!' }, { quoted: m });
            return;
        }

        try {
            mecha.sendReact(m.chat, '🕒', m.key);
            const animeUrl = await getRandomAnime(command);

            if (animeUrl) {
                mecha.sendMessage(m.chat, {
                    image: { url: animeUrl },
                    caption: `乂 *${command.toUpperCase()}*`,
                }, { quoted: m, ephemeralExpiration: 86400 });
            } else {
                mecha.sendMessage(m.chat, { text: `⚠ Gambar untuk *${command}* tidak ditemukan!` }, { quoted: m });
            }
        } catch (error) {
            console.error('Error fetching anime:', error);
            mecha.sendReact(m.chat, '❌', m.key);
        }
    },
    limit: true,
};