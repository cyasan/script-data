const axios = require("axios");
const cheerio = require("cheerio");

exports.run = {
  usage: ["komiku"],
  category: "searching",
  use: "nama anime",
  async: async (m, { func, mecha }) => {
    if (!m.text) return mecha.reply(m.chat, func.example(m.cmd, "One Piece"), m);

    mecha.sendReact(m.chat, "🕒", m.key); // Reaksi loading

    try {
      const { data } = await axios.get(
        `https://api.komiku.id/?post_type=anime&s=${encodeURIComponent(m.text)}&APIKEY=undefined`
      );

      const $ = cheerio.load(data);
      let animeList = [];

      $(".bge").each((i, elem) => {
        const title = $(elem).find("h3").text().trim();
        const genre = $(elem).find(".tpe1_inf b").text().trim();
        const description = $(elem).find("p").text().trim();
        const imageUrl = $(elem).find("img").attr("src");
        const animeUrl = $(elem).find("a").attr("href");

        animeList.push({
          title,
          genre,
          description,
          img: imageUrl.startsWith("http") ? imageUrl : `https://komiku.id/${imageUrl}`,
          url: `https://komiku.id/${animeUrl}`,
        });
      });

      if (animeList.length === 0) {
        return mecha.reply(m.chat, "Anime tidak ditemukan. Coba kata kunci lain!", m);
      }

      let anime = animeList[0]; // Ambil hasil pertama
      let caption = `乂 *SEARCHING ANIME*\n\n`;
      caption += `- *Judul:* ${anime.title}\n`;
      caption += `- *Genre:* ${anime.genre}\n`;
      caption += `- *Deskripsi:* ${anime.description}\n`;
      caption += `- *Link:* ${anime.url}\n\n`;
      caption += `_Data dari Komiku_`;

      await mecha.sendMessage(
        m.chat,
        {
          image: { url: anime.img },
          caption,
        },
        { quoted: m }
      );

      mecha.sendReact(m.chat, "✅", m.key); // Reaksi sukses
    } catch (err) {
      console.error("Error fetching anime data:", err);
      mecha.reply(m.chat, "Terjadi kesalahan saat mencari anime.", m);
    }
  },
  limit: true,
};