const axios = require("axios");
const cheerio = require("cheerio");

exports.run = {
  usage: ["ffnews"],
  category: "searching",
  async: async (m, { mecha, isPremium }) => {
    mecha.sendReact(m.chat, "🕒", m.key); // Reaksi loading

    try {
      // Ambil data dari situs resmi Free Fire
      const { data } = await axios.get("https://ff.garena.com/id/news/");
      const $ = cheerio.load(data);
      let results = [];

      $(".news-item.news-elem").each((i, elem) => {
        let time = $(elem).find(".news-time").text().trim();
        let title = $(elem).find(".news-title").text().trim();
        let link = $(elem).find("a").attr("href").trim();

        if (title && link) {
          results.push({
            title,
            time,
            link: "https://ff.garena.com" + link,
          });
        }
      });

      if (results.length === 0) return mecha.reply(m.chat, "Tidak ada berita terbaru saat ini.", m);

      // Jumlah berita berdasarkan status pengguna
      let limitNews = isPremium ? 10 : 3; // Premium: 10 berita, Free: 3 berita

      let caption = `乂 FREE FIRE NEWS & EVENTS\n\n`;
      results.slice(0, limitNews).forEach((news, i) => {
        caption += `${i + 1}. ${news.title}\nTanggal: ${news.time}\nBaca selengkapnya: ${news.link}\n\n`;
      });

      mecha.reply(m.chat, caption, m);
      mecha.sendReact(m.chat, "✅", m.key); // Reaksi sukses
    } catch (err) {
      console.error("Error fetching Free Fire news data:", err);
      mecha.reply(m.chat, "Terjadi kesalahan saat mencari berita/event Free Fire.", m);
    }
  },
  limit: true,
};