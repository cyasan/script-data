async function getRandomAnime(command) {
    if (!command) {
        console.error('Command tidak tersedia!');
        return null;
    }

    const animeUrl = `https://raw.githubusercontent.com/aerovoid4/Media/master/${command}.json`;
    console.log(`Fetching data from: ${animeUrl}`); // Debugging URL

    try {
        const response = await fetch(animeUrl);
        if (!response.ok) {
            console.error(`Error: ${response.status} - ${response.statusText}`);
            return null;
        }

        const data = await response.json();
        console.log(`Data received for ${command}:`, data); // Debugging data

        // Pastikan data adalah array sebelum mengambil gambar secara acak
        if (Array.isArray(data) && data.length > 0) {
            const randomIndex = Math.floor(Math.random() * data.length);
            return data[randomIndex]; // Mengembalikan URL gambar
        } else {
            console.error(`Data tidak valid untuk ${command}`);
        }
    } catch (error) {
        console.error(`Error fetching data for ${command}:`, error);
    }

    return null; // Jika terjadi error atau data tidak ditemukan
}

exports.run = {
    usage: [
    'wallhp', 'art', 'bts', 'cartoon', 'cyber', 'doraemon', 'exo',
    'gamewallpaper', 'hacker', 'islamic', 'jennie', 'jiso', 'justina',
    'lisa', 'mountain', 'pentol', 'pokemon', 'programming', 'satanic',
    'space', 'technology'
],
    category: 'random',
    async: async (m, { func, mecha, users, setting, froms }) => {
        const command = m.command; // Ambil perintah pengguna
        console.log(`Command received: ${command}`); // Debugging

        if (!command) {
            mecha.sendMessage(m.chat, { text: '⚠ Command tidak ditemukan!' }, { quoted: m });
            return;
        }

        try {
            mecha.sendReact(m.chat, '🕒', m.key);
            const animeUrl = await getRandomAnime(command);

            if (animeUrl) {
                mecha.sendMessage(m.chat, {
                    image: { url: animeUrl },
                    caption: `乂 *${command.toUpperCase()}*`,
                }, { quoted: m, ephemeralExpiration: 86400 });
            } else {
                mecha.sendMessage(m.chat, { text: `⚠ Gambar untuk *${command}* tidak ditemukan!` }, { quoted: m });
            }
        } catch (error) {
            console.error('Error fetching anime:', error);
            mecha.sendReact(m.chat, '❌', m.key);
        }
    },
    limit: true,
};