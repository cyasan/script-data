const axios = require('axios');
const cheerio = require('cheerio');

const lyrics = {
    search: async (song) => {
        try {
            const {
                data
            } = await axios.get(`https://www.lyrics.com/lyrics/${song}`);
            const $ = cheerio.load(data);
            const result = $('.best-matches .bm-case').map((i, element) => {
                const title = $(element).find('.bm-label a').first().text();
                const artist = $(element).find('.bm-label a').last().text();
                const album = $(element).find('.bm-label').eq(1).text().trim().replace(/\s+/g, ' ');
                const imageUrl = $(element).find('.album-thumb img').attr('src');
                const link = $(element).find('.bm-label a').first().attr('href');

                return {
                    title,
                    artist,
                    album,
                    imageUrl,
                    link: `https://www.lyrics.com${link}`
                };
            }).get();

            return result;
        } catch (error) {
            console.error(`Terjadi kesalahan: ${error.message}`);
        }
    },
    getLyrics: async (url) => {
        try {
            const {
                data
            } = await axios.get(url);
            const $ = cheerio.load(data);
            const artistImage = $('#featured-artist-avatar img').attr('src');
            const about = $('.artist-meta .bio').text().trim();
            const year = $('.lyric-details dt:contains("Year:") + dd').text().trim();
            const playlists = $('.lyric-details dt:contains("Playlists") + dd a').text().trim();
            const lyrics = $('#lyric-body-text').text().trim();

            const result = {
                artistImage,
                about,
                year,
                playlists,
                lyrics
            };

            return result;
        } catch (error) {
            console.error(`Terjadi kesalahan: ${error.message}`);
        }
    }
}

exports.run = {
    usage: ['lirik2'],
    use: 'options',
    category: 'searching',
    async: async (m, {
        func,
        mecha
    }) => {
        let [options, ...params] = m.args;
        if (params.length > 0) params = params.join(' ');

        if (/^search$/i.test(options)) {
            try {
                if (!params) return m.reply(func.example(m.cmd, 'melukis senja'));
                mecha.sendReact(m.chat, '🕒', m.key);
                const result = await lyrics.search(params);
                const caption = formatResponse(result);
                await mecha.sendMessage(m.chat, {
                    text: caption
                }, {
                    quoted: m,
                    ephemeralExpiration: m.expiration
                });
            } catch (error) {
                console.error('Error fetching lyrics:', error);
                m.reply('Terjadi kesalahan saat mengambil lirik. Silakan coba lagi nanti.');
            }
        } else if (/^get$/i.test(options)) {
            if (!params.match('https://www.lyrics.com')) return m.reply('Invalid link.')
            mecha.sendReact(m.chat, '🕒', m.key);
            const result = await lyrics.getLyrics(params);
            let caption = `- About: ${result.about}
- Year: ${result.year}
- Playlists: ${result.playlists}
- Lyrics:\n\n${result.lyrics}`
            await mecha.sendMessage(m.chat, {
                image: {
                    url: result.artistImage
                },
                caption: caption
            }, {
                quoted: m,
                ephemeralExpiration: m.expiration
            });
        } else m.reply('Opsi tidak valid! Pilih `search` atau `get`');
    },
    restrict: true,
    limit: true
};

function formatResponse(data) {
    let result = '*L I R I K - S E A R C H*';
    data.forEach(item => {
        result += `\n\n- Title: ${item.title}
- Artist: ${item.artist}
- Album: ${item.album || 'N/A'}
- imageUrl: ${item.imageUrl}
- Link: ${item.link}`;
    });
    return result;
}