const axios = require("axios");
const cheerio = require("cheerio");

exports.run = {
  usage: ["kusonime"],
  category: "searching",
  use: "nama anime",
  async: async (m, { func, mecha }) => {
    if (!m.text) return mecha.reply(m.chat, func.example(m.cmd, "Attack on Titan"), m);

    mecha.sendReact(m.chat, "🕒", m.key); // Reaksi loading

    try {
      const { data } = await axios.get(`https://kusonime.com/?s=${encodeURIComponent(m.text)}`);
      const $ = cheerio.load(data);
      let searchResults = [];

      $(".venz .detpost").each((i, el) => {
        const element = $(el);
        const title = element.find(".content h2 a").text().trim();
        const url = element.find(".content h2 a").attr("href");
        const thumbnail = element.find(".thumbz img").attr("src");
        const genres = element
          .find('.content p:contains("Genre") a')
          .map((i, el) => $(el).text())
          .get();
        const releaseTime = element
          .find('.content p:contains("Released on")')
          .text()
          .replace("Released on ", "")
          .trim();

        searchResults.push({
          title,
          url,
          thumbnail,
          genres,
          releaseTime,
        });
      });

      if (searchResults.length === 0) {
        return mecha.reply(m.chat, "Anime tidak ditemukan. Coba kata kunci lain!", m);
      }

      let anime = searchResults[0]; // Ambil hasil pertama
      let caption = `乂 *SEARCHING KUSONIME*\n\n`;
      caption += `- *Judul:* ${anime.title}\n`;
      caption += `- *Genre:* ${anime.genres.join(", ")}\n`;
      caption += `- *Rilis:* ${anime.releaseTime}\n`;
      caption += `- *Link:* ${anime.url}\n\n`;
      caption += `_Data dari Kusonime_`;

      await mecha.sendMessage(
        m.chat,
        {
          image: { url: anime.thumbnail },
          caption,
        },
        { quoted: m }
      );

      mecha.sendReact(m.chat, "✅", m.key); // Reaksi sukses
    } catch (err) {
      console.error("Error fetching Kusonime data:", err);
      mecha.reply(m.chat, "Terjadi kesalahan saat mencari anime di Kusonime.", m);
    }
  },
  limit: true,
};