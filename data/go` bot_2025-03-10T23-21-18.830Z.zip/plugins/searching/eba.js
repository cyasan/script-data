async function getRandomAnime() {
  const animeList = [
  "https://i.pinimg.com/originals/68/f8/91/68f891058f00df53c6831efa270918f6.jpg",
  "https://i.pinimg.com/originals/ec/0f/fd/ec0ffde37b58efde440ed5efa9b9a2ec.jpg",
  "https://i.pinimg.com/474x/83/c2/b6/83c2b65dbf8d405559f68490836c8a61.jpg",
  "https://i.pinimg.com/236x/48/ae/12/48ae12d2362e0c2cfa24019db05130c4--kimi-no-iru-machi-ales.jpg",
  "https://i.pinimg.com/236x/3b/87/91/3b8791b4d87f310c0f2367c2be474bc9.jpg",
  "https://i.pinimg.com/originals/0f/06/e9/0f06e9152ead234735dd2b142d353408.png",
  "https://i.pinimg.com/236x/f2/fb/0e/f2fb0e9bba20ba09ff18b2f5be5c2b97.jpg",
  "https://i.pinimg.com/474x/6e/05/da/6e05da192c20c6a9ab2f06206988a050--pencil-drawings-drawings-of.jpg",
  "https://i.pinimg.com/474x/54/6e/ce/546ecea8a2d0697ef8a3efeb7c1c123a--anime-characters-anime-art.jpg",
  "https://i.pinimg.com/originals/31/fe/e3/31fee335e244f2676a2f908f8bbb26b5.jpg",
  "https://i.pinimg.com/custom_covers/222x/812125813993452127_1504040891.jpg",
  "https://i.pinimg.com/originals/07/ce/49/07ce499a8e8c4ee37854174a1d3d6459.jpg",
  "https://i.pinimg.com/originals/94/57/1c/94571cb0cecfa9c15a87ed021c096a45.jpg",
  "https://i.pinimg.com/736x/29/1f/fb/291ffb84c4c466bcddb9c5025d761b3a--seo-romance-anime.jpg",
  "https://i.pinimg.com/originals/25/54/85/255485b5781e8e7937d761b75245ea55.jpg",
  "https://i.pinimg.com/236x/b4/3e/78/b43e7856754807a1d9f84c8ca2648834.jpg",
  "https://i.pinimg.com/originals/d5/78/37/d57837407f6c3833f5f492350ec03106.jpg",
  "https://i.pinimg.com/originals/db/cd/a3/dbcda3f42c77de996772ceb6874d39fc.jpg",
  "https://i.pinimg.com/originals/6e/56/87/6e56873fbd4c11f122591699d7fe4e8f.jpg",
  "https://i.pinimg.com/originals/bf/0d/f7/bf0df7d4dbc9c9755a0fdbe0e6e3b9e7.jpg"
];

  const randomIndex = Math.floor(Math.random() * animeList.length);
  return animeList[randomIndex];
}

exports.run = {
  usage: ['eba'], // Change command to 'anime'
  category: 'nsfw', // Change category for broader scope
  async: async (m, { func, mecha, users, setting, froms }) => {
    let { age } = global.db.users[m.sender];
    if (users.age < 20) {
      mecha.sendMessage(m.chat, { text: `Kamu masih dibawah umur untuk menggunakan fitur ini` }, { quoted: m });
      return; // Exit the function immediately
    }

    try {
      mecha.sendReact(m.chat, '🕒', m.key);
      const animeUrl = await getRandomAnime();

      // Send the image and store the sent message
      const sentMessage = await mecha.sendMessage(m.chat, {
        image: {
          url: animeUrl,
        },
        mimetype: 'image/jpeg',
      }, { quoted: m, ephemeralExpiration: 86400 });

      // Set a timeout to delete the message after 5 minutes
      setTimeout(() => {
        mecha.sendMessage(m.chat, { delete: sentMessage.key });
      }, 60000); // 5 minutes in milliseconds
    } catch (error) {
      console.error('Error fetching anime:', error);
      mecha.sendReact(m.chat, '❌', m.key);
    }
  },
  limit: true,
  premium: true,
  private: false,
};