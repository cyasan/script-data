async function getRandomAnime() {
  const animeList = [
  "https://i.pinimg.com/originals/3b/3d/e4/3b3de4b2a106b93461014459416aa72e.jpg",
  "https://i.pinimg.com/originals/2e/31/85/2e31859f47447f414001d5615d1f8a2a.jpg",
  "https://i.pinimg.com/originals/2c/f8/68/2cf868ec24d1518d62b6067f298e2634.jpg",
  "https://i.pinimg.com/originals/c5/f2/12/c5f212a583227bd254076e1ba8558c3a.jpg",
  "https://i.pinimg.com/originals/c1/ea/2c/c1ea2c8ff7ee1b9716955b8f8d78b1d4.jpg",
  "https://i.pinimg.com/originals/db/04/47/db04470cc3585e89cb8ac500453f36de.jpg",
  "https://i.pinimg.com/originals/2c/c6/14/2cc614349249e027c6788563346e8386.jpg",
  "https://i.pinimg.com/originals/d4/b8/fb/d4b8fbc27fed8d40e7d04edcbfe74d0e.jpg",
  "https://i.pinimg.com/originals/6e/25/e0/6e25e042b91f38e16ce2f07b9dd2a682.jpg",
  "https://i.pinimg.com/originals/43/71/6b/43716bcd5611a7d77f94f93d849ac7b6.jpg",
  "https://i.pinimg.com/originals/c4/98/c0/c498c0be6941d37f716ab366118bab5f.jpg",
  "https://i.pinimg.com/originals/5b/09/91/5b0991c9a0d0f5e1c7bb47a16f109153.jpg",
  "https://i.pinimg.com/originals/c2/67/d4/c267d4d6ab8da59ad5ba09aaea91f7dd.jpg",
  "https://i.pinimg.com/originals/0e/d0/48/0ed0481e4adc15a7ed2918715e469b93.jpg",
  "https://i.pinimg.com/originals/74/fd/cd/74fdcdccc63d629431d70b6fa270b8e3.jpg",
  "https://i.pinimg.com/originals/bc/a2/1c/bca21cc775a19e3740766d6e3d0f4b91.jpg",
  "https://i.pinimg.com/originals/8b/a5/6f/8ba56ff983e6411e04a7fc3c34cbb844.jpg",
  "https://i.pinimg.com/originals/06/21/bd/0621bd7a813b70ea82c289a4b8373cef.png",
  "https://i.pinimg.com/originals/aa/d2/b4/aad2b4ada036b8f1113764bfa50173f0.jpg",
  "https://i.pinimg.com/originals/1f/ad/bc/1fadbc08af83ca5be503d31cff22189f.jpg",
  "https://i.pinimg.com/originals/51/60/21/516021decd8a9be4261b0242b0488ee2.jpg",
  "https://i.pinimg.com/originals/19/18/d4/1918d44c65f876d0c9b70c7c7da0b899.jpg",
  "https://i.pinimg.com/originals/3a/a5/2d/3aa52d9ce041a5b7fe9640df6e5ddcda.png",
  "https://i.pinimg.com/originals/3a/92/a3/3a92a3121f34286b627453f7e2b62544.jpg",
  "https://i.pinimg.com/originals/a4/fd/58/a4fd5845de33b6b54c19a4bd3ad28a00.jpg",
  "https://i.pinimg.com/originals/82/61/4b/82614b4b57fde3e219b8bd9a0ef4f9c4.jpg",
  "https://i.pinimg.com/originals/a8/68/14/a86814c0173ae445ec51a034aeccd133.jpg",
  "https://i.pinimg.com/originals/d5/4d/98/d54d981b3022a37011518b3e11e1da13.jpg",
  "https://i.pinimg.com/originals/d2/c4/f1/d2c4f1fba5161a2df3399a93f44189cd.jpg",
  "https://i.pinimg.com/originals/ae/18/96/ae189621a67204e88d1f168166db4822.jpg",
  "https://i.pinimg.com/originals/65/75/d2/6575d20651e4b7711594d7d2a056852c.jpg",
  "https://i.pinimg.com/originals/fe/2a/8e/fe2a8ebc90c1c67e24a566b2973ef313.jpg"
];

  const randomIndex = Math.floor(Math.random() * animeList.length);
  const randomAnime = animeList[randomIndex];

  return randomAnime;
}

exports.run = {
  usage: ['kpop'], // Change command to 'anime'
  category: 'asupan', // Change category for broader scope
  async: async (m, { func, mecha, users, setting, froms }) => {

    try {
      mecha.sendReact(m.chat, '🕒', m.key);
      const animeUrl = await getRandomAnime();

      // Send the image with the caption as part of the message object
      mecha.sendMessage(m.chat, {
        image: {
          url: animeUrl,
        },
        caption: '',
      }, { quoted: m, ephemeralExpiration: 86400 });
    } catch (error) {
      console.error('Error fetching anime:', error);
      mecha.sendReact(m.chat, '❌', m.key);
    }
  },
  limit: true,
};