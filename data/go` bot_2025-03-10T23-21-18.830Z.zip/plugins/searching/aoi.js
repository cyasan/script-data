async function getRandomAnime() {
  const animeList = [
'https://files.catbox.moe/8i5jii.jpg',
'https://files.catbox.moe/y7w9yu.jpg',
'https://files.catbox.moe/hwua3i.jpg',
'https://files.catbox.moe/pzljc6.jpg',
'https://files.catbox.moe/6u75ns.jpg',
  ];

  const randomIndex = Math.floor(Math.random() * animeList.length);
  const randomAnime = animeList[randomIndex];

  return randomAnime;
}

exports.run = {
  usage: ['aoi'], // Change command to 'anime'
  category: 'anime', // Change category for broader scope
  async: async (m, { func, mecha, users, setting, froms }) => {

    try {
      mecha.sendReact(m.chat, '🕒', m.key);
      const animeUrl = await getRandomAnime();

      // Send the image with the caption as part of the message object
      mecha.sendMessage(m.chat, {
        image: {
          url: animeUrl,
        },
        caption: '乂 *AOI HINATA*',
      }, { quoted: m, ephemeralExpiration: 86400 });
    } catch (error) {
      console.error('Error fetching anime:', error);
      mecha.sendReact(m.chat, '❌', m.key);
    }
  },
  limit: true,
};