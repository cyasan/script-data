async function getRandomAnime() {
  const animeList = [
  "https://i.pinimg.com/originals/7b/04/93/7b049307bc82190d4eef46756920455c.jpg",
  "https://i.pinimg.com/736x/75/1d/4b/751d4bda81598c27a15ac46874b3a305.jpg",
  "https://i.pinimg.com/564x/09/be/e8/09bee8b62d0f0a03fa70271993e2d651.jpg",
  "https://i.pinimg.com/originals/eb/a3/7b/eba37b304f19d2c6e01c44390950d216.jpg",
  "https://i.pinimg.com/736x/74/45/71/7445710676b96d5285bcd4ba2b1868a6.jpg",
  "https://i.pinimg.com/736x/01/bb/7d/01bb7d019114debf0543d006b2bd3318.jpg",
  "https://i.pinimg.com/originals/02/71/8e/02718ebd3f9e98416d9175ac705b4a0e.jpg",
  "https://i.pinimg.com/originals/4a/3f/66/4a3f6645b495908644d0cd0549af99aa.jpg",
  "https://i.pinimg.com/originals/18/c6/50/18c650c1bb4b5aef278154e5c10c5d08.jpg",
  "https://i.pinimg.com/originals/22/cd/9e/22cd9e74f3aaf505767dc21bf96e4a40.jpg",
  "https://i.pinimg.com/474x/c1/7f/9a/c17f9a4a4c11682ca39ab5dd00eb34c0.jpg",
  "https://i.pinimg.com/originals/30/5e/a8/305ea8be4fe80e5325b3f3711a4cd011.jpg",
  "https://i.pinimg.com/originals/11/2d/a4/112da4d48263c4f4fdc8ddc23dde70da.jpg",
  "https://i.pinimg.com/originals/e6/18/45/e61845b9f4d1a98950104fbcd7d1f7bd.jpg",
  "https://i.pinimg.com/736x/2c/8b/ba/2c8bba0b5982417813198c4f5fe45d5e.jpg",
  "https://i.pinimg.com/originals/52/34/d9/5234d9bc2c0efcaccde111a4dd32684e.jpg",
  "https://i.pinimg.com/originals/0a/36/41/0a364143adb4095a50439406f75fe4d6.jpg",
  "https://i.pinimg.com/originals/9f/6d/b6/9f6db6c2e51d6a87fa480b4c0ba2de7e.jpg",
  "https://i.pinimg.com/originals/19/d6/79/19d679f225e57b0f6732ce43180865af.png",
  "https://i.pinimg.com/736x/ca/87/10/ca87103c416c2f359dc30d6f3e3dfb55.jpg",
  "https://i.pinimg.com/originals/2e/66/45/2e6645baf0381248cc6bb9d0c5cc544d.jpg",
  "https://i.pinimg.com/originals/86/05/2c/86052cf86d3dd90182e748f1b9eb9173.png",
  "https://i.pinimg.com/736x/77/02/23/770223234b80f81e7ffb1f40edc2b027.jpg",
  "https://i.pinimg.com/originals/32/23/20/322320be2b7d430f5870c778c0623315.jpg",
  "https://i.pinimg.com/736x/21/88/6c/21886c205354b1fa4cc68e6468febf45.jpg",
  "https://i.pinimg.com/564x/da/b6/0d/dab60d7b90405857bdfcb2d1024092c8.jpg",
  "https://i.pinimg.com/originals/a7/02/e1/a702e1b27f5bac1466bb2e34a2205664.png",
  "https://i.pinimg.com/736x/7e/ca/09/7eca09fe9c5ee85fd940c9e4deb5828e.jpg",
  "https://i.pinimg.com/originals/4a/76/d5/4a76d5d3302984ac2edc0276955b5760.jpg",
  "https://i.pinimg.com/736x/c4/29/e8/c429e80ff3156a112e72466e4fdc9009.jpg",
  "https://i.pinimg.com/originals/2c/07/3d/2c073d8b8d7b7d8d10195bd9b7ed0383.jpg",
  "https://i.pinimg.com/736x/8d/fe/c8/8dfec863f43d821b6c1a06f15744082d.jpg",
  "https://i.pinimg.com/originals/e7/3a/55/e73a55988f1c5dc02c4036b1fe794938.jpg",
  "https://i.pinimg.com/originals/1f/0d/27/1f0d2716c8a77bd7c199ae281f8547f5.jpg",
  "https://i.pinimg.com/originals/10/c5/1a/10c51a026a730566f51d5f44a1c0f9c5.png",
  "https://i.pinimg.com/originals/f3/6d/f2/f36df2f5da35801b31356d5f22f529b1.jpg",
  "https://i.pinimg.com/originals/fd/3a/94/fd3a94190fd98374fa72e085faa3fbcb.jpg",
  "https://i.pinimg.com/originals/79/77/fb/7977fb21d2719c0c0a19781191187b4c.png",
  "https://i.pinimg.com/originals/29/f3/52/29f352b8130f076ef00b632eef110eff.png",
  "https://i.pinimg.com/736x/86/40/0f/86400ff97da8c2d38e5171ba8cb422f1.jpg",
  "https://i.pinimg.com/originals/1e/52/79/1e52795d5b9629f7b837133abe61f1fb.jpg",
  "https://i.pinimg.com/736x/ac/02/bd/ac02bde28e5deb0e28984d0b5c9c77a7.jpg",
  "https://i.pinimg.com/236x/41/12/51/411251d0c0b7101d40953698e7b21a70.jpg",
  "https://i.pinimg.com/736x/96/12/46/96124654232a86831362a22c3fc60c9e.jpg",
  "https://i.pinimg.com/736x/93/77/02/937702c66b82aa76e95c67b716b773a5.jpg",
  "https://i.pinimg.com/originals/c9/fd/8a/c9fd8a58287a2aa31860eacb9c640dfe.jpg",
  "https://i.pinimg.com/originals/86/b5/dc/86b5dc082bb890a75ee0287e03e364f4.jpg",
  "https://i.pinimg.com/originals/6f/83/f2/6f83f2a911c8c92145fe36df7a8fbc4d.jpg",
  "https://i.pinimg.com/originals/21/e6/b1/21e6b1278d96852875449ba870b54294.jpg",
  "https://i.pinimg.com/736x/06/4a/7f/064a7ff14a04fd8bb624e075568213ba.jpg",
  "https://i.pinimg.com/474x/a3/20/65/a32065febc6dbd610ada5f20f7c7da2e.jpg",
  "https://i.pinimg.com/originals/2b/bb/e6/2bbbe6696d80c608c46cb716ccd195d7.png",
  "https://i.pinimg.com/originals/da/08/8c/da088c2b857b415b32c34e84f1a39654.jpg",
  "https://i.pinimg.com/originals/ec/4f/6e/ec4f6ecbdf1714fa58590106142030e4.png",
  "https://i.pinimg.com/474x/98/77/6e/98776e02a88773f4f50baf7862ad5403.jpg",
  "https://i.pinimg.com/originals/06/dc/76/06dc762a867599e6f2a19b152463e7a8.jpg",
  "https://i.pinimg.com/originals/83/21/bd/8321bdf2c7b94f32506107ca14b7f38f.jpg",
  "https://i.pinimg.com/236x/32/e8/20/32e820c0a331d6ea18b2811ccd7111c1.jpg",
  "https://i.pinimg.com/originals/13/0f/19/130f19ba762da8b736ffeb1299eb68c5.jpg",
  "https://i.pinimg.com/originals/37/02/c0/3702c0d5c4ef9d3a0d364ac7ee565180.jpg",
  "https://i.pinimg.com/originals/ea/00/e7/ea00e7cf20071db9bd629d00bec16eda.jpg",
  "https://i.pinimg.com/736x/1d/58/75/1d58751a974becc20dd43507e7fbf1c6.jpg",
  "https://i.pinimg.com/564x/05/d3/f6/05d3f6296134a08b643c54446b68fcdf.jpg"
];

  const randomIndex = Math.floor(Math.random() * animeList.length);
  const randomAnime = animeList[randomIndex];

  return randomAnime;
}

exports.run = {
  usage: ['neko'], // Change command to 'anime'
  category: 'anime', // Change category for broader scope
  async: async (m, { func, mecha, users, setting, froms }) => {

    try {
      mecha.sendReact(m.chat, '🕒', m.key);
      const animeUrl = await getRandomAnime();

      // Send the image with the caption as part of the message object
      mecha.sendMessage(m.chat, {
        image: {
          url: animeUrl,
        },
        caption: 'Source: Pinterest*',
      }, { quoted: m, ephemeralExpiration: 86400 });
    } catch (error) {
      console.error('Error fetching anime:', error);
      mecha.sendReact(m.chat, '❌', m.key);
    }
  },
  limit: true,
};