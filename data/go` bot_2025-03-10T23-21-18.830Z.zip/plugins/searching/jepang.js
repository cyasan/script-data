async function getRandomAnime() {
  const animeList = [
'https://files.catbox.moe/aazjis.jpg',
'https://files.catbox.moe/02563t.jpg',
'https://files.catbox.moe/fm9hff.jpg',
'https://files.catbox.moe/j3rvj4.jpg',
'https://files.catbox.moe/1oqev2.jpg',
'https://files.catbox.moe/kwb2i3.jpg',
'https://files.catbox.moe/f3yl2i.jpg',
'https://files.catbox.moe/ar1lav.jpg',
'https://files.catbox.moe/tr5fbf.jpg',
'https://files.catbox.moe/g2f1tc.jpg',
'https://files.catbox.moe/1ruagn.jpg',
'https://files.catbox.moe/r2wp4m.jpg',
'https://files.catbox.moe/0q9987.jpg',
'https://files.catbox.moe/w86b0k.jpg',
'https://files.catbox.moe/bdetdz.jpg',
'https://files.catbox.moe/p2xvep.jpg',
'https://files.catbox.moe/embesn.jpg',
'https://files.catbox.moe/hwbswc.jpg',
'https://files.catbox.moe/ra9no9.jpg',
'https://files.catbox.moe/hzkm7a.jpg',
  ];

  const randomIndex = Math.floor(Math.random() * animeList.length);
  const randomAnime = animeList[randomIndex];

  return randomAnime;
}

exports.run = {
  usage: ['jepang','korea'],
  category: 'asupan', // Change category for broader scope
  async: async (m, { func, mecha, users, setting, froms }) => {

    try {
      mecha.sendReact(m.chat, '🕒', m.key);
      const animeUrl = await getRandomAnime();
      // Send the image only if the user is an adult
      mecha.sendMessage(m.chat, {
        image: {
          url: animeUrl,
        },
        mimetype: 'image/jpeg',
      }, { quoted: m, ephemeralExpiration: 86400 });
    } catch (error) {
      console.error('Error fetching anime:', error);
      mecha.sendReact(m.chat, '❌', m.key);
    }
  },
limit: 3,
};