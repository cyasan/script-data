exports.run = {
  usage: ["playstore"],
  category: "searching",
  use: "nama aplikasi",
  async: async (m, { func, mecha }) => {
    if (!m.text) return mecha.reply(m.chat, func.example(m.cmd, "WhatsApp"), m);

    mecha.sendReact(m.chat, "🕒", m.key);

    try {
      // Dynamic Import
      const gplay = await import("google-play-scraper");

      let apps = await gplay.default.search({ term: m.text, num: 5, country: "id", lang: "id" });

      if (apps.length === 0) {
        return mecha.reply(m.chat, "Aplikasi tidak ditemukan!", m);
      }

      let app = apps[0];
      let caption = `乂 *SEARCHING PLAYSTORE*\n\n`;
      caption += `- *Nama:* ${app.title}\n`;
      caption += `- *Developer:* ${app.developer}\n`;
      caption += `- *Rating:* ${app.scoreText || "N/A"}\n`;
      caption += `- *Harga:* ${app.priceText || "Gratis"}\n`;
      caption += `- *Link:* ${app.url}\n\n`;
      caption += `_Data dari Google Play Store_`;

      await mecha.sendMessage(
        m.chat,
        { image: { url: app.icon }, caption },
        { quoted: m }
      );

      mecha.sendReact(m.chat, "✅", m.key);
    } catch (err) {
      console.error("Error fetching Play Store data:", err);
      mecha.reply(m.chat, "Terjadi kesalahan saat mencari aplikasi di Play Store.", m);
    }
  },
  limit: true,
};