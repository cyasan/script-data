const axios = require('axios');
const cheerio = require('cheerio');

const gempa = async () => {
return new Promise(async (resolve, reject) => {
axios.get('https://www.bmkg.go.id/gempabumi/gempabumi-dirasakan.bmkg')
.then(({
data
}) => {
const $ = cheerio.load(data)
const drasa = [];
$('table > tbody > tr:nth-child(1) > td:nth-child(6) > span').get().map((rest) => {
dir = $(rest).text();
drasa.push(dir.replace('\t', ' '))
})
teks = ''
for (let i = 0; i < drasa.length; i++) {
teks += drasa[i] + '\n'
}
const rasa = teks
const format = {
imagemap: $('div.modal-body > div > div:nth-child(1) > img').attr('src'),
magnitude: $('table > tbody > tr:nth-child(1) > td:nth-child(4)').text(),
kedalaman: $('table > tbody > tr:nth-child(1) > td:nth-child(5)').text(),
wilayah: $('table > tbody > tr:nth-child(1) > td:nth-child(6) > a').text(),
waktu: $('table > tbody > tr:nth-child(1) > td:nth-child(2)').text(),
lintang_bujur: $('table > tbody > tr:nth-child(1) > td:nth-child(3)').text(),
dirasakan: rasa
}
const result = {
creator: 'Surya',
data: format
}
resolve(result)
})
.catch(reject)
})
}

const gempanow = async () => {
let response = await fetch('https://www.bmkg.go.id/gempabumi/gempabumi-terkini.bmkg')
let $ = cheerio.load(await response.text())
let result = []
for (let i = 0; i < 30; i++) {
let data = $('body > div.wrapper > div.container.content > div > div.col-md-8 > div > div > table > tbody > tr').eq(i).find('td')
let waktu = $(data).eq(1).text().trim()
let lintang = $(data).eq(2).text().trim()
let bujur = $(data).eq(3).text().trim()
let magnitudo = $(data).eq(4).text().trim()
let kedalaman = $(data).eq(5).text().trim()
let wilayah = $(data).eq(6).text().trim()
result.push({
waktu,
lintang,
bujur,
magnitudo,
kedalaman,
wilayah
})
}
return result;
}

exports.run = {
usage: ['gempanow'],
category: 'searching',
async: async (m, { mecha }) => {
let result = await gempanow();
if (result.length == 0) return m.reply('Data empty.')
let txt = '乂  *G E M P A - N O W*'
result.forEach((data, index) => {
txt += `\n\n${index + 1}. ${data.wilayah}`
txt += `\n◦  Waktu : ${data.waktu}`
txt += `\n◦  Lintang : ${data.lintang}`
txt += `\n◦  Bujur : ${data.bujur}`
txt += `\n◦  Magnitudo : ${data.magnitudo}`
txt += `\n◦  Kedalaman : ${data.kedalaman}`
})
mecha.reply(m.chat, txt, m, {expiration: m.expiration})
},
limit: true
}