const fetch = require('node-fetch');

exports.run = {
  usage: ['meme'],
  category: 'asupan',
  async: async (m, { func, mecha, setting }) => {
    if (!m.text) return m.reply(func.example(m.cmd, 'hitam'));
    mecha.sendReact(m.chat, '🕒', m.key);
    let status = true;

    while (status) {
      try {
        let query = encodeURIComponent(m.text);
        let page = Math.floor(Math.random() * 10);
        let response = await fetch(`https://lahelu.com/api/post/get-search?query=${query}&page=${page}`);
        
        // Cek apakah response berhasil
        if (!response.ok) {
          return m.reply('Error fetching data. Please try again later.');
        }

        let data = await response.json();
        if (!data || data.postInfos.length < 1) {
          return m.reply('Empty data. Trying again...');
        }

        let random = Math.floor(Math.random() * data.postInfos.length);
        let result = data.postInfos[random];
        let video = result.media;
        let message = `- *Title:* ${result.title}
- *Total Comments:* ${result.totalComments}
- *Create Time:* ${new Date(result.createTime).toLocaleString()}
- *User Username:* ${result.userUsername}`;
        
        let button = [
          ['next', `${m.cmd} ${m.text}`],
          ['delete', `${m.prefix}delete`],
        ];
        
        await mecha.sendButton(m.chat, 'MEME FROM LAHELU', message, button, m, {
          media: video,
          expiration: m.expiration
        });
        
        status = false; // Mengubah status menjadi false jika berhasil
      } catch (error) {
        console.error(error);
        return m.reply('An error occurred. Please try again later.');
      }
    }
  },
  limit: true,
  location: 'plugins/meme.js'
}