async function getRandomAnime() {
  const animeList = [
'https://files.catbox.moe/s8o68d.jpg',
'https://files.catbox.moe/jd0g4d.jpg',
'https://files.catbox.moe/gldfv9.jpg',
'https://files.catbox.moe/uj2reu.jpg',
'https://files.catbox.moe/ez9yy8.jpg',
'https://files.catbox.moe/h5sy68.webp',
'https://files.catbox.moe/3ov3fk.jpg',
'https://files.catbox.moe/ze7qkt.jpg',
'https://files.catbox.moe/p4au53.jpg',
  ];

  const randomIndex = Math.floor(Math.random() * animeList.length);
  const randomAnime = animeList[randomIndex];

  return randomAnime;
}

exports.run = {
  usage: ['indonesia'],
hidden: ['indo'],
  category: 'asupan', // Change category for broader scope
  async: async (m, { func, mecha, users, setting, froms }) => {

    try {
      mecha.sendReact(m.chat, '🕒', m.key);
      const animeUrl = await getRandomAnime();
      // Send the image only if the user is an adult
      mecha.sendMessage(m.chat, {
        image: {
          url: animeUrl,
        },
        mimetype: 'image/jpeg',
      }, { quoted: m, ephemeralExpiration: 86400 });
    } catch (error) {
      console.error('Error fetching anime:', error);
      mecha.sendReact(m.chat, '❌', m.key);
    }
  },
limit: 3,
};