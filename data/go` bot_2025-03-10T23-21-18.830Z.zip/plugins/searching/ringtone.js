const axios = require("axios");
const cheerio = require("cheerio");

exports.run = {
  usage: ["ringtone"],
  category: "searching",
  use: "query",
  async: async (m, { func, mecha }) => {
    if (!m.text) return mecha.reply(m.chat, func.example(m.cmd, "Nokia Tune"), m);

    mecha.sendReact(m.chat, "🕒", m.key); // Reaksi loading

    try {
      const { data } = await axios.get(`https://meloboom.com/en/search/${encodeURIComponent(m.text)}`);
      const $ = cheerio.load(data);
      let results = [];

      $("ul > li").each((i, elem) => {
        const title = $(elem).find("h4").text().trim();
        const source = "https://meloboom.com/" + $(elem).find("a").attr("href");
        const audio = $(elem).find("audio").attr("src");

        if (title && audio) {
          results.push({ title, source, audio });
        }
      });

      if (results.length === 0) {
        return mecha.reply(m.chat, "Ringtone tidak ditemukan. Coba kata kunci lain!", m);
      }

      let ringtone = results[0]; // Ambil hasil pertama
      let caption = `*乂 RINGTONE SEARCH*\n\n`;
      caption += `- *Judul:* ${ringtone.title}\n`;
      caption += `- *Sumber:* ${ringtone.source}\n\n`;
      caption += `_Data dari Meloboom_`;

      // Kirim pesan teks terlebih dahulu
      let sentMsg = await mecha.reply(m.chat, caption, m);

      // Kirim audio dengan meng-reply pesan teks dari bot
      await mecha.sendMessage(
        m.chat,
        {
          audio: { url: ringtone.audio },
          mimetype: "audio/mpeg",
          ptt: false,
        },
        { quoted: sentMsg } // Audio akan meng-reply pesan teks
      );

      mecha.sendReact(m.chat, "✅", m.key); // Reaksi sukses
    } catch (err) {
      console.error("Error fetching Ringtone data:", err);
      mecha.reply(m.chat, "Terjadi kesalahan saat mencari ringtone di Meloboom.", m);
    }
  },
  limit: true,
};