const axios = require('axios');

exports.run = {
  usage: ['cekip'],
  use: 'mention or reply',
  category: 'owner',
  async: async (m, { mecha, text }) => {
    // Ambil user berdasarkan reply atau mention
    let target;
    if (m.quoted) {
      target = m.quoted.sender;
    } else if (m.mentions.length) {
      target = m.mentions[0];
    } else {
      return mecha.reply(m.chat, '❌ Silakan reply pesan pengguna atau tag pengguna yang ingin dicek IP-nya.', m);
    }

    // Cek apakah target ada di database
    let user = global.db.users[target];
    if (!user) {
      return mecha.reply(m.chat, '❌ Pengguna tidak ditemukan di database.', m);
    }

    // Pastikan IP tersimpan di database pengguna
    if (!user.ip) {
      return mecha.reply(m.chat, '❌ Pengguna ini tidak memiliki data IP tersimpan.', m);
    }

    let ipAddress = user.ip;

    // Validasi format IP
    if (!/^\d{1,3}(\.\d{1,3}){3}$/.test(ipAddress)) {
      return mecha.reply(m.chat, '❌ Format IP tidak valid.', m);
    }

    // Ambil data IP menggunakan API
    try {
      let response = await axios.get(`http://ip-api.com/json/${ipAddress}`);
      let data = response.data;

      // Jika status gagal
      if (data.status !== 'success') {
        return mecha.reply(m.chat, '❌ Tidak dapat menemukan informasi untuk IP tersebut.', m);
      }

      // Kirimkan informasi IP ke pengguna
      let result = `乂 *INFORMASI IP*
- *IP*: ${data.query}
- *Negara*: ${data.country} (${data.countryCode})
- *Kota*: ${data.city || 'Tidak Diketahui'}
- *Zona Waktu*: ${data.timezone}
- *Provider*: ${data.isp || 'Tidak Diketahui'}
- *Latitude*: ${data.lat}
- *Longitude*: ${data.lon}
- *Region*: ${data.regionName} (${data.region})`;

      mecha.reply(m.chat, result, m);
    } catch (error) {
      console.error(error);
      mecha.reply(m.chat, '❌ Terjadi kesalahan saat mengambil data IP. Silakan coba lagi nanti.', m);
    }
  },
  owner: true, // Hanya dapat diakses oleh owner
};