// plugin addlimit
exports.run = {
  usage: ['addlimit'],
  use: 'mention or reply',
  category: 'owner',
  async: async (m, { mecha, prefix }) => {
    // Pastikan ada yang di-mention atau di-reply
    let targetUser;
    if (m.mentionedJidList && m.mentionedJidList.length > 0) {
      // Ambil pengguna yang di-mention
      targetUser = global.db.users[m.mentionedJidList[0]];
    } else if (m.quoted && m.quoted.sender) {
      // Ambil pengguna yang direply
      targetUser = global.db.users[m.quoted.sender];
    }

    // Jika tidak ada pengguna yang di-mention atau di-reply
    if (!targetUser) {
      return mecha.reply(m.chat, 'Silakan mention atau reply pengguna yang ingin ditambahkan limitnya.', m);
    }

    // Ambil jumlah limit yang ingin ditambahkan
    let limitToAdd = m.text.replace(`${prefix}addlimit`, '').trim();
    
    // Cek apakah jumlah limit yang dimasukkan valid
    if (!limitToAdd || isNaN(limitToAdd) || parseInt(limitToAdd) <= 0) {
      return mecha.reply(m.chat, 'Silakan masukkan jumlah limit yang valid untuk ditambahkan.', m);
    }

    // Tambahkan limit
    targetUser.limit = (targetUser.limit || 0) + parseInt(limitToAdd);

    // Simpan perubahan limit ke database
    global.db.users[targetUser.id] = targetUser;

    // Kirimkan konfirmasi tanpa @, hanya nama pengguna
    mecha.reply(m.chat, `Successfully added ${limitToAdd} limit to ${targetUser.name}. Total limit: ${targetUser.limit}`, m);
  },
  owner: true, // Hanya owner yang dapat mengakses fitur ini
};