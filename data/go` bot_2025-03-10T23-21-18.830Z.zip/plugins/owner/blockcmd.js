exports.run = {
  usage: ['blockcmd'],
  hidden: ['blokcmd'],
  use: 'command',
  category: 'owner',
  async: async (m, { func, mecha, setting }) => {
    if (!m.text) 
      return mecha.sendMessage(m.chat, { text: func.example(m.cmd, 'menu') }, { quoted: m });
    if (setting.blockcmd.includes(m.text)) 
      return mecha.sendMessage(m.chat, { text: `*'${m.text}' already in the database.*` }, { quoted: m });
    setting.blockcmd.push(m.text.toLowerCase());
    mecha.sendMessage(m.chat, { text: `*'${m.text}' added successfully!*` }, { quoted: m });
  },
  owner: true
};