const toMs = require('ms');

exports.run = {
  usage: ['banned'],
  hidden: ['ban'],
  use: 'mention or reply',
  category: 'owner',
  async: async (m, { func, mecha, froms, setting, comand }) => {
    const [text1, text2] = m.text.split('|');
    if (m.quoted) {
      let user = global.db.users[m.quoted.sender];
      let expire = m.text ? Date.now() + toMs(m.text) : 'PERMANENT';
      if (typeof user == 'undefined') {
        return await mecha.sendMessage(
          m.chat,
          { text: 'User data not found.' },
          { quoted: m }
        );
      }
      if (user.banned) {
        return await mecha.sendMessage(
          m.chat,
          { text: 'Target already banned.' },
          { quoted: m }
        );
      }
      user.banned = true;
      user.expired.banned = expire;
      return await mecha.sendMessage(
        m.chat,
        {
          text: `Successfully added @${m.quoted.sender.replace(
            /@.+/,
            ''
          )} to the banned list.`,
          mentions: [m.quoted.sender],
        },
        { quoted: m }
      );
    } else if (m.text) {
      if (!text1) {
        return await mecha.sendMessage(
          m.chat,
          { text: `Contoh: ${comand} 62895415497664|30d` },
          { quoted: m }
        );
      }
      let number = isNaN(text1)
        ? text1.startsWith('+')
          ? text1.replace(/[()+\s-]/g, '')
          : text1.split('@')[1]
        : text1;
      if (isNaN(number)) {
        return await mecha.sendMessage(
          m.chat,
          { text: 'Invalid number.' },
          { quoted: m }
        );
      }
      if (number.length > 15) {
        return await mecha.sendMessage(
          m.chat,
          { text: 'Invalid format.' },
          { quoted: m }
        );
      }
      let ban = number.replace(/[^0-9]/g, '') + '@s.whatsapp.net';
      let user = global.db.users[ban];
      let expire = text2 ? Date.now() + toMs(text2) : 'PERMANENT';
      if (typeof user == 'undefined') {
        return await mecha.sendMessage(
          m.chat,
          { text: 'User data not found.' },
          { quoted: m }
        );
      }
      if (user.banned) {
        return await mecha.sendMessage(
          m.chat,
          { text: 'Target already banned.' },
          { quoted: m }
        );
      }
      user.banned = true;
      user.expired.banned = expire;
      return await mecha.sendMessage(
        m.chat,
        {
          text: `Successfully added *${user.name}* to the banned list.`,
        },
        { quoted: m }
      );
    } else {
      return await mecha.sendMessage(
        m.chat,
        { text: 'Mention or reply to the chat target.' },
        { quoted: m }
      );
    }
  },
  owner: true,
};