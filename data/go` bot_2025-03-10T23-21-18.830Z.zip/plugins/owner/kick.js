exports.run = {
  usage: ['bubarkan'],
  use: 'id grup',
  category: 'owner',
  async: async (m, { func, mecha, setting }) => {
    if (!m.text) return m.reply('Masukkan ID grup yang ingin dibubarkan.');

    let groupId = m.text.trim();
    if (!groupId.endsWith('@g.us')) return m.reply('Format ID grup tidak valid.');

    let groupMetadata = await mecha.groupMetadata(groupId).catch(() => null);
    if (!groupMetadata) return m.reply('Grup tidak ditemukan atau bot bukan anggota.');

    let participants = groupMetadata.participants.map((p) => p.id);
    if (!participants.length) return m.reply('Tidak ada peserta dalam grup ini.');

    // Kirim pesan sebelum membubarkan dengan hide tag
    await mecha.sendMessage(groupId, {
      text: 'Grup akan dibubarkan atas perintah Owner. Terimakasih dan selamat tinggal!',
      mentions: participants, // Hide tag: mentions tanpa teks @username
    }, { quoted: func.fstatus("System Notification") });

    // Keluarkan semua peserta kecuali owner bot
    for (let participant of participants) {
      if (![global.owner, m.bot, ...setting.owner].includes(participant)) {
        await mecha.groupParticipantsUpdate(groupId, [participant], 'remove').catch((err) => {
          console.error(`Gagal mengeluarkan ${participant}:`, err);
        });
      }
    }

    m.reply(`Grup ${groupId} berhasil dibubarkan.`);
  },
  owner: true
};