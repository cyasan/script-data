const {
    read,
    MIME_JPEG
} = require('jimp')

exports.run = {
    usage: ['setppbot'],
    hidden: ['setpp'],
    use: 'reply photo',
    category: 'owner',
    async: async (m, {
        func,
        mecha,
        quoted
    }) => {
        if (/image\/(jpe?g|png)/.test(quoted.mime)) {
            mecha.sendReact(m.chat, '🕒', m.key);
            if (/^(full|panjang)$/i.test(m.args[0])) {
                let media = await quoted.download()
                let {
                    img
                } = await resize(media)
                await mecha.query({
                    tag: 'iq',
                    attrs: {
                        to: m.isGc && m.isBotAdmin && /^(gc|grup|group)$/i.test(m.args[1]) ? m.chat : '@s.whatsapp.net',
                        type: 'set',
                        xmlns: 'w:profile:picture'
                    },
                    content: [{
                        tag: 'picture',
                        attrs: {
                            type: 'image'
                        },
                        content: img
                    }]
                })
                mecha.sendReact(m.chat, '✅', m.key)
            } else {
                let media = await quoted.download()
                let data = await mecha.updateProfilePicture(m.bot, media)
                mecha.sendReact(m.chat, '✅', m.key)
            }
        } else m.reply(`Kirim/Reply gambar dengan caption ${m.cmd} untuk mengubah foto profil bot.`)
    },
    owner: true,
    location: 'plugins/owner/setppbot.js'
}

async function resize(media) {
    const image = await read(media)
    const min = image.getWidth()
    const max = image.getHeight()
    const cropped = image.crop(0, 0, min, max)
    return {
        img: await cropped.scaleToFit(720, 720).getBufferAsync(MIME_JPEG),
        preview: await cropped.normalize().getBufferAsync(MIME_JPEG)
    }
}