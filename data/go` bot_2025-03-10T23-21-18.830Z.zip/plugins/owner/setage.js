// plugin setage
exports.run = {
  usage: ['setage'],
  use: 'umur',
  category: 'owner',
  async: async (m, { func, mecha, users, setting, froms, prefix }) => {

    // Pastikan pengguna sedang merespons pesan user yang ingin diubah umurnya
    if (!m.quoted || !m.quoted.sender) {
      return mecha.reply(m.chat, 'Silakan reply pesan user yang ingin diubah umurnya.', m);
    }

    // Ambil user yang sedang di-reply
    let user = global.db.users[m.quoted.sender];

    // Cek apakah user yang di-reply ada dalam database
    if (!user) {
      return mecha.reply(m.chat, 'User yang Anda reply tidak ditemukan di database.', m);
    }

    // Ambil umur yang ingin diubah
    let ageBaru = m.text.replace(`${prefix}setage`, '').trim();

    // Validasi input umur (hanya angka)
    if (!ageBaru || isNaN(ageBaru) || ageBaru <= 0) {
      return mecha.reply(m.chat, 'Silakan masukkan umur yang valid (angka lebih dari 0).', m);
    }

    // Ganti umur user dengan umur baru
    user.age = parseInt(ageBaru);

    // Simpan perubahan umur ke database
    global.db.users[m.quoted.sender] = user;

    // Kirimkan konfirmasi perubahan umur
    mecha.reply(m.chat, `Successfully changed age to: ${ageBaru} years old.`, m);
  },
  owner: true, // Hanya owner yang dapat mengakses fitur ini
};