exports.run = {
  usage: ['unblockcmd'],
  hidden: ['unblokcmd'],
  use: 'command',
  category: 'owner',
  async: async (m, { func, mecha, setting }) => {
    if (!m.text) 
      return mecha.sendMessage(m.chat, { text: func.example(m.cmd, 'menu') }, { quoted: m });
    if (!setting.blockcmd.includes(m.text)) 
      return mecha.sendMessage(m.chat, { text: `*'${m.text}' not in database.*` }, { quoted: m });
    setting.blockcmd.splice(setting.blockcmd.indexOf(m.text), 1);
    mecha.sendMessage(m.chat, { text: `*'${m.text}' has been removed.*` }, { quoted: m });
  },
  owner: true
};