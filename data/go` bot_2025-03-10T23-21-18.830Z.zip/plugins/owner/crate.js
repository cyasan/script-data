exports.run = {
  usage: ['addcrate'],
  use: 'crate,count',
  category: 'owner',
  async: async (m, { mecha, users, setting, owner }) => {
    if (!global.db.users) global.db.users = {};

    // Pastikan 'owner' ada dan terdefinisi dengan benar
    if (!owner || !Array.isArray(owner) || !owner.includes(m.sender)) {
      return; // Jika pengirim bukan owner, maka keluar
    }

    // Mendapatkan pengirim atau user yang disebut (mention/reply)
    let targetUser = m.mentionedJid && m.mentionedJid[0] ? m.mentionedJid[0] : m.replyMessage && m.replyMessage.sender ? m.replyMessage.sender : m.sender;

    // Jika tidak ada target yang valid, kirimkan pesan error
    if (!targetUser) {
      return m.reply('Harap sebutkan pengguna yang ingin ditargetkan dengan mention atau balas pesan mereka!');
    }

    let user = global.db.users[targetUser];
    if (!user) {
      return m.reply('User tidak ditemukan di database. Pastikan user sudah terdaftar!');
    }

    const items = {
      crate: {
        common: { price: 30000 },
        uncommon: { price: 50000 },
        epic: { price: 80000 },
        legendary: { price: 100000 },
        mythic: { price: 250000 },
      },
    };

    const args = m.text.split(/\s+/);
    const crateName = args[1]?.toLowerCase(); // Ambil crate dari argumen kedua
    const count = parseInt(args[2], 10); // Ambil jumlah dari argumen ketiga

    if (!crateName || !count || isNaN(count)) {
      return m.reply('Masukkan format yang benar: `addcrate <crate_name> <count>`');
    }

    if (!items.crate[crateName]) {
      return m.reply(`Item crate "${crateName}" tidak ditemukan!`);
    }

    // Tambahkan jumlah crate yang diinginkan ke user target
    user[crateName] = (user[crateName] || 0) + count;

    // Menyiapkan format pesan yang menunjukkan semua crate yang dimiliki user
    let crateList = '';
    for (let crate in items.crate) {
      if (user[crate] && user[crate] > 0) {
        crateList += `- ${crate.charAt(0).toUpperCase() + crate.slice(1)} = ${user[crate]}\n`;
      }
    }

    // Kirimkan pesan berhasil dengan format yang diinginkan
    return m.reply(
      `Successfully added Crate (${crateName}) ke ${targetUser}\n\n` +
      `Crate ${targetUser}:\n` +
      `${crateList || 'Tidak ada crate yang dimiliki.'}`
    );
  },
  owner: true,
};