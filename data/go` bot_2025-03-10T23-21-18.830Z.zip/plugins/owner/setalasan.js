// plugin setalasan
exports.run = {
  usage: ['setalasan'],
  use: 'text',
  category: 'owner',
  async: async (m, { func, mecha, users, setting, froms, prefix }) => {

    // Pastikan pengguna sedang merespons pesan yang berisi alasan afk
    if (!m.quoted || !m.quoted.sender) {
      return mecha.reply(m.chat, 'Silakan reply pesan user yang sedang AFK untuk mengubah alasannya.', m);
    }

    // Ambil user yang sedang AFK
    let user = global.db.users[m.quoted.sender];

    // Cek apakah user yang di-reply ada dalam database
    if (!user) {
      return mecha.reply(m.chat, 'User yang Anda reply tidak ditemukan di database.', m);
    }

    // Ambil teks alasan yang ingin diubah, pastikan command diikuti alasan baru
    let alasanBaru = m.text.replace(`${prefix}setalasan`, '').trim();

    // Jika alasan baru kosong, beri tahu pengguna
    if (!alasanBaru) {
      return mecha.reply(m.chat, 'Silakan masukkan alasan baru setelah command!', m);
    }

    // Ganti alasan AFK user dengan alasan baru, meskipun alasan sebelumnya tidak ada
    user.alasan = alasanBaru;

    // Simpan perubahan alasan afk ke database
    global.db.users[m.quoted.sender] = user;

    // Kirimkan konfirmasi
    mecha.reply(m.chat, `Successfully changed reason to: ${alasanBaru}`, m);
  },
  owner: true, // Hanya owner yang dapat mengakses fitur ini
};