exports.run = {
    usage: ['unadmin'],
    use: 'id grup',
    category: 'owner',
    async: async (m, { mecha }) => {

        if (!m.args[0]) {
            return mecha.sendMessage(m.chat, { 
                text: `Masukkan ID grup dengan format yang benar!\n\nContoh:\n${m.prefix + m.command} 111736183728382737@g.us` 
            }, { quoted: m });
        }

        let groupId = m.args[0].trim();

        if (!groupId.endsWith('@g.us')) {
            return mecha.sendMessage(m.chat, { 
                text: 'ID grup tidak valid! Pastikan ID grup berformat benar, misalnya: 111736183728382737@g.us' 
            }, { quoted: m });
        }

        let metadata = await mecha.groupMetadata(groupId).catch(() => null);
        if (!metadata) {
            return mecha.sendMessage(m.chat, { 
                text: 'Gagal mendapatkan informasi grup. Pastikan bot ada di grup tersebut dan ID grup benar!' 
            }, { quoted: m });
        }

        let owner = m.sender;
        let isAdmin = metadata.participants.find(p => p.id === owner && p.admin);

        if (!isAdmin) {
            return mecha.sendMessage(m.chat, { text: 'Kamu bukan admin di grup ini!' }, { quoted: m });
        }

        await mecha.groupParticipantsUpdate(groupId, [owner], 'demote')
            .then(() => mecha.sendReact(m.chat, '✅', m.key))
            .catch(() => mecha.sendReact(m.chat, '❌', m.key));
    },
    private: true,
    owner: true,
    boAdmin: true
};