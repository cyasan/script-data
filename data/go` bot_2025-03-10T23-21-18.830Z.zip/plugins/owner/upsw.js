// plugin upsw (buat story WhatsApp)
exports.run = {
  usage: ['upsw', 'upswimage', 'upswvideo'],
  category: 'owner',
  async: async (m, { mecha, prefix }) => {

    // Jika perintah .upsw diikuti dengan teks
    if (m.text.startsWith(`${prefix}upsw`)) {
      let storyText = m.text.replace(`${prefix}upsw`, '').trim();
      
      if (!storyText) {
        return mecha.reply(m.chat, 'Silakan masukkan teks untuk story!', m);
      }

      // Kirimkan story teks ke WhatsApp
      await mecha.sendMessage(m.chat, {
        text: storyText
      });

      // Kirim balasan konfirmasi
      return mecha.reply(m.chat, `Successfully posted text story: ${storyText}`, m);
    }

    // Jika perintah .upswimage sambil reply gambar
    if (m.text.startsWith(`${prefix}upswimage`) && m.quoted && m.quoted.mtype === 'imageMessage') {
      const image = m.quoted;

      // Kirimkan gambar sebagai WhatsApp story
      await mecha.sendMessage(m.chat, {
        image: image,
        caption: "Story image from owner"
      });

      // Kirim balasan konfirmasi
      return mecha.reply(m.chat, 'Successfully posted image story!', m);
    }

    // Jika perintah .upswvideo sambil reply video
    if (m.text.startsWith(`${prefix}upswvideo`) && m.quoted && m.quoted.mtype === 'videoMessage') {
      const video = m.quoted;

      // Kirimkan video sebagai WhatsApp story
      await mecha.sendMessage(m.chat, {
        video: video,
        caption: "Story video from owner"
      });

      // Kirim balasan konfirmasi
      return mecha.reply(m.chat, 'Successfully posted video story!', m);
    }

    // Jika tidak ada yang cocok
    return mecha.reply(m.chat, 'Perintah tidak dikenali. Gunakan .upsw untuk teks, .upswimage untuk gambar, atau .upswvideo untuk video.', m);
  },
  owner: true, // Hanya owner yang dapat mengakses fitur ini
};