exports.run = {
  usage: ['setlevel'],
  use: 'level',
  category: 'owner',
  async: async (m, { func, mecha, users, setting, froms, prefix }) => {

    // Pastikan pengguna sedang merespons pesan user yang ingin diubah levelnya
    if (!m.quoted || !m.quoted.sender) {
      return mecha.reply(m.chat, 'Silakan reply pesan user yang ingin diubah levelnya.', m);
    }

    // Ambil user yang sedang di-reply
    let user = global.db.users[m.quoted.sender];

    // Cek apakah user yang di-reply ada dalam database
    if (!user) {
      return mecha.reply(m.chat, 'User yang Anda reply tidak ditemukan di database.', m);
    }

    // Ambil input level baru
    let levelBaru = m.text.replace(`${prefix}setlevel`, '').trim();

    // Validasi input level (hanya angka positif)
    if (!levelBaru || isNaN(levelBaru) || parseInt(levelBaru) <= 0) {
      return mecha.reply(m.chat, 'Silakan masukkan level yang valid (angka lebih dari 0).', m);
    }

    // Set level baru untuk pengguna
    user.level = parseInt(levelBaru);

    // Simpan perubahan level ke database
    global.db.users[m.quoted.sender] = user;

    // Kirimkan konfirmasi perubahan level
    mecha.reply(m.chat, `Successfully changed level to: ${levelBaru}.`, m);
  },
  owner: true, // Hanya owner yang dapat mengakses fitur ini
};