exports.run = {
  usage: ['bcuser', 'bcprem', 'bcpc', 'bcgc', 'bcgc2', 'bcsewa', 'bctarget', 'sendmsg'],
  use: 'text',
  category: 'owner',
  async: async (m, { func, mecha, store, setting, quoted }) => {
    const sendBroadcast = async (targets, message, media = null, caption = '') => {
      let successCount = 0;
      let failedCount = 0;
      const failedTargets = [];

      for (let jid of targets) {
        try {
          await func.delay(2000); // Delay 2 detik antara setiap pengiriman
          if (media) {
            await mecha.sendMedia(jid, media, null, {
              caption: caption ? '乂  B R O A D C A S T\n\n' + caption : '',
              mentions: [jid],
              expiration: 86400
            });
          } else {
            await mecha.sendMessageModify(jid, message, null, {
              title: 'System Notification',
              body: global.header,
              thumbnail: await fetchImageBuffer(setting.cover),
              expiration: 86400
            });
          }
          successCount++;
        } catch (error) {
          failedCount++;
          failedTargets.push(jid);
          console.error(`Gagal mengirim ke ${jid}:`, error);
        }
      }

      return { successCount, failedCount, failedTargets };
    };

    switch (m.command) {
      case 'bcuser': {
        if (!m.text && !quoted) return mecha.sendMessage(m.chat, { text: func.example(m.cmd, 'minimal mandi') }, { quoted: m });
        let data = Object.values(global.db.users).filter(v => v.register && !v.banned).map(v => v.jid);
        await mecha.sendMessage(m.chat, { text: `Otw broadcast ke ${data.length} User` }, { quoted: m });

        let txt = m.text ? m.text.replace('@owner', `@${global.owner.split('@')[0]}`) : '';
        let media = quoted ? await quoted.download() : null;
        let caption = quoted && quoted.caption ? quoted.caption : txt;

        const { successCount, failedCount, failedTargets } = await sendBroadcast(data, caption, media);

        mecha.sendMessage(m.chat, {
          text: `Sukses broadcast ke ${successCount} User\nGagal: ${failedCount}\nTarget gagal: ${failedTargets.join(', ')}`
        }, { quoted: m });
      }
      break;

      case 'bcprem': {
        if (!m.text && !quoted) return mecha.sendMessage(m.chat, { text: func.example(m.prefix + m.command, 'minimal mandi') }, { quoted: m });
        let data = Object.values(global.db.users).filter(v => v.register && v.premium && !v.banned).map(v => v.jid);
        await mecha.sendMessage(m.chat, { text: `Otw broadcast ke ${data.length} Premium User` }, { quoted: m });

        let txt = m.text ? m.text.replace('@owner', `@${global.owner.split('@')[0]}`) : '';
        let media = quoted ? await quoted.download() : null;
        let caption = quoted && quoted.caption ? quoted.caption : txt;

        const { successCount, failedCount, failedTargets } = await sendBroadcast(data, caption, media);

        mecha.sendMessage(m.chat, {
          text: `Sukses broadcast ke ${successCount} Premium Users\nGagal: ${failedCount}\nTarget gagal: ${failedTargets.join(', ')}`
        }, { quoted: m });
      }
      break;

      case 'bcpc': {
        if (!m.text && !quoted) return mecha.sendMessage(m.chat, { text: func.example(m.prefix + m.command, 'minimal mandi') }, { quoted: m });
        let data = await store.chats.all().filter(v => v.id.endsWith('.net')).map(v => v.id);

        let txt = m.text ? m.text.replace('@owner', `@${global.owner.split('@')[0]}`) : '';
        let media = quoted ? await quoted.download() : null;
        let caption = quoted && quoted.caption ? quoted.caption : txt;

        mecha.sendMessage(m.chat, { text: `Mengirim broadcast ke ${data.length} Chat\nWaktu Selesai ${data.length * 2} detik` }, { quoted: m });

        const { successCount, failedCount, failedTargets } = await sendBroadcast(data, caption, media);

        mecha.sendMessage(m.chat, {
          text: `Sukses mengirim broadcast ke ${successCount} Users\nGagal: ${failedCount}\nTarget gagal: ${failedTargets.join(', ')}`
        }, { quoted: m });
      }
      break;

      case 'bcgc': {
        let getGroups = await mecha.groupFetchAllParticipating();
        let groups = Object.entries(getGroups).slice(0).map(entry => entry[1]);
        let data = groups.map(v => v.id);

        let txt = m.text ? m.text.replace('@owner', `@${global.owner.split('@')[0]}`) : '';
        let media = quoted ? await quoted.download() : null;
        let caption = quoted && quoted.caption ? quoted.caption : txt;

        mecha.sendMessage(m.chat, { text: `Mengirim broadcast ke ${data.length} group chat, waktu selesai ${data.length * 2} detik` }, { quoted: m });

        const { successCount, failedCount, failedTargets } = await sendBroadcast(data, caption, media);

        mecha.sendMessage(m.chat, {
          text: `Successfully send broadcast message to ${successCount} groups\nGagal: ${failedCount}\nTarget gagal: ${failedTargets.join(', ')}`
        }, { quoted: m });
      }
      break;

      case 'bcsewa': {
        let data = Object.values(global.db.groups).filter(v => v.sewa.status).map(x => x.jid);

        let txt = m.text ? m.text.replace('@owner', `@${global.owner.split('@')[0]}`) : '';
        let media = quoted ? await quoted.download() : null;
        let caption = quoted && quoted.caption ? quoted.caption : txt;

        mecha.sendMessage(m.chat, { text: `Mengirim broadcast ke ${data.length} group chat, waktu selesai ${data.length * 2} detik` }, { quoted: m });

        const { successCount, failedCount, failedTargets } = await sendBroadcast(data, caption, media);

        mecha.sendMessage(m.chat, {
          text: `Successfully send broadcast message to ${successCount} groups\nGagal: ${failedCount}\nTarget gagal: ${failedTargets.join(', ')}`
        }, { quoted: m });
      }
      break;

      case 'bctarget': {
        if (!m.text && !quoted) return mecha.sendMessage(m.chat, { text: func.example(m.prefix + m.command, 'minimal mandi | 6281234567890 atau 120363021@g.us') }, { quoted: m });

        let parts = m.text.split('|');  
        if (parts.length !== 2) return mecha.sendMessage(m.chat, { text: "Format salah. Gunakan format: teks | nomor atau teks | ID grup." }, { quoted: m });  

        let textMessage = parts[0].trim();  
        let target = parts[1].trim();  

        if (/^\d+$/.test(target)) { // Jika target hanya angka (nomor HP tanpa @s.whatsapp.net)  
          target = target + '@s.whatsapp.net';  
        }  

        if (target.endsWith('@s.whatsapp.net')) {  
          // Kirim ke nomor individu  
          await mecha.sendMessage(m.chat, { text: `Mengirim broadcast ke ${target.replace('@s.whatsapp.net', '')}...` }, { quoted: m });  
          await mecha.sendMessage(target, { text: textMessage }, { quoted: func.fstatus("System Notification") });  
          await mecha.sendMessage(m.chat, { text: `Berhasil mengirim broadcast ke ${target.replace('@s.whatsapp.net', '')}` }, { quoted: m });  
        } else if (target.endsWith('@g.us')) {  
          // Kirim ke ID Grup dengan Hidetag  
          let groupMetadata = await mecha.groupMetadata(target);  
          let participants = groupMetadata.participants.map(v => v.id);  

          await mecha.sendMessage(m.chat, { text: `Mengirim broadcast ke grup ${target} dengan ${participants.length} anggota...` }, { quoted: m });  

          await mecha.sendMessage(target, {  
            text: textMessage,  
            mentions: participants  
          }, { quoted: func.fstatus("System Notification"), ephemeralExpiration: 86400 });  

          await mecha.sendMessage(m.chat, { text: `Berhasil mengirim broadcast ke grup!` }, { quoted: m });  
        } else {  
          return mecha.sendMessage(m.chat, { text: "Format salah. Gunakan nomor tanpa '@s.whatsapp.net' atau ID grup dengan '@g.us'." }, { quoted: m });  
        }  
      }  
      break;  

      case 'bcgc2': {  
        if (!m.text && !quoted) return mecha.sendMessage(m.chat, { text: func.example(m.prefix + m.command, 'minimal mandi') }, { quoted: m });  

        let getGroups = await mecha.groupFetchAllParticipating();  
        let groups = Object.entries(getGroups).slice(0).map(entry => entry[1]);  
        let data = groups.map(v => v.id);  
        let textMessage = m.text ? m.text.trim() : '';
        let media = quoted ? await quoted.download() : null;
        let caption = quoted && quoted.caption ? quoted.caption : textMessage;

        mecha.sendMessage(m.chat, { text: `Mengirim broadcast ke ${data.length} grup...` }, { quoted: m });  

        const { successCount, failedCount, failedTargets } = await sendBroadcast(data, caption, media);

        mecha.sendMessage(m.chat, {
          text: `Berhasil mengirim broadcast ke ${successCount} grup!\nGagal: ${failedCount}\nTarget gagal: ${failedTargets.join(', ')}`
        }, { quoted: m });  
      }  
      break;  
case 'sendmsg': {
  if (!m.text && !quoted) return mecha.sendMessage(m.chat, { text: func.example(m.prefix + m.command, 'minimal mandi | 120363021@g.us atau 6281234567890') }, { quoted: m });

  let parts = m.text.split('|');
  if (parts.length !== 2) return mecha.sendMessage(m.chat, { text: "Format salah. Gunakan format: teks | ID grup atau nomor telepon." }, { quoted: m });

  let textMessage = parts[0].trim();
  let target = parts[1].trim();

  // Cek apakah target adalah ID grup atau nomor telepon
  if (!target.endsWith('@g.us')) {
    // Jika bukan ID grup, asumsikan itu nomor telepon
    if (!/^\d+$/.test(target)) return mecha.sendMessage(m.chat, { text: "Format nomor telepon salah. Gunakan angka saja, tanpa spasi atau tanda lain." }, { quoted: m });

    target = target + "@s.whatsapp.net"; // Format nomor telepon untuk WhatsApp
  }

  // Kirim pesan ke target
  await mecha.sendMessage(m.chat, { text: `Mengirim pesan ke ${target}...` }, { quoted: m });

  await mecha.sendMessage(target, {    
    text: textMessage,
    contextInfo: {
      forwardingScore: 1,
      isForwarded: true
    }
  }, { quoted: func.fstatus("Owner message") });

  await mecha.sendMessage(m.chat, { text: `Berhasil mengirim pesan ke ${target}!` }, { quoted: m });
}
break;
    }
  },
  owner: true
};