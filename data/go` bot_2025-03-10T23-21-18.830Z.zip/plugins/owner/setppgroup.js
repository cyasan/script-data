exports.run = {
    usage: ['settingppgroup'],
    hidden: ['settingppgrup', 'settingppgc'],
    use: 'reply photo / full + id_grup',
    category: 'owner',
    async: async (m, { func, mecha, quoted }) => {

        if (!m.args[0]) {
            return mecha.sendMessage(m.chat, { 
                text: `Masukkan ID grup!\nContoh: ${m.prefix + m.command} 111736183728382737@g.us` 
            }, { quoted: m })
        }

        if (!quoted || !/image\/(jpe?g|png)/.test(quoted.mime)) {
            return mecha.sendMessage(m.chat, { 
                text: `Kirim/reply gambar dengan caption ${m.cmd} id_grup` 
            }, { quoted: m })
        }

        let groupId = m.args[0]
        let media = await quoted.download()

        await mecha.updateProfilePicture(groupId, media)
            .then(async () => {
                // Kirim respons emoji di private chat owner
                mecha.sendReact(m.chat, '✅', m.key)

                // Kirim pesan ke grup
                await mecha.sendMessage(groupId, { 
                    text: `Bot mengganti foto profil Group atas perintah owner.` 
                }, { quoted: func.fstatus("System Notification") })
            })
            .catch(() => mecha.sendReact(m.chat, '❌', m.key))
    },
    private: true,
    owner: true,
    boAdmin: true
}