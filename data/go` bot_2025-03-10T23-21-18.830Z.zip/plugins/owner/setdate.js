exports.run = {
  usage: ['setdate'],
  use: 'tanggal bulan tahun',
  category: 'owner',
  async: async (m, { func, mecha, users, setting, froms, prefix }) => {

    // Pastikan pengguna sedang merespons pesan user yang ingin diubah tanggalnya
    if (!m.quoted || !m.quoted.sender) {
      return mecha.reply(m.chat, 'Silakan reply pesan user yang ingin diubah tanggal registrasinya.', m);
    }

    // Ambil user yang sedang di-reply
    let user = global.db.users[m.quoted.sender];

    // Cek apakah user yang di-reply ada dalam database
    if (!user) {
      return mecha.reply(m.chat, 'User yang Anda reply tidak ditemukan di database.', m);
    }

    // Ambil input tanggal baru
    let tanggalBaru = m.text.replace(`${prefix}setdate`, '').trim();

    // Validasi format tanggal (menggunakan regex untuk memeriksa format)
    let regexTanggal = /^(\d{1,2})\s([a-zA-Z]+)\s(\d{4})$/; // Format: DD MMMM YYYY
    let match = tanggalBaru.match(regexTanggal);

    if (!match) {
      return mecha.reply(m.chat, 'Silakan masukkan tanggal dengan format yang benar (contoh: 12 Desember 2024).', m);
    }

    // Parsing tanggal
    let [_, hari, bulan, tahun] = match;

    // Daftar bulan dalam bahasa Indonesia
    const bulanIndo = [
      'januari', 'februari', 'maret', 'april', 'mei', 'juni', 
      'juli', 'agustus', 'september', 'oktober', 'november', 'desember'
    ];

    bulan = bulan.toLowerCase();
    if (!bulanIndo.includes(bulan)) {
      return mecha.reply(m.chat, 'Nama bulan tidak valid. Pastikan Anda menggunakan nama bulan dalam bahasa Indonesia.', m);
    }

    // Validasi tanggal
    let tanggal = new Date(tahun, bulanIndo.indexOf(bulan), hari);
    if (isNaN(tanggal.getTime())) {
      return mecha.reply(m.chat, 'Tanggal yang Anda masukkan tidak valid.', m);
    }

    // Simpan tanggal ke database dalam format DD MMMM YYYY
    user.date = `${hari} ${bulan.charAt(0).toUpperCase() + bulan.slice(1)} ${tahun}`;

    // Kirimkan konfirmasi perubahan tanggal registrasi
    mecha.reply(m.chat, `Successfully changed registration date to: ${user.date}.`, m);
  },
  owner: true, // Hanya owner yang dapat mengakses fitur ini
};