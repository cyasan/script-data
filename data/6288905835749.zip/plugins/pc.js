exports.run = {
    main: async (m, {
        func,
        mecha,
        commands = []
    }) => {
        if (!m.fromMe && m.isPc && !(m.command && Array.isArray(commands) && commands.includes(m.command)) && !m.isPrefix && !/protocolMessage/.test(m.mtype)) {
            let user = global.db.users[m.sender];
            if (!('private' in user)) user.private = 0;

            const cooldown = 86400000;
            if (new Date() - user.private < cooldown) return;

            let caption = `Halo @${m.sender.split('@')[0]} 👋🏻, ada yang bisa saya bantu? \nKetik ${m.prefix}menu untuk melihat daftar perintah bot ini.`.trim();

            // Tambahkan pesan jika user belum register
            if (!user.register) {
                caption += `\n\n> _Registrasi di bot kami agar data kamu tidak hilang!_`;
            }

            mecha.sendMessage(m.chat, {
                text: caption,
                contextInfo: {
                    forwardingScore: 10,
                    isForwarded: true,
                    mentionedJid: [m.sender],
                    businessMessageForwardInfo: {
                        businessOwnerJid: '6283878301449@s.whatsapp.net'
                    },
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: '120363327728368573@newsletter',
                        serverMessageId: null,
                        newsletterName: `Powered by ` + global.ownerName
                    }
                }
            }, {
                quoted: m || null,
                ephemeralExpiration: m.expiration
            });

            user.private = new Date() * 1;
        }
    },
    private: true,
    location: 'plugins/event/_private.js'
};