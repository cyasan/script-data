const {
    default: makeWASocket,
    downloadContentFromMessage,
    getContentType,
    generateWAMessage,
    generateWAMessageFromContent,
    generateForwardMessageContent,
    prepareWAMessageMedia,
    getBinaryNodeChild,
    areJidsSameUser,
    proto,
    delay,
    jidDecode,
} = require('@whiskeysockets/baileys');
const fs = require('fs');
const chalk = require('chalk');
const moment = require('moment-timezone');
const fetch = require('node-fetch');
const util = require('util');
const phoneNumber = require('awesome-phonenumber');
const jimp = require('jimp');
const path = require('path');
const {
    fromBuffer
} = require('file-type');
const {
    randomBytes
} = require('crypto');
const func = require('./functions.js');
const {
    imageToWebp,
    videoToWebp,
    writeExifImg,
    writeExifVid,
    writeExifWebp
} = require('../lib/exif.js');

module.exports = class Extra {
    mention = (text = '') => text.match('@') ? [...text.matchAll(/@([0-9]{5,16}|0)/g)].map(v => v[1] + '@s.whatsapp.net') : []
    generateMessageId = () => {
        const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
        return 'LULLI' + Array.from({
            length: 11
        }, () => characters.charAt(Math.floor(Math.random() * characters.length))).join('');
    }

    initAdditionalFunc = (lulli, store) => {
        const {
            sendMessage
        } = lulli;

        lulli.sendMessage = async (jid, config, options) => {
            const regex = /^(\d.*@(s\.whatsapp\.net|g\.us|newsletter)|status@broadcast)$/;
            const chatId = regex.test(jid) ? jid : jid.replace(/[^0-9]/gi, '') + '@s.whatsapp.net';
            if (!regex.test(chatId)) return false;
            return await sendMessage(chatId, config, {
                messageId: this.generateMessageId(),
                ...options
            })
        }

        lulli.decodeJid = (jid) => {
            if (!jid) return jid
            if (/:\d+@/gi.test(jid)) {
                let decode = jidDecode(jid) || {}
                return decode.user && decode.server && decode.user + '@' + decode.server || jid
            } else return jid
        }


        lulli.getName = (jid) => {
            let id = lulli.decodeJid(jid)
            let v
            if (id?.endsWith('@g.us')) return new Promise(async (resolve) => {
                v = this.store.contacts[id] || this.store.messages['status@broadcast']?.array?.find(a => a?.key?.participant === id)
                if (!(v.name || v.subject)) v = lulli.groupMetadata[id] || {}
                resolve(v?.name || v?.subject || v?.pushName || (phoneNumber('+' + id.replace('@g.us', '')).getNumber('international')))
            })
            else v = id === '0@s.whatsapp.net' ? {
                id,
                name: 'WhatsApp'
            } : id === lulli.decodeJid(lulli?.user?.id) ? lulli.user : (this.store.contacts[id] || {})
            return (v?.name || v?.subject || v?.pushName || v?.verifiedName || (phoneNumber('+' + id.replace('@s.whatsapp.net', '')).getNumber('international')))
        }

        lulli.getBusinessProfile = async (jid) => {
            const results = await lulli.query({
                tag: 'iq',
                attrs: {
                    to: 's.whatsapp.net',
                    xmlns: 'w:biz',
                    type: 'get'
                },
                content: [{
                    tag: 'business_profile',
                    attrs: {
                        v: '244'
                    },
                    content: [{
                        tag: 'profile',
                        attrs: {
                            jid
                        }
                    }]
                }]
            })
            const profiles = getBinaryNodeChild(getBinaryNodeChild(results, 'business_profile'), 'profile')
            if (!profiles) return {} // if not bussines
            const address = getBinaryNodeChild(profiles, 'address')
            const description = getBinaryNodeChild(profiles, 'description')
            const website = getBinaryNodeChild(profiles, 'website')
            const email = getBinaryNodeChild(profiles, 'email')
            const category = getBinaryNodeChild(getBinaryNodeChild(profiles, 'categories'), 'category')
            return {
                jid: profiles.attrs?.jid,
                address: address?.content.toString(),
                description: description?.content.toString(),
                website: website?.content.toString(),
                email: email?.content.toString(),
                category: category?.content.toString(),
            }
        }

        lulli.sendGroupInvite = async (chatId, participant, options = {}) => {
            let {
                inviteCode,
                inviteExpiration,
                groupName,
                jpegThumbnail,
                caption,
                quoted
            } = options;
            if (!chatId || !inviteCode) return;
            let groupInvite = generateWAMessageFromContent(chatId, proto.Message.fromObject({
                groupInviteMessage: {
                    groupJid: chatId,
                    inviteCode: inviteCode,
                    inviteExpiration: inviteExpiration ? inviteExpiration : +new Date(new Date + (3 * 86400000)),
                    groupName: groupName ? groupName : lulli.getName(chatId),
                    jpegThumbnail: await lulli.resize(jpegThumbnail ? jpegThumbnail : 'https://telegra.ph/file/0d25a520bfa0909c74466.jpg', 200, 200),
                    caption: caption ? caption : 'Invitation to join my WhatsApp group',
                }
            }), {
                userJid: participant,
                quoted
            })
            let message = await lulli.relayMessage(participant, groupInvite.message, {
                messageId: groupInvite.key.id
            })
            return message
        }

        lulli.groupQueryInvite = async (code) => {
            let result = await lulli.query({
                tag: "iq",
                attrs: {
                    type: "get",
                    xmlns: "w:g2",
                    to: "@g.us"
                },
                content: [{
                    tag: "invite",
                    attrs: {
                        code
                    }
                }]
            })
            let group = getBinaryNodeChild(result, "group")
            let descRes = getBinaryNodeChild(group, "description")
            let desc, descId, descOwner, descTime
            if (descRes) {
                desc = getBinaryNodeChild(descRes, "body")?.content?.toString(),
                    descId = descRes?.attrs?.id,
                    descOwner = descRes?.attrs?.participant,
                    descTime = descRes?.attrs?.t
            }
            const data = {
                id: group?.attrs?.id.includes("@") ? group?.attrs?.id : group?.attrs?.id + "@g.us",
                owner: group?.attrs?.creator,
                subject: group?.attrs?.subject,
                subjectOwner: group?.attrs?.s_o,
                subjectTime: group?.attrs?.s_t,
                size: group?.attrs?.size,
                creation: group?.attrs?.creation,
                participants: group?.content?.filter(v => v.tag == "participant").map(v => v.attrs),
                desc,
                descId,
                descOwner,
                descTime
            }
            return data;
        }

        if (lulli.user && lulli.user.id) lulli.user.jid = lulli.decodeJid(lulli.user.id)
        lulli.ments = this.mention;
        lulli.makeid = (count) => randomBytes(count).toString('hex');

        lulli.sendMessageModify = (jid, text = '', quoted = '', opts = {}) => {
            const regex = /^\d.*(@s\.whatsapp\.net|@g\.us|@newsletter)$/;
            if (!regex.test(jid)) return false;
            return lulli.sendMessage(jid, {
                text: text,
                contextInfo: {
                    mentionedJid: this.mention(text),
                    forwardingScore: 256,
                    isForwarded: true,
                    ...(opts.newsletter ? {
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: '120363261409301854@newsletter',
                            newsletterName: `Ping : ${func.ping(4)} • Powered by SuryaDev`,
                            serverMessageId: -1
                        }
                    } : {}),
                    externalAdReply: {
                        showAdAttribution: opts.ads,
                        title: opts.title ? opts.title : global.header,
                        body: opts.body ? opts.body : global.footer,
                        mediaType: 1,
                        previewType: 'PHOTO',
                        thumbnailUrl: opts.thumbUrl,
                        thumbnail: opts.thumbnail,
                        sourceUrl: opts.url,
                        renderLargerThumbnail: opts.largeThumb
                    }
                }
            }, {
                quoted,
                ephemeralExpiration: func.expiration(opts.expiration),
                ...opts
            })
        }

        lulli.reply = async (jid, text, quoted, options = {}) => {
            const regex = /^\d.*(@s\.whatsapp\.net|@g\.us|@newsletter)$/;
            if (!regex.test(jid)) return false;
            await lulli.sendPresenceUpdate('composing', jid)
            return lulli.sendMessage(jid, {
                text: text,
                mentions: this.mention(text),
                ...options
            }, {
                quoted,
                ephemeralExpiration: func.expiration(options.expiration)
            })
        }

        lulli.sendReact = async (jid, emoticon, keys = {}) => {
            let reactionMessage = {
                react: {
                    text: emoticon,
                    key: keys
                }
            }
            return await lulli.sendMessage(jid, reactionMessage)
        }

        lulli.sendPoll = (jid, name = '', values = [], selectableCount = 1) => {
            return lulli.sendMessage(jid, {
                poll: {
                    name,
                    values,
                    selectableCount
                }
            })
        }

        lulli.sendbut = async (jid, text = '', footer = '', button = [...[display, content]], quoted, options = {}) => {
            const regex = /^\d.*(@s\.whatsapp\.net|@g\.us|@newsletter)$/;
            if (!regex.test(jid)) return false;
            if (!Array.isArray(button)) return;
            if (button.length == 0) return;
            if (!options.mentions) options.mentions = [];
            if (options.media) var {
                mime,
                data
            } = await lulli.getFile(options.media, true)
            if (global.config.button) {
                let buttons = [];
                button.map(([displayText, buttonId]) => {
                    buttons.push({
                        buttonId: buttonId,
                        buttonText: {
                            displayText: displayText
                        },
                        type: 1
                    })
                })
                return await lulli.sendMessage(jid, {
                    ...(options.media ? {
                        [`${mime.split('/')[0]}`]: data,
                        caption: text
                    } : {
                        text: text
                    }),
                    buttons: buttons,
                    footer: footer,
                    mentions: [...options.mentions, ...this.mention(text)],
                    viewOnce: true,
                    headerType: 6,
                }, {
                    quoted,
                    ephemeralExpiration: func.expiration(options.expiration)
                });
            } else {
                if (options.caption) text += options.caption;
                return await lulli.sendMessage(jid, {
                    ...(options.media ? {
                        [`${mime.split('/')[0]}`]: data,
                        caption: text
                    } : {
                        text
                    }),
                    mentions: [...options.mentions, ...this.mention(text)],
                }, {
                    quoted,
                    ephemeralExpiration: func.expiration(options.expiration)
                });
            }
        }

        lulli.sendButton = async (from, title = '', text = '', footer = '', button = [...[type, text, content]], quoted, options = {}) => {
            if (!Array.isArray(button)) return;
            if (button.length == 0) return;
            if (!options.mentions) options.mentions = [];
            let buttons = [];
            button.map(([name, display_text, id], i) => {
                if (name == 'list') return buttons.push({
                    name: 'single_select',
                    buttonParamsJson: JSON.stringify({
                        title: display_text,
                        sections: id
                    })
                });
                else if (name == 'button') return buttons.push({
                    name: 'quick_reply',
                    buttonParamsJson: JSON.stringify({
                        display_text: display_text,
                        id: id
                    })
                });
                else if (name == 'url') return buttons.push({
                    name: 'cta_url',
                    buttonParamsJson: JSON.stringify({
                        display_text: display_text,
                        url: id,
                        merchant_url: id
                    })
                });
                else if (name == 'call') return buttons.push({
                    name: 'cta_call',
                    buttonParamsJson: JSON.stringify({
                        display_text: display_text,
                        id: id
                    })
                });
                else if (name == 'copy') return buttons.push({
                    name: 'cta_copy',
                    buttonParamsJson: JSON.stringify({
                        display_text: display_text,
                        id: id,
                        copy_code: id
                    })
                });
                else if (name == 'reminder') return buttons.push({
                    name: 'cta_reminder',
                    buttonParamsJson: JSON.stringify({
                        display_text: display_text,
                        id: id
                    })
                });
                else if (name == 'address') return buttons.push({
                    name: 'address_message',
                    buttonParamsJson: JSON.stringify({
                        display_text: display_text,
                        id: id
                    })
                });
                else if (name == 'location') return buttons.push({
                    name: 'send_location',
                    buttonParamsJson: JSON.stringify({
                        display_text: display_text,
                        id: id
                    })
                });
            })
            if (options.media) var {
                mime,
                data
            } = await lulli.getFile(options.media, true)
            let msg = generateWAMessageFromContent(from, proto.Message.fromObject({
                viewOnceMessage: {
                    message: {
                        interactiveMessage: proto.Message.InteractiveMessage.create({
                            contextInfo: {
                                mentionedJid: [...options.mentions, ...this.mention(title + text)],
                                isForwarded: true,
                                forwardingScore: 256,
                                forwardedNewsletterMessageInfo: {
                                    newsletterJid: '120363261409301854@newsletter',
                                    newsletterName: `Ping : ${func.ping(4)} • Powered by SuryaDev`,
                                    serverMessageId: -1
                                }
                            },
                            body: proto.Message.InteractiveMessage.Body.create({
                                text: text
                            }),
                            footer: proto.Message.InteractiveMessage.Footer.create({
                                text: footer
                            }),
                            header: proto.Message.InteractiveMessage.Header.create({
                                title: title,
                                subtitle: 'SuryaDev',
                                hasMediaAttachment: options.media ? true : false,
                                ...(options.media ? (await prepareWAMessageMedia({
                                    [`${mime.split('/')[0]}`]: data
                                }, {
                                    upload: lulli.waUploadToServer
                                })) : {}),
                            }),
                            nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                                buttons: buttons
                            })
                        })
                    }
                }
            }), {
                userJid: lulli.user.jid,
                quoted
            });
            return lulli.relayMessage(msg.key.remoteJid, msg.message, {
                messageId: msg.key.id
            })
        }

        lulli.sendIAMessage = async (jid, buttons = [], quoted, opts = {}, options = {}) => {
            if (!Array.isArray(buttons)) return;
            if (buttons.length == 0) return;
            if (!opts.mentions) opts.mentions = [];
            if (opts.media) {
                var {
                    mime,
                    data
                } = await lulli.getFile(opts.media, true)
                if (/image/.test(mime)) {
                    var message = await prepareWAMessageMedia({
                        image: data
                    }, {
                        upload: lulli.waUploadToServer
                    });
                    var media = {
                        imageMessage: message.imageMessage
                    };
                } else if (/video/.test(mime)) {
                    var message = await prepareWAMessageMedia({
                        video: data
                    }, {
                        upload: lulli.waUploadToServer
                    });
                    var media = {
                        videoMessage: message.videoMessage
                    };
                } else {
                    var media = {};
                }
            }
            const msg = generateWAMessageFromContent(jid, {
                viewOnceMessage: {
                    message: {
                        messageContextInfo: {
                            deviceListMetadata: {},
                            deviceListMetadataVersion: 2
                        },
                        interactiveMessage: {
                            header: proto.Message.InteractiveMessage.create({
                                title: opts.header ? opts.header : '',
                                subtitle: opts.subtitle ? opts.subtitle : '',
                                hasMediaAttachment: !!(opts.media && /image|video/.test(mime)),
                                ...media
                            }),
                            body: proto.Message.InteractiveMessage.create({
                                text: opts.content ? opts.content : ''
                            }),
                            footer: proto.Message.InteractiveMessage.create({
                                text: opts.footer ? opts.footer : ''
                            }),
                            nativeFlowMessage: proto.Message.InteractiveMessage.create({
                                buttons: buttons,
                                messageParamsJson: ''
                            }),
                            contextInfo: {
                                mentionedJid: [...opts.mentions, ...this.mention(opts.content)],
                                isForwarded: true,
                                forwardingScore: 256,
                                forwardedNewsletterMessageInfo: {
                                    newsletterJid: '120363261409301854@newsletter',
                                    newsletterName: `Ping ${func.ping(4)} • Powered by SuryaDev`,
                                    serverMessageId: -1
                                },
                                ...options
                            }
                        }
                    }
                }
            }, {
                userJid: lulli.user.jid,
                quoted
            });
            await lulli.sendPresenceUpdate('composing', jid);
            lulli.relayMessage(jid, msg.message, {
                messageId: msg.key.id
            });
            return msg;
        };

        lulli.notify = async (text) => {
            const contextInfo = {
                mentionedJid: this.mention(text),
                externalAdReply: {
                    title: 'System Notification',
                    body: global.header,
                    thumbnailUrl: setting.cover,
                    sourceUrl: 'https://tiktok.com/@suryaskylark05',
                    mediaType: 1,
                    renderLargerThumbnail: false
                }
            };
            let messages = {
                extendedTextMessage: {
                    text: text,
                    mentions: this.mention(text),
                    contextInfo: contextInfo
                }
            };
            let messageToChannel = proto.Message.encode(messages).finish();
            let result = {
                tag: 'message',
                attrs: {
                    to: '120363261409301854@newsletter',
                    type: 'text'
                },
                content: [{
                    tag: 'plaintext',
                    attrs: {},
                    content: messageToChannel
                }]
            };
            return lulli.query(result);
        };

        lulli.setStatus = async (status) => {
            return await lulli.query({
                tag: 'iq',
                attrs: {
                    to: '@s.whatsapp.net',
                    type: 'set',
                    xmlns: 'status',
                },
                content: [{
                    tag: 'status',
                    attrs: {},
                    content: Buffer.from(status, 'utf-8')
                }]
            })
            // <iq to="s.whatsapp.net" type="set" xmlns="status" id="21168.6213-69"><status>"Hai, saya menggunakan WhatsApp"</status></iq>
        }

        lulli.resize = async (image, width, height) => {
            if (!width) width = 400;
            if (!height) height = 400;
            let buffer = Buffer.isBuffer(image) ? image : /^data:.*?\/.*?;base64,/i.test(image) ? Buffer.from(image.split(',')[1], 'base64') : /^https?:\/\//.test(image) ? await (await fetch(image)).buffer() : fs.existsSync(image) ? fs.readFileSync(image) : typeof image === 'string' ? image : Buffer.alloc(0)
            if (!Buffer.isBuffer(buffer)) throw new TypeError('Result is not a buffer')
            const read = await jimp.read(buffer);
            const data = await read.resize(width, height).getBufferAsync(jimp.MIME_JPEG);
            return data;
        };

        lulli.createprofile = async (jid, buff) => {
            const media = await jimp.read(buff);
            const crop = media.crop(0, 0, (await media.getWidth()), (await media.getHeight()));
            const img = await crop.scaleToFit(720, 720).getBufferAsync(jimp.MIME_JPEG);
            return lulli.query({
                tag: 'iq',
                attrs: {
                    to: '@s.whatsapp.net',
                    type: 'set',
                    xmlns: 'w:profile:picture'
                },
                content: [{
                    tag: 'picture',
                    attrs: {
                        type: 'image'
                    },
                    content: img
                }]
            })
        }

        lulli.downloadM = async (m, type, saveToFile) => {
            if (!m || !(m.url || m.directPath)) return Buffer.alloc(0)
            const stream = await downloadContentFromMessage(m, type)
            let buffer = Buffer.from([])
            for await (const chunk of stream) {
                buffer = Buffer.concat([buffer, chunk])
            }
            if (saveToFile) var {
                filename
            } = await lulli.getFile(buffer, true)
            return saveToFile && fs.existsSync(filename) ? filename : buffer
        }

        lulli.downloadAndSaveMediaMessage = async (message, filename) => {
            if (message.quoted ? message.quoted.message : message.msg.viewOnce) {
                let type = message.quoted ? Object.keys(message.quoted.message)[0] : message.mtype;
                message = message.quoted ? message.quoted.message[type] : message.msg;
            } else {
                let quoted = message.quoted ? message.quoted : message;
                message = quoted.msg ? quoted.msg : quoted;
            }
            let mime = (message.msg || message).mimetype || ''
            let messageType = message.mtype ? message.mtype.replace(/Message/gi, '') : mime.split('/')[0]
            const stream = await downloadContentFromMessage(message, messageType)
            let buffer = Buffer.from([])
            for await (const chunk of stream) {
                buffer = Buffer.concat([buffer, chunk])
            }
            let type = await fromBuffer(buffer)
            let trueFileName = './sampah/' + (filename ? filename : func.filename(type.ext))
            // save to file
            await fs.writeFileSync(trueFileName, buffer)
            return trueFileName
        }

        lulli.getFile = async (PATH, returnAsFilename) => {
            let res, filename
            let data = Buffer.isBuffer(PATH) ? PATH : /^data:.*?\/.*?;base64,/i.test(PATH) ? Buffer.from(PATH.split(',')[1], 'base64') : /^https?:\/\//.test(PATH) ? await (res = await fetch(PATH)).buffer() : fs.existsSync(PATH) ? (filename = PATH, fs.readFileSync(PATH)) : typeof PATH === 'string' ? PATH : Buffer.alloc(0)
            if (!Buffer.isBuffer(data)) throw new TypeError('Result is not a buffer')
            let type = await fromBuffer(data) || {
                mime: 'application/octet-stream',
                ext: '.bin'
            }
            if (data && returnAsFilename && !filename)(filename = path.join(__dirname, '../sampah/' + new Date * 1 + '.' + type.ext), await fs.promises.writeFile(filename, data))
            return {
                res,
                filename,
                ...type,
                data
            }
        }

        lulli.getmetadata = async (jid) => {
            try {
                const groupList = await lulli.groupFetchAllParticipating();
                if (!Object.keys(groupList).includes(jid)) return ({});
                let metadata = Object.values(groupList).find((x) => x.id === jid);
                if (metadata) {
                    return metadata;
                } else {
                    let metadata = await lulli.groupMetadata(jid) || {};
                    return metadata;
                }
            } catch {
                let metadata = global.db.metadata[jid] || {};
                return metadata;
            }
        }

        lulli.isgroup = (jid) => new Promise(async (resolve) => {
            const groupList = await lulli.groupFetchAllParticipating();
            const groupData = Object.keys(groupList);
            const findGroup = groupData.find((id) => id === jid);
            const status = findGroup ? true : false;
            resolve(status);
        })

        lulli.sendMedia = async (jid, path, quoted, options = {}) => {
            let {
                ext,
                mime,
                data
            } = await lulli.getFile(path)
            let messageType = mime.split('/')[0]
            let type = messageType.replace('application', 'document') || messageType
            return await lulli.sendMessage(jid, {
                [`${type}`]: data,
                mimetype: mime,
                ...options
            }, {
                quoted,
                ephemeralExpiration: func.expiration(options.expiration)
            })
        }

        lulli.sendFile = async (jid, path, caption = '', quoted, ptt = false, options = {}) => {
            let type = await lulli.getFile(path, true)
            let {
                res,
                data: file,
                filename: pathFile
            } = type
            if (res && res.status !== 200 || file.length <= 65536) {
                try {
                    throw {
                        json: JSON.parse(file.toString())
                    }
                } catch (e) {
                    if (e.json) throw e.json
                }
            }
            if (!type) options.asDocument = true
            let mtype = '',
                mimetype = type.mime,
                convert
            if (/webp/.test(type.mime) || (/image/.test(type.mime) && options.asSticker)) mtype = 'sticker'
            else if (/image/.test(type.mime) || (/webp/.test(type.mime) && options.asImage)) mtype = 'image'
            else if (/video/.test(type.mime)) mtype = 'video'
            else if (/audio/.test(type.mime))(
                convert = await (ptt ? toPTT : toAudio)(file, type.ext),
                file = convert.data,
                pathFile = convert.filename,
                mtype = 'audio',
                mimetype = 'audio/ogg; codecs=opus'
            )
            else mtype = 'document'
            if (options.asDocument) mtype = 'document'
            let message = {
                ...options,
                caption,
                ptt,
                [mtype]: {
                    url: pathFile
                },
                mimetype
            }
            let m
            try {
                m = await lulli.sendMessage(jid, message, {
                    quoted,
                    ephemeralExpiration: func.expiration(options.expiration)
                })
            } catch (e) {
                lulli.logger.error(e)
                m = null
            } finally {
                if (!m) m = await lulli.sendMessage(jid, {
                    ...message,
                    [mtype]: file
                }, {
                    quoted,
                    ephemeralExpiration: func.expiration(options.expiration)
                })
                return m
            }
        }

        /* FUNCTION MAKE STICKER BY SURYA */
        lulli.sendStickerFromUrl = async (from, PATH, quoted, options = {}) => {
            let {
                writeExif
            } = require('../lib/sticker')
            let types = await lulli.getFile(PATH, true)
            let {
                filename,
                size,
                ext,
                mime,
                data
            } = types
            let type = '',
                mimetype = mime,
                pathFile = filename
            let media = {
                mimetype: mime,
                data
            }
            pathFile = await writeExif(media, {
                packname: options.packname ? options.packname : 'Suryaaa 𝑓𝑡 Wulannn.',
                author: options.author ? options.author : '',
                categories: options.categories ? options.categories : []
            })
            await fs.promises.unlink(filename)
            return await lulli.sendMessage(from, {
                sticker: {
                    url: pathFile
                }
            }, {
                quoted,
                ephemeralExpiration: func.expiration(options.expiration),
                ...options
            })
        }

        lulli.sendSticker = async (jid, path, quoted, options = {}) => {
            let buffer = /^https?:\/\//.test(path) ? await (await fetch(path)).buffer() : Buffer.isBuffer(path) ? path : /^data:.*?\/.*?;base64,/i.test(path) ? Buffer.from(path.split(',')[1], 'base64') : Buffer.alloc(0)
            let {
                mime
            } = await fromBuffer(buffer)
            let convert = (/image\/(jpe?g|png|gif)|octet/.test(mime)) ? (options && (options.packname || options.author)) ? await writeExifImg(buffer, options) : await imageToWebp(buffer) : (/video/.test(mime)) ? (options && (options.packname || options.author)) ? await writeExifVid(buffer, options) : await videoToWebp(buffer) : (/webp/.test(mime)) ? await writeExifWebp(buffer, options) : Buffer.alloc(0)
            return lulli.sendMessage(jid, {
                sticker: {
                    url: convert
                },
                ...options
            }, {
                quoted,
                ephemeralExpiration: func.expiration(options.expiration)
            })
        }

        lulli.sendkontak = (jid, numbers, name, quoted, options = {}) => {
            let number = numbers.replace(/[^0-9]/g, '')
            const vcard = 'BEGIN:VCARD\n' +
                'VERSION:3.0\n' +
                'FN:' + name + '\n' +
                'ORG:;\n' +
                'TEL;type=CELL;type=VOICE;waid=' + number + ':+' + number + '\n' +
                'item1.X-ABLabel:Ponsel\n' +
                'item2.EMAIL;type=INTERNET:suryaskylark05@gmail.com\n' +
                'item2.X-ABLabel:Email\nitem3.URL:https://instagram.com/surya_skylark05\n' +
                'item3.X-ABLabel:Instagram\n' +
                'item4.ADR:;;Indonesia;;;;\n' +
                'item4.X-ABLabel:Region\n' +
                'END:VCARD'
            return lulli.sendMessage(jid, {
                contacts: {
                    displayName: name,
                    contacts: [{
                        vcard
                    }]
                },
                mentions: [number + '@s.whatsapp.net']
            }, {
                quoted,
                ephemeralExpiration: func.expiration(options.expiration)
            })
        }

        lulli.sendkontakV2 = (jid, name, arr = [...[satu = "", dua = "", tiga = ""]], quoted = '', opts = {}) => {
            const vcard = {
                contacts: {
                    displayName: name,
                    contacts: arr.map(i => ({
                        displayName: i[0],
                        vcard: 'BEGIN:VCARD\n' + 'VERSION:3.0\n' + 'FN:' + i[0] + '\n' + 'ORG:' + i[2] + ';\n' + 'TEL;type=CELL;type=VOICE;waid=' + i[1] + ':+' + i[1] + '\n' + 'END:VCARD'
                    }))
                },
                ...opts
            }
            return lulli.sendMessage(jid, vcard, {
                quoted,
                ephemeralExpiration: func.expiration(opts.expiration)
            })
        };

        lulli.sendContact = async (jid, contact, quoted, info = {}, opts = {}) => {
            let list = []
            contact.map(v => list.push({
                displayName: v.name,
                vcard: `BEGIN:VCARD\nVERSION:3.0\nFN:${v.name}\nORG:${info && info.org ? info.org : 'Surya Dev'}\nTEL;type=CELL;type=VOICE;waid=${v.number}:${phoneNumber('+' + v.number).getNumber('international')}\nEMAIL;type=Email:${info && info.email ? info.email : 'suryaskylark05@gmail.com'}\nURL;type=Website:${info && info.website ? info.website : 'https://neoxr.my.id'}\nADR;type=Location:;;Unknown;;\nOther:${v.about}\nEND:VCARD`
            }))
            return lulli.sendMessage(jid, {
                contacts: {
                    displayName: `${list.length} Contact`,
                    contacts: list
                },
                ...opts
            }, {
                quoted,
                ephemeralExpiration: func.expiration(opts.expiration)
            })
        }

        lulli.copyNForward = async (jid, message, forceForward = false, options = {}) => {
            let vtype
            if (options.readViewOnce) {
                message.message = message.message && message.message.ephemeralMessage && message.message.ephemeralMessage.message ? message.message.ephemeralMessage.message : (message.message || undefined)
                vtype = Object.keys(message.message.viewOnceMessage.message)[0]
                delete(message.message && message.message.ignore ? message.message.ignore : (message.message || undefined))
                delete message.message.viewOnceMessage.message[vtype].viewOnce
                message.message = {
                    ...message.message.viewOnceMessage.message
                }
            }

            let mtype = Object.keys(message.message)[0]
            let content = await generateForwardMessageContent(message, forceForward)
            let ctype = Object.keys(content)[0]
            let context = {}
            if (mtype != "conversation") context = message.message[mtype].contextInfo
            content[ctype].contextInfo = {
                ...context,
                ...content[ctype].contextInfo
            }
            const waMessage = await generateWAMessageFromContent(jid, content, options ? {
                ...content[ctype],
                ...options,
                ...(options.contextInfo ? {
                    contextInfo: {
                        ...content[ctype].contextInfo,
                        ...options.contextInfo
                    }
                } : {})
            } : {})
            await lulli.relayMessage(jid, waMessage.message, {
                quoted: options.quoted,
                ephemeralExpiration: 86400,
                messageId: waMessage.key.id
            })
            return waMessage
        }

        lulli.cMod = async (jid, copy, text = '', sender = lulli.user.id, options = {}) => {
            let mtype = getContentType(copy.message);
            let isEphemeral = mtype === 'ephemeralMessage';
            if (isEphemeral) {
                mtype = Object.keys(copy.message.ephemeralMessage.message)[0];
                copy.message = copy.message.ephemeralMessage.message[mtype];
            }
            let content = copy.message;
            if (typeof content === 'string') {
                copy.message = text || content;
            } else if (text || content.caption) {
                content.caption = text || content.caption;
            } else if (content.text) {
                content.text = text || content.text;
            }
            if (typeof content !== 'string') {
                copy.message = {
                    ...content,
                    ...options
                };
            }
            if (copy.key.participant) {
                sender = sender || copy.key.participant;
            } else if (copy.key.remoteJid.includes('@s.whatsapp.net')) {
                sender = sender || copy.key.remoteJid;
            } else if (copy.key.remoteJid.includes('@broadcast')) {
                sender = sender || copy.key.remoteJid;
            }
            copy.key.remoteJid = jid;
            copy.key.fromMe = areJidsSameUser(sender, (lulli.user && lulli.user.id));
            return proto.WebMessageInfo.fromObject(copy);
        }

        lulli.downloadMediaMessage = async (message) => {
            let quoted = message.quoted ? message.quoted : message
            if (quoted?.msg?.viewOnce) {
                let type = message.quoted ? Object.keys(message.quoted.message)[0] : message.mtype
                message = message.quoted ? message.quoted.message[type] : message.msg
            }
            let mime = (message.msg || message).mimetype || ''
            let messageType = message.mtype ? message.mtype.replace(/Message/gi, '') : mime.split('/')[0]
            const stream = await downloadContentFromMessage(message, messageType)
            let buffer = Buffer.from([])
            for await (const chunk of stream) {
                buffer = Buffer.concat([buffer, chunk])
            }
            return buffer
        }

        lulli.preSudo = async (text, who, m, chatUpdate) => {
            let messages = await generateWAMessage(m.chat, {
                text,
                mentions: m.mentionedJid
            }, {
                userJid: who,
                quoted: m.quoted && m.quoted.fakeObj
            })
            messages.key.fromMe = areJidsSameUser(who, lulli.user.id)
            messages.key.id = m.key.id
            messages.pushName = m.pushname
            if (m.isGc) messages.key.participant = messages.participant = who
            let msg = {
                ...chatUpdate,
                messages: [proto.WebMessageInfo.fromObject(messages)].map(v => (v.lulli = this, v)),
                type: 'append'
            }
            lulli.ev.emit('messages.upsert', msg)
        }

        lulli.appenTextMessage = async (m, text, chatUpdate) => {
            let messages = await generateWAMessage(m.chat, {
                text: text,
                mentions: m.mentionedJid
            }, {
                userJid: lulli.user.id,
                quoted: m.quoted && m.quoted.fakeObj
            })
            messages.key.fromMe = m.key.fromMe
            messages.key.id = m.key.id
            messages.pushName = m.pushName
            if (m.isGc) messages.key.participant = messages.participant = m.key.participant
            let message = {
                ...chatUpdate,
                messages: [proto.WebMessageInfo.fromObject(messages)],
                type: 'append'
            }
            lulli.ev.emit('messages.upsert', message);
        };

        lulli.serializeM = (m) => {
            return this.initSerialize(lulli, m, store)
        }

        return lulli;
    }

    initSerialize = (lulli, m, store) => {
        if (!m) return m
        let M = proto.WebMessageInfo
        const mtype = () => {
            try {
                return Object.keys(m.message)[0] == "senderKeyDistributionMessage" ? Object.keys(m.message)[2] == "messageContextInfo" ? Object.keys(m.message)[1] : Object.keys(m.message)[2] : Object.keys(m.message)[0] != "messageContextInfo" ? Object.keys(m.message)[0] : Object.keys(m.message)[1];
            } catch {
                return null;
            }
        };
        const checkBlockedKeyId = (id) => {
            return /^(?=.{16}$)(MECHA|LULLI|BAE5)/.test(id) ||
                /^(?=.{20}$)(B24E|B1EY)/.test(id) ||
                /^(?=.{22}$)(3EB0)/.test(id) ||
                /^(SADAP)/.test(id) ? true : false;
            // /^3EB0/.test(id) && id.length === 12
        }
        if (m.key) {
            m.id = m.key.id
            m.isBot = /pollCreationMessage/.test(mtype()) ? false : checkBlockedKeyId(m.id);
            m.chat = m.key.remoteJid;
            m.fromMe = /pollCreationMessage/.test(mtype()) ? false : m.key.fromMe;
            m.isGc = m.chat.endsWith('@g.us')
            m.isPc = m.chat.endsWith('@s.whatsapp.net')
            m.sender = m.fromMe ? (lulli.user.id.split(':')[0] + '@s.whatsapp.net' || lulli.user.id) : (m.key.participant || m.key.remoteJid);
        }
        if (m.message) {
            m.pushname = m.pushName || '';
            m.bot = lulli.user.id ? lulli.user.id.split(':')[0] + '@s.whatsapp.net' : lulli.user.jid;
            m.setting = global.db.setting ? global.db.setting[m.bot] : {};
            m.user = {
                id: m.sender,
                device: m.isBot ? 'web' : 'smartphone',
                jadibot: lulli.user.jadibot ? true : false
            };
            if (m.isGc) {
                m.metadata = global.db.metadata[m.chat] || {};
                m.groupName = m.metadata?.subject || '';
                m.members = m.metadata?.participants || [];
                m.admins = (m.members.reduce((memberAdmin, memberNow) => (memberNow.admin ? memberAdmin.push({
                    id: memberNow.id,
                    admin: memberNow.admin
                }) : [...memberAdmin]) && memberAdmin, []))
                m.isAdmin = !!m.admins.find((member) => member.id === m.sender)
                m.isBotAdmin = !!m.admins.find((member) => member.id === m.bot)
            }
            if (m.message.viewOnceMessage) {
                m.mtype = Object.keys(m.message.viewOnceMessage.message)[0];
                m.msg = m.message.viewOnceMessage.message[m.mtype];
            } else if (m.message.viewOnceMessageV2) {
                m.mtype = Object.keys(m.message.viewOnceMessageV2.message)[0];
                m.msg = m.message.viewOnceMessageV2.message[m.mtype];
            } else {
                m.mtype = mtype();
                m.msg = m.message[m.mtype];
            }
            if (m.mtype === "ephemeralMessage" || m.mtype === "documentWithCaptionMessage") {
                this.initSerialize(lulli, m.msg, store);
                m.mtype = m.msg.mtype;
                m.msg = m.msg.msg;
            }
            m.isMedia = !!m.msg?.mimetype
            if (m.isMedia) {
                m.mime = m.msg?.mimetype;
                m.size = m.msg?.fileLength;
                m.height = m.msg?.height || '';
                m.width = m.msg?.width || '';
                if (/webp/i.test(m.mime)) {
                    m.isAnimated = m.msg?.isAnimated;
                }
                if (/audio|video/i.test(m.mime)) {
                    m.seconds = m.msg?.seconds;
                }
            }
            let quoted = m.quoted = typeof m.msg != 'undefined' ? m.msg.contextInfo ? m.msg.contextInfo.quotedMessage : null : null
            m.mentionedJid = typeof m.msg != 'undefined' ? m.msg.contextInfo ? m.msg.contextInfo.mentionedJid : [] : []
            if (m.quoted) {
                let type = Object.keys(m.quoted)[0]
                m.quoted = m.quoted[type]
                if (/productMessage|documentWithCaptionMessage/i.test(type)) {
                    type = Object.keys(m.quoted)[0]
                    m.quoted = m.quoted[type]
                }
                if (typeof m.quoted === 'string') m.quoted = {
                    text: m.quoted
                };
                m.quoted.id = m.msg.contextInfo.stanzaId
                m.quoted.chat = m.msg.contextInfo.remoteJid || m.chat
                m.quoted.isBot = m.quoted.id ? checkBlockedKeyId(m.quoted.id) : false
                m.quoted.sender = m.msg.contextInfo.participant.split(":")[0] || m.msg.contextInfo.participant
                m.quoted.fromMe = areJidsSameUser(m.quoted.sender, (lulli.user && lulli.user.id));
                m.quoted.mentionedJid = m.msg.contextInfo ? m.msg.contextInfo.mentionedJid : []
                m.quoted.copyNForward = (jid, forceForward = false, options = {}) => lulli.copyNForward(jid, vM, forceForward, options)
                m.getQuotedObj = async () => {
                    if (!m.quoted.id) return false;
                    let quotedMsg = await store.loadMessage(m.chat, m.quoted.id);
                    return this.initSerialize(lulli, quotedMsg, store);
                };
                let vM = m.quoted.fakeObj = M.fromObject({
                    key: {
                        remoteJid: m.quoted.chat,
                        fromMe: m.quoted.fromMe,
                        id: m.quoted.id
                    },
                    message: quoted,
                    ...(m.isGc ? {
                        participant: m.quoted.sender
                    } : {})
                })
                m.quoted.mtype = m.quoted != null ? Object.keys(m.quoted.fakeObj.message)[0] : null;
                m.quoted.text = m.quoted?.text || m.quoted?.caption || (m.quoted.mtype === "interactiveMessage" ? m.quoted?.body?.text : '') || (/viewOnceMessage/.test(m.quoted.mtype) ? m.quoted.message[Object.keys(m.quoted.message)[0]].caption : '') || (m.quoted.mtype == "buttonsMessage" ? m.quoted.contentText : '') || (m.quoted.mtype == "templateMessage" ? m.quoted?.hydratedFourRowTemplate?.hydratedContentText : '') || '';
                m.quoted.isMedia = !!(m.quoted.message ? m.quoted.message[Object.keys(m.quoted.message)[0]].mimetype : m.quoted.mimetype);
                m.quoted.download = () => {
                    if (m.quoted.isMedia) {
                        let type = m.quoted.message ? Object.keys(m.quoted.message)[0] : m.quoted;
                        let q = m.quoted.message ? m.quoted.message[type] : m.quoted;
                        return lulli.downloadMediaMessage(q)
                    }
                }
                if (m.quoted.isMedia) {
                    let type = m.quoted.message ? Object.keys(m.quoted.message)[0] : m.quoted;
                    let q = m.quoted.message ? m.quoted.message[type] : m.quoted;
                    m.quoted.mime = q.mimetype;
                    m.quoted.size = q.fileLength;
                    m.quoted.height = q.height || '';
                    m.quoted.width = q.width || '';
                    if (/webp/i.test(m.quoted.mime)) {
                        m.quoted.isAnimated = q.isAnimated || false
                    }
                    if (/audio|video/i.test(m.quoted.mime)) {
                        m.quoted.seconds = q.seconds;
                    }
                }
            }
            m.reply = async (text, options = {}) => {
                lulli.sendMessage(m.chat, {
                    text: text,
                    contextInfo: m.setting.fakereply ? {
                        mentionedJid: [m.sender, ...this.mention(text)],
                        forwardingScore: 256,
                        isForwarded: true,
                        /*forwardedNewsletterMessageInfo: {
                        newsletterJid: '120363261409301854@newsletter',
                        newsletterName: `Ping : ${func.ping(4)} • Powered by SuryaDev`,
                        serverMessageId: -1
                        },*/
                        externalAdReply: {
                            title: global.header,
                            body: global.fake,
                            sourceUrl: 'https://whatsapp.com/channel/0029VaU3j0z2ER6liR0MY601',
                            thumbnail: await (await fetch(m.setting.cover)).buffer()
                        }
                    } : {
                        mentionedJid: [m.sender, ...this.mention(text)],
                        /*forwardingScore: 0, 
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                        newsletterJid: '120363261409301854@newsletter',
                        newsletterName: `Ping : ${func.ping(4)} • Powered by SuryaDev`,
                        serverMessageId: -1
                        }*/
                    },
                    ...options
                }, {
                    quoted: m,
                    ephemeralExpiration: func.expiration(m.expiration),
                    detectLinks: false,
                    ...options
                })
            }
            m.copyNForward = (jid = m.chat, message, forceForward = false, options = {}) => lulli.copyNForward(jid, message, forceForward, options);
            if (typeof m.msg != 'undefined') {
                if (m.msg.url) m.download = () => lulli.downloadMediaMessage(m.msg)
            }
        }
        m.body = (m.mtype == "interactiveResponseMessage" ? JSON.parse(m.msg?.nativeFlowResponseMessage?.paramsJson).id : '') || (m.mtype == "stickerMessage" && global.db && global.db.stickercmd ? typeof global.db.stickercmd[m.msg.fileSha256.toString()] != "undefined" ? global.db.stickercmd[m.msg.fileSha256.toString()].text : '' : '') || (m.mtype == "editedMessage" ? m.msg.message?.protocolMessage?.editedMessage?.extendedTextMessage?.text : '') || (m.mtype == "listResponseMessage" ? m.message.listResponseMessage.singleSelectReply.selectedRowId : '') || (m.mtype == "buttonsResponseMessage" ? m.message.buttonsResponseMessage.selectedButtonId : '') || (m.mtype == "templateButtonReplyMessage" ? m.message.templateButtonReplyMessage.selectedId : '') || (typeof m.msg != "undefined" ? m.msg.text : '') || (typeof m.msg != "undefined" ? m.msg.caption : '') || m.msg || '';
        m.budy = (typeof m.body == 'string' ? m.body : '')
        m.prefix = m.setting.multiprefix ? (global.prefixes.test(m.budy) ? m.budy.match(global.prefixes)[0] : '.') : m.setting.prefix;
        m.isDevs = [...global.devs, ...global.developer].includes(m.sender)
        m.isOwner = [global.owner, m.bot, ...global.db.owner].includes(m.sender);
        m.isVIP = m.isGc ? global.db.groups[m.chat]?.sewa?.vip || global.db.groups[m.chat]?.vip || false : false;
        m.isPrem = Object.values(global.db.users).some(user => user.premium && user.jid === m.sender);
        m.isPrefix = m.budy.startsWith(m.prefix);
        m.command = (m.isOwner || m.isPrem || m.isVIP) ? m.budy.replace(m.prefix, '').trim().split(/ +/).shift().toLowerCase() : m.isPrefix ? m.budy.replace(m.prefix, '').trim().split(/ +/).shift().toLowerCase() : '';
        m.cmd = m.prefix + m.command;
        m.arg = m.budy.trim().split(/ +/).filter(a => a) || [];
        m.args = m.budy.trim().replace(new RegExp('^' + func.escapeRegExp(m.prefix), 'i'), '').replace(m.budy.replace(m.prefix, '').trim().split(/ +/).shift(), '').split(/ +/).filter(a => a) || []
        m.text = m.args.join(' ')
        m.expiration = m.msg?.contextInfo?.expiration || 0

        return M.fromObject(m);
    };

    initPrototype = () => {
        Number.prototype.rupiah = function rupiah() {
            var tostr = this.toString();
            var mlds = tostr.length % 3;
            var iris = tostr.substr(0, mlds);
            var ribu = tostr.substr(mlds).match(/\d{3}/g);
            let res;
            if (ribu) {
                res = mlds ? "," : "";
                iris += res + ribu.join(",");
            }
            return iris;
        };

        Array.prototype.random = function random() {
            return this[Math.floor(Math.random() * this.length)];
        };

        Number.prototype.datestring = function datestring() {
            let year = this.getFullYear(),
                moon = this.getMonth(),
                date = this.getDate(),
                hours = this.getHours(),
                minutes = this.getMinutes();
            return `${date}-${moon + 1}-${year} ${hours}:${minutes}`;
        };

        Number.prototype.timers = function timers() {
            const seconds = Math.floor((this / 1000) % 60),
                minutes = Math.floor((this / (60 * 1000)) % 60),
                hours = Math.floor((this / (60 * 60 * 1000)) % 24),
                days = Math.floor(this / (24 * 60 * 60 * 1000));
            return `${days ? days + ' hari ' : ''}${hours ? hours + ' jam ' : ''}${minutes ? minutes + ' menit ' : ''}${seconds ? seconds + ' detik' : ''}`
        };

        Number.prototype.sizeString = function sizeString(des = 2) {
            if (this === 0) return "0 Bytes";
            const dm = des < 0 ? 0 : des;
            const sizes = ["Bytes", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB"];
            const i = Math.floor(Math.log(this) / Math.log(1024));
            return parseFloat((this / Math.pow(1024, i)).toFixed(dm)) + " " + sizes[i];
        };

        Number.prototype.toTimeString = function toTimeString() {
            // const milliseconds = this % 1000
            const seconds = Math.floor((this / 1000) % 60)
            const minutes = Math.floor((this / (60 * 1000)) % 60)
            const hours = Math.floor((this / (60 * 60 * 1000)) % 24)
            const days = Math.floor((this / (24 * 60 * 60 * 1000)))
            return (
                (days ? `${days} day ` : '') +
                (hours ? `${hours} hour ` : '') +
                (minutes ? `${minutes} minute ` : '') +
                (seconds ? `${seconds} second` : '')
            ).trim()
        };
    }
}

func.reloadFile(__filename)