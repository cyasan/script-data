const fs = require('fs');

exports.run = {
    main: async (m, {
        func,
        mecha,
        groups,
        setting,
    }) => {
        if (m.budy && groups.antitoxic && !m.isAdmin && !m.isPrem && !m.isPrefix) {
            let caption = func.pickRandom([
                'عَنْ أَبِي الدَّرْدَاءِ، أَنَّ النَّبِيَّ صَلَّى اللَّهُ عَلَيْهِ وَسَلَّمَ قَالَ: إِنَّ اللَّهَ لَيُبْغِضُ الفَاحِشَ البَذِيءَ\n\nDari Abu Ad-Darda’ radhiallahu ‘anhu bahwasanya Rasulullah ﷺ bersabda, “Sungguh Allah benci dengan orang yang lisannya kotor dan kasar.” (HR. At-Tirmidzi no.2002)',
                'لَا يُحِبُّ اللَّهُ الْجَهْرَ بِالسُّوءِ مِنَ الْقَوْلِ إِلَّا مَنْ ظُلِمَ ۚ وَكَانَ اللَّهُ سَمِيعًا عَلِيمًا\nArtinya :\nAllah tidak menyukai perkataan buruk, (yang diucapkan) secara terus terang kecuali oleh orang yang dizalimi. Dan Allah Maha Mendengar lagi Maha Mengetahui. (QS. An-Nisa : 148)',
                '“Tidak ada sesuatu yang lebih berat dalam timbangan seorang mukmin pada hari kiamat selain akhlaknya yang baik. Allah sangat membenci orang yang kata-katanya kasar dan kotor.” (HR. At-Tirmidzi no.2002)',
            ])
            let member = groups.member.find(v => v.jid == m.sender);
            let array = m.budy.toLowerCase().split(' ');
            let status = array.filter(data => data.replace(/[^a-zA-Z]/gi, '')).map((kata) => setting.toxic.some((kasar) => kasar == kata)).filter((state) => state);
            if (status.length > 0) {
                member.toxic += 1;
                if (member.toxic >= setting.max_toxic) return mecha.reply(m.chat, `乂  *A N T I  T O X I C*\n\n*Toxic : (${member.toxic}/${setting.max_toxic}), selamat tinggal ~~*`, m).then(async () => {
                    await mecha.groupParticipantsUpdate(m.chat, [m.sender], 'remove').then(async () => {
                        await mecha.sendMessage(m.chat, {
                            delete: {
                                remoteJid: m.chat,
                                fromMe: false,
                                id: m.key.id,
                                participant: m.sender
                            }
                        });
                    });
                });
                return await mecha.sendMessage(m.chat, {
                        delete: {
                            remoteJid: m.chat,
                            fromMe: false,
                            id: m.key.id,
                            participant: m.sender
                        }
                    })
                    .then(async () => {
                        await mecha.sendMessage(m.chat, {
                            text: caption,
                            contextInfo: {
                                externalAdReply: {
                                    title: `ᴊᴀɴɢᴀɴ ᴛᴏxɪᴄ (${member.toxic}/${setting.max_toxic})`,
                                    body: '𝑎𝑏𝑎𝑖𝑘𝑎𝑛 𝑗𝑖𝑘𝑎 𝑘𝑎𝑚𝑢 𝑛𝑜𝑛 𝑚𝑢𝑠𝑙𝑖𝑚.',
                                    //title: `Jangan Toxic! (${member.toxic}/${setting.max_toxic})`, 
                                    //body: 'abaikan jika kamu non muslim.', 
                                    mediaType: 1,
                                    previewType: 'PHOTO',
                                    thumbnailUrl: setting.cover,
                                    sourceUrl: null
                                }
                            }
                        }, {
                            quoted: m,
                            ephemeralExpiration: m.expiration
                        });
                        await mecha.sendMessage(m.chat, {
                            sticker: {
                                url: 'https://files.catbox.moe/uciswn.webp'
                            }
                        }, {
                            quoted: null,
                            ephemeralExpiration: m.expiration
                        });
                    })
            }
        }
    },
    group: true,
    botAdmin: true,
    location: 'plugins/event/_antitoxic.js'
}