const fetch = require('node-fetch')

exports.run = {
    usage: ['listbot'],
    hidden: ['listjadibot'],
    category: 'jadibot',
    async: async (m, {
        func,
        mecha,
        setting
    }) => {
        const data = Object.values(global.db.users).filter(item => item.jadibot)
        if (data.length == 0) return m.reply('*Empty data.*')
        let caption = '乂  *L I S T  J A D I  B O T*\n'
        data.forEach((item, index) => {
            let bot = Object.values(global.jadibot).filter(x => x.user && x.user.jadibot).find(v => v.user.jid === item.jid)
            let setting = global.db.setting[item.jid];
            caption += `\n${index + 1}. @${item.jid.split('@')[0]}`
            caption += `\n◦  Expire: ${/PERMANENT/.test(item.expired.jadibot) ? 'PERMANENT' : func.expireTime(item.expired.jadibot)}`
            caption += `\n◦  Status: ${bot ? '✅Active' : '❌Non-active'}`
            caption += `\n◦  Maintenance: ${setting.maintenance ? 'Yes' : 'No'}\n`
            if (bot) caption += `◦  Uptime: ${func.clockString(new Date - bot.user.uptime)}\n`
        })
        mecha.reply(m.chat, caption, m, {
            expiration: m.expiration
        })
    },
    owner: true,
    location: 'plugins/jadibot/listbot.js'
}