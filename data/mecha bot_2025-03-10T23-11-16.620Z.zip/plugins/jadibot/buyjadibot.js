const crypto = require('crypto'), 
moment = require('moment-timezone');

const pricejadibot = [
{
id: 'PJ1',
name: 'Jadibot 1',
duration: '7 day',
price: 5000,
},
{
id: 'PJ2',
name: 'Jadibot 2',
duration: '15 day',
price: 10000,
},
{
id: 'PJ3',
name: 'Jadibot 3',
duration: '30 day',
price: 20000,
},
{
id: 'PJ4',
name: 'Jadibot 4',
duration: '60 day',
price: 30000,
},
{
id: 'PJ5',
name: 'Jadibot 5',
duration: '90 day',
price: 50000,
}
]

exports.run = {
usage: ['buyjadibot'],
hidden: ['belijadibot'],
category: 'special',
async: async (m, { func, mecha, setting }) => {
let title = '「 LIST HARGA JADIBOT 」'
let footer = 'silahkan pilih paket jadibot dibawah'
let body = pricejadibot.map(data => `*PAKET ${data.id.toUpperCase()}*\n- Rp${func.toRupiah(data.price)} / ${data.duration}`).join('\n\n')
let rows = []
for (let data of pricejadibot) {
rows.push({
header: `PAKET ${data.name.toUpperCase()}`,
title: `Rp. ${func.toRupiah(data.price)}`,
description: `Duration ${data.duration}`,
id: `${data.id}`
})
}
let sections = [
{
title: 'PAKET JADIBOT',
rows: rows
}
]
let buttons = [
['list', 'Click Here ⎙', sections],
]
mecha.sendButton(m.chat, title, body, footer, buttons, m, {
expiration: m.expiration
})
},
main: async (m, { func, mecha, quoted }) => {
if (typeof global.db.buyjadibot == 'undefined') global.db.buyjadibot = {};
if (typeof pricejadibot !== 'undefined' && pricejadibot.some(x => x.id === m.budy)) {
let paket = pricejadibot.find(v => v.id === m.budy);
global.db.buyjadibot[m.sender] = {
id: crypto.randomBytes(5).toString('hex').toUpperCase(),
number: m.sender,
name: m.pushname,
session: 'payment',
date: moment.tz('Asia/Jakarta').format('DD MMMM YYYY'),
payment: '',
data: {
name: paket.name,
duration: paket.duration,
price: paket.price
}
}
setTimeout(function () {
delete global.db.buyjadibot[data_jadibot.number];
}, 1000 * 60 * 15)
let body = `1. Melakukan pembelian artinya anda setuju dengan segala kebijakan kami.
2. Jika bot mengalami kendala atau perbaikan hingga 24 jam atau lebih, kami berikan kompensasi berupa penambahan waktu jadibot.
3. Perpanjangan hanya berlaku jika masa aktif tersisa kurang dari 3 hari.`
let sections = [
{
title: 'METODE PEMBAYARAN',
rows: [
{
header: 'QRIS',
title: 'Online ✅',
description: 'Pembayaran Via QRIS (pajak +500)',
id: 'jadibot_via_qris',
},
{
header: 'DANA',
title: 'Online ✅',
description: 'Pembayaran Via DANA',
id: 'jadibot_via_dana',
},
],
},
]
let buttons = [
['list', 'Click Here ⎙', sections],
]
mecha.sendButton(m.chat, 'I N F O R M A T I O N', body, 'Pilih metode pembayaran dibawah', buttons, m, {
expiration: m.expiration
})
}
if (typeof global.db.buyjadibot[m.sender] != 'undefined') {
let data_jadibot = global.db.buyjadibot[m.sender]
if (data_jadibot.session === 'payment') {
data_jadibot.session = 'metode_pembayaran'
} else if (data_jadibot.session === 'metode_pembayaran') {
data_jadibot.session = 'konfirmasi_jadibot'
let sections = [
{
title: 'KONFIRMASI JADIBOT',
rows: [
{
header: '',
title: 'LANJUT',
description: 'Untuk Melanjutkan Buy Jadibot',
id: 'lanjutkan_jadibot',
},
{
header: '',
title: 'BATAL',
description: 'Untuk Membatalkan Buy Jadibot',
id: 'batalkan_jadibot',
},
],
},
]
let buttons = [
['list', 'Click Here ⎙', sections],
]
if (m.budy.toLowerCase() === 'jadibot_via_qris') {
data_jadibot.payment = 'QRIS'
data_jadibot.data.price += 500;
let body = `⋄ ID : ${data_jadibot.id}
⋄ Nomor : ${data_jadibot.number.split('@')[0]}
⋄ Tanggal : ${data_jadibot.date}
⋄ Nama Paket : ${data_jadibot.data.name}
⋄ Durasi : ${data_jadibot.data.duration}
⋄ Pembayaran Via : ${data_jadibot.payment}
⋄ Harga : Rp${func.toRupiah(data_jadibot.data.price)},-`
mecha.sendButton(m.chat, 'KONFIRMASI JADIBOT', body, 'Pembelian akan dibatalkan otomatis apabila terdapat kesalahan input', buttons, m, {
expiration: m.expiration
})
} else if (m.budy.toLowerCase() === 'jadibot_via_dana') {
data_jadibot.payment = 'DANA'
let body = `⋄ ID : ${data_jadibot.id}
⋄ Nomor : ${data_jadibot.number.split('@')[0]}
⋄ Tanggal : ${data_jadibot.date}
⋄ Nama Paket : ${data_jadibot.data.name}
⋄ Durasi : ${data_jadibot.data.duration}
⋄ Pembayaran Via : ${data_jadibot.payment}
⋄ Harga : Rp${func.toRupiah(data_jadibot.data.price)},-`
mecha.sendButton(m.chat, 'KONFIRMASI JADIBOT', body, 'Pembelian akan dibatalkan otomatis apabila terdapat kesalahan input', buttons, m, {
expiration: m.expiration
})
}
} else if (data_jadibot.session === 'konfirmasi_jadibot') {
if (m.budy.toLowerCase() === 'lanjutkan_jadibot') {
data_jadibot.session = 'bukti_pembayaran'
if (data_jadibot.payment === 'QRIS') {
var payqris = `*P A Y M E N T - Q R I S*

*URL :* ${global.payment.qris.link}
*A/N :* ${global.payment.qris.an}
*Harga :* Rp${func.toRupiah(data_jadibot.data.price)},-

_silahkan transfer *Rp${func.toRupiah(data_jadibot.data.price)},-* pada qris yang sudah tertera, jika sudah harap kirim bukti foto dengan caption *Bukti* untuk di acc oleh owner._`
mecha.sendMessage(m.chat, {image: {url: global.payment.qris.link}, caption: payqris}, {quoted: m, ephemeralExpiration: m.expiration})
} else if (data_jadibot.payment === 'DANA') {
var paydana = `*P A Y M E N T - D A N A*
 
*NOMOR :* ${global.payment.dana.nope}
*A/N :* ${global.payment.dana.an}
*Harga :* Rp${func.toRupiah(data_jadibot.data.price)},-

_pembelian hanya berlaku selama 15 menit segera selesaikan pembayaran sebelum melewati batas waktu, jika sudah harap kirim bukti foto dengan caption *Bukti* untuk di acc oleh owner._`
mecha.sendMessage(m.chat, {text: paydana}, {quoted: m, ephemeralExpiration: m.expiration})
}
} else if (m.budy.toLowerCase() === 'batalkan_jadibot') {
m.reply(`Baik kak, buyjadibot dengan ID : ${data_jadibot.id} sudah dibatalkan`)
delete global.db.buyjadibot[data_jadibot.number];
}
} else if (data_jadibot.session === 'bukti_pembayaran') {
if (m.budy.toLowerCase() === 'bukti') {
if (!/image\/(jpe?g|png)/.test(quoted.mime)) return m.reply(`Kirim gambar dengan caption *bukti* atau reply gambar yang sudah dikirim dengan caption *bukti*`)
let media = await mecha.downloadAndSaveMediaMessage(m)
let button = [
['button', 'Confirm', `${m.prefix}accjadibot ${data_jadibot.number}`],
['button', 'Reject', `${m.prefix}rejectjadibot ${data_jadibot.number}`]
]
let body = `⋄ ID : ${data_jadibot.id}
⋄ Nomor : ${data_jadibot.number.split('@')[0]}
⋄ Tanggal : ${data_jadibot.date}
⋄ Nama Paket : ${data_jadibot.data.name}
⋄ Durasi : ${data_jadibot.data.duration}
⋄ Harga : Rp${func.toRupiah(data_jadibot.data.price)},-`
body += `\n\nAda yang transfer nih kak, coba dicek saldonya`
let footer = `Jika sudah masuk klik tombol 'Confirm' dibawah\nJika belum masuk klik tombol 'Reject' dibawah`
await mecha.sendButton(global.owner, 'J A D I B O T - U S E R', body, footer, button, m, {
media: media,
expiration: m.expiration
})
m.reply('_Mohon tunggu, owner akan memeriksa bukti transfer_ 🙏🏻')
}
}
}
}
}