const fs = require('fs');
const path = require('path');

exports.run = {
    usage: ['encrypt'],
    hidden: ['enc'],
    use: 'type, filename',
    category: 'owner',
    async: async (m, {
        func,
        mecha
    }) => {
        let inputString;
        let encryptedType = 'medium';
        let fileName = 'encrypt.js';
        const [type, filename] = m.text.split(',');
        if (m.quoted && /(application|text)\/(javascript|octet-stream)/i.test(m.quoted.mime)) {
            let buffer = await m.quoted.download();
            inputString = Buffer.from(buffer, 'base64').toString('utf-8');
            fileName = m.quoted.fileName;
            encryptedType = type || 'medium';
        } else if (m.quoted && m.quoted.text) {
            inputString = m.quoted.text;
            fileName = filename || 'encrypt.js';
            encryptedType = type || 'medium';
        } else {
            return m.reply('Input/reply file javascript yang ingin di enkripsi.')
        }
        if (encryptedType && !['low', 'medium', 'high'].includes(encryptedType)) return m.reply(`Format invalid.\n\n*List Opsi*:\n1. low\n2. medium\n3. high`)
        await mecha.sendReact(m.chat, '🕒', m.key)
        const data = await func.obfus(inputString, type ? type : 'medium');
        if (data.status != 200) return m.reply(data.message);
        const encryptedContent = '// buy the script to get the full code\n' + data.result;
        if (encryptedContent.length >= 65536) {
            const filePath = path.join(process.cwd(), 'media', fileName);
            fs.writeFileSync(filePath, encryptedContent);
            await mecha.sendMessage(m.chat, {
                document: {
                    url: filePath
                },
                mimetype: 'application/javascript',
                fileName: fileName
            }, {
                quoted: m,
                ephemeralExpiration: m.expiration
            })
        } else {
            mecha.reply(m.chat, encryptedContent, m, {
                expiration: m.expiration
            })
        }
        // Simpan hasil enkripsi ke file
        fs.writeFileSync('./media/' + fileName, JSON.stringify(encryptedContent));
    },
    devs: true
}