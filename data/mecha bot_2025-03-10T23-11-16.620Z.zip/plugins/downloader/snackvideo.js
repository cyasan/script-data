const fetch = require('node-fetch')
const cheerio = require('cheerio')

async function snackVideo(url) {
return new Promise(async (resolve, reject) => {
try {
if (!/snackvideo.com/gi.test(url)) return reject("Invalid URL!");
const res = await fetch(url).then((v) => v.text());
const $ = cheerio.load(res);
const video = $("div.video-box").find("a-video-player");
const author = $("div.author-info");
const attr = $("div.action");
const data = {
status: true,
title: $(author).find("div.author-desc > span").children("span").eq(0).text().trim(),
thumbnail: $(video).parent().siblings("div.background-mask").children("img").attr("src"),
media: $(video).attr("src"),
author: $("div.author-name").text().trim(),
authorImage: $(attr).find("div.avatar > img").attr("src"),
like: $(attr).find("div.common").eq(0).text().trim(),
comment: $(attr).find("div.common").eq(1).text().trim(),
share: $(attr).find("div.common").eq(2).text().trim(),
};
resolve(data);
} catch (error) {
resolve({
status: false,
message: String(error)
});
}
});
}

exports.run = {
usage: ['snackvideo'],
hidden: ['snackdl'],
use: 'url snack video',
category: 'downloader',
async: async (m, { func, mecha }) => {
if (!m.text) return m.reply(func.example(m.cmd, 'https://s.snackvideo.com/p/d1j3rYee'))
if (!/snackvideo.com/gi.test(m.args[0])) return m.reply('Invalid URL!');
mecha.sendReact(m.chat, '🕒', m.key)
const res = await snackVideo(m.args[0])
if (!res.status) return m.reply(res.message)
let txt = '*SNACKVIDEO DOWNLOADER*\n'
txt += `\n- Title: ${res.title}`
txt += `\n- Author: ${res.author}`
txt += `\n- Like: ${res.like}`
txt += `\n- Comment: ${res.comment}`
txt += `\n- Share: ${res.share}`
await mecha.sendMessage(m.chat, {
video: {
url: res.media
},
caption: txt
}, {quoted: m, ephemeralExpiration: m.expiration})
},
premium: true,
limit: true
}