/* 
Facebook downloader from getfvid.com
~ fumi
*/

const axios = require('axios');
const cheerio = require('cheerio');

async function facebook(link){
return new Promise((resolve,reject) => {
let config = {
'url': link
}
axios('https://www.getfvid.com/downloader',{
method: 'POST',
data: new URLSearchParams(Object.entries(config)),
headers: {
"content-type": "application/x-www-form-urlencoded",
"user-agent":  "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
"cookie": "_ga=; _pbjs_userid_consent_data=; cto_bidid=; _gid=; __gads=ID=; cookieconsent_status=dismiss"
}
})
.then(async({ data }) => {
const $ = cheerio.load(data)
resolve({
video_sd: $('body > div.page-content > div > div > div.col-lg-10.col-md-10.col-centered > div > div:nth-child(3) > div > div.col-md-4.btns-download > p:nth-child(1) > a').attr('href'),
video_hd: $('body > div.page-content > div > div > div.col-lg-10.col-md-10.col-centered > div > div:nth-child(3) > div > div.col-md-4.btns-download > p:nth-child(1) > a').attr('href'),
audio: $('body > div.page-content > div > div > div.col-lg-10.col-md-10.col-centered > div > div:nth-child(3) > div > div.col-md-4.btns-download > p:nth-child(2) > a').attr('href')
})
})
.catch(reject)
})
}

exports.run = {
usage: ['facebook2'],
hidden: ['fbdl2'],
use: 'link facebook',
category: 'downloader',
async: async (m, { func, mecha }) => {
if (m.text && /--video_sd|--video_hd|--audio/.test(m.args[0])) {
mecha.sendReact(m.chat, '🕒', m.key)
await mecha.sendMedia(m.chat, m.args[1], m, {
caption: global.mess.ok,
expiration: m.expiration
})
return !0
}
if (!m.text) return m.reply(`Masukkan URL!\n\nContoh: *${m.cmd} https://www.facebook.com/watch/?v=1393572814172251*`)
if (!m.args[0].match(/(?:https?:\/\/(web\.|www\.|m\.)?(facebook|fb)\.(com|watch)\S+)?$/)) return m.reply(global.mess.error.url)
if (m.args[0].includes('https://l.facebook.com/l.php?u=')) return m.reply(global.mess.error.url)
mecha.sendReact(m.chat, '🕒', m.key)
await facebook(m.args[0]).then(async res => {
let buttons = [
['button', 'Video SD', `${m.cmd} --video_sd ${res.video_sd}`],
['button', 'Video HD', `${m.cmd} --video_hd ${res.video_hd}`],
['button', 'Audio', `${m.cmd} --audio ${res.audio}`],
]
let body = '```Result from:```' + '\t`' + m.args[0] + '`'
mecha.sendButton(m.chat, 'F A C E B O O K - D O W N L O A D E R', body, 'please select the button below.', buttons, m, {
expiration: m.expiration
})
})
},
premium: true,
limit: true
}