const axios = require('axios');
const yts = require('yt-search');
const ffmpeg = require('fluent-ffmpeg');
const fs = require('fs');
const path = require('path');

async function getBuffer(url) {
    try {
        const response = await axios.get(url, {
            responseType: 'arraybuffer'
        });
        return Buffer.from(response.data, 'binary');
    } catch (error) {
        console.error('Error fetching buffer:', error);
        return null;
    }
}

async function compressAudio(inputFileName, outputFileName) {
    const inputAudioPath = path.join(process.cwd(), inputFileName);
    const outputAudioPath = path.join(process.cwd(), outputFileName);

    return new Promise((resolve, reject) => {
        ffmpeg(inputAudioPath)
            .audioBitrate('128k')
            .toFormat('mp3')
            .on('end', () => {
                console.log('Proses kompresi selesai!');
                resolve(outputAudioPath);
            })
            .on('error', (err) => {
                console.error('Terjadi kesalahan:', err.message);
                reject(err);
            })
            .save(outputAudioPath);
    });
}

let processedAudio = new Set();
const chatId = '120363341809155691@newsletter';

exports.run = {
    usage: ['play2'],
    use: 'judul lagu',
    category: 'downloader',
    async: async (m, {
        func,
        mecha,
        users
    }) => {
        if (!m.text) return m.reply(func.example(m.cmd, 'melukis senja'))
        const query = m.text.trim();
        if (processedAudio.has(query)) return m.reply('Masih ada proses yang belum selesai BODOH.')
        processedAudio.add(query);
        mecha.sendReact(m.chat, '🕒', m.key);
        try {
            const video = (await yts(query)).videos[0];
            let durationInSeconds = (video?.timestamp || video?.duration?.timestamp).split(':').reduce((acc, time) => (60 * acc) + +time)
            if (durationInSeconds >= 3600) {
                mecha.sendReact(m.chat, '❌', m.key)
                return m.reply('Video is longer than 1 hour!')
            }
            if (!video) return m.reply('Video tidak ditemukan.');
            let caption = '*Y O U T U B E - P L A Y*\n';
            caption += `\n∘ Title : ${video.title || '-'}` +
                `\n∘ Duration : ${video.timestamp || '-'}` +
                `\n∘ Views : ${video.views || '-'}` +
                `\n∘ Upload : ${video.ago || '-'}` +
                `\n∘ Author : ${video.author?.name || '-'}` +
                `\n∘ URL : ${video.url}` +
                `\n∘ Description: ${video.description || '-'}` +
                `\n\nPlease wait, the audio file is being sent...`;

            const thumbnailBuffer = await getBuffer(video.thumbnail);
            let message = await mecha.sendMessage(m.chat, {
                image: thumbnailBuffer,
                caption,
            }, {
                quoted: m,
                ephemeralExpiration: m.expiration
            })

            const response = await axios.get(`https://p.oceansaver.in/ajax/download.php?format=mp3&url=${encodeURIComponent(video.url)}&api=dfcb6d76f2f6a9894gjkege8a4ab232222`, {
                headers: {
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
                }
            });

            if (!response.data || !response.data.success) return m.reply('Gagal mengunduh audio.');

            const {
                id,
                title,
                info
            } = response.data;
            const {
                image
            } = info;

            while (true) {
                const progress = await axios.get(`https://p.oceansaver.in/ajax/progress.php?id=${id}`, {
                    headers: {
                        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
                    }
                });

                if (progress.data && progress.data.success && progress.data.progress === 1000) {
                    const downloadUrl = progress.data.download_url;
                    const audioBuffer = await getBuffer(downloadUrl);
                    const fileName = title + '.mp3';
                    fs.writeFileSync(fileName, audioBuffer);
                    const outputAudioPath = func.filename('mp3');
                    await compressAudio(fileName, outputAudioPath);

                    if (m.isPrem || !global.devs.includes(m.bot)) {
                        await mecha.sendMessage(m.chat, {
                            audio: fs.readFileSync(outputAudioPath),
                            mimetype: 'audio/mpeg',
                            fileName: fileName,
                            /*contextInfo: {
                                externalAdReply: {
                                    title: video.title,
                                    body: video.timestamp || '-',
                                    thumbnail: thumbnailBuffer,
                                    mediaType: 2,
                                    mediaUrl: video.url,
                                    sourceUrl: video.url
                                }
                            }*/
                        }, {
                            quoted: message,
                            ephemeralExpiration: m.expiration
                        });
                    } else {
                        await mecha.sendMessage(chatId, {
                            audio: fs.readFileSync(outputAudioPath),
                            mimetype: 'audio/mpeg',
                            fileName: fileName,
                            ptt: true,
                        }).then(_ => mecha.sendMessage(chatId, {
                                text: video.title,
                                contextInfo: {
                                    externalAdReply: {
                                        title: `Request from ${users.name}`,
                                        body: global.header,
                                        thumbnail: thumbnailBuffer,
                                        mediaType: 1,
                                        previewType: 'PHOTO',
                                        mediaUrl: video.url,
                                        sourceUrl: video.url,
                                        renderLargerThumbnail: false
                                    }
                                }
                            })
                            .then(_ => mecha.reply(m.chat, 'Lagu berhasil dikirim\n- silahkan dengarkan disini: https://whatsapp.com/channel/0029ValXeD6C6ZvZAycpiH1z', message, {
                                expiration: m.expiration
                            })))
                    }

                    // Menghapus file sementara
                    fs.unlinkSync(fileName);
                    fs.unlinkSync(outputAudioPath);
                    processedAudio.delete(query);
                    break;
                }
                await new Promise(resolve => setTimeout(resolve, 5000));
            }
        } catch (error) {
            processedAudio.delete(query);
            console.error('Error in processing:', error);
            return mecha.reply(m.chat, error.message, m, {
                expiration: m.expiration
            });
        }
    },
    restrict: true,
    limit: 3,
    location: 'plugins/downloader/play2.js'
};