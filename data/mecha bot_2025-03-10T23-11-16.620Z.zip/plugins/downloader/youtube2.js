const axios = require("axios");

async function download(url, type) {
    if (!/^(audio|video)$/i.test(type)) type = 'audio';
    const response = await axios.get(`https://api.suraweb.online/download/youtube/${type}?url=${encodeURIComponent(url)}&quality=hd`)
    const result = response.data;
    return result;
}

exports.run = {
    usage: ['yta2', 'ytv2'],
    use: 'link',
    category: 'downloader',
    async: async (m, {
        func,
        mecha,
    }) => {
        try {
            if (/yt?(a|mp3)/i.test(m.command)) {
                if (!m.args || !m.args[0]) return m.reply(func.example(m.cmd, 'https://youtu.be/1fOBgosDo7s?si=_8VLb2NqwyICoEhY'))
                if (!/^(?:https?:\/\/)?(?:www\.|m\.|music\.)?youtu\.?be(?:\.com)?\/?.*(?:watch|embed)?(?:.*v=|v\/|\/)([\w\-_]+)\&?/.test(m.args[0])) return m.reply(global.mess.error.url)
                mecha.sendReact(m.chat, '🕒', m.key)
                const result = await download(m.args[0], 'audio');
                if (!result.status) return m.reply('Something when wrong!');
                const {
                    id,
                    title,
                    description,
                    thumbnailUrl,
                    author,
                    duration,
                    views,
                    downloadLink,
                    format,
                } = result.data;
                let caption = `*YOUTUBE DOWNLOADER MP3*\n
- VideoId: ${id}
- Title: ${title}
- Author: ${author}
- Duration: ${duration}
- Views: ${views}
- Description: ${description}`
                caption += `\n\nPlease wait, the audio file is being sent...`
                await mecha.reply(m.chat, caption, m, {
                    typing: 'recording',
                    expiration: m.expiration
                })
                mecha.sendMessage(m.chat, {
                    audio: {
                        url: downloadLink
                    },
                    mimetype: 'audio/mpeg',
                    fileName: title + '.' + format
                }, {
                    quoted: m,
                    ephemeralExpiration: m.expiration
                })
            } else if (/yt?(v|mp4)/i.test(m.command)) {
                if (!m.args || !m.args[0]) return m.reply(func.example(m.cmd, 'https://youtu.be/1fOBgosDo7s?si=_8VLb2NqwyICoEhY'))
                if (!/^(?:https?:\/\/)?(?:www\.|m\.|music\.)?youtu\.?be(?:\.com)?\/?.*(?:watch|embed)?(?:.*v=|v\/|\/)([\w\-_]+)\&?/.test(m.args[0])) return m.reply(global.mess.error.url)
                mecha.sendReact(m.chat, '🕒', m.key)
                const result = await download(m.args[0], 'video');
                if (!result.status) return m.reply('Something when wrong!');
                const {
                    id,
                    title,
                    description,
                    thumbnailUrl,
                    author,
                    duration,
                    views,
                    downloadLink,
                    format,
                } = result.data;
                let caption = `*YOUTUBE DOWNLOADER MP4*\n
- VideoId: ${id}
- Title: ${title}
- Author: ${author}
- Duration: ${duration}
- Views: ${views}
- Description: ${description}`
                caption += `\n\nPlease wait, the video file is being sent...`
                await mecha.reply(m.chat, caption, m, {
                    typing: 'recording',
                    expiration: m.expiration
                })
                mecha.sendMessage(m.chat, {
                    video: {
                        url: downloadLink
                    },
                    mimetype: 'video/mp4',
                    fileName: title + '.' + format
                }, {
                    quoted: m,
                    ephemeralExpiration: m.expiration
                })
            }
        } catch (error) {
            return mecha.reply(m.chat, error.message, m, {
                expiration: m.expiration
            })
        }
    },
    limit: 3,
    location: 'plugins/downloader/youtube2.js'
}