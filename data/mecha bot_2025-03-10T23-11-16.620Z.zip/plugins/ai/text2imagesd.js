const axios = require('axios');
const FormData = require('form-data');

async function text2imageSd(prompt) {
try {
if (!prompt) return { status: false, message: "undefined reading prompt" };
return await new Promise(async(resolve, reject) => {
const form = new FormData();
form.append("prompt", prompt);
axios.post("https://www.aiallin.online/loader.php", form, {
headers: form.getHeaders()
})
.then(async res => {
const data = res.data;
if (data.status !== "success") return reject("failed generate image!");
resolve({ status: true, image: "https://www.aiallin.online" + data.url })
}).catch(reject)
});
} catch (e) {
return { status: false, message: String(e) };
}
}

exports.run = {
usage: ['text2imagesd'],
hidden: ['text2imgsd'],
use: '1girl, 2.5D anime style',
category: 'ai',
async: async (m, { func, mecha }) => {
if (!m.text) return m.reply(func.example(m.cmd, 'masterpiece, best quality, 1girl, solo, long hair, skirt, outdoors, cloud, black hair, blue eyes, shirt, long sleeves, shoes, sky, tree, black skirt, full body, blue sky, bangs, blush, blue shirt, sneakers, standing, grass, white footwear, cloudy sky, day, print shirt, looking at viewer, walking, from side, <lora:add_detail:1>'))
mecha.sendReact(m.chat, '🕒', m.key)
text2imageSd(m.text).then(result => {
if (!result.status) return m.reply(result.message)
mecha.sendMessage(m.chat, {
image: {
url: result.image
},
caption: `*Prompt*: ${m.text}`
}, {quoted: m, ephemeralExpiration: m.expiration})
}).catch(error => mecha.reply(m.chat, error, m))
},
premium: true,
limit: 5
}