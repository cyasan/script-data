exports.run = {
usage: ['omniai'],
hidden: ['omni', 'omniplex'],
use: 'question',
category: 'ai',
async: async (m, { func, mecha }) => {
const { omniplexAi } = await import('@kaviaann/scraper')
const name = global.db.users[m.sender].name;
if (!m.text) return m.reply(func.example(m.cmd, "`Hai " + name + "\tApa yang bisa saya bantu?`"));
const date = new Date();
let run = true;
mecha.sendReact(m.chat, '🕒', m.key)
setTimeout(async () => {
if (!run) return;
mecha.sendReact(m.chat, '❌', m.key)
return await m.reply("*Terlalu lama untuk mencari jawaban, silahkan coba lagi*");
}, 30 * 1000);
return await omniplexAi(m.text + "Dan namaku adalah " + name, "Kamu adalah Mecha, sebuah asisten virtual yang bertugas untuk membantu untuk menyelesaikan permasalahan yang diberikan, sekarang " + `detik ${date.getSeconds()}, menit ${date.getMinutes()}, jam ${date.getHours()}, tanggal ${date.getDate()}, hari ke ${date.getDay()}, bulan ke ${date.getMonth()}, dan tahun ${date.getFullYear()}` + ". Kamu akan menjawab dalam bahasa indonesia, dan juga kamu dapat menggunakan * untuk teks bold, _ untuk text italic, dan ` untuk teks code, gunakan [nama websitenya] untuk website. Contohnya : *PERHATIAN!* Saya adalah _Mecha_ Dan saya bisa membantu untuk menyelesaikan `permasalahan anda`")
.then(async (v) => {
mecha.sendReact(m.chat, '🕒', m.key)
if (v.mode === "chat") {
await m.reply(v.data);
} else {
if (v.search?.images?.value?.length || v.search?.videos?.value?.length) {
const type = Object.keys(v.search).includes("videos") ? "videos" : Object.keys(v.search).includes("images") ? "images" : "web";
const media = type === "images" ? v.search.images.value[Math.floor(Math.random() * v.search.images.value.length)] : v.search.videos.value[Math.floor(Math.random() * v.search.videos.value.length)];
await mecha.sendMessage(m.chat, {
text: v.data,
contextInfo: {
mentionedJid: [m.sender],
externalAdReply: {
thumbnailUrl: media.thumbnailUrl || "",
title: "Question : " + m.text,
body: "Omniplex AI",
renderLargerThumbnail: true,
mediaType: 1,
sourceUrl: type === "images" || type === "videos" ? media.hostPageUrl : v.search.webPages.value[0].url,
},
},
});
} else await m.reply(v.data);
}
run = false;
return mecha.sendReact(m.chat, '✅', m.key)
})
.catch((v) => m.reply("*`Terjadi kesalahan :`*\n\n" + v.toString().trim()));
},
limit: true
}