const axios = require('axios');

function joox(query) {
return new Promise((resolve, reject) => {
const time = Math.floor(new Date() / 1000)
axios.get('http://api.joox.com/web-fcgi-bin//web_search?lang=id&country=id&type=0&search_input=' + query + '&pn=1&sin=0&ein=29&_=' + time)
.then(({ data }) => {
let result = []
let hasil = []
let promoses = []
let ids = []
data.itemlist.forEach(result => {
ids.push(result.songid)
});
for (let i = 0; i < data.itemlist.length; i++) {
const get = 'http://api.joox.com/web-fcgi-bin/web_get_songinfo?songid=' + ids[i]
promoses.push(
axios.get(get, {
headers: {
Cookie: 'wmid=142420656; user_type=1; country=id; session_key=2a5d97d05dc8fe238150184eaf3519ad;'
}
})
.then(({ data }) => {
const res = JSON.parse(data.replace('MusicInfoCallback(', '').replace('\n)', ''))
hasil.push({
lagu: res.msong,
album: res.malbum,
penyanyi: res.msinger,
publish: res.public_time,
img: res.imgSrc,
mp3: res.mp3Url
})
Promise.all(promoses).then(() => resolve({
creator: 'SuryaDev.',
status: true,
data: hasil,
}))
}).catch(reject)
)
}
}).catch(reject)
})
}

exports.run = {
usage: ['joox'],
use: 'text',
category: 'downloader',
async: async (m, { func, mecha }) => {
if (!m.text) return m.reply(func.example(m.cmd, 'akad'))
if (isUrl(m.text)) return m.reply(func.example(m.cmd, 'akad'))
mecha.sendReact(m.chat, '🕒', m.key)
joox(m.text).then(res => {
let joox = JSON.stringify(res)
let json = JSON.parse(joox)
let random = Math.floor(Math.random() * json.data.length)
let result = json.data[random]
let txt = `*J O O X*\n
%Penyanyi% : ${result.penyanyi}
%Judul% : ${result.lagu}
%Album% : ${result.album}
%Diterbitkan% : ${result.publish}
%Link% : ${result.mp3}`.trim()
mecha.sendMedia(m.chat, result.img, m, {caption: txt.replaceAll('%', '```'), expiration: m.expiration})
mecha.sendMedia(m.chat, result.mp3, m, {expiration: m.expiration})
})
}
}

const isUrl = (text) => {
return text.match(new RegExp(/https?:\/\/(www\.)?[-a-zA-Z0-9@:%._+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b([-a-zA-Z0-9()@:%_+.~#?&/=]*)/, 'gi'))
}

async function shortlink(url) {
isurl = /https?:\/\//.test(url)
return isurl ? (await axios.get('https://tinyurl.com/api-create.php?url='+encodeURIComponent(url))).data : ''
}