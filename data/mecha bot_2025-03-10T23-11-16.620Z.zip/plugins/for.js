exports.run = {
usage: ['for'],
use: 'text',
category: 'tools',
async: async (m, { func, mecha }) => {
if (!m.text) return m.reply(func.example(m.cmd, 'I Love You'))
if (m.text.length > 50) return m.reply('Max 50 character!')
let data = [...m.text];
let txt = '';
let { key } = await mecha.sendMessage(m.chat, {text: m.text}, {quoted: m, ephemeralExpiration: m.expiration})
for (let i = 0; i < data.length; i++) {
txt += data[i];
await mecha.relayMessage(m.chat, {
protocolMessage: {
key: key,
type: 14,
editedMessage: {
conversation: txt
}
}
}, {quoted: null, ephemeralExpiration: m.expiration});
await new Promise(resolve => setTimeout(resolve, 500));
}
},
limit: true
}