exports.run = {
    usage: ['totalwin'],
    hidden: ['totalmenang'],
    category: 'games',
    async: async (m, { func, mecha }) => {
        let games = global.db.users[m.sender].game;
        let totalwin = Object.values(games).reduce((acc, val) => acc + val, 0);
        if (totalwin === 0) return m.reply('Data kosong.');

        let caption = `乂 *LIST TOTAL WIN GAMES*\n\n` + 
                  Object.entries(games)
                      .filter(([key, value]) => value > 0)
                      .map(([key, value]) => `- ${func.ucword(key)} : ${value}\n`)
                      .join('') + 
                  `\nTotal : *${totalwin}*`;

        mecha.reply(m.chat, caption, m, {
            expiration: m.expiration
        });
    },
    location: 'plugins/games/totalwin.js'
}