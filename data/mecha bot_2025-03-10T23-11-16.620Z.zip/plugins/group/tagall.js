exports.run = {
usage: ['tagall'],
use: 'text',
category: 'group',
async: async (m, { func, mecha }) => {
let caption = `乂  *T A G - A L L*\n${m.text ? '\nPesan: ' + m.text + '\n' : ''}`
m.members.forEach(item => {
caption += `\n${item.admin == 'superadmin' ? '👑' : item.admin == 'admin' ? '😈' : '👤'} @${item.id.split('@')[0]}`
})
mecha.sendMessage(m.chat, {
text: caption, 
mentions: m.members.map(v => v.id)
}, {quoted: func.fverified, ephemeralExpiration: m.expiration})
},
group: true,
admin: true
}