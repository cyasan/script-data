const path = require('path');
const fs = require('fs');

exports.run = {
usage: ['clearsession'],
hidden: ['delsession'],
category: 'owner',
async: async (m, { func, mecha }) => {
let sessions = 'session';
mecha.sendReact(m.chat, '🕒', m.key)
fs.readdir(sessions, async function(err, files) {
if (err) {
console.log('Unable to scan directory: ' + err);
return m.reply('Unable to scan directory: ' + err);
}
let filteredArray = await files.filter(item => item.startsWith("pre-key") || item.startsWith("sender-key") || item.startsWith("session-") || item.startsWith("app-state"))
if (filteredArray.length == 0) return m.reply('Empty data.')
await filteredArray.forEach(function(file) {
//fs.unlinkSync(`./${sessions}/${file}`)
fs.unlinkSync(path.join(sessions, file))
});
await func.delay(2000)
m.reply(`Successfully clear ${filteredArray.length} files sessions.`);
})
},
owner: true
}