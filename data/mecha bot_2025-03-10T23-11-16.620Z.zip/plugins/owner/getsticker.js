exports.run = {
usage: ['getsticker'],
hidden: ['getstiker', 'getstik'],
use: 'number',
category: 'owner',
async: async (m, { func, mecha }) => {
if (isNaN(m.text)) {
if (!m.text) return m.reply(func.example(m.cmd, 'malas'))
if (!global.db.sticker[m.text]) return m.reply(`Sticker dengan nama *'${m.text}'* tidak ditemukan.`)
await mecha.sendMessage(m.chat, {sticker: {url: global.db.sticker[m.text].link }}, {quoted: m, ephemeralExpiration: m.expiration})
} else {
if (!m.text) return m.reply(func.example(m.cmd, '1'))
let stik = Object.entries(global.db.sticker).map(([key, value]) => {
return { ...value, jid: key }
})
if (Number(m.text) >= stik.length) {
let txt = `Sticker dengan id ${m.args[0]} tidak ditemukan\n\n`
for (let [index, list] of Object.keys(global.db.sticker).entries()) {
txt += `${index++}. ${list}\n`
}
return mecha.reply(m.chat, txt, m)
}
mecha.sendMessage(m.chat, {
sticker: {
url: stik[m.args[0]].link
}
}, {quoted: m, ephemeralExpiration: m.expiration})
}
},
limit: true
}