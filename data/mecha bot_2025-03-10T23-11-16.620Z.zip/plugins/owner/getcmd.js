exports.run = {
usage: ['getcmd'],
use: 'cmd id',
category: 'owner',
async: async (m, { func, mecha }) => {
if (!m.text) return m.reply(func.example(m.cmd, '1'))
if (isNaN(m.text)) return m.reply('ID harus berupa angka!')
let cmd = Object.entries(global.db.stickercmd).map(([key, value]) => {return { ...value, jid: key }})
if (Number(m.text) >= cmd.length) return m.reply(`Tidak ditemukan!`)
mecha.sendMessage(m.chat, {
sticker: {
url: cmd[m.text].link
}
}, {quoted: m, ephemeralExpiration: m.expiration})
},
owner: true
}