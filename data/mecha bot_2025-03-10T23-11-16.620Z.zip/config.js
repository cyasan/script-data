global.owner = '62895415497664' + '@s.whatsapp.net';
global.ownerName = 'SuryaDev';
global.developer = [
    '62895415497664',
    '6285702691440',
    '6289504842184'
].map(replacement);
global.botName = 'Mecha Bot'
global.fake = 'Copyright © 2025 SuryaDev'
global.header = `© mecha-bot v${require('./package.json').version} (Beta)`
global.footer = 'ꜱɪᴍᴘʟᴇ ᴡʜᴀᴛꜱᴀᴘᴘ ʙᴏᴛ ᴍᴀᴅᴇ ʙʏ sᴜʀʏᴀ'
global.cooldown = 1
global.max_ram = 3
global.blocks = ['91', '92', '212']
global.prefixes = /^[°•π÷×¶∆£¢€¥®™+✓_=|/~!?@#%^&.©^]/i
global.newsletter = '120363261409301854@newsletter'
global.qrisUrl = 'https://telegra.ph/file/080cbdedf32c6c84ff435.jpg'
global.audioUrl = 'https://cdn.filestackcontent.com/2r7cSUozTQ2tTS15NfFj';
global.pairing = {
    copyFromLink: true, // https://iyaudah-iya.vercel.app/pairing
    status: true,
    number: '6285602467071',
    code: 'FUFUFAFA'
}
global.config = {
    session: 'session',
    online: true,
    version: [2, 3000, 1015901307],
    browser: ['Windows', 'Chrome', '20.0.04'],
   button: true
}
global.quoteApi = 'https://qc.botcahx.eu.org/generate'
global.mongoUrl = '';
global.panelApi = {
    domain: 'https://mechabot.paneldigital.me',
    apikey: 'ptla_DBEVpAcnjsRoOBeStIcMCwyRm81mh1LOO3kfZqxMlQf',
    capikey: 'ptlc_Rp1TjERGg2GM98jL8nKgqbECwhD2sNmGekn2XrpFi6E',
    eggs: '15'
}
global.mess = {
    wait: 'Processed . . .',
    ok: 'Successfully.',
    limit: 'kamu telah mencapai limit harian dan akan di reset setiap jam 00.00\n- beli premium untuk mendapatkan unlimited limit.',
    premium: 'yahh, kamu bukan user premium, beli premium dulu yuk',
    jadibot: 'This feature only for jadibot user.',
    owner: 'This feature is only for owners.',
    devs: 'This feature is only for developers.',
    group: 'This feature will only work in groups.',
    private: 'Use this feature in private chat.',
    admin: 'This feature only for group admin.',
    botAdmin: 'This feature will work when I become an admin',
    bot: 'This feature can only be accessed by bots',
    wrong: 'Wrong format!',
    error: {
        url: 'URL is Invalid!',
        api: 'Sorry an error occurred!'
    },
    block: {
        owner: `This feature is being blocked by owner!`,
        system: `This feature is being blocked by system because an error occurred!`
    },
    query: 'Enter search text',
    search: 'Searching . . .',
    scrap: 'Scrapping . . .',
    wrongFormat: 'Incorrect format, please look at the menu again',
    game: 'Bermain game di obrolan pribadi hanya untuk pengguna premium, tingkatkan ke paket premium hanya Rp. 20.000 selama 1 bulan.'
}

function replacement (id) {
    return id.replace(/[^0-9]/g, '') + '@s.whatsapp.net';
}

require('./system/functions.js').reloadFile(__filename);