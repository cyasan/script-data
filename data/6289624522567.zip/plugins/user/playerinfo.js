
const fetch = require('node-fetch');

exports.run = {
usage: ['playerinfo'],
hidden: ['userinfo'],
use: 'mention or reply',
category: 'user',
async: async (m, { func, mecha, froms, setting }) => {
let number = isNaN(m.text) ? (m.text.startsWith('+') ? m.text.replace(/[()+\s-]/g, '') : m.text.split('@')[1]) : m.text
if (!m.text && !m.quoted) return m.reply('Mention or Reply chat target.')
if (isNaN(number)) return m.reply('Invalid number.')
if (number.length > 15) return m.reply('Invalid format.')
if (global.db.users[froms] == undefined) return m.reply('User data not found.')
if (global.db.users[global.db.users[froms].pasangan.id] == undefined) global.db.users[froms].pasangan.id = ''
let { name, gender, age, limit, balance, premium, banned, jadibot, warning, register, date, pasangan, expired, level, exp, role } = global.db.users[froms]
let pacar = `Berpacaran dengan @${pasangan.id.split('@')[0]}`
let pacarnya = pasangan.id ? (global.db.users[pasangan.id].pasangan.id ? pacar : 'Sedang digantung @' + pasangan.id.split('@')[0]) : 'Jomblo'
let about = (await mecha.fetchStatus(froms).catch(_ => {}) || {}).status || ''
let listblock = await mecha.fetchBlocklist().catch((_) => []);
let caption = `════════════════
乂  *USER - PROFILE*
════════════════
◦ *Name* : ${name ? name : m.pushname}
◦ *Gender* : ${gender ? gender : '-'}
◦ *Age* : ${age ? age : '-'}
◦ *Limit* : ${premium ? 'Unlimited' : limit}
◦ *Balance* : ${func.formatNumber(balance)}
◦ *Level* : ${level}
◦ *Exp* : ${exp} / ${10 * Math.pow(level, 2) + 50 * level + 100}
◦ *Role* : ${role}
◦ *Status* : ${pacarnya}
◦ *About* : ${about ? about : '-'}

════════════════
乂  *USER - STATUS*
════════════════
◦ *Warning* : ${warning} / 3
◦ *Blocked* : ${listblock.includes(m.sender) ? 'BLOCKED!' : '-'}
◦ *Banned* : ${banned ? ' (' + (expired.banned == 'PERMANENT' ? 'PERMANENT' : func.timeReverse(expired.banned)) + ')' : '-'}
◦ *Premium* : ${premium ? ' (' + (expired.premium == 'PERMANENT' ? 'PERMANENT' : func.timeReverse(expired.premium)) + ')' : '-'}
◦ *Jadibot* : ${jadibot ? ' (' + (expired.jadibot == 'PERMANENT' ? 'PERMANENT' : func.timeReverse(expired.jadibot)) + ')' : '-'}
◦ *Register* : ${register ? ' (' + date + ')' : '-'}`
//await m.reply(caption);
mecha.sendMessageModify(m.chat, caption, m, {
largeThumb: true, 
thumbnail: await (await fetch(await mecha.profilePictureUrl(m.sender, 'image').catch(_ => 'https://files.catbox.moe/chmsfn.jpg'))).buffer(),
expiration: m.expiration
})
},
group: true
}