exports.run = {
usage: ['setcommand'],
use: 'symbol',
category: 'owner',
async: async (m, { func, mecha, setting }) => {
if (!m.text) return m.reply(func.example(m.cmd, '#'))
if (m.args[0] == 'multi') {
if (setting.multiprefix) return m.reply('Your Symbol already this.')
setting.multiprefix = true;
m.reply(`Successfully changed`)
} else {
if (setting.prefix == m.args[0] && !setting.multiprefix) return m.reply('Your Symbol already this.')
setting.multiprefix = false;
setting.prefix = m.args[0];
m.reply(`Successfully changed Symbol to : ${m.args[0]}`)
}
},
owner: true
}