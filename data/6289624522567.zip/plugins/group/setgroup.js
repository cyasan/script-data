exports.run = {
usage: ['open', 'close'],
category: 'group',
async: async (m, { func, mecha }) => {
if (m.command === 'close'){
await mecha.groupSettingUpdate(m.chat, 'announcement')
.then((res) => mecha.sendMessage(m.chat, {react: {text: '✅', key: m.key}}))
.catch((err) => mecha.sendReact(m.chat, '❌', m.key))
} else if (m.command === 'open'){
await
mecha.groupSettingUpdate(m.chat, 'not_announcement')
.then((res) => mecha.sendMessage(m.chat, {react: {text: '✅', key: m.key}}))
.catch((err) => mecha.sendReact(m.chat, '❌', m.key))
}},
group: true,
admin: true,
botAdmin: true
}