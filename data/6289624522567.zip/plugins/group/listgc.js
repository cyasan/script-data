exports.run = {

    usage: ['idgc2', 'listgc'],

    use: 'group',

    category: 'group',

    premium: true,
    owner: true,
    admin: true,

    async: async (m, { func, mecha, quoted }) => {

        // Cek apakah perintah dijalankan di dalam grup

        const isGroup = m.isGroup;

        let meta;

        if (isGroup) {

            meta = await mecha.groupMetadata(m.chat);

        }

        switch (m.command) {

            case 'listgc':

                if (!isGroup) {

                    // Jika tidak dalam grup, ambil semua grup yang diikuti

                    let gcall = Object.values(await mecha.groupFetchAllParticipating().catch(_ => null));

                    let listgc = `*｢ LIST ALL CHAT GRUP ｣*\n\n`;

                    if (gcall.length === 0) {

                        listgc += "Tidak ada grup yang ditemukan.";

                    } else {

                        gcall.forEach((meta) => {

                            listgc += `*• Nama :* ${meta.subject}\n*• ID :* ${meta.id}\n*• Total Member :* ${meta.participants.length} Member\n*• Status Grup :* ${meta.announce ? "Tertutup" : "Terbuka"}\n*• Pembuat :* ${meta.owner ? '@' + meta.owner.split('@')[0] : 'Tidak diketahui'}\n\n`;

                        });

                    }

                    await m.reply(listgc);

                } else {

                    // Jika dalam grup, tampilkan pesan yang sesuai

                    await m.reply("Perintah ini hanya dapat digunakan di luar grup.");

                }

                break;

            case 'idgc2':

                if (isGroup) {

                    // Mengakses data grup dari global.db.groups

                    let metaid = m.chat; // ID grup saat ini

                    let set = global.db.groups[m.chat] || {}; // Ambil data grup atau objek kosong jika tidak ada

                    // Mengambil metadata grup

                    let response = `*ID Grup:* ${meta.id}\n*Nama Grup:* ${meta.subject}\n*Total Anggota:* ${meta.participants.length} Anggota\n*Status Grup:* ${meta.announce ? "Tertutup" : "Terbuka"}\n*Pembuat:* ${meta.owner ? '@' + meta.owner.split('@')[0] : 'Tidak Diketahui'}`;

                    // Mengirimkan pesan

                    await m.reply(response);

                } else {

                    // Jika tidak dalam grup, tampilkan pesan yang sesuai

                    await m.reply("Perintah ini hanya dapat digunakan di dalam grup.");

                }

                break;

            // Tambahkan case lain jika diperlukan

        } // Penutupan switch

    } // Penutupan async function

}; // Penutupan exports.run