exports.run = {
usage: ['buyprem', 'sewabot'],
hidden: ['premium', 'sewa'],
category: 'special',
async: async (m, { func, mecha, setting }) => {
let caption;
if (func.somematch(['buyprem', 'premium'], m.command)) {
caption =  `「 *LIST HARGA PREMIUM* 」

*PAKET P1*
- Rp5.000 / 3 Day
- Unlock Feature Premium
- Unlimited Limit

*PAKET P2*
- Rp10.000 / 7 Day
- Unlock Feature Premium
- Unlimited Limit

*PAKET P3*
- Rp20.000 / 14 Day
- Perpanjang Rp20.000
- Unlock Feature Premium
- Unlimited Limit

*PAKET P4*
- Rp40.000 / 30 Day
- Perpanjang Rp30.000
- Unlock Feature Premium
- Unlimited Limit

*PAYMENT // PEMBAYARAN*
• Dana : 089514015323
• Gopay : 089624522567
• Seabank : 901701867632
• Bank Jago : 108784352600
• 𝐐𝐑𝐈𝐒//𝐐𝐑 𝐂𝐎𝐃𝐄 [ 𝐀𝐋𝐋𝐏𝐀𝐘 ]

*INFORMATION*
1. Melakukan pembelian artinya anda setuju dengan segala kebijakan kami.
2. Semua pembelian bergaransi.
3. Tidak puas dengan layanan kami? Kami kembalikan uang Anda 100% dalam jangka waktu 1 jam setelah pembelian.
4. Jika bot mengalami kendala atau perbaikan hingga 24 jam atau lebih, kami berikan kompensasi berupa penambahan waktu sewa.
5. Perpanjangan hanya berlaku jika masa aktif tersisa kurang dari 3 hari.

Berminat? Hubungi :
wa.me/${global.owner.replace(/[^0-9]/g, '')}`
} else if (func.somematch(['sewabot', 'sewa'], m.command)) {
caption = `「 *LIST HARGA SEWA BOT* 」

*PAKET S1*
- Rp15.000 / Group
- Perpanjang Rp10.000
- Masa Aktif 7 Hari

*PAKET S2*
- Rp30.000 / Group
- Perpanjang Rp25.000
- Masa 𝐀ktif 14 H𝐚𝐫𝐢

*PAKET S3*
- Rp40.000 / Group
- Perpanjang Rp35.000
- Masa Aktif 1 Bulan
- Access All Feature

*PAKET S4*
- Rp60.000 / Group
- Perpanjang Rp50.000
- Masa aktif 2 Bulan
- Access All Feature

*KEUNTUNGAN*
- Fast respon
- Bot on 24 Jam
- Anti-Link (Auto Kick)
- Anti-Virtex (Auto Kick)
- Games/Gamble/Spotify
- Menfess/Music
- Downloader img/video/audio
- AI (Artificial Intelligence)
- Dan Masih Banyak lagi Feature

*PAYMENT*
• Dana : 089514015323
• Gopay : 089624522567
• Seabank : 901701867632
• Bank Jago : 108784352600
• 𝐐𝐑𝐈𝐒//𝐐𝐑-𝐂𝐎𝐃𝐄 [ 𝐀𝐋𝐋𝐏𝐀𝐘 ]

*INFORMATION*
1. Melakukan pembelian artinya anda setuju dengan segala kebijakan kami.
2. Semua pembelian bergaransi.
3. Tidak puas dengan layanan kami? Kami kembalikan uang Anda 100% dalam jangka waktu 1 jam setelah pembelian.
4. Jika bot mengalami kendala atau perbaikan hingga 24 jam atau lebih, kami berikan kompensasi berupa penambahan waktu sewa.
5. Perpanjangan hanya berlaku jika masa aktif tersisa kurang dari 3 hari.

Berminat? Hubungi :
wa.me/${global.owner.replace(/[^0-9]/g, '')}`
}
mecha.sendMessage(m.chat, {
image: {
url: global.qrisUrl
}, 
caption: caption
}, {quoted: m, ephemeralExpiration: m.expiration});
}
}