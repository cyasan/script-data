const cheerio = require('cheerio');
const fetch = require('node-fetch');

function cleanText(html) {
    // Menghapus kode HTML
    const text = html.replace( /<[^>]+>/g, '');
    
    // Menghapus spasi di awal dan akhir string
    let cleanedText = text.trim();
    
    // Mengganti beberapa spasi berturut-turut dengan satu spasi
    cleanedText = cleanedText.replace(/\s+/g, ' ');

    // Menghapus enter yang tidak penting
    cleanedText = cleanedText.replace(/\n+/g, '\n');

    return cleanedText;
}

async function searchDongeng(q) {
    try {
        const url = 'https://dongengceritarakyat.com/?s=' + q; // Ganti dengan URL halaman web yang ingin Anda crawl
        const response = await fetch(url);
        const body = await response.text();
        const $ = cheerio.load(body);
        const results = [];

        $('article').each((index, element) => {
            const article = $(element);
            const result = {
                entryTitle: article.find('.entry-title a').text(),
                link: article.find('.entry-title a').attr('href'),
                imageSrc: article.find('.featured-image amp-img').attr('src'),
                entrySummary: article.find('.entry-summary').text(),
                footerTag: article.find('.cat-links a').text(),
                from: article.find('.tags-links a').text()
            };
            results.push(result);
        });

        return results;
    } catch (error) {
        console.error('Error:', error);
        return [];
    }
};

async function readDongeng(url) {
    const response = await fetch(url);
    const html = await response.text();
    const $ = cheerio.load(html);

    return {
        image: $('div.featured-image amp-img').attr('src'),
        title: $('h1.entry-title').text(),
        date: $('span.posted-date').text(),
        author: $('span.posted-author a').text(),
        content: $('div.entry-content').text(),
        tag: $('span.tags-links a').text(),
        cat: $('span.cat-links a').text(),
    };
}

exports.run = {
    usage: ['dongeng', 'dongeng-read'],
    use: 'query',
    category: 'searching',
    async: async (m, {
        func,
        mecha
    }) => {
        switch (m.command) {
            case 'dongeng': {
                if (!m.text) return m.reply(func.example(m.cmd, 'kancil'))
                mecha.sendReact(m.chat, '⌛', m.key);
                try {
                    let results = await searchDongeng(m.text)
                    /*let caption = results.map((item, index) => {
                        return `${index + 1}. ${item.entryTitle}
- Link: ${item.link}
- footerTag: ${item.footerTag}
- From: ${item.from}`
                    }).join('\n\n');
                    mecha.reply(m.chat, caption, m, {
                        expiration: m.expiration
                    })*/
                    let body = '```Result from:```' + ' `' + m.text + '`'
                    let rows = []
                    results.forEach((item, index) => {
                        rows.push({
                            header: item.footerTag,
                            title: `${index + 1}. ${item.entryTitle}`,
                            description: item.entrySummary.trim(),
                            id: `${m.prefix}dongeng-read ${item.link}`
                        })
                    })
                    let sections = [{
                        title: 'PILIH DONGENG DIBAWAH',
                        rows: rows
                    }]
                    let buttons = [
                        ['list', 'Click Here ⎙', sections],
                    ]
                    mecha.sendButton(m.chat, `D O N G E N G - S E A R C H`, body, 'select the list button below.', buttons, m, {
                        expiration: m.expiration
                    })
                } catch (e) {
                    return await m.reply(e.message)
                }
            }
            break
            case 'dongeng-read': {
                if (!m.text) return m.reply(func.example(m.cmd, 'https://dongengceritarakyat.com/dongeng-kancil-dan-jerapah-dan-pesan-moral/'))
                if (!m.args[0].includes('https://dongengceritarakyat.com/')) return m.reply(global.mess.error.url)
                mecha.sendReact(m.chat, '⌛', m.key);
                try {
                    let item = await readDongeng(m.text)
                    let caption = `*D O N G E N G - R E A D*

- *Title:* ${item.title}
- *Thumbnail:* ${item.image}
- *Category:* ${item.cat}
- *Tag:* ${item.tag}
- *Author Name:* ${item.author}
- *Date:* ${item.date}
- *Content:* ${cleanText(item.content)}`
                    await mecha.sendMedia(m.chat, item.image, m, {
                        caption: caption.trim(),
                        expiration: m.expiration
                    })

                } catch (e) {
                    return await m.reply(e.message)
                }
            }
            break
        }
    },
    limit: 1,
    location: 'plugins/searching/dongeng.js'
}