const axios = require('axios');
const cheerio = require('cheerio');

async function tiktokstalk(user) {
return new Promise(async(resolve, reject) => {
await axios.get(`https://urlebird.com/user/${user}/`)
.then((data) => {
let $ = cheerio.load(data.data);
resolve({
status: true,
creator: 'WilzxStore',
thumbnail: $('div[class="col-md-auto justify-content-center text-center"] > img').attr('src'),
name: $('h1.user').text().trim(),
username: $('div.content > h5').text().trim(),
followers: $('div[class="col-7 col-md-auto text-truncate"]').text().trim().split(' ')[1],
following: $('div[class="col-auto d-none d-sm-block text-truncate"]').text().trim().split(' ')[1],
bio: $('div.content > p').text().trim()
})
})
.catch((e) => {
reject({ status: false, creator: 'SuryaDev', msg: e })
})
})
}

exports.run = {
usage: ['tiktokstalk'],
hidden: ['ttstalk'],
use: 'username',
category: 'searching',
async: async (m, { func, mecha }) => {
if (!m.text) return m.reply(func.example(m.cmd, 'nama tiktok anda'))
mecha.sendReact(m.chat, '⌛', m.key)
try {
await tiktokstalk(m.text).then(async (res) => {
if (!res.status) return m.reply('Error Username tidak ditemukan\nSilahkan kirim Username yang valid!')
let txt = `乂  *TIKTOK STALKER*\n`
txt += `\n◦  Name: ${res.name}`
txt += `\n◦  Username: ${res.username}`
txt += `\n◦  Followers: ${res.followers}`
txt += `\n◦  Following: ${res.following}`
txt += `\n◦  Bio: ${res.bio}`
mecha.sendMessageModify(m.chat, txt, m, {
title: 'TIKTOK STALKER',
body: global.header, 
thumbnail: await mecha.resize(res.thumbnail, 300, 175),
largeThumb: true, 
expiration: m.expiration
})
}).catch((e) => m.reply('Username tidak ditemukan!'))
} catch (err) {
m.reply(global.mess.error.api)
}
},
limit: 2
}