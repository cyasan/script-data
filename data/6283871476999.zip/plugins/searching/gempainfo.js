const fetch = require('node-fetch')
const link = 'https://data.bmkg.go.id/DataMKG/TEWS/'

exports.run = {
usage: ['gempainfo'],
category: 'searching',
async: async (m, { func, mecha }) => {
mecha.sendReact(m.chat, '⌛', m.key)
try {
let res = await fetch(link + 'autogempa.json')
let result = await res.json()
result = result.Infogempa.gempa
let txt = `Tanggal : ${result.Tanggal}\n`
txt += `Waktu : ${result.Jam}\n`
txt += `Potensi : *${result.Potensi}*\n`
txt += `Magnitude : ${result.Magnitude}\n`
txt += `Kedalaman : ${result.Kedalaman}\n`
txt += `Wilayah : ${result.Wilayah}\n`
txt += `Lintang : ${result.Lintang} & Bujur: ${result.Bujur}\n`
txt += `Koordinat : ${result.Coordinates}\n`
txt += result.Dirasakan ? `Dirasakan : ${result.Dirasakan}` : ''
let imgBuffer = await (await fetch(link + result.Shakemap)).buffer()
await mecha.sendMedia(m.chat, imgBuffer, m, {
caption: txt,
expiration: m.expiration
})
} catch (e) {
console.log(e)
m.reply(global.mess.error.api)
}
}
}