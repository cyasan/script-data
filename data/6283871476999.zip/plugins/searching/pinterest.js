const axios = require('axios');

exports.run = {
    usage: ['pinterest'],
    hidden: ['pin'],
    use: 'text',
    category: 'searching',
    async: async (m, {
        func,
        mecha
    }) => {
        if (!m.text) return m.reply(func.example(m.cmd, 'nakano miku'))
        if ((m.mentionedJid || []).length > 0) return m.reply('Stress ??')
        mecha.sendReact(m.chat, '🕒', m.key)
        let caption = '```Result from:```' + '\t`' + m.text + '`'
        let {
            data
        } = await axios.get(`https://api.siputzx.my.id/api/s/pinterest?query=${encodeURIComponent(m.text)}`);
        if (!data.status) return m.reply('Somenting went wrong');
        let array = data.data.map(v => v.images_url);
        shuffleArray(array); // Mengacak array
        let result = array[Math.floor(Math.random() * array.length)]
        await mecha.sendMessage(m.chat, {
            image: {
                url: result
            },
            caption: caption
        }, {
            quoted: m,
            ephemeralExpiration: m.expiration
        });
    },
    restrict: true,
    limit: true,
    location: 'plugins/searching/pinterest.js'
}

function shuffleArray(array) {
    for (let i = array.length - 1; i > 0; i--) {
        const rand = Math.floor(Math.random() * (i + 1));
        [array[i], array[rand]] = [array[rand], array[i]];
    }
}