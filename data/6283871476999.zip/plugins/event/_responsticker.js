exports.run = {
main: async (m, { func, mecha, packname, author, isPrem }) => {
if (m.budy && global.db.sticker[m.budy] && isPrem) {
mecha.sendStickerFromUrl(m.chat, global.db.sticker[m.budy].link, m, {
packname: packname, 
author: author, 
expiration: m.expiration
})
}
},
limit: true
}