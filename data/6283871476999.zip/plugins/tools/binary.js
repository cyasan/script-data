function TextToBinary(text) {
let result = '';

for (let i = 0; i < text.length; i++) {
let char = text.charCodeAt(i);
let string = char.toString(2);

while (string.length < 8) {
string = '0' + string;
}

result += string;
}

return result;
}

function BinaryToText(code) {
let result = '';
let array = [];

for (let i = 0; i < code.length; i += 8) {
let substring = code.substring(i, i + 8);
array.push(substring);
}

for (let i = 0; i < array.length; i++) {
let count = 0;
let amount = 0;

for (let j = array[i].length - 1; j >= 0; j--) {
if (array[i][j] === '1') {
count += Math.pow(2, amount);
}
amount++;
}

let char = String.fromCharCode(count);
result += char;
}

return result;
} 

exports.run = {
usage: ['binary', 'ebinary'],
use: 'paramater',
category: 'tools',
async: async (m, { func, mecha }) => {
switch (m.command) {
case 'binary':{
let text;
if (m.args.length >= 1) {
text = m.args.slice(0).join(" ");
} else if (m.quoted && m.quoted.text) {
text = m.quoted.text;
} else return m.reply(func.example(m.cmd, 'suryadev'))
mecha.sendReact(m.chat, '⌛', m.key)
let result = await TextToBinary(text)
mecha.reply(m.chat, result, m, {
expiration: m.expiration
})
}
break
case 'ebinary':{
let text;
if (m.args.length >= 1) {
text = m.args.slice(0).join(" ");
} else if (m.quoted && m.quoted.text) {
text = m.quoted.text;
} else return m.reply(func.example(m.cmd, '01110100011100100110100101100111011001110110010101110010'))
mecha.sendReact(m.chat, '⌛', m.key)
let result = await BinaryToText(text)
mecha.reply(m.chat, result, m, {
expiration: m.expiration
})
}
break
}
},
limit: true
}