const axios = require('axios');
const fs = require('fs');
let index = 0;

async function tiktokStory(username) {
return new Promise(async (resolve, reject) => {
const uuid = encodeURIComponent(`@${username}`)
await axios.get(`https://tiktok-video-no-watermark2.p.rapidapi.com/user/posts?unique_id=${uuid}&count=1000`, {
headers: {
"Accept": "application/json, text/plain, */*",
"User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36",
"X-Rapidapi-Host": "tiktok-video-no-watermark2.p.rapidapi.com",
"X-Rapidapi-Key": "533115be6amsh2515f73f171c6f1p160d9djsn833294e42f10"
}
})
.then(({ data }) => {
let result = []
for (let [index, res] of data.data.videos.entries()) {
result.push({
index: index + 1,
video_id: res.video_id,
region: res.region,
title: res.title,
cover: res.cover,
origin_cover: res.origin_cover,
duration: res.duration,
play: res.play,
wmplay: res.wmplay,
size: res.size,
wm_size: res.wm_size,
music: res.music
})
}
resolve({
status: true,
creator: 'WilzxStore.',
data: result
})
})
.catch((e) => {
reject({
status: false,
creator: 'WilzxStore.',
message: e
})
})
})
}

exports.run = {
usage: ['tiktokstory'],
hidden: ['ttstory'],
use: 'username',
category: 'searching',
async: async (m, { func, mecha, setting }) => {
if (!m.text) return m.reply(func.example(m.cmd, 'babals__'))
let txt = '乂  *TIKTOK SEARCH*'
let result = await tiktokStory(m.text)
m.reply(`Wait sedang menyimpan ${result.data.length} video...`)
result.data.forEach(async (data) => {
index++;
txt += `\n\n${data.index}. ${data.title}`
txt += `\n◦  Size: ${func.formatSize(data.size)}`
txt += `\n◦  Duration: ${data.duration}`
txt += `\n◦  Url: ${data.play}`
let buffer = await func.fetchBuffer(data.play);
let path = './media/' + func.filename('mp4');
fs.writeFileSync(path, buffer);
let anu = await func.telegraPh(path);
setting.videogalau.push(anu.url);
await new Promise(resolve => setTimeout(resolve, 1000));
})
mecha.reply(m.cha, txt + '\n\nSukses menyimpan video dengan total : ' + index, m, {expiration: m.expiration})
},
owner: true
}