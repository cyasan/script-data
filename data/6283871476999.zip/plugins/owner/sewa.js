const toMs = require('ms')

exports.run = {
usage: ['sewa+', 'sewa-'],
use: '120xxxg.us 7d',
category: 'owner',
async: async (m, { func, mecha }) => {
let [id, time] = m.args;
if (!(id && time)) return m.reply(func.example(m.cmd, '120xxxg.us 7d'))
let groups = global.db.groups[id];
if (typeof groups == 'undefined') return m.reply('Group not found.')
if (!groups.sewa.status) return m.reply('Grup tersebut tidak ada di list sewa.')
if (m.command === 'sewa+') {
groups.sewa.expired += toMs(time)
m.reply(`Successfully added rental time to group ${groups.name} for ${time}`)
} else if (m.command === 'sewa-') {
groups.sewa.expired -= toMs(time)
m.reply(`Successfully reduced rental time to group ${groups.name} for ${time}`)
}
},
owner: true
}