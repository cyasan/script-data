const ffmpeg = require('fluent-ffmpeg');
const fs = require('fs');
const path = require('path');

exports.run = {
    usage: ['autocutvideo'],
    hidden: ['autocutvid', 'autocut'],
    use: 'reply video',
    category: 'owner',
    async: async (m, {
        func,
        mecha,
        quoted
    }) => {
        mecha.autocutvideo = mecha.autocutvideo ? mecha.autocutvideo : {};
        if (m.sender in mecha.autocutvideo) return m.reply('Masih ada proses yang sedang dijalankan, silahkan tunggu.');
        if (!quoted || !/video|mp4/.test(quoted.mime)) return m.reply(`Kirim/Reply video dengan caption ${m.cmd}`);
        const seconds = 60;
        const inputVideoPath = await mecha.downloadAndSaveMediaMessage(m);
        const outputVideoPath = path.join(process.cwd(), 'sampah');
        try {
            if (Number(quoted.seconds) > seconds) {
                mecha.autocutvideo[m.sender] = true;
                m.reply('Tunggu sebentar, proses ini memakan waktu cukup lama...')
                // Buat direktori jika belum ada
                const outputDir = './sampah';
                if (!fs.existsSync(outputDir)) {
                    fs.mkdirSync(outputDir, {
                        recursive: true
                    }); // Pastikan direktori dan subdirektorinya ada
                }

                /**
                 * Function to cut video into segments of maximum 1 minute.
                 * @param {string} inputVideoPath - The path to the input video file.
                 * @param {string} outputDirectory - The directory to save the output video segments.
                 */
                async function cutVideo(inputVideoPath, outputDirectory) {
                    console.log('Memulai memotong durasi video');
                    ffmpeg.ffprobe(inputVideoPath, async (err, metadata) => {
                        if (err) {
                            console.error('Error getting video metadata:', err);
                            mecha.reply(m.chat, err.message, m, {
                                expiration: m.expiration
                            })
                            return;
                        }

                        const duration = metadata.format.duration; // Total duration in seconds
                        const segments = Math.ceil(duration / seconds); // Calculate number of segments

                        for (let index = 0; index < segments; index++) {
                            const startTime = index * seconds; // Start time for each segment
                            const outputVideoPath = `${outputDirectory}/segment_${index + 1}.mp4`; // Output file path

                            ffmpeg(inputVideoPath)
                                .setStartTime(startTime) // Start time for the segment
                                .setDuration(Math.min(seconds, duration - startTime)) // Duration for the segment
                                .output(outputVideoPath)
                                .on('end', async () => {
                                    console.log(`Segment ${index + 1} created: ${outputVideoPath}`);
                                    await mecha.sendMessage(m.chat, {
                                        video: {
                                            url: outputVideoPath
                                        },
                                        caption: `Video ${index + 1}`
                                    }, {
                                        quoted: m,
                                        ephemeralExpiration: m.expiration
                                    });
                                })
                                .on('error', (err) => {
                                    console.error('Error cutting video:', err);
                                    mecha.reply(m.chat, err.message, m, {
                                        expiration: m.expiration
                                    })
                                    return;
                                })
                                .run();
                            await new Promise(resolve => setTimeout(resolve, 1000));
                        }
                        mecha.reply(m.chat, 'Successfully cut video', m, {
                            expiration: m.expiration
                        });
                        delete mecha.autocutvideo[m.sender];
                    });
                }

                await cutVideo(inputVideoPath, outputVideoPath);
            } else m.reply(`Durasi video harus lebih dari ${seconds} detik.`);
        } catch (error) {
            console.log(error);
            delete mecha.autocutvideo[m.sender];
            return mecha.reply(m.chat, error.message, m, {
                expiration: m.expiration
            })
        }
    },
    owner: true
}