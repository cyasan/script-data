const toMs = require('ms')

exports.run = {
usage: ['prem+', 'prem-'],
use: '628xxx,7d',
category: 'owner',
async: async (m, { func, mecha }) => {
let [jid, time] = m.text.split(',');
if (!(jid && time)) return m.reply(func.example(m.cmd, '6285194293890,7d'))
jid = jid.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
let users = global.db.users[jid];
if (typeof users == 'undefined') return m.reply('User data not found.')
if (!users.premium) return m.reply('User data not premium.')
if (users.expired.premium === 'PERMANENT') return m.reply('User data premium already PERMANENT')
if (m.command === 'prem+') {
users.expired.premium += toMs(time)
m.reply(`Successfully added premium time *${users.name}* for ${time}`)
} else if (m.command === 'prem-') {
users.expired.premium -= toMs(time)
m.reply(`Successfully reduced premium time *${users.name}* for ${time}`)
}
},
owner: true
}