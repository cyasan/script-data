exports.run = {
    usage: ['addowner', 'delowner', 'listowner'],
    use: 'mention or reply',
    category: 'developer',
    async: async (m, {
        func,
        mecha,
        setting,
        froms
    }) => {
        switch (m.command) {
            case 'addowner':
                if (global.db.owner.length >= 5) return m.reply('Jumlah owner sudah max.')
                if (!froms) return m.reply('Mention or Reply chat target.')
                if (global.db.owner.includes(froms)) return m.reply(`@${froms.split('@')[0]} already in the database.`)
                global.db.owner.push(froms)
                m.reply(`Successfully added @${froms.split('@')[0]} as owner`)
                break
            case 'delowner':
                if (!froms) return m.reply('Mention or Reply chat target.')
                if (!global.db.owner.includes(froms)) return m.reply(`@${froms.split('@')[0]} not in database.`)
                if (froms.includes('62882003321562@s.whatsapp.net')) return;
                global.db.owner.splice(global.db.owner.indexOf(froms), 1)
                m.reply(`Successfully removed @${froms.split('@')[0]} from owner`)
                break
            case 'listowner':
                if (global.db.owner.length == 0) return m.reply('Empty data.')
                let caption = `乂  *L I S T - O W N E R*\n\nTotal : ${global.db.owner.length}\n`
                for (let [index, jid] of global.db.owner.entries()) {
                    caption += `\n${index + 1}. @${jid.split('@')[0]}`
                }
                m.reply(caption)
                break
        }
    },
    devs: true,
    location: 'plugins/developer/setowner.js'
}