exports.run = {
    usage: ['upswgroup'],
    hidden: ['upswgc'],
    use: 'reply media with caption',
    category: 'developer',
    async: async (m, {
        func,
        mecha,
        quoted
    }) => {
        if (/audio|video|image\/(jpe?g|png)/.test(quoted.mime)) {
            let groups = Object.values(await mecha.groupFetchAllParticipating()).filter(v => v.participants.find(v => v.id == mecha.user.jid) && v.announce == false)
            let groupData = groups.map(x => x.id)
            let statusJidList = groups.flatMap(group => group.participants.map(v => v.id));
            const caption = m.text ? '#UP STATUS DARI BOT\n' + m.text : '#UP STATUS DARI BOT'
            const media = await quoted.download();
            mecha.sendReact(m.chat, '⌛', m.key);
            if (/image\/(jpe?g|png)/.test(quoted.mime)) {
                await mecha.sendMessage('status@broadcast', {
                    image: media,
                    caption: caption
                }, {
                    statusJidList: statusJidList
                });
            } else if (/video\/mp4/.test(quoted.mime)) {
                await mecha.sendMessage('status@broadcast', {
                    video: media,
                    caption: caption
                }, {
                    statusJidList: statusJidList
                });
            } else if (/audio/.test(quoted.mime)) {
                await mecha.sendMessage('status@broadcast', {
                    audio: media,
                    ptt: true,
                    mimetype: quoted.mime || 'audio/mpeg',
                }, {
                    statusJidList: statusJidList
                });
            }
            await m.reply(`Berhasil mengirim cerita ke ${statusJidList.length} user di ${groupData.length} group.`)
        } else m.reply('Input media yang ingin dijadikan story.')
    },
    devs: true,
    location: 'plugins/upswgc.js'
}