const axios = require('axios');

async function muslimai(query) {
    const searchUrl = 'https://www.muslimai.io/api/search';
    const searchData = {
        query: query
    };
    const headers = {
        'Content-Type': 'application/json'
    };
    try {
        const searchResponse = await axios.post(searchUrl, searchData, {
            headers: headers
        });
        const passages = searchResponse.data.map(item => item.content).join('\n\n');
        const answerUrl = 'https://www.muslimai.io/api/answer';
        const answerData = {
            prompt: `Gunakan bagian-bagian berikut untuk menjawab pertanyaan tersebut sebaik kemampuan Anda sebagai pakar Al-Quran kelas dunia. Jangan sebutkan bahwa Anda diberi bagian apa pun dalam jawaban Anda: ${query}\n\n${passages}`
        };

        const answerResponse = await axios.post(answerUrl, answerData, {
            headers: headers
        });

        const result = {
            answer: answerResponse.data,
            source: searchResponse.data
        };

        return result;
    } catch (error) {
        return error
        console.error('Error occurred:', error.response ? error.response.data : error.message);
    }
}

exports.run = {
    usage: ['muslim-ai'],
    hidden: ['muslimai'],
    use: 'text',
    category: 'ai',
    async: async (m, {
        func,
        mecha,
        errorMessage
    }) => {
        if (!m.text) return m.reply(func.example(m.cmd, 'hai luminai'));
        mecha.sendReact(m.chat, '⌛', m.key)
        let messageId = 'TANJIRO' + func.makeid(22).toUpperCase() + 'MUSLIMAI'
        try {
            // let response = await func.fetchJson(`https://api.siputzx.my.id/api/ai/muslimai?query=${encodeURI(m.text)}`);
            // if (!response.status) return mecha.sendReact(m.chat, '❌', m.key)
            let response = await muslimai(m.text.trim());
            mecha.sendMessage(m.chat, {
                text: response.answer // response.data
            }, {
                quoted: m,
                ephemeralExpiration: m.expiration,
                messageId: messageId
            });
        } catch (error) {
            mecha.sendReact(m.chat, '❌', m.key)
            return errorMessage(error)
        }
    },
    main: async (m, {
        func,
        mecha,
        users,
        errorMessage
    }) => {
        if (m.budy && m.quoted && m.quoted.fromMe && m.quoted.id.endsWith('MUSLIMAI') && !m.isPrefix) {
            mecha.sendReact(m.chat, '⌛', m.key)
            let messageId = 'TANJIRO' + func.makeid(22).toUpperCase() + 'MUSLIMAI'
            try {
                // let response = await func.fetchJson(`https://api.siputzx.my.id/api/ai/muslimai?query=${encodeURI(m.budy)}`);
                // if (!response.status) return mecha.sendReact(m.chat, '❌', m.key)
                let response = await muslimai(m.budy.trim());
                mecha.sendMessage(m.chat, {
                    text: response.answer // response.data
                }, {
                    quoted: m,
                    ephemeralExpiration: m.expiration,
                    messageId: messageId
                });
                users.limit -= 1;
            } catch (error) {
                mecha.sendReact(m.chat, '❌', m.key)
                return errorMessage(error)
            }
        }
    },
    limit: true,
    location: 'plugins/ai/muslim-ai.js'
}