const axios = require('axios')

async function html2img(html, css) {
try {
let a = await axios.post("https://htmlcsstoimage.com/demo_run", {
html: html,
console_mode: "",
url: "",
css: css ? css : "",
selector: "",
ms_delay: "",
render_when_ready: "false",
viewport_height: "",
viewport_width: "",
google_fonts: "",
device_scale: "",
},
{
headers: {
cookie:
"_hcti_website_session=SFhp%2FC3qpFOizmifGuqCaeHU5CGGm3fe2AOrGjkgLzK5xmme5U87lIrQvaSAsTh%2BIiWePfEjeRS2mQSemfqXDkca4SBEq0VMfidbgOrve6Ijivp8iPzoyVIxsG4wHncopQ5gdPDe45sYPJUZ%2FWoNhiYfNKg6XpTIBTbu4OQ7VmDQ8mxaNMukgYSB2%2FtNim%2BcRoE%2B9woQBO0unxrNYy0oRf3bKQbqhCDVUJ5iRYm4Dd4yIOkj1nNv39VQrcebkAAp9sPPrbsMGguP%2Bp9eiXGqxQPS5ycYlqK%2B2Zz8FU8%3D--MJPaMU59qWTaoEzF--Wjee8Ftq%2B%2FChRFKnsVi2Ow%3D%3D; _ga_JLLLQJL669=GS1.1.1711473771.1.0.1711473771.0.0.0; _ga=GA1.2.535741333.1711473772; _gid=GA1.2.601778978.1711473772; _gat_gtag_UA_32961413_2=1",
"x-csrf-token":
"pO7JhtS8osD491DfzpbVYXzThWKZjPoXXFBi69aJnlFRHIO9UGP7Gj9Y93xItqiCHzisYobEoWqcFqZqGVJsow",
},
},
);
return a.data.url;
} catch {
return null;
}
}

exports.run = {
usage: ['html2img'],
hidden: ['html'],
use: 'code html',
category: 'ai',
async: async (m, { func, mecha }) => {
let text;
if (m.args.length >= 1) {
text = m.args.slice(0).join(" ");
} else if (m.quoted && m.quoted.text) {
text = m.quoted.text;
} else return m.reply('Input or reply code html.')
mecha.sendReact(m.chat, '⌛', m.key)
let result = await html2img(text)
if (result == null) return m.reply('Tetot')
mecha.sendMedia(m.chat, result, m, {
caption: global.mess.ok,
expiration: m.expiration
})
},
premium: true
}