process.on('uncaughtException', console.log);
process.env['NODE_TLS_REJECT_UNAUTHORIZED'] = '0';
require('events').EventEmitter.defaultMaxListeners = 500;
const {
    Baileys,
    InvCloud
} = require('./system/connector.js');
const {
    groupAdd,
    groupRemove
} = new(require('./system/groups'));
const multidb = new(require('./system/multidb.js'))();
const func = require('./system/functions');
const chalk = require('chalk');
const fs = require('fs');
const path = require('path');
const {
    platform
} = require('os');
const {
    Browsers
} = require('@whiskeysockets/baileys');

/* additional config */
require('./config');

/* temporary database */
global.jadibot = {};

const socket = new Baileys({
    pairing: {
        ...global.pairing
    },
    ...global.config
}, {
    browser: Browsers.ubuntu('Chrome')
});

/* starting to connect */
socket.on('connect', async res => {
    /* write connection log */
    if (res && typeof res === 'object' && res.message) func.logFile(res.message, 'connect')
})

/* print error */
socket.on('error', async error => {
    /* write error log */
    console.log(chalk.redBright.bold(error.message))
    if (error && typeof error === 'object' && error.message) func.logFile(error.message, 'connect')
})

/* bot is connected */
socket.on('ready', async (mecha) => {
    /* auto restart if ram usage is over */
    const ramCheck = setInterval(async () => {
        var ramUsage = process.memoryUsage().rss
        if (ramUsage >= (global.max_ram * 1000000000)) {
            clearInterval(ramCheck)
            await multidb.init.save(global.db);
            console.info(`RAM telah mencapai ${global.max_ram} GB, Sistem merestart bot secara otomatis.`)
            process.send('reset');
        }
    }, 60 * 1000)

    /* create temp directory if doesn't exists */
    if (!fs.existsSync('./sampah')) fs.mkdirSync('./sampah');

    /* create jadibot session directory if doesn't exists */
    if (!fs.existsSync('./jadibot')) fs.mkdirSync('./jadibot');

    /* additional events */
    require('./system/events.js')(mecha);

    /* clear temp folder every 10 minutes */
    setInterval(async () => {
        try {
            const tmpFiles = fs.readdirSync('./sampah')
            if (tmpFiles.length > 10) {
                tmpFiles.filter(item => !item.endsWith('.file')).map(item => fs.unlinkSync('./sampah/' + item))
            }

            /* this source from @jarspay */
            const TIME = 1000 * 60 * 60
            const filename = []
            const files = await fs.readdirSync('./session')
            for (const file of files) {
                if (file != 'creds.json') filename.push(path.join('./session', file))
            }

            if (global.db.setting[mecha.user.jid].autoclearsession) await Promise.allSettled(filename.map(async (file) => {
                const stat = await fs.statSync(file)
                if (stat.isFile() && (Date.now() - stat.mtimeMs >= TIME)) {
                    if (platform() === 'win32') {
                        let fileHandle
                        try {
                            fileHandle = await fs.openSync(file, 'r+')
                        } catch (e) {} finally {
                            await fileHandle.close()
                        }
                    }
                    console.log('Delete session: ' + file);
                    await fs.unlinkSync(file);
                }
            }))
        } catch {}
    }, 60 * 1000 * 10)

    /* save database every 30 seconds */
    setInterval(async () => {
        if (global.db) await multidb.init.save(global.db);
    }, 30_000)

    for (let x of global.db.jadibot) {
        if (x.status && global.db.users[x.number] && global.db.users[x.number].jadibot && fs.existsSync(`${x.session}/creds.json`) && typeof global.jadibot[x.number] == 'undefined') await require('./system/jadibot.js').Jadibot(mecha, x.number);
    }

})

/* print all message object */
socket.on('message', async extra => {
    const {
        m,
        store
    } = extra;
    require('./handler')(socket.mecha, extra);
    if (global.db.setting[m.bot].autoread && m.chat === 'status@broadcast') {
        if (m.message?.protocolMessage) return;
        await socket.mecha.readMessages([m.key])
        if (m.broadcast) {
            if (!fs.existsSync('./database/story.json')) fs.writeFileSync('./database/story.json', JSON.stringify([], null, 2))
            let story = JSON.parse(fs.readFileSync('./database/story.json'));
            story.push({
                mtype: m.mtype,
                pushname: m.pushname,
                sender: m.sender,
                caption: m.budy,
                msg: {
                    key: m.key,
                    message: m.message
                }
            })
            fs.writeFileSync('./database/story.json', JSON.stringify(story, null, 2))
        }
    };
})

/* print deleted message object */
socket.on('message.delete', extra => {
    const {
        origin,
        delete: messages
    } = extra;
    const mecha = socket.mecha;
    if (!messages || !origin || origin.fromMe || origin.isBot || !origin.sender) return
    if (Object.keys(messages.message) < 1) return;
    if (origin.isGc && global.db.groups[origin.chat] && global.db.groups[origin.chat].antidelete) return mecha.copyNForward(origin.chat, messages, false, {
        quoted: messages,
        ephemeralExpiration: origin.expiration || 86400
    })
})

/* AFK detector */
//socket.on('presence.update', extra => console.log(extra))

/* Anti Call Auto Reject */
socket.on('caller', extra => {
    require('./system/anticall')(socket.mecha, extra)
})

socket.on('group.add', async extra => groupAdd(socket.mecha, extra))
socket.on('group.remove', extra => groupRemove(socket.mecha, extra))
//socket.on('group.promote', extra => console.log(extra))
//socket.on('group.demote', extra => console.log(extra))