const fs = require('fs');
const fetch = require('node-fetch');
const path = require('path');
const {
    proto,
    prepareWAMessageMedia,
    generateWAMessageContent,
    generateWAMessageFromContent
} = require('@whiskeysockets/baileys');

const styles = (text) => {
    var xStr = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', '1', '2', '3', '4', '5', '6', '7', '8', '9', '0'];
    var yStr = ['α', '𝖻', '𝖼', '𝖽', 'ᧉ', '𝖿', '𝗀', '𝗁', 'ꪱ', '𝗃', '𝗄', '𝗅', '𝗆', '𝗇', '𝗈', '𝗉', '𝗊', '𝗋', '𝗌', '𝗍', '𝗎', '𝗏', 'ѡ', '𝗑', 'ⴗ', '𝗓', '1', '2', '3', '4', '5', '6', '7', '8', '9', '0'];
    var replacer = []
    xStr.map((v, i) => replacer.push({
        original: v,
        convert: yStr[i]
    }))
    var str = text.toLowerCase().split('')
    var output = []
    str.map(v => {
        const find = replacer.find(x => x.original == v)
        find ? output.push(find.convert) : output.push(v)
    })
    return output.join('')
}

exports.run = {
    usage: ['menu'],
    hidden: ['allmenu'],
    async: async (m, {
        func,
        mecha,
        plugins,
        setting,
        users,
        calender,
        fkon
    }) => {
        if (m.text && !Object.values(plugins).some(v => v.run.usage && v.run.category === m.text.trim().toLowerCase())) {
            return m.reply(`😕 Maaf, menu *${m.text.trim()}* tidak tersedia. Coba periksa daftar menu yang ada atau ketik *${m.prefix}menu* untuk melihat semua fitur yang tersedia!`);
        }
        await mecha.sendReact(m.chat, '🕒', m.key)
        try {
            const sizedb = fs.statSync('./database/database.json').size;
            const packages = JSON.parse(fs.readFileSync('./package.json', 'utf-8'));
            const library = packages.dependencies['@adiwajshing/baileys'] ? '@adiwajshing/baileys@^' + require('@adiwajshing/baileys/package.json').version : packages.dependencies['@whiskeysockets/baileys'] ? '@whiskeysockets/baileys@^' + require('@whiskeysockets/baileys/package.json').version : 'baileys'
            const version = `${packages.name} v${packages.version}`
            const hit_today = func.formatNumber(Object.entries(global.db.statistic).map((v) => v[1].hittoday).reduce((a, b) => a + b))
            const total_hit = func.formatNumber(Object.entries(global.db.statistic).map((v) => v[1].hit).reduce((a, b) => a + b))
            const typedb = /mongo/.test(global.mongoUrl) ? 'MongoDB' : `Local (${sizedb.sizeString()})`
            const style = setting.style
            const message = `Hi ${m.pushname?.replaceAll('\n', '')} 👋🏻
Saya adalah sebuah sistem otomatis (WhatsApp Bot) yang dapat membantu untuk melakukan sesuatu, mencari dan mendapatkan data/informasi hanya melalui WhatsApp.

◦ *Database* : ${typedb}
◦ *Library* : ${library}
◦ *Version* : ${version}
◦ *Hit Today* : ${hit_today}
◦ *Total Hit* : ${total_hit}
◦ *Total Feature* : ${func.totalFeature(plugins)}

Jika Anda menemukan kesalahan atau ingin meningkatkan paket premium, hubungi owner.`
            if (style === 1 || /^allmenu$/.test(m.command)) {
                let filter = Object.entries(plugins).filter(([_, obj]) => obj.run.usage)
                let cmd = Object.fromEntries(filter)
                let category = []
                for (let name in cmd) {
                    let obj = cmd[name].run
                    if (!cmd) continue
                    if (!obj.category) continue
                    if (Object.keys(category).includes(obj.category)) category[obj.category].push(obj)
                    else {
                        category[obj.category] = []
                        category[obj.category].push(obj)
                    }
                }
                const keys = Object.keys(category).sort()
                let caption = message
                for (let k of keys) {
                    caption += '\n\n乂  *' + k.toUpperCase().split('').map(v => v).join(' ') + '*\n\n'
                    let cmd = Object.entries(plugins).filter(([_, v]) => v.run.usage && v.run.category == k.toLowerCase())
                    let usage = Object.keys(Object.fromEntries(cmd))
                    if (usage.length == 0) return
                    let commands = []
                    cmd.map(([_, v]) => {
                        switch (v.run.usage.constructor.name) {
                            case 'Array':
                                v.run.usage.map(x => commands.push({
                                    usage: x,
                                    use: v.run.use ? func.texted('bold', v.run.use) : '',
                                    info: v.run.premium ? '🅟' : v.run.limit ? '🅛︎' : ''
                                }))
                                break
                            case 'String':
                                commands.push({
                                    usage: v.run.usage,
                                    use: v.run.use ? func.texted('bold', v.run.use) : '',
                                    info: v.run.premium ? '🅟' : v.run.limit ? '🅛︎' : ''
                                })
                        }
                    })
                    caption += commands.sort((a, b) => a.usage.localeCompare(b.usage)).map(v => `	◦  ${m.prefix + v.usage} ${v.use} ${v.info}`).join('\n')
                }
                mecha.sendMessageModify(m.chat, styles(caption) + '\n\n' + global.footer, m, {
                    title: global.header,
                    body: global.footer,
                    thumbnail: await (await fetch(setting.cover)).buffer(),
                    thumbUrl: setting.cover,
                    largeThumb: true,
                    url: setting.link,
                    expiration: m.expiration
                })
            } else if (style === 2) {
                let filter = Object.entries(plugins).filter(([_, obj]) => obj.run.usage)
                let cmd = Object.fromEntries(filter)
                let category = []
                for (let name in cmd) {
                    let obj = cmd[name].run
                    if (!cmd) continue
                    if (!obj.category) continue
                    if (Object.keys(category).includes(obj.category)) category[obj.category].push(obj)
                    else {
                        category[obj.category] = []
                        category[obj.category].push(obj)
                    }
                }
                const keys = Object.keys(category).sort()
                let caption = message
                for (let k of keys) {
                    caption += '\n\n –  *' + k.toUpperCase().split('').map(v => v).join(' ') + '*\n\n'
                    let cmd = Object.entries(plugins).filter(([_, v]) => v.run.usage && v.run.category == k.toLowerCase())
                    let usage = Object.keys(Object.fromEntries(cmd))
                    if (usage.length == 0) return
                    let commands = []
                    cmd.map(([_, v]) => {
                        switch (v.run.usage.constructor.name) {
                            case 'Array':
                                v.run.usage.map(x => commands.push({
                                    usage: x,
                                    use: v.run.use ? func.texted('bold', v.run.use) : '',
                                    info: v.run.premium ? '🅟' : v.run.limit ? '🅛︎' : ''
                                }))
                                break
                            case 'String':
                                commands.push({
                                    usage: v.run.usage,
                                    use: v.run.use ? func.texted('bold', v.run.use) : '',
                                    info: v.run.premium ? '🅟' : v.run.limit ? '🅛︎' : ''
                                })
                        }
                    })
                    caption += commands.sort((a, b) => a.usage.localeCompare(b.usage)).map((v, i) => {
                        if (i == 0) {
                            return `┌  ◦  ${m.prefix + v.usage} ${v.use} ${v.info}`
                        } else if (i == commands.sort((a, b) => a.usage.localeCompare(b.usage)).length - 1) {
                            return `└  ◦  ${m.prefix + v.usage} ${v.use} ${v.info}`
                        } else {
                            return `│  ◦  ${m.prefix + v.usage} ${v.use} ${v.info}`
                        }
                    }).join('\n')
                }
                mecha.sendMessageModify(m.chat, styles(caption) + '\n\n' + global.footer, m, {
                    title: global.header,
                    body: global.footer,
                    thumbnail: await (await fetch(setting.cover)).buffer(),
                    thumbUrl: setting.cover,
                    largeThumb: true,
                    url: setting.link,
                    expiration: m.expiration
                })
            } else if (style === 3) {
                let filter = Object.entries(plugins).filter(([_, obj]) => obj.run.usage)
                let cmd = Object.fromEntries(filter)
                let category = []
                for (let name in cmd) {
                    let obj = cmd[name].run
                    if (!cmd) continue
                    if (!obj.category) continue
                    if (Object.keys(category).includes(obj.category)) category[obj.category].push(obj)
                    else {
                        category[obj.category] = []
                        category[obj.category].push(obj)
                    }
                }
                const keys = Object.keys(category).sort()
                let caption = message
                for (let k of keys) {
                    caption += '\n\n –  *' + k.toUpperCase().split('').map(v => v).join(' ') + '*\n\n'
                    let cmd = Object.entries(plugins).filter(([_, v]) => v.run.usage && v.run.category == k.toLowerCase())
                    let usage = Object.keys(Object.fromEntries(cmd))
                    if (usage.length == 0) return
                    let commands = []
                    cmd.map(([_, v]) => {
                        switch (v.run.usage.constructor.name) {
                            case 'Array':
                                v.run.usage.map(x => commands.push({
                                    usage: x,
                                    use: v.run.use ? func.texted('bold', v.run.use) : '',
                                    info: v.run.premium ? '🅟' : v.run.limit ? '🅛︎' : ''
                                }))
                                break
                            case 'String':
                                commands.push({
                                    usage: v.run.usage,
                                    use: v.run.use ? func.texted('bold', v.run.use) : '',
                                    info: v.run.premium ? '🅟' : v.run.limit ? '🅛︎' : ''
                                })
                        }
                    })
                    caption += commands.sort((a, b) => a.usage.localeCompare(b.usage)).map((v, i) => {
                        if (i == 0) {
                            return `┌  ◦  ${m.prefix + v.usage} ${v.use} ${v.info}`
                        } else if (i == commands.sort((a, b) => a.usage.localeCompare(b.usage)).length - 1) {
                            return `└  ◦  ${m.prefix + v.usage} ${v.use} ${v.info}`
                        } else {
                            return `│  ◦  ${m.prefix + v.usage} ${v.use} ${v.info}`
                        }
                    }).join('\n')
                }
                mecha.sendMessageModify(m.chat, caption + '\n\n' + global.footer, m, {
                    title: global.header,
                    body: global.footer,
                    thumbnail: await (await fetch(setting.cover)).buffer(),
                    thumbUrl: setting.cover,
                    largeThumb: true,
                    url: setting.link,
                    expiration: m.expiration
                })
            } else if (style === 4) {
                if (m.text) {
                    let cmd = Object.entries(plugins).filter(([_, v]) => v.run.usage && v.run.category == m.text.trim().toLowerCase())
                    let usage = Object.keys(Object.fromEntries(cmd))
                    if (usage.length == 0) return
                    let commands = []
                    cmd.map(([_, v]) => {
                        switch (v.run.usage.constructor.name) {
                            case 'Array':
                                v.run.usage.map(x => commands.push({
                                    usage: x,
                                    use: v.run.use ? func.texted('bold', v.run.use) : '',
                                    info: v.run.premium ? '🅟' : v.run.limit ? '🅛︎' : ''
                                }))
                                break
                            case 'String':
                                commands.push({
                                    usage: v.run.usage,
                                    use: v.run.use ? func.texted('bold', v.run.use) : '',
                                    info: v.run.premium ? '🅟' : v.run.limit ? '🅛︎' : ''
                                })
                        }
                    })
                    let caption = commands.sort((a, b) => a.usage.localeCompare(b.usage)).map((v, i) => {
                        if (i == 0) {
                            return `┌  ◦  ${m.prefix + v.usage} ${v.use} ${v.info}`
                        } else if (i == commands.sort((a, b) => a.usage.localeCompare(b.usage)).length - 1) {
                            return `└  ◦  ${m.prefix + v.usage} ${v.use} ${v.info}`
                        } else {
                            return `│  ◦  ${m.prefix + v.usage} ${v.use} ${v.info}`
                        }
                    }).join('\n')
                    m.reply(caption)
                } else {
                    let caption = message
                    caption += '\n' + String.fromCharCode(8206).repeat(4001) + '\n'
                    let filter = Object.entries(plugins).filter(([_, obj]) => obj.run.usage)
                    let cmd = Object.fromEntries(filter)
                    let category = []
                    for (let name in cmd) {
                        let obj = cmd[name].run
                        if (!cmd) continue
                        if (!obj.category) continue
                        if (Object.keys(category).includes(obj.category)) category[obj.category].push(obj)
                        else {
                            category[obj.category] = []
                            category[obj.category].push(obj)
                        }
                    }
                    const keys = Object.keys(category).sort()
                    caption += keys.sort((a, b) => a.localeCompare(b)).map((v, i) => {
                        if (i == 0) {
                            return `┌  ◦  ${m.cmd} ${v}`
                        } else if (i == keys.sort((a, b) => a.localeCompare(b)).length - 1) {
                            return `└  ◦  ${m.cmd} ${v}`
                        } else {
                            return `│  ◦  ${m.cmd} ${v}`
                        }
                    }).join('\n')
                    mecha.sendMessageModify(m.chat, caption + '\n\n' + global.footer, m, {
                        title: global.header,
                        body: global.footer,
                        thumbnail: await (await fetch(setting.cover)).buffer(),
                        thumbUrl: setting.cover,
                        largeThumb: true,
                        url: setting.link,
                        expiration: m.expiration
                    })
                }
            } else if (style === 5) {
                if (m.text) {
                    let cmd = Object.entries(plugins).filter(([_, v]) => v.run.usage && v.run.category == m.text.trim().toLowerCase())
                    let usage = Object.keys(Object.fromEntries(cmd))
                    if (usage.length == 0) return
                    let commands = []
                    cmd.map(([_, v]) => {
                        switch (v.run.usage.constructor.name) {
                            case 'Array':
                                v.run.usage.map(x => commands.push({
                                    usage: x,
                                    use: v.run.use ? func.texted('bold', v.run.use) : '',
                                    info: v.run.premium ? '🅟' : v.run.limit ? '🅛︎' : ''
                                }))
                                break
                            case 'String':
                                commands.push({
                                    usage: v.run.usage,
                                    use: v.run.use ? func.texted('bold', v.run.use) : '',
                                    info: v.run.premium ? '🅟' : v.run.limit ? '🅛︎' : ''
                                })
                        }
                    })
                    let caption = commands.sort((a, b) => a.usage.localeCompare(b.usage)).map((v, i) => {
                        if (i == 0) {
                            return `┌  ◦  ${m.prefix + v.usage} ${v.use} ${v.info}`
                        } else if (i == commands.sort((a, b) => a.usage.localeCompare(b.usage)).length - 1) {
                            return `└  ◦  ${m.prefix + v.usage} ${v.use} ${v.info}`
                        } else {
                            return `│  ◦  ${m.prefix + v.usage} ${v.use} ${v.info}`
                        }
                    }).join('\n')
                    m.reply(styles(caption))
                } else {
                    let caption = message
                    let filter = Object.entries(plugins).filter(([_, obj]) => obj.run.usage)
                    let cmd = Object.fromEntries(filter)
                    let category = []
                    for (let name in cmd) {
                        let obj = cmd[name].run
                        if (!cmd) continue
                        if (!obj.category) continue
                        if (Object.keys(category).includes(obj.category)) category[obj.category].push(obj)
                        else {
                            category[obj.category] = []
                            category[obj.category].push(obj)
                        }
                    }
                    const keys = Object.keys(category).sort();
                    let sections = [];
                    const label = {
                        highlight_label: 'Populer Feature'
                    }
                    keys.sort((a, b) => a.localeCompare(b)).map((v, i) => sections.push({
                        ...(/downloader|convert|games|ai/.test(v) ? label : {}),
                        rows: [{
                            title: `${func.ucword(v)} Feature`,
                            description: `There are ${func.arrayJoin(Object.entries(plugins).filter(([_, x]) => x.run.usage && x.run.category == v.trim().toLowerCase()).map(([_, x]) => x.run.usage)).length} commands`,
                            id: `${m.cmd} ${v}`
                        }]
                    }))
                    sections.push({
                        highlight_label: 'Displays All Features',
                        rows: [{
                            title: 'All Feature',
                            description: `There are ${func.totalFeature(plugins)} commands`,
                            id: `${m.prefix}allmenu`
                        }]
                    })

                    let buttons = [
                        ['list', 'List Menu', sections],
                        ['url', 'saluran', 'https://chat.whatsapp.com/DOEHoU9KRLG7wo13C2TdXD'],
                        ['button', 'owner', `${m.prefix}owner`],
                    ]

                    mecha.sendButton(m.chat, '', caption, global.footer, buttons, m, {
                        media: setting.cover,
                        expiration: m.expiration
                    })
                }
            }
        } catch (error) {
            mecha.reply(m.chat, error.message, m, {
                expiration: m.expiration
            })
        }
    },
    restrict: true
}