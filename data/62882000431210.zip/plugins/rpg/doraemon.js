const fetch = require('node-fetch');

exports.run = {
    usage: ['doraemon'],
    category: 'rpg',
    register: true,
    async: async (m, { func, mecha }) => {
        try {
            let user = global.db.users[m.sender];
            user.lastDoraemon = user.lastDoraemon || 0;
            let now = new Date() * 1;
            let timeSinceLastAction = now - user.lastDoraemon;

            // Cooldown: 10 minutes
            if (timeSinceLastAction < 600000) {
                return m.reply(`*Anda harus menunggu ${Math.ceil((600000 - timeSinceLastAction) / 60000)} menit sebelum bermain lagi!*`);
            }

            let action = Math.random();
            let itemFound = '';
            let reward = 0;

            // Randomly decide the outcome
            if (action < 0.3) {
                itemFound = 'Pasta Waktu';
                reward = 2000000; // Money
            } else if (action < 0.6) {
                itemFound = 'Senter Tembus Pandang';
                reward = 1500000; // Money
            } else if (action < 0.9) {
                itemFound = 'Doraemon';
                reward = 1000000; // Money
            } else {
                return m.reply(`*Sayang sekali! Anda tidak menemukan apa pun di petualangan ini.*`);
            }

            user.money += reward; // Add reward to user's money
            user.lastDoraemon = now; // Update the last action time

            m.reply(`🎉 *Selamat!* Anda menemukan ${itemFound} dan mendapatkan Rp ${reward} 💰!`);
        } catch (e) {
            console.error(e);
            m.reply(`Terjadi kesalahan, coba lagi nanti.`);
        }
    }
}