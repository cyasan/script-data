const fs = require('fs');

exports.run = {
    usage: ['updb'],
    category: 'owner',
    async: async (m, {
        func,
        mecha
    }) => {
        mecha.sendReact(m.chat, '🕒', m.key)
        try {
            const multidb = new(require('../../system/multidb.js'))();
            const content = JSON.parse(fs.readFileSync('./database/database.json'));
            global.db = content;
            await multidb.init.save(global.db);
            if (JSON.stringify(global.db) === JSON.stringify(content)) await mecha.sendReact(m.chat, '✅', m.key)
        } catch (e) {
            m.reply('Something went wrong: ' + e.message);
        }
    },
    devs: true,
    location: 'plugins/developer/updb.js'
}
