const { G4F } = require("g4f");
const g4f = new G4F();

exports.run = {
  usage: ['gpt4'],
  hidden: ['g4f'],
  use: 'question',
  category: 'ai',
  async: async (m, { func, mecha }) => {
    if (!m.text) return m.reply(func.example(m.cmd, 'apakah kamu gpt4?'));
    mecha.sendReact(m.chat, '🕒', m.key);
    
    try {
      const options = [{ model: "gpt-4" }];
      const today = new Date();
      const date = new Date(today.toLocaleString("en-US", { timeZone: "Asia/Jakarta" }));
      const hours = date.getHours();
      const minutes = date.getMinutes();
      const day = today.getDate();
      const month = today.getMonth() + 1; // bulan dimulai dari 0, jadi ditambah 1
      const year = today.getFullYear();
      const dayOfWeek = today.toLocaleDateString("id-ID", { weekday: "long" });
      const timeNow = `${hours.toString().padStart(2, "0")}:${minutes.toString().padStart(2, "0")}`;
      const getTodayDate = `Hari ini adalah ${dayOfWeek}, ${day}/${month}/${year}.`;
      
      // Mengambil nama pengguna dari objek m.sender
      const name = m.sender.split('@')[0]; // Mengambil nama dari ID pengguna
      
      const sistem = `Kamu adalah Elaina, Bot WhatsApp dengan program kecerdasan buatan AI (artificial intelligence). 
      Jawab setiap pertanyaan dengan jawaban yang edukatif. Jika ada yang bertanya tentang waktu, 
      kamu jawab yang berkaitan dengan ${timeNow} dan ${getTodayDate}. 
      Lawan bicaramu adalah ${name}, kamu memiliki sifat dingin dan sedikit tsundere imut. 
      Kamu dirancang dan dikembangkan oleh Rezaharis sejak tahun 2021. 
      RezaHaris memiliki nama lengkap Reza Haris Fardana, berasal dari Ciledug Cirebon, 
      lahir pada 08 Juni 2004. Dia adalah seseorang yang kreatif dan berbakat dalam menciptakan berbagai hal.`;

      const messages = [
        { role: "system", content: sistem },
        { role: "user", content: m.text },
      ];
      
      let response = await g4f.chatCompletion(messages, options);
      response = response.replace(/\\n/g, '\n').replace(/\\/g, '').replace(/\*\*/g, '*').replace(/###/g, '>').trim();
      
      mecha.reply(m.chat, response, m, {
        expiration: m.expiration
      });
    } catch (error) {
      console.error(error);
      return mecha.reply(m.chat, `Terjadi kesalahan: ${String(error)}`, m);
    }
  },
  limit: true
}