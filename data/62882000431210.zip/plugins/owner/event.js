exports.run = {
    usage: ['eventpc', 'eventgc', 'eventsewa'],
    use: 'text or reply media',
    category: 'owner',
    async: async (m, {
        func,
        mecha,
        setting,
        quoted
    }) => {
        mecha.quizset = mecha.quizset ? mecha.quizset : [];
        if (!m.isOwner) return m.reply(global.mess.owner);
        try {
            const chatJid = Object.values(global.db.users).filter(item => item.register && !item.banned).map(item => item.jid);
            const groupList = Object.values(await mecha.groupFetchAllParticipating()).filter(item => item.participants.find(item => item.id == mecha.user.jid) && item.announce == false);
            const sewaList = Object.values(global.db.groups).filter(item => item.sewa.status && item.sewa.expired && item.sewa.expired != 0 && !isNaN(item.sewa.expired)).map(item => item.jid);
            const groupJid = groupList.map(item => item.id);
            const sewaJid = groupJid.filter(groupId => sewaList.includes(groupId));
            let mentions = [];
            groupList.map(({
                participants
            }) => participants.map(item => item.id)).map(jid => mentions.push(...jid));
            const chat = m.command == 'eventpc' ? chatJid : m.command == 'eventgc' ? groupJid : sewaJid;
            if (chat.length == 0) return m.reply('Error, ID does not exist.')
            if (!m.text) return m.reply(explain(m.cmd))
            let [question, answer, slot, rKey1, rVal1, rKey2, rVal2] = m.text.split('|')
            const rewardKey = Object.freeze({
                1: 'PREMIUM',
                2: 'BALANCE',
                3: 'LIMIT',
                4: 'RANDOM_BALANCE',
                5: 'RANDOM_LIMIT'
            })
            if (!question) return m.reply('Event should have questions.')
            if (!answer) return m.reply('Event should have an answer.')
            if (!slot) return m.reply('Give the number of respondents.')
            if (slot && isNaN(slot)) return m.reply('The number of respondents must be in numeric form.')
            mecha.sendReact(m.chat, '🕒', m.key)
            const id = func.makeid(15);
            const {
                dateNow,
                timeNow
            } = timeZone();
            const timer = 60 * 1000 * 10;
            let catbox;
            if (/video|image\/(jpe?g|png)/.test(quoted.mime)) {
                const media = await quoted.download();
                catbox = await func.catbox(media);
                if (!catbox.status) return m.reply(catbox.message || global.mess.error.api);
            }
            mecha.quizset.push({
                id: id,
                status: true,
                question: question.trim(),
                answer: answer.trim().toLowerCase(),
                reward_key_1: Number(rKey1 || 4),
                reward_value_1: Number(rVal1 || 1),
                reward_key_2: Number(rKey2 || 4),
                reward_value_2: Number(rVal2 || 1),
                slot: Number(slot),
                correct: [],
                respondents: [],
                keyId: [],
                created_at: Date.now(),
                datenow: dateNow,
                timenow: timeNow,
                timer: timer,
                isImage: catbox ? true : false,
                url: catbox ? catbox.url : setting.cover,
                timeout: setTimeout(async function() {
                    let index = mecha.quizset.findIndex(item => item.id === id);
                    if (mecha.quizset[index].keyId.length > 0) {
                        for (let key of mecha.quizset[index].keyId) {
                            await mecha.sendMessage(key.remoteJid, {
                                delete: {
                                    remoteJid: key.remoteJid,
                                    id: key.id,
                                    fromMe: key.fromMe,
                                    participant: m.bot
                                }
                            })
                            await new Promise(resolve => setTimeout(resolve, 2000));
                        }
                    }
                    if (index !== -1) {
                        mecha.quizset.splice(index, 1);
                    }
                }, timer)
            })
            let caption = `乂  *E V E N T - G I F T🎁*\n\n`
            caption += `Event gift edisi ${dateNow} (${timeNow}) WIB\n\n`
            caption += `Question : *${question.trim()}*\n`
            caption += `Slot : *${slot.trim()}*\n`
            caption += `Expired : *${((timer / 1000) / 60)} menit*\n`
            caption += `- reply pesan broadcast ini dengan jawaban yang benar.\n\n`
            caption += `#ID-${id}`
            for (let jid of chat) {
                let {
                    key
                } = await mecha.sendMessage(jid, {
                    ...(catbox ? {
                        image: {
                            url: catbox ? catbox.url : setting.cover
                        },
                        caption: caption,
                    } : {
                        text: caption
                    }),
                    mentions: /eventgc|eventsewa/.test(m.command) ? mentions : []
                }, {
                    quoted: null,
                    ephemeralExpiration: m.expiration
                })
                let quizset = mecha.quizset.find(item => item.id == id);
                quizset.keyId.push(key);
                await new Promise(resolve => setTimeout(resolve, 5000));
            }
            mecha.reply(m.chat, `Successfully send broadcast message to ${chat.length} ${m.command == 'eventpc' ? 'chats' : 'groups'}`, m)
        } catch (error) {
            return mecha.reply(m.chat, error.message, m, {
                expiration: m.expiration
            })
        }
    },
    main: async (m, {
        func,
        mecha,
        users,
        setting,
        packname,
        author
    }) => {
        mecha.quizset = mecha.quizset ? mecha.quizset : [];
        try {
            if (m.budy && m.quoted && m.quoted.fromMe && m.quoted.text && /[#]ID/.test(m.quoted.text)) {
                const id = (m.quoted.text.split('#ID-')[1]).trim();
                let quizset = mecha.quizset.find(item => item.id == id)
                if (!quizset) return
                if (!quizset.status || quizset.correct.length == quizset.slot || (new Date() - quizset.created_at > setting.timer)) return mecha.reply(m.chat, `${func.texted('italic', `❌ Event telah selesai silahkan tunggu edisi *Event gift* di lain kesempatan.`)}\n\n${quizset.correct.map(jid => `- @${jid.split('@')[0]}`).join('\n')}\n\n^ Ke-${quizset.correct.length} orang diatas adalah mereka yang mendapatkan hadiah event edisi saat ini.`, m, {
                    expiration: m.expiration
                }).then(_ => quizset.status = false)
                if (/^(qzclue|clue)$/i.test(m.budy)) return m.reply('Clue : ' + func.texted('monospace', quizset.answer.replace(/[bcdfghjklmnpqrstvwxyz]/g, '-')))
                if (quizset.respondents.includes(m.sender)) return m.reply(`Maaf kamu hanya bisa menjawab 1 kali saja jika code yang kamu masukan salah kesempatan kamu akan *hangus*.`)
                quizset.respondents.push(m.sender)
                if (quizset.answer != m.budy.toLowerCase()) return mecha.sendMessage(m.chat, {
                    sticker: {
                        url: 'https://files.catbox.moe/mxuqjf.webp'
                    }
                }, {
                    quoted: m,
                    ephemeralExpiration: m.expiration
                })
                quizset.correct.push(m.sender);
                let hadiah = '';
                let rewards = [
                    { key: quizset.reward_key_1, value: quizset.reward_value_1 },
                    { key: quizset.reward_key_2, value: quizset.reward_value_2 }
                ];

                for (let reward of rewards) {
                    if (reward.key == 1) {
                        const value = reward.value || 1;
                        const expired = 86400000 * parseInt(value);
                        if (users.premium) {
                            users.limit += 10;
                            users.premium = true;
                            users.expired.premium += expired;
                        } else {
                            users.limit += 10;
                            users.premium = true;
                            users.expired.premium = Date.now() + expired;
                        }
                        hadiah += `✅ selamat kamu mendapatkan reward akses premium untuk ${value} hari.\n`;
                    } else if (reward.key == 2) {
                        const value = (reward.value * 1000) || 5000;
                        users.balance += value;
                        hadiah += `✅ selamat kamu mendapatkan reward balance sebanyak ${func.rupiah(value)}.\n`;
                    } else if (reward.key == 3) {
                        const value = reward.value || 10
                        users.limit += value
                        hadiah += `✅ selamat kamu mendapatkan reward limit sebanyak ${func.rupiah(value)}.\n`;
                    } else if (reward.key == 4) {
                        const value = func.ranNumb(1, 10000)
                        users.balance += value
                        hadiah += `✅ selamat kamu mendapatkan reward balance sebanyak ${func.rupiah(value)}.\n`;
                    } else if (reward.key == 5) {
                        const value = func.ranNumb(1, 15)
                        users.limit += value
                        hadiah += `✅ selamat kamu mendapatkan reward limit sebanyak ${func.rupiah(value)}.\n`;
                    }
                }

                mecha.sendReact(m.chat, '🎉', m.key);
                if (quizset.correct.length >= quizset.slot) {
                    quizset.status = false;
                    return await mecha.reply(m.chat, `Event Gift edisi ${quizset.datenow} (${quizset.timenow}) WIB telah selesai.\n${quizset.correct.map(jid => `- @${jid.split('@')[0]}`).join('\n')}\n\n^ Ke-${quizset.correct.length} orang diatas adalah mereka yang mendapatkan hadiah event edisi saat ini.`, null, {
                        expiration: m.expiration
                    })
                }
                mecha.reply(m.chat, func.texted('bold', hadiah), m, {
                    expiration: m.expiration
                }).then(async () => {
                    let caption = `乂  *E V E N T - G I F T🎁*\n\n`
                    caption += `Event Gift edisi ${quizset.datenow} (${quizset.timenow}) WIB\n\n`
                    caption += `Question : *${quizset.question.trim()}*\n`
                    caption += `Slot : *${quizset.slot - quizset.correct.length}*\n`
                    caption += `Timeout : *${((quizset.timer / 1000) / 60)} menit*\n`
                    caption += `- reply pesan broadcast ini dengan jawaban yang benar.\n\n`
                    caption += `#ID-${quizset.id}`
                    let {
                        key
                    } = await mecha.sendMessage(m.chat, {
                        ...(quizset.isImage ? {
                            image: {
                                url: quizset.url
                            },
                            caption: caption,
                        } : {
                            text: caption
                        }),
                    }, {
                        quoted: null,
                        ephemeralExpiration: m.expiration
                    });
                    quizset.keyId.push(key);
                })
            }
        } catch (error) {
            return mecha.reply(m.chat, error.message, m, {
                expiration: m.expiration
            })
        }
    }
}

const explain = (command) => {
    return `乂  *R K E Y*

1: 'PREMIUM'
2: 'BALANCE'
3: 'LIMIT' 
4: 'RANDOM_BALANCE'
5: 'RANDOM_LIMIT'

Format : ${command} question | answer | slot | rKey1 | rValue1 | rKey2 | rValue2`
}

function timeZone() {
    const today = new Date();
    const date = new Date(today.toLocaleString('en-US', {
        timeZone: 'Asia/Jakarta'
    }));
    const hours = date.getHours();
    const minutes = date.getMinutes();
    const day = today.getDate();
    const month = today.getMonth() + 1;
    const year = today.getFullYear();
    const dateNow = `${day}/${month}/${year}`
    const timeNow = `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}`;
    return {
        dateNow,
        timeNow
    }
}