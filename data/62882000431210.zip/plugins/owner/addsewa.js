const toMs = require('ms')
const {
    getBinaryNodeChild
} = require('@whiskeysockets/baileys');

exports.run = {
    usage: ['addsewa', 'delsewa'],
    use: 'parameter',
    category: 'owner',
    async: async (m, {
        func,
        mecha,
        errorMessage
    }) => {
        async function getGroupIdWithGroupLink(url) {
            try {
                const regex = /chat.whatsapp.com\/([0-9A-Za-z]{20,24})/i
                const [_, code] = url.match(regex) || [];
                if (!code) return {
                    status: false,
                    message: 'No invite url detected.'
                };
                const response = await mecha.query({
                    tag: 'iq',
                    attrs: {
                        type: 'get',
                        xmlns: 'w:g2',
                        to: '@g.us'
                    },
                    content: [{
                        tag: 'invite',
                        attrs: {
                            code: code
                        }
                    }]
                })
                const group = getBinaryNodeChild(response, 'group');
                const groupId = group?.attrs?.id.includes('@') ? group?.attrs?.id : group?.attrs?.id + '@g.us';
                return {
                    status: true,
                    code,
                    groupId
                }
            } catch (error) {
                return {
                    status: false,
                    message: error.message
                };

            }
        }

        function getGroupDataWithGroupId(groupId) {
            let groupData = global.db.groups[groupId];
            if (typeof groupData !== 'object') global.db.groups[groupId] = {};
            if (groupData) {
                if (!('jid' in groupData)) groupData.jid = groupId;
                if (!('sewa' in groupData)) groupData.sewa = {
                    status: true,
                    notice: true,
                    vip: false,
                    expired: 0
                }
            } else {
                global.db.groups[groupId] = {
                    jid: groupId,
                    sewa: {
                        status: true,
                        notice: true,
                        vip: false,
                        expired: 0
                    }
                }
            }
            return groupData;
        }

        switch (m.command) {
            case 'addsewa': {
                const [value, params] = m.args;
                if (/^\d.*(@g\.us)$/.test(m.chat)) {
                    let groupData = global.db.groups[m.chat];
                    if (typeof groupData == 'undefined') return m.reply('Group data not found.')
                    if (/^(vip)$/i.test(value)) {
                        if (groupData && groupData.sewa && !groupData.sewa.status) return m.reply('Grup ini tidak ada di data sewa.')
                        if (groupData && groupData.sewa && groupData.sewa.status && groupData.sewa.vip) return m.reply('Already rented VIP!')
                        groupData.sewa.vip = true;
                        mecha.reply(m.chat, 'Successfully added rent `VIP` to this group.', m, {
                            expiration: m.expiration
                        })
                    } else {
                        const duration = value ? Date.now() + toMs(value) : Date.now() + 2592000000;
                        if (groupData && groupData.sewa && groupData.sewa.status) return m.reply('Grup tersebut sudah ada di data sewa.')
                        groupData.sewa.status = true;
                        groupData.sewa.notice = true;
                        groupData.sewa.expired = duration;
                        mecha.reply(m.chat, `Successfully added rent to this group for ${value ? value : '30d'}`, m, {
                            expiration: m.expiration
                        })
                    }
                } else if (/^https:\/\/chat\.whatsapp\.com\/[A-Za-z0-9]+/.test(value)) {
                    const result = await getGroupIdWithGroupLink(value);
                    if (!result.status) return m.reply(result.message);
                    const groupId = result.groupId;
                    let groupData = global.db.groups[groupId];
                    if (typeof groupData == 'undefined') return m.reply('Group data not found.')
                    if (/^(vip)$/i.test(params)) {
                        if (groupData && groupData.sewa && !groupData.sewa.status) return m.reply('Grup ini tidak ada di data sewa.')
                        if (groupData && groupData.sewa && groupData.sewa.status && groupData.sewa.vip) return m.reply('Already rented VIP!')
                        groupData.sewa.vip = true;
                        mecha.reply(m.chat, 'Successfully added rent `VIP` to this group.', m, {
                            expiration: m.expiration
                        }).then(async () => {
                            mecha.reply(groupId, 'This group successfully rented bot `VIP`.', func.fverified, {
                                expiration: m.expiration
                            })
                        })
                    } else {
                        const code = result.code;
                        const getGroups = await mecha.groupFetchAllParticipating();
                        const listGroups = Object.values(getGroups).map(item => item.id);
                        if (!listGroups.includes(groupId)) {
                            try {
                                await mecha.groupAcceptInvite(code)
                            } catch {}
                        }
                        try {
                            const time = params ? params : '30d';
                            const duration = params ? Date.now() + toMs(params) : Date.now() + 2592000000;
                            let groupData = getGroupDataWithGroupId(groupId);
                            if (typeof groupData == 'undefined') return m.reply('Group data not found.');
                            if (groupData.sewa && groupData.sewa.status) return m.reply('Grup tersebut sudah ada di data sewa.')
                            groupData.sewa.status = true;
                            groupData.sewa.notice = true;
                            groupData.sewa.expired = duration;
                            mecha.reply(m.chat, `Successfully added rent to this group for ${time}`, m, {
                                expiration: m.expiration
                            }).then(async () => {
                                mecha.reply(groupId, `This group successfully rented bot for ${time}`, func.fverified, {
                                    expiration: m.expiration
                                })
                            })
                        } catch (error) {
                            let err = String(error)
                            if (err.includes('not-authorized')) return m.reply('Masukkan bot kedalam grup tersebut terlebih dahulu.')
                            return errorMessage(error)
                        }
                    }
                } else {
                    let caption = `Contoh penggunaan:\n\n
*in private chat*:
- ${m.prefix}addsewa <link grup> vip
_bot akan disewa \`VIP\` oleh grup tersebut_.
- addsewa <link grup> 30d
_bot akan disewa selama 30 day oleh grup tersebut_.

*in group chat*:
- ${m.prefix}addsewa vip
_bot akan disewa \`VIP\` oleh grup ini.
- ${m.prefix}addsewa 30d
_bot akan disewa selama 30 day oleh grup ini_.`
                    mecha.reply(m.chat, caption, m, {
                        expiration: m.expiration
                    })
                }
            }
            break
            case 'delsewa': {
                const [value, params] = m.args;
                if (/^\d.*(@g\.us)$/.test(m.chat)) {
                    let groupData = global.db.groups[m.chat];
                    if (typeof groupData == 'undefined') return m.reply('Group data not found.')
                    const isSewaVIP = /^(vip)$/i.test(value) ? true : false;
                    if (isSewaVIP) {
                        if (groupData && groupData.sewa && !groupData.sewa.status) return m.reply('Grup ini tidak ada di data sewa.')
                        if (groupData && groupData.sewa && !groupData.sewa.vip) return m.reply('VIP data not found.')
                        groupData.sewa.vip = false;
                        mecha.reply(m.chat, 'Successfully deleted rent `VIP` to this group.', m, {
                            expiration: m.expiration
                        })
                    } else {
                        if (groupData && groupData.sewa && !groupData.sewa.status) return m.reply('Grup ini tidak ada di data sewa.')
                        groupData.sewa.expired = 0;
                        groupData.sewa.status = false;
                        groupData.sewa.notice = false;
                        groupData.sewa.vip = false;
                        mecha.reply(m.chat, `Successfully deleted rent to this group.`, m, {
                            expiration: m.expiration
                        })
                    }
                } else if (/^https:\/\/chat\.whatsapp\.com\/[A-Za-z0-9]+/.test(value)) {
                    const result = await getGroupIdWithGroupLink(value);
                    if (!result.status) return m.reply(result.message);
                    const groupId = result.groupId;
                    let groupData = global.db.groups[groupId];
                    if (typeof groupData == 'undefined') return m.reply('Group data not found.')
                    if (/^(vip)$/i.test(params)) {
                        if (groupData && groupData.sewa && !groupData.sewa.status) return m.reply('Grup tersebut tidak ada di data sewa.')
                        if (groupData && groupData.sewa && !groupData.sewa.vip) return m.reply('VIP data not found.')
                        groupData.sewa.vip = false;
                        mecha.reply(m.chat, 'Successfully deleted rent `VIP` to this group.', m, {
                            expiration: m.expiration
                        })
                    } else {
                        if (groupData && groupData.sewa && !groupData.sewa.status) return m.reply('Grup tersebut tidak ada di data sewa.')
                        groupData.sewa.expired = 0;
                        groupData.sewa.status = false;
                        groupData.sewa.notice = false;
                        mecha.reply(m.chat, `Successfully deleted rent to this group.`, m, {
                            expiration: m.expiration
                        })
                    }
                } else {
                    let caption = `Contoh penggunaan:\n\n
*in private chat*:
- ${m.prefix}delsewa <link grup> vip
_menghapus status sewabot \`VIP\` pada grup tersebut_.
- ${m.prefix}delsewa <link grup>
_menghapus status sewabot pada grup tersebut_.

*in group chat*:
- ${m.prefix}delsewa vip
_menghapus status sewabot \`VIP\` pada grup ini.
- ${m.prefix}delsewa
_menghapus status sewabot pada grup ini_.`
                    mecha.reply(m.chat, caption, m, {
                        expiration: m.expiration
                    })
                }
            }
            break
        }
    },
    owner: true
}