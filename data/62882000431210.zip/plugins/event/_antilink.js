exports.run = {
  main: async (m, { func, mecha, groups, errorMessage }) => {
    try {
      // Debug: Log status antilink untuk memastikan nilainya
      console.log('Antilink status:', groups.antilink);
      
      // Pastikan groups.antilink adalah boolean
      const isAntilinkActive = Boolean(groups.antilink);
      
      // Cek apakah pesan mengandung link grup WhatsApp
      const hasWhatsAppLink = m.budy && m.budy.match(/(https?:\/\/)?(www\.)?chat\.whatsapp\.com\/(invite\/)?[a-zA-Z0-9]+/gi);
      
      // Jika tidak ada link atau pengirim adalah admin/owner, abaikan
      if (!hasWhatsAppLink || m.isAdmin || m.isOwner) return;
      
      // Dapatkan kode invite grup saat ini
      const groupInviteCode = await mecha.groupInviteCode(m.chat).catch(() => null);
      if (!groupInviteCode) return; // Jika gagal mendapatkan kode invite
      
      // Cek apakah link mengandung kode grup ini
      const isSameGroupLink = m.budy.includes(groupInviteCode);
      
      // Jika link bukan dari grup ini
      if (!isSameGroupLink) {
        // Hapus pesan yang mengandung link (tanpa peduli status antilink)
        await mecha.sendMessage(m.chat, {
          delete: {
            remoteJid: m.chat, 
            fromMe: false, 
            id: m.key.id, 
            participant: m.sender
          }
        }).catch(e => console.error('Gagal menghapus pesan:', e));
        
        // HANYA jika anti-link aktif, kirim peringatan dan kick pengirim
        if (isAntilinkActive) {
          await mecha.sendMessage(m.chat, {
            text: `Maaf @${m.sender.split('@')[0]}, Anda akan dikeluarkan karena mengirim link grup lain.`, 
            mentions: [m.sender]
          }, {
            quoted: func.fstatus('Anti Link Grup Lain'), 
            ephemeralExpiration: m.expiration
          }).catch(e => console.error('Gagal mengirim pesan:', e));
          
          await mecha.groupParticipantsUpdate(m.chat, [m.sender], 'remove')
            .catch(e => console.error('Gagal mengeluarkan member:', e));
        }
      }
    } catch (e) {
      console.error('Error in antilink handler:', e);
      return errorMessage(e);
    }
  },
  group: true,
  botAdmin: true
};
