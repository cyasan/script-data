exports.run = {
    usage: ['listpesan'],
    hidden: ['listchat'],
    category: 'group',
    async: async (m, {
        func,
        mecha,
        groups
    }) => {
        if (!groups.hasOwnProperty('countchat')) {
            groups.countchat = true;
        }
        if (/^(on|off)$/i.test(m.args[0])) {
            let option = m.args[0].toLowerCase()
            let status = option === 'on' ? true : false;
            if (groups.countchat == status) return m.reply(`Count chat has been ${option == 'on' ? 'activated' : 'inactivated'} previously.`)
            groups.countchat = status;
            mecha.reply(m.chat, `Count chat has been ${option == 'on' ? 'activated' : 'inactivated'} successfully.`, m, {
                expiration: m.expiration
            })
        } else {
            const members = groups.member.filter((v) => v.chat !== undefined && global.db.users[v.jid] !== undefined && v.chat > 0)
            const data = members.filter(itemPertama => m.members.some(itemKedua => itemKedua.id === itemPertama.jid))
            if (data.length == 0) return m.reply(`Jika ingin mengunakan nya coba aktifkan terlebih dahulu\n\n${m.cmd} on/off`)
            let listchat = data.sort((a, b) => b.chat - a.chat)
            let member = listchat.map(v => v.jid);
            let totalpesan = 0;
            for (let x of listchat) totalpesan += x.chat;
            let caption = `乂  *L I S T - P E S A N*\n`;
            caption += `\n${formatTanggal()}`;
            caption += `\n${func.rupiah(totalpesan)} Total Semua Pesan`;
            caption += `\nKamu Top ${member.indexOf(m.sender) + 1} Chat dari ${m.members.length} Peserta\n`;
            caption += listchat.map((item, index) => `${index + 1}. @${item.jid.replace(/@.+/g, '')}: ${item.chat} pesan`).join('\n');
            mecha.reply(m.chat, caption, m, {
                expiration: m.expiration
            })
        }
    },
    group: true
}

function formatTanggal() {
    const now = new Date();

    // Mendapatkan bagian-bagian dari tanggal
    const month = String(now.getMonth() + 1).padStart(2, '0'); // Bulan (1-12)
    const day = String(now.getDate()).padStart(2, '0'); // Hari (1-31)
    const year = now.getFullYear(); // Tahun (YYYY)

    // Mendapatkan waktu
    const date = new Date(now.toLocaleString('en-US', {
        timeZone: 'Asia/Jakarta'
    }));
    let hours = date.getHours();
    const minutes = String(date.getMinutes()).padStart(2, '0'); // Menit (00-59)
    const seconds = String(date.getSeconds()).padStart(2, '0'); // Detik (00-59)

    // Menentukan AM/PM
    const ampm = hours >= 12 ? 'PM' : 'AM';
    hours = hours % 12; // Mengubah ke format 12 jam
    hours = hours ? String(hours).padStart(2, '0') : '12'; // Jika jam 0, ganti dengan 12

    // Menggabungkan semua bagian
    return `${month}-${day}-${year}, ${hours}:${minutes}:${seconds} ${ampm}`;
}