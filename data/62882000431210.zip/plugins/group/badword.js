exports.run = {
    usage: [
        'addbadword',
        'delbadword',
        'listbadword'
    ],
    use: 'badword',
    category: 'owner',
    async: async (m, {
        func,
        mecha,
        groups
    }) => {
        if (!groups.hasOwnProperty('toxic')) {
            groups.toxic = [];
        }
        switch (m.command) {
            case 'addbadword':
                if (!m.text) return m.reply(func.example(m.cmd, 'kontol'))
                if (groups.toxic.includes(m.text)) return m.reply(`*'${m.text}' already in the database.*`)
                groups.toxic.push(m.text.toLowerCase())
                m.reply(`*'${m.text}' added successfully!*`)
                break
            case 'delbadword':
                if (!m.text) return m.reply(func.example(m.cmd, 'kontol'))
                if (!groups.toxic.includes(m.text)) return m.reply(`*'${m.text}' not in database.*`)
                let index = groups.toxic.indexOf(m.text.toLowerCase());
                groups.toxic.splice(index, 1);
                m.reply(`*'${m.text}' has been removed.*`)
                break
            case 'listbadword':
                if (groups.toxic.length == 0) return m.reply('Empty data.')
                let txt = `乂  *LIST BAD WORD*\n\nTotal : ${groups.toxic.length}\n`
                txt += groups.toxic.map((v, i) => `${i + 1}. ${v}`).join('\n')
                mecha.reply(m.chat, txt, m, {
                    expiration: m.expiration
                })
                break
        }
    },
    group: true,
admin: true
}