function isAlreadyResponList(name, list) {
  return !!list.find(item => item.name === name);
}

function delResponList(name, list) {
  let index = list.findIndex(item => item.name === name);
  if (index !== -1) list.splice(index, 1);
}

exports.run = {
  usage: ["addlist", "dellist", "list", "clearlist"],
  use: "reply dengan sticker, teks, gambar, atau video",
  category: "admin tools",
  async: async (e, { func: t, mecha: a, groups: s, quoted: i }) => {
    switch (e.command) {
      case "addlist":
        if (!e.isGc) return e.reply(global.mess.group);
        if (!e.isAdmin && !e.isOwner) return e.reply(global.mess.admin);
        if (!e.text) return e.reply("Masukkan nama untuk daftar!");

        let name = e.text.trim().toLowerCase();
        if (isAlreadyResponList(name, s.list)) return e.reply("Nama tersebut sudah ada di database!");

        if (/webp|image|video/.test(i.mime)) {
          let media = await i.download();
          let uploaded = await t.catbox(media);

          if (!uploaded.status || !/^https:\/\/files\.catbox\.moe\/[a-zA-Z0-9]+(\.[a-zA-Z0-9]+)$/.test(uploaded.url)) {
            return e.reply("Gagal mengunggah media, coba lagi.");
          }

          let type = /webp/.test(i.mime) ? "sticker" : /image/.test(i.mime) ? "image" : "video";
          let content = { url: uploaded.url };

          // Jika media memiliki teks
          if (i.text) {
            content.text = i.text;
          }

          s.list.push({ name, type, content });
          await e.reply(`✅ Berhasil menambahkan *${name}* ke dalam database!`);
        } 
        else if (e.quoted && e.quoted.text) {
          s.list.push({ name, type: "text", content: e.quoted.text });
          await e.reply(`✅ Berhasil menambahkan teks *${name}* ke dalam database!`);
        } 
        else {
          return e.reply(`Balas media atau teks dengan caption *${e.cmd} <nama>*`);
        }
        break;

      case "dellist":
        if (!e.isGc) return e.reply(global.mess.group);
        if (!e.isAdmin && !e.isOwner) return e.reply(global.mess.admin);
        if (!e.text) return e.reply(t.example(e.cmd, "nama_list"));

        let delName = e.text.trim().toLowerCase();
        if (!isAlreadyResponList(delName, s.list)) return e.reply("Nama tidak ditemukan dalam database!");

        delResponList(delName, s.list);
        await e.reply(`✅ *${delName}* berhasil dihapus dari database!`);
        break;

      case "list":
        if (!e.isGc) return e.reply(global.mess.group);
        if (s.list.length === 0) return e.reply("📂 Tidak ada daftar saat ini.");

        let listText = "*📜 DAFTAR RESPON 📜*\n\n";
        listText += s.list
          .sort((a, b) => a.name.localeCompare(b.name))
          .map((item, index) => `${index + 1}. ${item.name}\n- Tipe: ${item.type}`)
          .join("\n\n");

        a.reply(e.chat, listText, e, { expiration: e.expiration });
        break;

      case "clearlist":
        if (!e.isGc) return e.reply(global.mess.group);
        if (!e.isAdmin && !e.isOwner) return e.reply(global.mess.admin);
        if (s.list.length === 0) return e.reply("Database sudah kosong.");

        s.list = [];
        e.reply("✅ Semua daftar berhasil dihapus.");
        break;
    }
  },

  main: async (e, { mecha: t, groups: a }) => {
    let input = e.budy && e.budy.trim().toLowerCase();
    if (!e.isGc || !e.budy || e.isPrefix) return;

    let found = a.list.find(item => item.name === input);
    if (!found) return;

    switch (found.type) {
      case "sticker":
        return t.sendMessage(e.chat, { sticker: { url: found.content.url } }, { quoted: e, ephemeralExpiration: e.expiration });
      case "image":
        return t.sendMessage(e.chat, { image: { url: found.content.url }, caption: found.content.text || "" }, { quoted: e, ephemeralExpiration: e.expiration });
      case "video":
        return t.sendMessage(e.chat, { video: { url: found.content.url }, caption: found.content.text || "" }, { quoted: e, ephemeralExpiration: e.expiration });
      case "text":
        return t.sendMessage(e.chat, { text: found.content, mentions: t.ments(found.content) }, { quoted: e, ephemeralExpiration: e.expiration });
    }
  }
};
