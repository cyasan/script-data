const fetch = require('node-fetch');

exports.run = {
    usage: ['limit'],
    hidden: ['ceklimit', 'balance'],
    use: 'mention or reply',
    category: 'user',
    async: async (m, {
        func,
        mecha,
        setting,
        froms
    }) => {
        function checkVIPMember(jid) {
            if (/^\d.*(@g\.us)$/.test(m.chat)) {
                let groups = global.db.groups[m.chat];
                if (groups.sewa && groups.sewa.status && groups.sewa.vip) {
                    let metadata = global.db.metadata[m.chat] || {};
                    let members = metadata?.participants?.map(x => x.id) || [];
                    if (members.includes(jid)) return true;
                }
            }
            return false;
        }

        try {
            let name, limit, balance, isPrem, isVIP, isOwner;
            if (m.quoted || m.text) {
                if (!froms) return m.reply('Invalid number.')
                if (typeof global.db.users[froms] == 'undefined') return m.reply('User data not found.')
                name = global.db.users[froms].name;
                limit = global.db.users[froms].limit;
                balance = global.db.users[froms].balance;
                isPrem = global.db.users[froms].premium;
                isVIP = checkVIPMember(froms);
                isOwner = [global.owner, m.bot, ...m.setting.owner].includes(froms);
            } else {
                name = m.pushname;
                limit = global.db.users[m.sender].limit;
                balance = global.db.users[m.sender].balance;
                isPrem = global.db.users[m.sender].premium;
                isVIP = checkVIPMember(m.sender);
                isOwner = [global.owner, m.bot, ...setting.owner].includes(m.sender);
            }
            mecha.sendReact(m.chat, '🕒', m.key);
            await mecha.sendMessageModify(m.chat, `Limit \`${name}\``, m, {
                title: `Limit: ${isVIP ? 'Unlimited' : (limit + '/' + (isPrem ? setting.limit.premium : setting.limit.free))}\nBalance: $${func.rupiah(balance)}`,
                body: `Status: ${isOwner ? 'Owner' : isVIP ? 'VIP Member' : isPrem ? 'Premium' : 'Free'}`,
                thumbnail: await (await fetch(setting.cover)).buffer(),
                url: setting.link,
                expiration: m.expiration
            })
            await mecha.sendReact(m.chat, '', m.key);
        } catch (error) {
            console.log(error);
            mecha.sendReact(m.chat, '❌', m.key);
        }
    }
}