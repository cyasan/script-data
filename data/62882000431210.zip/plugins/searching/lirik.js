let axios=require("axios");exports.run={usage:["lirik"],use:"judul lagu",category:"searching",async:async(a,{func:e,mecha:r})=>{try{if(!a.text)return a.reply(e.example(a.cmd,"melukis senja"));r.sendReact(a.chat,"🕒",a.key);var t=encodeURIComponent(a.text),i=(await axios.get("https://api.ryzendesu.vip/api/search/lyrics?query="+t)).data;if(0==i?.length)return a.reply("Lirik not found.");var s=i.random(),n=(`Lirik \`${e.ucword(a.text)}\`

- *Name*: ${s.name}
- *trackName*: ${s.trackName}
- *artistName*: ${s.artistName}
- *albumName*: ${s.albumName}
- *duration*: ${s.duration}
- *instrumental*: ${s.instrumental}
- *plainLyrics*: ${s.plainLyrics}
- *syncedLyrics*: `+s.syncedLyrics).trim();await r.sendMessage(a.chat,{text:n},{quoted:a,ephemeralExpiration:a.expiration})}catch(e){console.error("Error fetching lyrics:",e),a.reply(e.message)}},restrict:!0,limit:!0,location:"plugins/searching/lirik.js"};