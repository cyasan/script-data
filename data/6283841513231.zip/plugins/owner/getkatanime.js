const fs = require('fs'),
fetch = require('node-fetch');

exports.run = {
usage: ['getkatanime'],
category: 'owner',
async: async (m, { func, mecha }) => {
await mecha.sendReact(m.chat, '⌛', m.key)
if (!fs.existsSync('./database/katanime.json')) fs.writeFileSync('./database/katanime.json', JSON.stringify([], null, 2))
let katanime = JSON.parse(fs.readFileSync('./database/katanime.json'));
index = 0;
for (let i = 0; i < 10000; i++) {
let res = await fetch('https://katanime.vercel.app/api/getrandom?limit=1').then(data => data.json())
if (!res.sukses) continue;
if (!res.result[0]) continue;
let { id, english, indo, character, anime } = res.result[0]
if (katanime.some(x => x.id == id)) continue;
index++
katanime.push({
id: id,
english: english,
indo: indo,
character: character,
anime: anime
})
await new Promise(resolve => setTimeout(resolve, 100));
}
fs.writeFileSync('./database/katanime.json', JSON.stringify(katanime, null, 2))
mecha.sendMessage(m.chat, {text: `Berhasil mengumpulkan *${index}* data kata anime\n> jumlah kata anime saat ini: ${katanime.length}`}, {quoted: null, ephemeralExpiration: m.expiration})
},
owner: true
}