const util = require('util');
const exec = util.promisify(require('child_process').exec);
const fs = require('fs');
const path = require('path');

function delay(ms) {
return new Promise(resolve => setTimeout(resolve, ms));
}

exports.run = {
usage: ['upswvid'],
hidden: ['swvid', 'vidsw'],
use: 'reply video',
category: 'owner',
async: async (m, { func, mecha, quoted }) => {
if (!quoted || !/video/.test(quoted.mime) || /webp/.test(quoted.mime)) return m.reply(`Kirim/Reply video Dengan Caption ${m.cmd}`);
mecha.sendReact(m.chat, '⌛', m.key)
const caption = m.text ? '#UP STATUS DARI BOT\n' + m.text : '#UP STATUS DARI BOT'
const seconds = 60
const statusJidList = Object.values(global.db.users).map(x => x.jid)
const media = await mecha.downloadAndSaveMediaMessage(m)
try {
if (quoted.seconds > seconds) {
//m.reply(`Video harus 30 detik`)
const ran = `${Math.floor(Math.random() * 10000)}`;
// Buat direktori jika belum ada
const outputDir = './sampah/output-upsw/';
if (!fs.existsSync(outputDir)) {
fs.mkdirSync(outputDir, { recursive: true }); // Pastikan direktori dan subdirektorinya ada
}
console.log("Memulai memotong durasi video");
await exec(`ffmpeg -hide_banner -err_detect ignore_err -i ${media} -r 24 -codec:v libx264 -vsync 1 -codec:a aac -ac 2 -ar 48k -f segment -preset fast -segment_format mp4 -segment_time ${seconds} -force_key_frames "expr:gte(t,n_forced*${seconds})" ${path.join(outputDir, ran)}%d.mp4`);
for (let i = 0; i <= 14; i++) {
const filePath = path.join(outputDir, `${ran}${i}.mp4`);
if (fs.existsSync(filePath)) {
console.log('Video: ', filePath);
await mecha.sendMessage('status@broadcast', {
video: fs.readFileSync(filePath),
caption: caption
}, 
{
statusJidList: statusJidList
});
setTimeout(() => {
fs.unlinkSync(filePath);
}, 1000);
// Jeda sebentar sebelum mengunggah video berikutnya
await delay(20000); // Atur sesuai kebutuhan
// Hentikan proses jika potongan video berikutnya tidak ditemukan
if (!fs.existsSync(path.join(outputDir, `${ran}${i + 1}.mp4`))) {
break;
}
}
}
m.reply('Success upload status menggunakan bot');
} else {
await mecha.sendMessage('status@broadcast', {
video: fs.readFileSync(media),
caption: caption
}, 
{
statusJidList: statusJidList
});
m.reply('Success upload status menggunakan bot')
}
} catch (err) {
console.log(err);
return mecha.reply(m.chat, func.jsonFormat(err), m, {
expiration: m.expiration
})
}
},
owner: true
}