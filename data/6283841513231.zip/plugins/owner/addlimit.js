exports.run = {
usage: ['addlimit'],
use: 'mention or reply',
category: 'owner',
async: async (m, { func, mecha, froms, setting }) => {
if (m.quoted) {
if (!m.text) return m.reply('Input nominalnya.')
let nominal = m.text.replace(/[^0-9]/g, '')
if (isNaN(nominal)) return m.reply('Nominal harus berupa angka.')
if (Number(nominal) >= 1000000000000000) return m.reply('Kebanyakan!')
let count = nominal.length > 0 ? Math.min(1000000000000000, Math.max(parseInt(nominal), 1)) : Math.min(1)
if (count < 1) return m.reply('Minimal 1 limit.')
let user = global.db.users[m.quoted.sender]
if (typeof user == 'undefined') return m.reply('User data not found.')
user.limit += parseInt(count);
m.reply(`Successfully added ${count.rupiah()} limit to @${m.quoted.sender.replace(/@.+/, '')}\n- current limit: ${user.limit.rupiah()}`)
} else if (m.text) {
const [target, amount] = m.text.split(',');
if (!(target && amount)) return m.reply(`Contoh : ${m.cmd} 62xxx|10`)
let number = isNaN(target) ? (target.startsWith('+') ? target.replace(/[()+\s-]/g, '') : (target).split('@')[1]) : target
if (isNaN(number)) return m.reply('Invalid number.')
if (number.length > 15) return m.reply('Invalid format.')
let jid = target.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
let user = global.db.users[jid]
let nominal = amount.replace(/[^0-9]/g, '')
if (typeof user == 'undefined') return m.reply('User data not found.')
if (isNaN(nominal)) return m.reply('Nominal harus berupa angka.')
if (Number(nominal) >= 1000000000000000) return m.reply('Kebanyakan!')
let count = nominal.length > 0 ? Math.min(1000000000000000, Math.max(parseInt(nominal), 1)) : Math.min(1)
if (count < 1) return m.reply('Minimal 1 limit.')
user.limit += parseInt(count);
m.reply(`Successfully added ${count.rupiah()} limit to @${jid.replace(/@.+/, '')}\n- current limit: ${user.limit.rupiah()}`)
} else m.reply('Mention or Reply chat target.')
},
owner: true
}