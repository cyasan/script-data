const fs = require('fs')
const path = require('path')

exports.run = {
usage: ['sendstickerc'],
hidden: ['sendstikerc'],
category: 'owner',
async: async (m, { func, mecha, packname, author }) => {
let detik = 1;
let amount = 500;
if (m.text && !isNaN(m.text)) amount = m.text;
let data = fs.readdirSync('./sticker').filter(v => v.endsWith('.webp')).slice(0, amount)
if (data.length == 0) return m.reply('Empty trash.')
await m.reply(`_Wait sedang mengirim ${amount} stiker dalam waktu ${amount * detik} detik.._`)
for (let file of data) {
let files = path.join('sticker', file)
mecha.sendSticker('120363352779958494@newsletter', fs.readFileSync(files), null, {
packname,
author,
expiration: m.expiration
}).then(_ => fs.unlinkSync(files))
await new Promise(resolve => setTimeout(resolve, detik * 1000));
}
await m.reply(`Success send ${data.length} stickers.`)
},
owner: true
}