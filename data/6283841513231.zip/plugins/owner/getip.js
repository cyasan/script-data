const axios = require('axios');

async function getIP() {
try {
const { data } = await axios.get('https://api.ipify.org', {
params: {
format: 'json'
}
});
return `IP kamu adalah ${data.ip}`;
} catch (e) {
return 'Terjadi kesalahan saat memproses permintaan.';
console.log(e);
}
}

exports.run = {
usage: ['getip'],
hidden: ['ip'],
category: 'owner',
async: async (m, { func, mecha }) => {
let result = await getIP()
mecha.reply(m.chat, result, m, {
expiration: m.expiration
})
},
owner: true
}