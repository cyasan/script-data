const fetch = require('node-fetch');
const fs = require('fs');
const { format } = require('util');

exports.run = {
usage: ['gethtml'],
use: 'url',
category: 'owner',
async: async (m, { func, mecha }) => {
function isHTMLCode(code) {
const htmlRegex = new RegExp('<[^<]+?>');
return htmlRegex.test(code);
}
if (m.quoted || m.text) {
let url = m.quoted ? m.quoted.text : m.text ? m.text : ''
if (!/^https?:\/\//.test(url)) return m.reply('Masukan link dengan awalan dengan http:// atau https://')
mecha.sendReact(m.chat, '⌛', m.key)
let _url = new URL(url)
let res = await fetch(_url.href)
if (res.headers.get('content-length') > 100 * 1024 * 1024 * 1024) {
// delete res
throw `Content-Length: ${res.headers.get('content-length')}`
}
if (!/text|json/.test(res.headers.get('content-type'))) return m.reply('url tersebut tidak mengandung kode html.')
let code = await res.buffer();
try {
code = format(JSON.parse(code + ''))
} catch (e) {
code = code + ''
} finally {
if (isHTMLCode(code)) {
const titleRegex = /<title>(.*?)<\/title>/g;
const titleMatch = code.match(titleRegex);
let title = 'untitled.html';

if (titleMatch) {
title = titleMatch[0].replace(/<\/?title>/g, '') + '.html';
}

let htmlPath = `${title}.html`;
fs.writeFileSync(htmlPath, code);
console.log(`HTML content from ${url} has been saved to ${title}.html`);
mecha.sendMessage(m.chat, {
document: {
url: htmlPath
},
mimetype: 'text/html',
fileName: title,
}, {quoted: m, ephemeralExpiration: m.expiration}).then(_ => fs.unlinkSync(htmlPath));
} else m.reply('url tersebut tidak mengandung kode html.')
}
} else m.reply('Input or reply url nya!')
},
owner: true
}