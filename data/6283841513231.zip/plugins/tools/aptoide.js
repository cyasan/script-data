const fetch = require('node-fetch');

/*const APIs = {
1: "https://apkcombo.com",
2: "apk-dl.com",
3: "https://apk.support",
4: "https://apps.evozi.com/apk-downloader",
5: "http://ws75.aptoide.com/api/7",
6: "https://cafebazaar.ir",
};

const Proxy = (url) => url ? `https://translate.google.com/translate?sl=en&tl=fr&hl=en&u=${encodeURIComponent(url)}&client=webapp` : '';
const api = (ID, path = '/', query = {}) => (ID in APIs ? APIs[ID] : ID) + path + (query ? '?' + new URLSearchParams(Object.entries({ ...query })) : '');

const tools = {
APIs,
Proxy,
api,
};*/

let aptoide = {
search: async function (query) {
let res = await fetch(`https://ws75.aptoide.com/api/7/apps/search?query=${encodeURIComponent(query)}&limit=1000`)
let result = {};
res = await res.json();
result = res.datalist.list.map((v) => {
return {
name: v.name,
id: v.package,
};
});
return result;
},
download: async function (id) {
let res = await fetch(`https://ws75.aptoide.com/api/7/apps/search?query=${encodeURIComponent(id)}&limit=1`)
res = await res.json();
return {
img: res.datalist.list[0].icon,
developer: res.datalist.list[0].store.name,
appname: res.datalist.list[0].name,
link: res.datalist.list[0].file.path,
};
},
};

exports.run = {
usage: ['aptoidesearch', 'aptoidedl'],
use: 'options',
category: 'tools',
async: async (m, { func, mecha }) => {
switch (m.command) {
case 'aptoidesearch':{
if (!m.text) return m.reply(func.example(m.cmd, 'cinta'))
mecha.sendReact(m.chat, '⌛', m.key)
let result = await aptoide.search(m.text)
let body = '```Result from:```' + ' `' + m.text + '`'
let rows = []
for (let [index, data] of result.entries()) {
if (!data.name && !data.id) continue
rows.push({
header: `${index + 1}. ${data.id}`,
title: `${data.name}`,
id: `${m.prefix}aptoidedl ${data.id}`
})
}
let sections = [{
title: 'PILIH APLIKASI DIBAWAH',
rows: rows
}]
let buttons = [
['list', 'Click Here ⎙', sections],
]
mecha.sendButton(m.chat, `A P T O I D E - S E A R C H`, body, 'select the list button below.', buttons, m, {
userJid: m.sender,
expiration: m.expiration
})
}
break
case 'aptoidedl':{
if (!m.text) return m.reply(func.example(m.cmd, 'id.b2u.tutorialtermuxid'))
mecha.sendReact(m.chat, '⌛', m.key)
let result = await aptoide.download(m.args[0])
let txt = `Developer: ${result.developer}\nAppname: ${result.appname}`
mecha.sendMedia(m.chat, result.link, m, {
caption: txt,
fileName: result.appname,
expiration: m.expiration
})
}
break
}
},
limit: true
}