const fetch = require('node-fetch');

exports.run = {
    usage: ['cekcuaca'],
    hidden: ['cca'],
    use: 'kota/desa',
    category: 'tools',
    async: async (m, {
        func,
        mecha
    }) => {
        if (!m.text) return m.reply('masukkan nama kota/desa');
        mecha.sendReact(m.chat, '⌛', m.key);
        try {
            let url = `https://api.diioffc.web.id/api/tools/cekcuaca?query=${encodeURIComponent(m.text)}`;
            const res = await fetch(url);
            const response = await res.json();
            let caption = `*C E K - C U A C A*

- *Nama Kota/Desa*: ${response.result.name}
- *Zona Waktu*: ${response.result.timezone || '-'}
- *Description*: ${response.result?.weather[0]?.description || '-'}
- *Suhu*: ${response.result.main?.temp || '-'}
- *Suhu Minus*: ${response.result.main?.temp_min || '-'}
- *Suhu Maks*: ${response.result.main?.temp_max || '-'}
- *Tekanan*: ${response.result?.main?.preesure || '-'}
- *Kelembapan*: ${response.result?.main?.humidity || '-'}
- *Kecepatan Angin*: ${response.result?.wind?.speed || '-'}`
            mecha.sendMessage(m.chat, {
                image: {
                    url: `https://tse4.mm.bing.net/th?id=OIP.XC9RLrV4cN8oAQCFcvkvwgHaEJ&pid=Api&P=0&h=180`
                },
                caption: caption
            }, {
                quoted: m,
                ephemeralExpiration: m.expiration
            })
        } catch (err) {
            console.log(err);
            await m.reply('Tidak ditemukan.')
        }
    },
    limit: 5,
    location: 'plugins/tools/cekcuaca.js'
}