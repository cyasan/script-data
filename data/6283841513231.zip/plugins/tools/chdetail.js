const channelDetail = async (url) => {
    let cheerio = require("cheerio"),
        axios = require("axios"),
        creator = "MannR"
    try {
        if (!url.includes("whatsapp.com")) return {
            status: false,
            creator,
            message: "Input WhatsApp Channel Url"
        }
        const {
            data
        } = await axios.get(url)
        const $ = cheerio.load(data)
        const pageTitle = $("title[id='pageTitle']").text().trim().replace(" | ", " ")
        const followers = $("h5[class='_9vd5 _9scy']").text().replace("Channel | ", "")
        const name = $("h3[class='_9vd5 _9t2_']").text().trim()
        const description = $("meta[name='description']").attr("content").replace(pageTitle + ". ", "").replace(". " + followers, "")
        return {
            status: true,
            creator,
            result: {
                name: name,
                followers: followers,
                description: description
            }
        }
    } catch (error) {
        return {
            status: false,
            message: error.message
        }
    }
}

exports.run = {
    usage: ['chdetail'],
    use: 'link saluran',
    category: 'tools',
    async: async (m, {
        func,
        mecha
    }) => {
        if (!m.text) return m.reply(func.example(m.cmd, 'https://whatsapp.com/channel/'))
        if (!m.args[0].includes("whatsapp.com")) return m.reply(global.mess.error.api)
        mecha.sendReact(m.chat, '⌛', m.key);
        const data = await channelDetail(m.args[0])
        if (!data.status) return m.reply(data.message);
        const results = data.result;
        let caption = '*C H A N N E L - D E T A I L*\n'
        for (let key in results) caption += `\n- ${func.ucword(key)}: ${results[key]}`;
        mecha.reply(m.chat, caption, m, {
            typing: 'recording',
            expiration: m.expiration
        })
    },
    premium: true,
    location: 'plugins/tools/chdetail.js'
}