const axios = require('axios');
const fs = require('fs');
const path = require('path');

const imgBase = (filePath) => {
  const filex = fs.readFileSync(filePath);
  const based = filex.toString('base64');
  const mimeType = `image/${path.extname(filePath).slice(1)}`;
  return `data:${mimeType};base64,${based}`;
};

const headers = {
  'authority': 'labs.writingmate.ai',
  'accept': '*/*',
  'content-type': 'application/json',
  'origin': 'https://labs.writingmate.ai',
  'referer': 'https://labs.writingmate.ai/share/JyVg?__show_banner=false',
  'user-agent': 'Postify/1.0.0',
};

const mateai = {
  create: async (imagePath, prompt = "Analyze this image and provide a detailed creative prompt not longer than 400 symbols.") => {
  
    const imgUrl = imgBase(imagePath);
    
    const data = {
      response_format: {
        type: "json_schema",
        json_schema: {
          name: "image_prompt",
          strict: true,
          schema: {
            type: "object",
            properties: { prompt: { type: "string" } },
            required: ["prompt"],
            additionalProperties: false
          }
        }
      },
      
      chatSettings: {
        model: "gpt-4o-mini",
        temperature: 0.7,
        contextLength: 16385,
        includeProfileContext: false,
        includeWorkspaceInstructions: false,
        embeddingsProvider: "openai"
      },
      
      messages: [
        {
          role: "user",
          content: [
            { type: "image_url", image_url: { url: imgUrl } },
            { type: "text", text: prompt }
          ]
        }
      ],
      customModelId: ""
    };
    try {
      const response = await axios.post('https://labs.writingmate.ai/api/chat/public', data, { headers });
      return response.data;
    } catch (error) {
      throw new Error(`${error.message}`);
    }
  }
};

exports.run = {
usage: ['prompt'],
hidden: ['prom'],
use: 'query',
category: 'ai',
async: async (m, { func, mecha, quoted }) => {
if (!quoted.mime) return m.reply(func.example(m.cmd, 'send/reply media'))
mecha.sendReact(m.chat, '⌛', m.key)
try {
let media = await mecha.downloadAndSaveMediaMessage(m);
if (!media) return mecha.sendReact(m.chat, '❌', m.key)
let result = await mateai.create(media);
m.reply("`" + result.prompt + "`");
} catch (error) {
return await m.reply(error.message);
}
},
premium: true
}