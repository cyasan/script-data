const axios = require('axios');

exports.run = {
  usage: ['yupraai'],
  hidden: ['ypai'],
  use: 'text',
  category: 'ai',
  async: async (m, { mecha }) => {
    if (!m.text) return m.reply(`Gunakan format: *${m.prefix + m.command} HALO*`);

    try {
      const response = await axios.get('https://api.yupradev.biz.id/ai/ypai', {
        params: {
          text: m.text,
          t: Date.now(),
          session: m.sender
        },
        headers: {
          'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/135.0.0.0 Mobile Safari/537.36',
          'Referer': `https://ai.yupradev.biz.id/${m.sender}`
        }
      });

      const hasil = response.data?.result;
      if (!hasil) return m.reply('lu si Jawa jadinya ga ada apa apa ');

      m.reply(hasil);
    } catch (e) {
      m.reply("error Cok" + e.message);
    }
  }
};