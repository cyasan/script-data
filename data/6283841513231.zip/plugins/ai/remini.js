const fetch = require('node-fetch')

exports.run = {
    usage: ['remini'],
    hidden: ['hd'],
    use: 'reply photo',
    category: 'ai',
    async: async (m, {
        func,
        mecha,
        quoted
    }) => {
        async function processingHDR(imageUrl) {
            const api = `https://fastrestapis.fasturl.cloud/aiimage/upscale?imageUrl=${encodeURIComponent(imageUrl)}&resize=2`
            const res = await fetch(api)

            if (!res.ok) {
                const errText = await res.text()
                console.log('FastRestAPIs error:', errText)
                throw 'Gagal dari API upscale'
            }

            const arrayBuffer = await res.arrayBuffer()
            return Buffer.from(arrayBuffer)
        }

        const method = m.command;
        const supported = ['hd', 'remini']
        if (!supported.includes(method)) return m.reply('Perintah tidak dikenali.')

        mecha[method] = mecha[method] || {}
        if (m.sender in mecha[method]) return m.reply('Masih ada proses yang sedang berjalan, tunggu sebentar.')

        if (!quoted.mime) return m.reply(`Kirim/Reply gambar dengan caption *${m.cmd}*`)
        if (!/image\/(jpe?g|png)/.test(quoted.mime)) return m.reply(`Mime *${quoted.mime}* tidak didukung.`)

        mecha[method][m.sender] = true
        mecha.sendReact(m.chat, '🕒', m.key);

        try {
            const media = await quoted.download()
            if (!media || !Buffer.isBuffer(media)) return m.reply('Gagal mengunduh atau file tidak valid.')
            const imageUrl = await func.tmpfiles(media)
            const result = await processingHDR(imageUrl)

            await mecha.sendMedia(m.chat, result, m, {
                caption: global.mess.ok,
                expiration: m.expiration
            })
        } catch (e) {
            await m.reply(`Something went wrong: ${e.message}`);
        } finally {
            delete mecha[method][m.sender]
        }
    },
    premium: true,
    location: 'plugins/ai/remini.js'
}