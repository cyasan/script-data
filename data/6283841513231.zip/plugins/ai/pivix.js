const fetch = require('node-fetch');

exports.run = {
usage: ['pivix'],
category: 'searching',
async: async (m, { func, mecha, setting }) => {
if (!m.text) return m.reply(func.example(m.cmd, 'query'))
mecha.sendReact(m.chat, '⌛', m.key)
try {
let search = await func.fetchJson(`https://widipe.com/pixiv?query=${m.text}`);
let xiv = search.result

let hasil = xiv[Math.floor(Math.random() * xiv.length)] 
let caption = `*Title:* ${hasil.title}
*Author:* ${hasil.author}
*Tags:* ${hasil.tags}`;
let button = [
['button', 'Next', `${m.cmd} ${m.text}`],
]
mecha.sendButton(m.chat, `P I V I X`, caption, global.footer, button, m, {
userJid: m.sender,
media: `${hasil.urls.regular}`,
expiration: m.expiration
});
} catch (e) {
return m.reply('result not found.') 
}
},
limit: true
}