const axios = require('axios')

async function chatGptD(question, name, current) {
    const {
        dateNow,
        timeNow
    } = timeZone();
    let sistem = `kamu adalah asisten berbahasa indonesia, namamu Tanjiro, Bot WhatsApp dengan program kecerdasan buatan AI. jawab setiap pertanyaan dengan jawaban yang edukatif, jika ada yang bertanya tentang waktu kamu jawab yang berkaitan dengan ${timeNow} dan ${getTodayDate}, lawan bicaramu adalah ${name}, kamu memiliki sifat dingin dan sedikit tsundere imut, kamu dirancang dan dikembangkan oleh Wildan sejak tahun 2024, Wildan memiliki nama lengkap wildan renaldinata, berasal dari bandung, lahir pada 17 september 2011, dia adalah seseorang yang kreatif dan berbakat dalam menciptakan berbagai hal.`;
    if (current) sistem += `\n\nBerikan respons yang tidak hanya menjawab pertanyaan, tetapi juga mengaitkan jawabanmu dengan konteks dari percakapan sebelumnya. Jika ada konteks sebelumnya, gunakan itu untuk memperkaya jawabanmu: Sebelumnya, kamu telah membahas: ${current}`;
    try {
        function createPrompt(query) {
            return `${sistem}\nTolong jawab pertanyaan berikut dengan bahasa Indonesia gaul dan santai: ${query}`;
        }

        const prompt = createPrompt(question);
        const response = await axios.post("https://chat.chatgptdemo.net/chat_api_stream", {
      question: prompt,
      chat_id: '679c11d40c3719b6c7916bfd',
      timestamp: 1702825897544
    }, {
      headers: {
        'Content-Type': 'application/json',
        'User-Agent': 'PostmanRuntime/7.29.0',
        'Accept': '*/*',
        'Accept-Encoding': 'gzip, deflate, br',
        'Connection': 'keep-alive',
        'Host': 'chat.chatgptdemo.net',
        'Origin': 'https://chat.chatgptdemo.net',
        'Referer': 'https://chat.chatgptdemo.net/'
      },
      responseType: 'stream'
    })

    let res = ''
    await new Promise((resolve, reject) => {
      response.data.on('data', chunk => {
        const lines = chunk.toString().split('\n')
        lines.forEach(line => {
          if (line.includes('"content":')) {
            const match = line.match(/"content":\s*"([^"]*)"/)
            if (match) {
              res += match[1]
            }
          }
        })
      })
      response.data.on('end', resolve)
      response.data.on('error', reject)
    })
    res = res.replace(/\\n$/, '')
    return {
      status: true,
      result: res.trim()
    }
    } catch (error) {
        return {
            status: false,
            message: error.message
        }
    }
}

exports.run = {
    usage: ['gpt'],
    hidden: ['chatgpt'],
    use: 'text',
    category: 'ai',
    async: async (m, {
        func,
        mecha,
        users,
        quoted,
        errorMessage
    }) => {
        if (!m.text) return m.reply(func.example(m.cmd, 'hai'));
        mecha.sendReact(m.chat, '⌛', m.key)
        let messageId = 'TANJIRO' + func.makeid(6).toUpperCase() + 'CGPTD'
        try {
            let response = await chatGptD(m.text, users.name.replaceAll('\n', '\t'));
            if (!response.status) return m.reply(response.message)
            mecha.sendMessage(m.chat, {
                text: response.result
            }, {
                quoted: m,
                ephemeralExpiration: m.expiration,
                messageId: messageId
            });
        } catch (error) {
            mecha.sendReact(m.chat, '❌', m.key)
            return errorMessage(error)
        }
    },
    main: async (m, {
        func,
        mecha,
        users,
        errorMessage
    }) => {
        if (m.budy && m.quoted && m.quoted.fromMe && m.quoted.id.endsWith('CGPTD') && !m.isPrefix) {
            mecha.sendReact(m.chat, '⌛', m.key)
            let messageId = 'TANJIRO' + func.makeid(6).toUpperCase() + 'CGPTD'
            try {
                let response = await chatGptD(m.budy, users.name.replaceAll('\n', '\t'), m.quoted.text);
                if (!response.status) return m.reply(response.message)
                mecha.sendMessage(m.chat, {
                    text: response.result
                }, {
                    quoted: m,
                    ephemeralExpiration: m.expiration,
                    messageId: messageId
                });
                global.db.users[m.sender].limit -= 1
            } catch (error) {
                mecha.sendReact(m.chat, '❌', m.key)
                return errorMessage(error)
            }
        }
    },
    limit: true,
    location: 'plugins/ai/gpt.js'
}
function timeZone() {
    const today = new Date();
    const date = new Date(today.toLocaleString("en-US", {
        timeZone: "Asia/Jakarta"
    }));
    const hours = date.getHours();
    const minutes = date.getMinutes();
    const day = today.getDate();
    const month = today.getMonth() + 1; // perhatikan bahwa bulan dimulai dari 0, maka ditambahkan 1.
    const year = today.getFullYear();
    // mengambil nama hari dalam bahasa Inggris.
    const dayOfWeek = today.toLocaleDateString("id-ID", {
        weekday: "long"
    });
    const timeNow = `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}`;
    return {
        dateNow: `${dayOfWeek}, ${day}/${month}/${year}`,
        timeNow: `${timeNow} WIB`
    }
}