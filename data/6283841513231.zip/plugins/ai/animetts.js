const axios = require('axios');

const models = {
miku: { voice_id: "67aee909-5d4b-11ee-a861-00163e2ac61b", voice_name: "Hatsune Miku" },
nahida: { voice_id: "67ae0979-5d4b-11ee-a861-00163e2ac61b", voice_name: "Nahida (Exclusive)" },
nami: { voice_id: "67ad95a0-5d4b-11ee-a861-00163e2ac61b", voice_name: "Nami" },
ana: { voice_id: "f2ec72cc-110c-11ef-811c-00163e0255ec", voice_name: "Ana(Female)" },
optimus_prime: { voice_id: "67ae0f40-5d4b-11ee-a861-00163e2ac61b", voice_name: "Optimus Prime" },
goku: { voice_id: "67aed50c-5d4b-11ee-a861-00163e2ac61b", voice_name: "Goku" },
taylor_swift: { voice_id: "67ae4751-5d4b-11ee-a861-00163e2ac61b", voice_name: "Taylor Swift" },
elon_musk: { voice_id: "67ada61f-5d4b-11ee-a861-00163e2ac61b", voice_name: "Elon Musk" },
mickey_mouse: { voice_id: "67ae7d37-5d4b-11ee-a861-00163e2ac61b", voice_name: "Mickey Mouse" },
kendrick_lamar: { voice_id: "67add638-5d4b-11ee-a861-00163e2ac61b", voice_name: "Kendrick Lamar" },
angela_adkinsh: { voice_id: "d23f2adb-5d1b-11ee-a861-00163e2ac61b", voice_name: "Angela Adkinsh" },
eminem: { voice_id: "c82964b9-d093-11ee-bfb7-e86f38d7ec1a", voice_name: "Eminem" }
};

async function animeTts(text) {
function uuid() {
return `${Math.floor(Math.random() * 256)}.${Math.floor(Math.random() * 256)}.${Math.floor(Math.random() * 256)}.${Math.floor(Math.random() * 256)}`;
}

const InsAgents = [
"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3",
"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_6) AppleWebKit/602.3.12 (KHTML, like Gecko) Version/10.1.2 Safari/602.3.12",
"Mozilla/5.0 (Linux; Android 8.0.0; Pixel 2 XL Build/OPD3.170816.012) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.87 Mobile Safari/537.36"
];
const randomUserAgent = InsAgents[Math.floor(Math.random() * InsAgents.length)];

const requests = Object.entries(models).map(async ([modelName, { voice_id, voice_name }]) => {
const ngeloot = {
raw_text: text,
url: "https://filme.imyfone.com/text-to-speech/anime-text-to-speech/",
product_id: "200054",
convert_data: [
{
voice_id,
speed: "1", // maksimal 100 wak normal 1
volume: "50", // maksimal 100 normal 50
text,
pos: 0
}
]
};

const headers = {
headers: {
'Content-Type': 'application/json',
'Accept': '*/*',
'X-Forwarded-For': uuid(),
'User-Agent': randomUserAgent
},
};

try {
const response = await axios.post('https://voxbox-tts-api.imyfone.com/pc/v1/voice/tts', JSON.stringify(ngeloot), headers);
const result = response.data;
const { channel_id, oss_url } = result.data.convert_result[0];
return { modelName, channel_id, oss_url, voice_id, voice_name };
} catch (error) {
console.error(`Error untuk model ${modelName}:`, error);
return { modelName, error: `Error untuk model ${modelName}` };
}
});

const data = await Promise.all(requests);

const formatted = data.map(({ modelName, channel_id, oss_url, voice_id, voice_name, error }) => {
if (error) {
return { modelName, error };
}
return {
modelName,
channel_id,
voice_name,
oss_url,
voice_id
};
});

return {
status: true,
creator: "INS",
result: formatted
};
}

exports.run = {
usage: ['animetts'],
hidden: ['atts'],
use: 'text',
category: 'ai',
async: async (m, { func, mecha }) => {
if (!m.text) return m.reply(func.example(m.cmd, 'Hai'))
mecha.sendReact(m.chat, '⌛', m.key)
const data = await animeTts(m.text)
for (let i of data.result) {
await func.delay(1000)
await fetch(i.oss_url).then(response => response.arrayBuffer()).then(buffer => {
// Gunakan buffer di sini
return mecha.sendMessage(m.chat, {
audio: Buffer.from(buffer, 'base64'),
mimetype: 'audio/mp4',
ptt: true
}, {quoted: func.fstatus(i.voice_name), ephemeralExpiration: m.expiration})
})
.catch(error => {
return mecha.reply(m.chat, 'Gagal mengambil data:' + String(error), m);
});
}
},
limit: true
}