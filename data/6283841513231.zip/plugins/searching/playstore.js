const { proto, generateWAMessageFromContent, generateWAMessageContent, prepareWAMessageMedia } = require('@whiskeysockets/baileys');
const axios = require('axios');
const fetch = require('node-fetch');
const cheerio = require('cheerio');

async function PlayStore(search) {
return new Promise(async (resolve, reject) => {
try {
const {
data,
status
} = await axios.get(`https://play.google.com/store/search?q=${search}&c=apps`)
const hasil = []
const $ = cheerio.load(data)
$('.ULeU3b > .VfPpkd-WsjYwc.VfPpkd-WsjYwc-OWXEXe-INsAgc.KC1dQ.Usd1Ac.AaN0Dd.Y8RQXd > .VfPpkd-aGsRMb > .VfPpkd-EScbFb-JIbuQc.TAQqTe > a').each((i, u) => {
const linkk = $(u).attr('href')
const nama = $(u).find('.j2FCNc > .cXFu1 > .ubGTjb > .DdYX5').text()
const developer = $(u).find('.j2FCNc > .cXFu1 > .ubGTjb > .wMUdtb').text()
const img = $(u).find('.j2FCNc > img').attr('src')
const rate = $(u).find('.j2FCNc > .cXFu1 > .ubGTjb > div').attr('aria-label')
const rate2 = $(u).find('.j2FCNc > .cXFu1 > .ubGTjb > div > span.w2kbF').text()
const link = `https://play.google.com${linkk}`

hasil.push({
link: link,
nama: nama ? nama : 'No name',
developer: developer ? developer : 'No Developer',
img: img ? img : 'https://i.ibb.co/G7CrCwN/404.png',
rate: rate ? rate : 'No Rate',
rate2: rate2 ? rate2 : 'No Rate',
link_dev: `https://play.google.com/store/apps/developer?id=${developer.split(" ").join('+')}`
})
})
if (hasil.every(x => x === undefined)) return resolve({
developer: '@xorizn',
mess: 'no result found'
})
resolve(hasil)
} catch (err) {
console.error(err)
}
})
}

exports.run = {
usage: ['playstore'],
use: 'query',
category: 'searching',
async: async (m, { func, mecha }) => {
if (!m.text) return m.reply(func.example(m.cmd, 'mobile legends'))
mecha.sendReact(m.chat, '⌛', m.key)
let result = await PlayStore(m.text)
if (result.length == 0) return m.reply('Empty data.')
async function createImage(url) {
const { imageMessage } = await generateWAMessageContent({image: {url: url}}, {upload: mecha.waUploadToServer});
return imageMessage;
}

function shuffleArray(array) {
for (let i = array.length - 1; i > 0; i--) {
const rand = Math.floor(Math.random() * (i + 1));
[array[i], array[rand]] = [array[rand], array[i]];
}
}

let cards = [];
let array = result.splice(0, 10); // Mengambil 10 gambar pertama dari array yang sudah diacak
for (let [index, data] of array.entries()) {
cards.push({
body: proto.Message.InteractiveMessage.Body.fromObject({
text: `- Developer: ${data.developer}\n- Rate: ${data.rate}`
}),
footer: proto.Message.InteractiveMessage.Footer.fromObject({
text: 'Powered by : play.google.com'
}),
header: proto.Message.InteractiveMessage.Header.fromObject({
title: data.nama,
subtitle: 'SuryaDev.',
hasMediaAttachment: true,
imageMessage: await createImage(data.img)
}),
nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.fromObject({
buttons: [{
name: 'cta_url',
buttonParamsJson: JSON.stringify({
display_text: 'Source Url',
url: data.link,
merchant_url: data.link_dev
})
}
]
})
});
}

const msg = generateWAMessageFromContent(m.chat, {
viewOnceMessage: {
message: {
messageContextInfo: {
deviceListMetadata: {},
deviceListMetadataVersion: 2
},
interactiveMessage: proto.Message.InteractiveMessage.fromObject({
body: proto.Message.InteractiveMessage.Body.create({
text: '```Result from:```'
}),
footer: proto.Message.InteractiveMessage.Footer.create({
text: '`' + m.text + '`'
}),
header: proto.Message.InteractiveMessage.Header.create({
hasMediaAttachment: false
}),
carouselMessage: proto.Message.InteractiveMessage.CarouselMessage.fromObject({
cards: [
...cards
]
})
})
}
}
}, {});

await mecha.relayMessage(m.chat, msg.message, {
messageId: msg.key.id
});
},
limit: true
}