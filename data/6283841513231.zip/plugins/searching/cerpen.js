//Cerpen Fax
const fs = require('fs')
const cheerio = require('cheerio')
const axios = require('axios')

async function cerpen (category) {
return new Promise((resolve, reject) => {
let title = category.toLowerCase().replace(/[()*]/g, "")
let judul = title.replace(/\s/g, "-")
let page = Math.floor(Math.random() * 5)
axios.get('http://cerpenmu.com/category/cerpen-'+judul+'/page/'+page)
.then((get) => {
let $ = cheerio.load(get.data)
let link = []
$('article.post').each(function (a, b) {
link.push($(b).find('a').attr('href'))
})
let random = link[Math.floor(Math.random() * link.length)]
axios.get(random)
.then((res) => {
let $$ = cheerio.load(res.data)
let hasil = {
title: $$('#content > article > h1').text(),
author: $$('#content > article').text().split('Cerpen Karangan: ')[1].split('Kategori: ')[0],
kategori: $$('#content > article').text().split('Kategori: ')[1].split('\n')[0],
lolos: $$('#content > article').text().split('Lolos moderasi pada: ')[1].split('\n')[0],
cerita: $$('#content > article > p').text()
}
resolve(hasil)
})
})
})
}

const category = ['anak', 'jawa', 'sunda', 'budaya', 'cinta', 'galau', 'gokil', 'inspiratif', 'jepang', 'kehidupan', 'keluarga', 'korea', 'kristen', 'liburan', 'lingkungan', 'malaysia', 'mengharukan', 'misteri', 'motivasi', 'nasihat', 'nasionalisme', 'olahraga', 'penantian', 'pendidikan', 'pengorbanan', 'penyesalan', 'perjuangan', 'perpisahan', 'persahabatan', 'petualangan', 'ramadhan', 'remaja', 'renungan', 'rindu', 'rohani', 'romantis', 'sastra', 'sedih', 'sejarah', 'terjemahan']
const cmd = 'cerpen-'

exports.run = {
usage: ['cerpen', ...category.map(item => cmd + item)],
category: 'cerpen',
async: async (m, { func, mecha }) => {
if (!category.includes(m.command.replace(cmd, ''))) {
let caption = '*C E R I T A - P E N D E K*\n\n'
caption += `_(Contoh, ketik: *${m.prefix}cerpen-anak* untuk memilih opsi 1)._\n\n`
caption += category.map((item, index) => `${index + 1}. ${item}`).join('\n');
mecha.reply(m.chat, caption, m, {
expiration: m.expiration
})
} else {
mecha.sendReact(m.chat, '⌛', m.key)
let res = await cerpen(m.command.split('-')[1].trim())
let caption = `◦  *Title* : ${res.title}\n`
caption += `◦  *Author* : ${res.author}\n`
caption += `◦  *Category* : ${res.kategori}\n`
caption += `◦  *Pass Moderation* : ${res.lolos}\n`
caption += `◦  *Story* :\n`
caption += res.cerita
mecha.reply(m.chat, caption, m, {
expiration: m.expiration
})
}
},
limit: true
}