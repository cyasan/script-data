const axios = require('axios');
const cheerio = require('cheerio');

class Halodoc {
   constructor(penyakit = null) {
      this.peny = penyakit;
      this.baseSearchArtikel = `https://www.halodoc.com/artikel/search/${penyakit}`;
      this.obatBaseUrl = `https://www.halodoc.com/obat-dan-vitamin/search/${penyakit}`;
   }
   
   async getArtikelSearch() {
      const { data } = await axios.get(this.baseSearchArtikel);
      const $ = cheerio.load(data);
      const articles = [];

      $('magneto-card').each((index, element) => {
         const title = $(element).find('header a').text().trim();
         const description = $(element).find('.description').text().trim();
         const link = $(element).find('header a').attr('href');
         const image = $(element).find('picture img').attr('src');
         
         articles.push({
            title,
            description,
            link: `https://www.halodoc.com${link}`,
            image,
         });
      });

      return articles;
   }
   
   async getObatSearch() {
      const { data } = await axios.get(this.obatBaseUrl);
      const $ = cheerio.load(data);
      const obatList = [];

      $('li.custom-container__list__container').each((index, element) => {
         const title = $(element).find('.hd-base-product-search-card__title').text().trim();
         const subtitle = $(element).find('.hd-base-product-search-card__subtitle').text().trim();
         const price = $(element).find('.hd-base-product-search-card__price').text().trim();
         const image = $(element).find('.hd-base-image-mapper__img').attr('src');
         const link = $(element).find('.hd-base-product-search-card__content a').attr('href');
         
         obatList.push({
            title,
            subtitle,
            price,
            image,
            link: `https://www.halodoc.com${link}`,
         });
      });

      return obatList;
   }
   
   async getDetailUrl(url) {
      const { data } = await axios.get(url);
      const $ = cheerio.load(data);
      
      const title = $('h3.section-header__content-text-title').text().trim();
      const subheadline = $('.article-page__article-subheadline').text().trim();
      const summary = $('.article-page__summary').text().trim();
      const reviewer = $('.article-page__reviewer').text().trim();
      const readTime = $('.article-page__reading-time').text().trim();
      const image = $('.article-page__image-container img').attr('src');
      
      return {
         title,
         subheadline,
         summary,
         review: reviewer,
         readTime,
         imageBase64: image,
      };
   }
}

exports.run = {
usage: ['halodoc', 'halodoc-obat', 'halodoc-detail'],
use: 'parameter',
category: 'tools',
async: async (m, { func, mecha }) => {
switch (m.command) {
case 'halodoc':{
if (!m.text) return m.reply(func.example(m.cmd, 'sariawan'))
mecha.sendReact(m.chat, '⌛', m.key);
let rows = [];
const Halodocc = new Halodoc(m.text);
const results = await Halodocc.getArtikelSearch();
if (results.length < 1) return m.reply('result data article not found.')
for (let [index, data] of results.entries()) {
rows.push({
// header: data.type,
title: `${index + 1}. ${data.title}`,
description: data.description,
id: `${m.prefix}halodoc-detail ${data.link}`
})
}
let sections = [{
title: 'PILIH HALODOC DIBAWAH',
rows: rows
}]
let buttons = [
['list', 'Click Here ⎙', sections],
]
mecha.sendButton(m.chat, 'HALODOC SEARCHING', `Result from: \`${m.text}\`\nTotal results: *${results.length}* article`, 'select the list button below.', buttons, m, {
expiration: m.expiration
})
}
break
case 'halodoc-obat':{
if (!m.text) return m.reply(func.example(m.cmd, 'sariawan'))
mecha.sendReact(m.chat, '⌛', m.key);
let rows = [];
const Halodocc = new Halodoc(m.text);
const results = await Halodocc.getObatSearch();
if (results.length < 1) return m.reply('result drug data not found.')
let caption = '*H A L O D O C - O B A T*'
results.forEach((item, index) => {
caption += `\n\n${index + 1}. ${item.title}
- Subtitle: ${item.subtitle}
- Price: ${item.price}
- Image: ${item.image}`;
// - Link: ${item.link}`;
})
mecha.reply(m.chat, caption, m, {
expiration: m.expiration
})
}
break
case 'halodoc-detail':{
if (!m.text) return m.reply(func.example(m.cmd, 'https://www.halodoc.com/artikel/cek-fakta-sakit-gigi-bisa-sebabkan-penyakit-jantung'))
if (!m.args[0].includes('https://www.halodoc.com/artikel/')) return m.reply(global.mess.error.api)
mecha.sendReact(m.chat, '⌛', m.key)
const Halodocc = new Halodoc();
let result = await Halodocc.getDetailUrl(m.args[0]);
let caption = `- Title : ${result.title}
- Subheadline : ${result?.subheadline?.trim()}
- Summary : ${result?.summary?.trim()}
- Review : ${result?.review?.trim()}
- Read Time :\n\n${result?.readTime?.trim()}`
const base64Data = result.imageBase64.replace(/^data:image\/png;base64,/, "");
// Mengonversi Base64 menjadi buffer
const buffer = Buffer.from(base64Data, 'base64');
mecha.sendMedia(m.chat, buffer, m, {
caption,
expiration: m.expiration
})
}
break
}
},
limit: true
}