const { proto } = require('@whiskeysockets/baileys');

exports.run = {
usage: ['sendch'],
hidden: ['sendchannel'],
use: 'text',
category: 'developer',
async: async (m, { func, mecha, users, setting }) => {
if (!users.hasOwnProperty('lastsendch')) {
users.lastsendch = 0;
}
if (!m.text) return m.reply(func.example(m.cmd, 'halo'))
async function sendMessageToChannel (text) {
let messages = {
extendedTextMessage: {
text: text,
mentions: mecha.ments(text),
contextInfo: {
mentionedJid: mecha.ments(text),
externalAdReply: {
title: 'System Notification',
body: global.header,
thumbnailUrl: setting.cover,
sourceUrl: '',
mediaType: 1,
renderLargerThumbnail: false
}
}
}
};
let messageToChannel = proto.Message.encode(messages).finish();
let result = {
tag: 'message',
attrs: {
to: '120363352779958494@newsletter',
type: 'text'
},
content: [
{
tag: 'plaintext',
attrs: {},
content: messageToChannel
}
]
};
return mecha.query(result);
}
let timing = func.pickRandom([900000, 1800000]);
let times = users.lastsendch + timing;
if (Date.now() - users.lastsendch < timing) return m.reply(`Kamu sudah sendch, mohon tunggu *${func.msToTime(times - Date.now())}* untuk bisa *sendch* kembali.`)
users.lastsendch = Date.now();
await sendMessageToChannel(m.text)
.then(() => mecha.sendReact(m.chat, '✅', m.key))
.catch(() => mecha.sendReact(m.chat, '❌', m.key))
},
devs: false
}