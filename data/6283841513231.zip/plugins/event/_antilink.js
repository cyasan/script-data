exports.run = {
    main: async (m, {
        func,
        mecha,
        groups,
        errorMessage
    }) => {
        try {
            // remove link then kick when antilink is turned on
            if (m.budy && groups.antilink && !m.isAdmin && !m.isOwner) {
                if (m.budy.match(/(chat.whatsapp.com)/gi) && !['https://chat.whatsapp.com/BgrnHVRRpRaJKHN7AxGYEa', 'https://chat.whatsapp.com/' + await mecha.groupInviteCode(m.chat)].includes(m.budy)) return mecha.sendMessage(m.chat, {
                        delete: {
                            remoteJid: m.chat,
                            fromMe: false,
                            id: m.key.id,
                            participant: m.sender
                        }
                    })
                    .then(() => mecha.sendMessage(m.chat, {
                        text: `Sorry @${m.sender.split('@')[0]} you will be removed from this group.`,
                        mentions: [m.sender]
                    }, {
                        quoted: func.fstatus('Anti Tautan Grup Lain'),
                        ephemeralExpiration: m.expiration
                    }))
                    .then(() => mecha.groupParticipantsUpdate(m.chat, [m.sender], 'remove'))
            }

            if (m.budy && m.budy.match(/(whatsapp.com\/channel)/gi) && !m.isAdmin && !m.isOwner) {
                return await mecha.sendMessage(m.chat, {
                    delete: {
                        remoteJid: m.chat,
                        fromMe: false,
                        id: m.key.id,
                        participant: m.sender
                    }
                })
            } else {
                const newsletterMessage = m.msg?.contextInfo?.forwardedNewsletterMessageInfo;
                if (newsletterMessage && !m.isAdmin && !m.isOwner) {
                    if (['120363261409301854@newsletter'].includes(newsletterMessage.newsletterJid)) return false;
                    let text = `*Newsletter Message Detected*

- Jid: ${newsletterMessage.newsletterJid}
- Name: ${newsletterMessage.newsletterName}`
                    mecha.reply(m.chat, text, m, {
                        expiration: m.expiration
                    })
                    return await mecha.sendMessage(m.chat, {
                        delete: {
                            remoteJid: m.chat,
                            fromMe: false,
                            id: m.key.id,
                            participant: m.sender
                        }
                    })
                }
            }

            if (m.budy && m.budy.match(/(t.me\/Xin_Kenji|NekoHost menyediakan|menyediakan layanan hosting|Kalian Butuh Server|Nyari Server murah dan Berkualitas)/gi) && !m.isAdmin && !m.isOwner) {
                return await mecha.sendMessage(m.chat, {
                    delete: {
                        remoteJid: m.chat,
                        fromMe: false,
                        id: m.key.id,
                        participant: m.sender
                    }
                })
            }

            // it only removes links when antilink is turned off
            if (m.budy && !groups.antilink && !m.isAdmin && !m.isOwner) {
                if (m.budy.match(/(chat.whatsapp.com)/gi) && !m.budy.includes(await mecha.groupInviteCode(m.chat))) return await mecha.sendMessage(m.chat, {
                    delete: {
                        remoteJid: m.chat,
                        fromMe: false,
                        id: m.key.id,
                        participant: m.sender
                    }
                })
            }
        } catch (error) {
            return errorMessage(error)
        }
    },
    group: true,
    botAdmin: true,
    location: 'plugins/event/_antilink.js'
}