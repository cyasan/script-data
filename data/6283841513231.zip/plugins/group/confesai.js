const axios = require('axios');

exports.run = {
    usage: ['confesai'],
    hidden: ['confessai'],
    use: 'groupid,perasaan',
    category: 'group',
    async: async (m, {
        func,
        mecha
    }) => {
        if (!m.text) return m.reply(func.example(m.cmd, 'Id grup|kecewa'));
        mecha.sendReact(m.chat, '⌛', m.key)
        let [groupId, perasaan] = m.text.split('|').map(t => t.trim());
        if (!(groupId && perasaan)) return m.reply(`Format salah!\nContoh: ${m.prefix}confesai id grup@g.us|kecewa`);

        try {
            let groupMeta = await mecha.groupMetadata(groupId).catch(() => null);
            if (!groupMeta) return m.reply('bot tidak bisa akses grup tersebut.');

            const prompt = `Kamu adalah AI curhat yang bikin confess kayak anak Gen Z lagi galau di grup. 
        Perasaan pengguna saat ini: ${perasaan}. 
        Buat teks confess yang dikirim **kalimat pendek banget (1-2 kata per pesan)**.
        Pakai bahasa sehari-hari yang gaul, tambahkan jeda dramatis, typo kecil yang dikoreksi, dan efek mikir.`;

            let response = (await axios.post('https://luminai.my.id/', {
                content: perasaan,
                user: m.sender,
                prompt: prompt
            })).data.result;

            const metadata = global.db.metadata[groupId];
            if (!metadata) return m.reply('metadata grup tersebut tidak ada.');
            const expiration = metadata.ephemeralDuration || 0;
            let messages = response.split('\n').filter(line => line.trim());

            await mecha.sendPresenceUpdate('composing', groupId);
            const array = [mecha, ...Object.values(global.jadibot).filter(x => x.user)];
            const repeatedArray = repeatArray(array, 10);
            for (let index = 0; index < messages.length; index++) {
                try {
                    const client = repeatedArray[index];
                    if (!client || !client.user) continue;
                    let msg = messages[index];

                    await func.delay(1500 + Math.floor(Math.random() * 3000));
                    let sentMessage;
                    sentMessage = await client.sendMessage(groupId, {
                        text: msg
                    }, {
                        quoted: null,
                        ephemeralExpiration: expiration
                    }).catch(async (e) => {
                        await func.delay(1500);
                        sentMessage = await client.sendMessage(groupId, {
                            text: msg
                        }, {
                            quoted: null,
                            ephemeralExpiration: expiration
                        })
                        // m.reply(`Gagal kirim pesan!\n- ${e.message}`)
                    });

                    if (index === 2 && msg.includes("gatau")) {
                        await client.sendMessage(groupId, {
                            delete: {
                                remoteJid: groupId,
                                fromMe: true,
                                id: sentMessage.key.id
                            }
                        });
                        await func.delay(3000);
                        await client.sendMessage(groupId, {
                            text: "Gatau... eh, gatau sih. Tapi ya... 😕"
                        }, {
                            quoted: null,
                            ephemeralExpiration: expiration
                        });
                    }

                    /*if (index === 7) {
                        await func.delay(5000);
                        try {
                            await client.sendMessage(groupId, {
                                audio: {
                                    url: 'https://files.catbox.moe/2trq3w.mp3'
                                },
                                mimetype: 'audio/mpeg',
                                ptt: true
                            }, {
                                quoted: null,
                                ephemeralExpiration: expiration
                            });
                        } catch (err) {
                            console.log("Gagal ngirim audio, lanjut teks...");
                        }
                    }*/

                    if (index % 5 === 0 && index !== 0) await func.delay(5000);
                } catch (error) {
                    console.error(error);
                    continue;
                }
            }
            await mecha.sendMessage(groupId, {
                audio: {
                    url: 'https://files.catbox.moe/2trq3w.mp3'
                },
                mimetype: 'audio/mpeg',
                ptt: true
            }, {
                quoted: null,
                ephemeralExpiration: expiration
            });
            mecha.reply(m.chat, `Successful confession to group “${metadata.subject}“`, m, {
                expiration: m.expiration
            })
        } catch (err) {
            m.reply(`Gagal confess ke grup!\n\nError: ${err.message}\nStack: ${err.stack}`);
        }
    },
    location: 'plugins/group/confesai.js'
}

function repeatArray(arr, times) {
    const result = [];
    for (let i = 0; i < times; i++) {
        result.push(...arr); // Menambahkan seluruh elemen array ke hasil
    }
    return result;
}