const fs = require('fs');
let isAdded = false;

exports.run = {
usage: ['addmember'],
category: 'group',
async: async (m, { func, mecha }) => {
mecha.addmember = mecha.addmember ? mecha.addmember : {};
mecha.addmember[m.chat] = {};
if (global.db && !global.db.hasOwnProperty('members')) {
global.db.members = [];
}
if (isAdded) return m.reply('addmember sebelumnya masih berlangsung, silahkan tunggu sampai selesai.')
let amounts = 100;
let captions = '';
let [amount, ...params] = m.text.split(' ');
if (!amount) return m.reply('Input slice amount\n\n' + func.example(m.cmd, '500'));
if (amount && !isNaN(amount)) amounts = parseInt(amount);
if (params.length > 0) captions = params.join(' ');
const userData = [
  '6285194293890@s.whatsapp.net',
  '6283871476999@s.whatsapp.net'
]
const membersData = userData.filter(jid => ![...global.db.members].includes(jid)).slice(0, amounts);

let database = mecha.addmember[m.chat];
let meta = await (await mecha.groupMetadata(m.chat));
try {
let memberData = (await Promise.all(membersData.map(v => v.replace(/[^0-9]/g, '')).filter(v => v.length > 4 && v.length < 20).map(async (v) => [v, await mecha.onWhatsApp(v + '@s.whatsapp.net')]))).filter(v => v[1][0]?.exists).map(v => v[0] + '@s.whatsapp.net')
if (memberData.length == 0) return m.reply('Empty data.');
await mecha.reply(m.chat, `Menambahkan *${memberData.length}* peserta ke dalam grup "${meta.subject}".`, m, {
expiration: m.expiration
});
for (let jid of memberData) {
database[jid] = {
jid: jid,
status: null
};
}
await new Promise(resolve => setTimeout(resolve, 3000));
const thumbnail = await mecha.profilePictureUrl(m.chat, 'image').catch(_ => 'https://telegra.ph/file/0d25a520bfa0909c74466.jpg');
const addParticipants = async (jid) => {
await mecha.groupParticipantsUpdate(m.chat, [jid], 'add').then(async (response) => {
for (let item of response) {
if (item.status == 403){ // di privasi
await mecha.sendGroupInvite(m.chat, item.jid, {
inviteCode: item.content.content[0].attrs.code,
inviteExpiration: item.content.content[0].attrs.expiration,
groupName: meta.subject,
jpegThumbnail: thumbnail,
caption: captions ? captions : 'Undangan untuk bergabung ke grup WhatsApp saya',
quoted: null
})
database[item.jid].status = item.status;
} else if (item.status == 409){ // sudah ada di grup
database[item.jid].status = item.status;
} else if (item.status == 408){ // keluar baru baru ini
database[item.jid].status = item.status;
} else if (item.status == 401){ // diblock
database[item.jid].status = item.status;
} else {
database[item.jid].status = item.status;
}
}
});
}
broadcastMessage(memberData, addParticipants, m.chat);
} catch (error) {
console.log(error);
return mecha.reply(m.chat, `Terjadi kesalahan:\n${func.jsonFormat(error)}`, m, {
expiration: m.expiration
})
}
function broadcastMessage(participantData, addedParticipants, chatId) {
isAdded = true;
let old = new Date();
let failed = 0;
let index = 0;

async function addParticipants() {
if (index < participantData.length) {
try {
global.db.members.push(participantData[index]);
console.log('add member:', participantData[index]);
await addedParticipants(participantData[index]);
} catch (error) {
console.log(error.message);
failed++;
};
index++;
let delay = 10000; // Default delay 10 detik
if (index % 10 === 0) {
delay = 60000; // Jeda 60 detik setiap kelipatan 10
console.log('Jeda 60 detik setiap setiap kelipatan 10...');
}
if (index % 100 === 0) {
delay += 10000; // Tambah 10 detik jika kelipatan 100
console.log('Jeda bertambah 10 detik untuk kelipatan 100...');
}
setTimeout(addParticipants, delay);
} else {
isAdded = false;
let blocked = Object.values(database).filter(x => x.status == 401);
let diprivasi = Object.values(database).filter(x => x.status == 403);
let barukeluar = Object.values(database).filter(x => x.status == 408);
let udahada = Object.values(database).filter(x => x.status == 409);
let sukses = Object.values(database).filter(x => x.status == 200);
let caption = `Successfully added ${member.length} participant into group ${meta.subject} in *${Math.floor(((new Date - old) / 1000))}* seconds.\n- Success: ${(index - failed) + (failed > 0 ? `\n- Failed: ${failed}` : '')}`
if (sukses.length > 0) caption += '\n\nMember yang berhasil ditambahkan :\n' + sukses.map((item, index) => `- ${index + 1}. @${item.jid.split('@')[0]}`).join('\n')
if (udahada.length > 0) caption += '\n\nMember yang sudah ada di grup :\n' + udahada.map((item, index) => `- ${index + 1}. @${item.jid.split('@')[0]}`).join('\n')
if (barukeluar.length > 0) caption += '\n\nMember yang keluar baru baru ini :\n' + barukeluar.map((item, index) => `- ${index + 1}. @${item.jid.split('@')[0]}`).join('\n')
if (diprivasi.length > 0) caption += '\n\nMember yang privasi invite :\n' + diprivasi.map((item, index) => `- ${index + 1}. @${item.jid.split('@')[0]}`).join('\n')
if (blocked.length > 0) caption += '\n\nMember yang memblokir bot :\n' + blocked.map((item, index) => `- ${index + 1}. @${item.jid.split('@')[0]}`).join('\n')
await mecha.reply(chatId, caption.trim(), m, {
expiration: m.expiration
});
}
}

addParticipants();
}
},
devs: true,
group: true,
botAdmin: true
}