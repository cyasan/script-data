const similarity = require('similarity');
const gamesUrl = 'https://raw.githubusercontent.com/Jabalsurya2105/database/master/games/susunkata.json';
const sensitive = 0.75;
let keyId = {};
let alreadyAnswered = new Set;

exports.run = {
    usage: ['susunkata'],
    hidden: ['skata'],
    category: 'games',
    async: async (m, {
        func,
        mecha,
        setting,
        users
    }) => {
        mecha.susunkata = mecha.susunkata || {};
        if (func.ceklimit(m.sender, 1)) return m.reply(global.mess.limit)
        if (m.chat in mecha.susunkata) return mecha.reply(m.chat, 'Masih ada soal belum terjawab di chat ini', keyId[m.chat], {
            expiration: m.expiration
        });
        let data = await fetch(gamesUrl).then(response => response.json());
        let {
            soal,
            jawaban
        } = data.result.random();
        let hadiah = func.hadiah(setting.hadiah);
        let id = Date.now();
        alreadyAnswered.clear();
        let caption = `乂 *GAMES SUSUN KATA*\n\n${func.texted('monospace', soal)}\n${users.premium ? '\nPetunjuk: ' + func.createClue(jawaban) : ''}\nHadiah: $${hadiah} balance\nWaktu: ${setting.gamewaktu} detik`
        keyId[m.chat] = await mecha.reply(m.chat, caption, m, {
            expiration: m.expiration
        });
        mecha.susunkata[m.chat] = {
            id: id,
            soal: soal,
            jawaban: jawaban.toLowerCase(),
            hadiah: hadiah,
            nextQuestion: 1,
            timeout: setTimeout(async function() {
                let gameData = mecha.susunkata[m.chat];
                if (gameData.id == id) {
                    mecha.reply(m.chat, `Waktu habis!\n\nJawabannya adalah: ${func.texted('monospace', jawaban)}`, keyId[m.chat], {
                        expiration: m.expiration
                    }).then(async () => {
                        if (keyId[m.chat]) {
                            await func.delay(1500).then(async () => await mecha.sendMessage(m.chat, {
                                delete: keyId[m.chat].key
                            }))
                        }
                    })
                    delete mecha.susunkata[m.chat];
                }
            }, setting.gamewaktu * 1000)
        }
    },
    main: async (m, {
        func,
        mecha,
        setting,
        users
    }) => {
        // Games Susun Kata By SuryaDev
        mecha.susunkata = mecha.susunkata || {};
        if ((m.chat in mecha.susunkata) && !m.fromMe && !m.isPrefix) {
            let gameData = mecha.susunkata[m.chat];
            if (similarity(gameData.jawaban, m.budy.toLowerCase()) >= sensitive) {
                if (alreadyAnswered.has(gameData.jawaban)) return mecha.sendReact(m.chat, '🥴', m.key);
                alreadyAnswered.add(gameData.jawaban);
                // mecha.sendReact(m.chat, '✅', m.key)
                users.balance += gameData.hadiah;
                users.game.susunkata++;
                gameData.nextQuestion++;
                if (gameData.timeout) clearTimeout(gameData.timeout);
                let key;
                if (users.limit < 1) {
                    let price = setting.limit.price;
                    if (users.balance > price) {
                        users.balance -= price;
                        key = await mecha.reply(m.chat, `Sistem otomatis mengambil \`${price} balance\` kamu sebagai pengganti limit.`, m, {
                            expiration: m.expiration
                        })
                        await new Promise(resolve => setTimeout(resolve, 1000));
                    } else {
                        delete mecha.susunkata[m.chat];
                        return await mecha.reply(m.chat, 'Soal dihentikan karena limit & balance kamu sudah habis.', m, {
                            expiration: m.expiration
                        })
                    }
                } else {
                    users.limit -= 1;
                    /*if (keyId[m.chat]) await mecha.sendMessage(m.chat, {
                        delete: keyId[m.chat].key
                    })*/
                }
                let data = await fetch(gamesUrl).then(response => response.json());
                let result = data.result.random();
                let hadiah = func.hadiah(setting.hadiah);
                let id = Date.now();
                alreadyAnswered.clear();
                let caption = `*LANJUT SOAL KE-${gameData.nextQuestion}*\n\n${func.texted('monospace', result.soal)}\n${users.premium ? '\nPetunjuk: ' + func.createClue(result.jawaban) : ''}\nHadiah: $${hadiah} balance\nWaktu: ${setting.gamewaktu} detik`
                let message;
                message = await mecha.sendMessage(m.chat, {
                    text: caption,
                    ...(key ? {
                        edit: key
                    } : {}),
                }, {
                    quoted: m,
                    ephemeralExpiration: m.expiration
                }).catch(async () => {
                    await func.delay(1500);
                    message = await mecha.sendMessage(m.chat, {
                        text: caption,
                        /*...(key ? {
                            edit: key
                        } : {}),*/
                    }, {
                        quoted: m,
                        ephemeralExpiration: m.expiration
                    })
                })
                keyId[m.chat] = message;
                Object.assign(gameData, {
                    id: id,
                    soal: result.soal,
                    jawaban: result.jawaban.toLowerCase(),
                    hadiah: hadiah,
                    timeout: setTimeout(function() {
                        if (gameData.id == id) {
                            mecha.reply(m.chat, `Waktu habis!\n\nJawabannya adalah: ${func.texted('monospace', result.jawaban)}`, keyId[m.chat], {
                                expiration: m.expiration
                            }).then(async () => {
                                if (keyId[m.chat]) {
                                    await func.delay(1500).then(async () => await mecha.sendMessage(m.chat, {
                                        delete: keyId[m.chat].key
                                    }))
                                }
                            })
                            delete mecha.susunkata[m.chat];
                        }
                    }, setting.gamewaktu * 2000)
                })
                if (mecha.susunkata[m.chat]) return false;
            } else if (/conversation|extendedTextMessage/.test(m.mtype) && setting.incorrect) {
                await mecha.sendReact(m.chat, '❌', m.key)
            }
        }
    },
    location: 'plugins/games/susunkata.js'
}