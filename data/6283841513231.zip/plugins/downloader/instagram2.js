const axios = require('axios');
const cheerio = require('cheerio');

function instagram(url) {
return new Promise(async(resolve,reject) => {
try {
let res = await axios("https://indown.io/");
let _$ = cheerio.load(res.data);
let referer = _$("input[name=referer]").val();
let locale = _$("input[name=locale]").val();
let _token = _$("input[name=_token]").val();
let { data } = await axios.post("https://indown.io/download", new URLSearchParams({ link: url, referer, locale, _token }), { headers: { cookie: res.headers["set-cookie"].join("; ") }});
let $ = cheerio.load(data);
let result = [];
let __$ = cheerio.load($("#result").html());
__$("video").each(function () {
let $$ = $(this);
result.push({
type: "video",
thumbnail: $$.attr("poster"),
url: $$.find("source").attr("src"),
});
});
__$("img").each(function () {
let $$ = $(this);
result.push({
type: "image",
url: $$.attr("src"),
});
});
resolve({ status: true, result: result })
} catch (e) {
console.log(e)
reject({ status: false, msg: e })
}
})
}

exports.run = {
usage: ['instagram2'],
hidden: ['igdl2'],
use: 'link instagram',
category: 'downloader',
async: async (m, { func, mecha }) => {
if (!m.text) return m.reply(func.example(m.cmd, 'https://www.instagram.com/reel/C2HyV6LhC6Q/?igsh=MXFydzJqcDFiNjF5eA=='))
if (!m.text.includes('instagram.com')) return m.reply(mess.error.url)
mecha.sendReact(m.chat, '⌛', m.key)
let url = func.isUrl(m.text)
await instagram(url[0]).then(async (res) => {
if (!res.status) return m.reply(global.mess.error.api)
for (let i of res.result) {
await mecha.sendMedia(m.chat, i.url, m, { caption: global.mess.ok, expiration: m.expiration })
}
}).catch((e) => m.reply(global.mess.error.api))
},
premium: true,
limit: 5
}