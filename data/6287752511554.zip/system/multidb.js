const fs = require('fs');

module.exports = class MultiDB {
    constructor() {
        this.MongoURL = global.mongoUrl;
        this.init = (this.MongoURL && /mongo/.test(this.MongoURL)) ? new(require('./mongodb'))(this.MongoURL) : new(require('./localdb'))();
    }

    initDatabase = async () => {
        let content = {};

        try {
            if (!(this.MongoURL && /mongo/.test(this.MongoURL))) {
                const data = fs.readFileSync('./database/database.json', 'utf8');
                content = JSON.parse(data);
            }
        } catch (error) {
            console.error("Error reading database file:", error);
        }

        // Load database
        global.db = {
            users: {},
            groups: {},
            statistic: {},
            sticker: {},
            stickercmd: {},
            setting: {},
            register: {},
            menfes: {},
            tictactoe: {},
            petakbom: {},
            casino: {},
            werewolf: {},
            chess: {},
            sambungkata: {},
            opentime: {},
            closetime: {},
            metadata: {},
            jadibot: [],
            premium: [],
            sewabot: [],
            owner: [],
            ...(await this.init.read() || content)
        };

        // Save database
        await this.init.save(global.db);
    }
};