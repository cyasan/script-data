// nomor owner ubah nomor lu
global.owner = '6282278088233@s.whatsapp.net'
// nama owner ubah nama lu
global.ownerName = '✰Nathzz✰'
// nomor pengembang yang bisa akses fitur saveplugin, delplugin, getplugin dan eval
global.developer = [
// ganti nomor lu tapi jangan asal add nomor, nanti bisa curi kode bot
    '6282278088233',
    '6282281564519',
].map(number => number.replace(/[^0-9]/g, '') + '@s.whatsapp.net')
// nama bot lu
global.botName = '友|•𝐍𝐞𝐤𝐨𝐜𝐡𝐚𝐧 𝐌𝐃'
// fake pada beberapa fitur
global.fake = 'Copyright © 2024 ✰Nathzz✰'
// header pada beberapa fitur
global.header = `友|•𝐍𝐞𝐤𝐨𝐜𝐡𝐚𝐧 𝐌𝐃 v${require('./package.json').version}`
// footer pada beberapa fitur
global.footer = 'ꜱɪᴍᴘʟᴇ ᴡʜᴀᴛꜱᴀᴘᴘ ʙᴏᴛ ᴍᴀᴅᴇ ʙʏ ɴᴀᴛʜᴀɴ'
// jeda anti spam / detik
global.cooldown = 1
// ram maksimal untuk auto restart / gb
global.max_ram = 3
// blacklist nomor dengan kode negara tersebut
global.blocks = ['91', '92', '212']
// multi prefix default
global.prefixes = /^[°•π÷×¶∆£¢€¥®™+✓_=|/~!?@#%^&.©^]/i
// setting id channel (cara ambil: ketik .getidch lalu teruskan pesan dari saluranmu ke bot.
global.newsletter = '120363294067531884@newsletter'
// qris url di beberapa fitur seperti donate, buyprem dan sewabot
global.qrisUrl = 'https://files.catbox.moe/1md5j5.jpg'
// audio url yang ada di menu
global.audioUrl = 'https://files.catbox.moe/vdeg6p.aac';
// setting pairing code
global.pairing = {
    copyFromLink: true, // ubah true jika ingin salin pairing via link https://iyaudah-iya.vercel.app/pairing
    status: true, // ubah false jika ingin menggunakan qr
    number: '6287752511554', // ubah jadi nomor bot lu
    code: 'NEKOMDV2'
}
// setting configuration baileys
global.config = {
    session: 'session',
    online: true,
    version: [2, 3000, 1015901307],
    browser: ['Windows', 'Chrome', '22.04.4']
}
// apikey fitur quickchat
global.quoteApi = 'https://bot.lyo.su/quote/generate'
// url database mongodb (daftar di https://www.mongodb.com/)
global.mongoUrl = ''
// setting message
global.mess = {
    wait: 'Diproses . . .',
    ok: 'Berhasil.',
    limit: 'Anda telah mencapai limit dan akan disetel ulang pada pukul 00.00\n\n> untuk mendapatkan limit tak terbatas, tingkatkan ke paket premium.',
    premium: 'Fitur ini hanya untuk pengguna premium.',
    jadibot: 'Fitur ini hanya untuk pengguna jadibot.',
    owner: 'Fitur ini diblokir oleh owner!.',
    devs: 'Fitur ini hanya untuk developer.',
    group: 'Fitur ini hanya bisa digunakan di dalam grup.',
    private: 'Gunakan fitur ini dalam obrolan pribadi.',
    admin: 'Fitur ini hanya untuk admin grup.',
    botAdmin: 'Fitur ini akan berfungsi ketika saya menjadi admin',
    gconly: 'Bot hanya dapat digunakan di dalam grup.',
    bot: 'Fitur ini hanya dapat diakses oleh bot',
    wrong: 'Format salah!',
    error: {
        url: 'URL Tidak Valid!',
        api: 'Maaf terjadi kesalahan!'
    },
    block: {
        owner: `Fitur ini diblokir oleh owner!`,
        system: `Fitur ini diblokir oleh sistem karena terjadi kesalahan!`
    },
    query: 'Masukkan teks pencarian',
    search: 'Mencari . . .',
    scrap: 'Scrapping . . .',
    wrongFormat: 'Format yang salah, tolong lihat menu lagi',
    game: 'Bermain game di obrolan pribadi hanya untuk pengguna premium, tingkatkan ke paket premium hanya Rp. 20.000 selama 1 bulan.'
}

// menghapus cache setelah update
require('./system/functions.js').reloadFile(__filename);