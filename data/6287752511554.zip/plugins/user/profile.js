const fetch = require('node-fetch');

exports.run = {
usage: ['profile'],
hidden: ['profil'],
use: 'mention or reply',
category: 'user',
async: async (m, { func, mecha, froms, setting }) => {
let number = isNaN(m.text) ? (m.text.startsWith('+') ? m.text.replace(/[()+\s-]/g, '') : m.text.split('@')[1]) : m.text
if (!m.text && !m.quoted) return m.reply('Mention or Reply chat target.')
if (isNaN(number)) return m.reply('Invalid number.')
if (number.length > 15) return m.reply('Invalid format.')
if (global.db.users[froms] == undefined) return m.reply('User data not found.')
if (global.db.users[global.db.users[froms].pasangan.id] == undefined) global.db.users[froms].pasangan.id = ''
let { name, gender, age, limit, balance, premium, banned, jadibot, warning, register, date, pasangan, expired, level, exp, role } = global.db.users[froms]
let pacar = `ʙᴇʀᴘᴀᴄᴀʀᴀɴ ᴅᴇɴɢᴀɴ @${pasangan.id.split('@')[0]}`
let pacarnya = pasangan.id ? (global.db.users[pasangan.id].pasangan.id ? pacar : 'sᴇᴅᴀɴɢ ᴅɪɢᴀɴᴛᴜɴɢ @' + pasangan.id.split('@')[0]) : 'ᴄɪᴇᴇ ᴊᴏᴍʙʟᴏ ᴀʙᴀᴅɪ🫵🏻🤣'
try {
var about = (await mecha.fetchStatus(froms).catch(_ => {}) || {}).status || '';
} catch {
var about = '-';
}
let listblock = await mecha.fetchBlocklist().catch((_) => []);
let caption = `᳇• *U S E R - P R O F I L E*

    ◈ *ɴᴀᴍᴇ* : ${name ? name : '-'}
    ◈ *ɢᴇɴᴅᴇʀ* : ${gender ? gender : '-'}
    ◈ *ᴜᴍᴜʀ* : ${age ? age : '-'}
    ◈ *ʟɪᴍɪᴛ* : ${limit}
    ◈ *ʙᴀʟᴀɴᴄᴇ* : ${func.formatNumber(balance)}
    ◈ *ʟᴇᴠᴇʟ* : ${level}
    ◈ *ᴇxᴘ* : ${exp} / ${10 * Math.pow(level, 2) + 50 * level + 100}
    ◈ *ʀᴏʟᴇ* : ${role}
    ◈ *ʟᴏᴠᴇʀs* : ${pacarnya}
    ◈ *ᴀʙᴏᴜᴛ* : ${about ? about : '-'}

᳇• *U S E R - S T A T U S*

    ◈ *ᴡᴀʀɴɪɴɢ* : ${warning} / 3
    ◈ *ʙʟᴏᴄᴋᴇᴅ* : ${listblock.includes(froms) ? 'ʏᴇs' : 'ɴᴏ'}
    ◈ *ʙᴀɴɴᴇᴅ* : ${banned ? 'ʏᴇs (' + (expired.banned == 'PERMANENT' ? 'PERMANENT' : func.timeReverse(expired.banned)) + ')' : 'ɴᴏ'}
    ◈ *ᴘʀᴇᴍɪᴜᴍ* : ${premium ? 'ʏᴇs (' + (expired.premium == 'PERMANENT' ? 'PERMANENT' : func.timeReverse(expired.premium)) + ')' : 'ɴᴏ'}
    ◈ *ᴊᴀᴅɪʙᴏᴛ* : ${jadibot ? 'ʏᴇs (' + (expired.jadibot == 'PERMANENT' ? 'PERMANENT' : func.timeReverse(expired.jadibot)) + ')' : 'ɴᴏ'}
    ◈ *ʀᴇɢɪsᴛᴇʀ* : ${register ? 'ʏᴇs (' + date + ')': 'ɴᴏ'}`
await (setting.fakereply ? mecha.sendMessageModify(m.chat, caption, m, {
largeThumb: true, 
thumbnail: await (await fetch(await mecha.profilePictureUrl(froms, 'image').catch(_ => 'https://telegra.ph/file/0d25a520bfa0909c74466.jpg'))).buffer(),
expiration: m.expiration
}) : m.reply(caption))
},
group: true
}