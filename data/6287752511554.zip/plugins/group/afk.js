exports.run = {
    usage: ['afk', 'listafk'],
    category: 'group',
    async: async (m, {
        func,
        mecha,
        users
    }) => {
        switch (m.command) {
            case 'afk':
                users.afk = +new Date;
                users.alasan = m.text ? m.text : '';
                users.afkObj = {
                    key: m.key,
                    message: m.message
                }
                mecha.reply(m.chat, `${m.pushname} sedang AFK${m.text ? '\nAlasan: ' + m.text : ''}`, m, {
                    expiration: m.expiration
                })
                break
            case 'listafk':
                let afkdata = Object.values(global.db.users).filter(v => v.afk > 0)
                if (afkdata.length == 0) return m.reply('Empty data.')
                let caption = `乂  *LIST USER AFK*\nTotal : *${afkdata.length}*\n`
                caption += afkdata.map((v, i) => `\n${i + 1}. @${v.jid.split('@')[0]}\n◦  Reason: ${v.alasan ? v.alasan : 'tanpa alasan'}\n◦  Selama: ${func.clockString(Date.now() - v.afk)}`).join('\n')
                mecha.reply(m.chat, caption, m, {
                    expiration: m.expiration
                })
                break
        }
    },
    group: true,
    location: 'plugins/group/afk.js'
}