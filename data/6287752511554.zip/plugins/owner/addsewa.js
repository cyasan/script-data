let toMs=require("ms"),getBinaryNodeChild=require("@whiskeysockets/baileys").getBinaryNodeChild;exports.run={usage:["addsewa","delsewa"],use:"parameter",category:"owner",async:async(t,{func:s,mecha:i,errorMessage:r})=>{async function e(e){try{var a,t,s=/chat.whatsapp.com\/([0-9A-Za-z]{20,24})/i,[,r]=e.match(s)||[];return r?(a=await i.query({tag:"iq",attrs:{type:"get",xmlns:"w:g2",to:"@g.us"},content:[{tag:"invite",attrs:{code:r}}]}),{status:!0,code:r,groupId:(t=getBinaryNodeChild(a,"group"))?.attrs?.id.includes("@")?t?.attrs?.id:t?.attrs?.id+"@g.us"}):{status:!1,message:"No invite url detected."}}catch(e){return{status:!1,message:e.message}}}switch(t.command){case"addsewa":var[p,u]=t.args;if(/^\d.*(@g\.us)$/.test(t.chat)){var d=global.db.groups[t.chat];if(void 0===d)return t.reply("Group data not found.");if(/^(vip)$/i.test(p)){if(d&&d.sewa&&!d.sewa.status)return t.reply("Grup ini tidak ada di data sewa.");if(d&&d.sewa&&d.sewa.status&&d.sewa.vip)return t.reply("Already rented VIP!");d.sewa.vip=!0,i.reply(t.chat,"Successfully added rent `VIP` to this group.",t,{expiration:t.expiration})}else{var o=p?Date.now()+toMs(p):1/0;if(d&&d.sewa&&d.sewa.status)return t.reply("Grup tersebut sudah ada di data sewa.");d.sewa.status=!0,d.sewa.notice=!0,d.sewa.expired=o,i.reply(t.chat,"Successfully added rent to this group for "+(p||"30d"),t,{expiration:t.expiration})}}else if(/^https:\/\/chat\.whatsapp\.com\/[A-Za-z0-9]+/.test(p)){d=await e(p);if(!d.status)return t.reply(d.message);let a=d.groupId;o=global.db.groups[a];if(void 0===o)return t.reply("Group data not found.");if(/^(vip)$/i.test(u)){if(o&&o.sewa&&!o.sewa.status)return t.reply("Grup ini tidak ada di data sewa.");if(o&&o.sewa&&o.sewa.status&&o.sewa.vip)return t.reply("Already rented VIP!");o.sewa.vip=!0,i.reply(t.chat,"Successfully added rent `VIP` to this group.",t,{expiration:t.expiration}).then(async()=>{i.reply(a,"This group successfully rented bot `VIP`.",s.fverified,{expiration:t.expiration})})}else{p=d.code,o=await i.groupFetchAllParticipating();if(!Object.values(o).map(e=>e.id).includes(a))try{await i.groupAcceptInvite(p)}catch{}try{let e=u||"30d";var n=u?Date.now()+toMs(u):1/0,l=(w=a,"object"!=typeof(c=global.db.groups[w])&&(global.db.groups[w]={jid:w,sewa:{status:!1,notice:!1,vip:!1,expired:0}}),c);if(void 0===l)return t.reply("Group data not found.");if(l.sewa&&l.sewa.status)return t.reply("Grup tersebut sudah ada di data sewa.");l.sewa.status=!0,l.sewa.notice=!0,l.sewa.expired=n,i.reply(t.chat,"Successfully added rent to this group for "+e,t,{expiration:t.expiration}).then(async()=>{i.reply(a,"This group successfully rented bot for "+e,s.fverified,{expiration:t.expiration})})}catch(e){return String(e).includes("not-authorized")?t.reply("Masukkan bot kedalam grup tersebut terlebih dahulu."):r(e)}}}else{d=`Contoh penggunaan:


*in private chat*:
- ${t.prefix}addsewa <link grup> vip
_bot akan disewa \`VIP\` oleh grup tersebut_.
- addsewa <link grup> 30d
_bot akan disewa selama 30 day oleh grup tersebut_.

*in group chat*:
- ${t.prefix}addsewa vip
_bot akan disewa \`VIP\` oleh grup ini.
- ${t.prefix}addsewa 30d
_bot akan disewa selama 30 day oleh grup ini_.`;i.reply(t.chat,d,t,{expiration:t.expiration})}break;case"delsewa":var[o,p]=t.args;if(/^\d.*(@g\.us)$/.test(t.chat)){u=global.db.groups[t.chat];if(void 0===u)return t.reply("Group data not found.");if(!!/^(vip)$/i.test(o)){if(u&&u.sewa&&!u.sewa.status)return t.reply("Grup ini tidak ada di data sewa.");if(u&&u.sewa&&!u.sewa.vip)return t.reply("VIP data not found.");u.sewa.vip=!1,i.reply(t.chat,"Successfully deleted rent `VIP` to this group.",t,{expiration:t.expiration})}else{if(u&&u.sewa&&!u.sewa.status)return t.reply("Grup ini tidak ada di data sewa.");u.sewa.expired=0,u.sewa.status=!1,u.sewa.notice=!1,u.sewa.vip=!1,i.reply(t.chat,"Successfully deleted rent to this group.",t,{expiration:t.expiration})}}else if(/^https:\/\/chat\.whatsapp\.com\/[A-Za-z0-9]+/.test(o)){w=await e(o);if(!w.status)return t.reply(w.message);c=global.db.groups[w.groupId];if(void 0===c)return t.reply("Group data not found.");if(/^(vip)$/i.test(p)){if(c&&c.sewa&&!c.sewa.status)return t.reply("Grup tersebut tidak ada di data sewa.");if(c&&c.sewa&&!c.sewa.vip)return t.reply("VIP data not found.");c.sewa.vip=!1,i.reply(t.chat,"Successfully deleted rent `VIP` to this group.",t,{expiration:t.expiration})}else{if(c&&c.sewa&&!c.sewa.status)return t.reply("Grup tersebut tidak ada di data sewa.");c.sewa.expired=0,c.sewa.status=!1,c.sewa.notice=!1,i.reply(t.chat,"Successfully deleted rent to this group.",t,{expiration:t.expiration})}}else{l=`Contoh penggunaan:


*in private chat*:
- ${t.prefix}delsewa <link grup> vip
_menghapus status sewabot \`VIP\` pada grup tersebut_.
- ${t.prefix}delsewa <link grup>
_menghapus status sewabot pada grup tersebut_.

*in group chat*:
- ${t.prefix}delsewa vip
_menghapus status sewabot \`VIP\` pada grup ini.
- ${t.prefix}delsewa
_menghapus status sewabot pada grup ini_.`;i.reply(t.chat,l,t,{expiration:t.expiration})}}var w,c},owner:!0,location:"plugins/owner/addsewa.js"};