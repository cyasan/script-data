exports.run = {
usage: ['addmoney'],
use: 'mention or reply',
category: 'owner',
async: async (m, { func, mecha, froms, setting }) => {
if (m.quoted) {
if (!m.text) return m.reply('Input nominalnya.')
let nominal = m.text.replace(/[^0-9]/g, '')
if (isNaN(nominal)) return m.reply('Nominal harus berupa angka.')
let count = nominal.length > 0 ? Math.max(parseInt(nominal), 1) : Math.min(1) // Hapus batas atas
let user = global.db.users[m.quoted.sender]
if (typeof user == 'undefined') return m.reply('User  data not found.')
user.money += parseInt(count);
m.reply(`Sukses menambah ${count.rupiah()} money ke @${m.quoted.sender.replace(/@.+/, '')}\n- Money dia saat ini: ${user.money.rupiah()}`)
} else if (m.text) {
const [target, amount] = m.text.split('|');
if (!(target && amount)) return m.reply(`Contoh : ${m.cmd} 6282278088233|1.000.000`)
let number = isNaN(target) ? (target.startsWith('+') ? target.replace(/[()+\s-]/g, '') : (target).split('@')[1]) : target
if (isNaN(number)) return m.reply('Invalid number.')
if (number.length > 15) return m.reply('Invalid format.')
let jid = target.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
let user = global.db.users[jid]
let nominal = amount.replace(/[^0-9]/g, '')
if (typeof user == 'undefined') return m.reply('User  data not found.')
if (isNaN(nominal)) return m.reply('Nominal harus berupa angka.')
let count = nominal.length > 0 ? Math.max(parseInt(nominal), 1) : Math.min(1) // Hapus batas atas
user.money += parseInt(count);
m.reply(`Sukses menambah ${count.rupiah()} money ke @${jid.replace(/@.+/, '')}\n- Uang dia saat ini: ${user.money.rupiah()}`)
} else m.reply('Mention or Reply chat target.')
},
owner: true
}