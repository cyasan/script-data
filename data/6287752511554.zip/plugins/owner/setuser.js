exports.run = {
    usage: ['setuser'],
    category: 'owner',
    async: async (m, {
        func,
        mecha,
        froms
    }) => {
        if (m.quoted && m.quoted.sender) {
            let users = global.db.users[froms];
            // if (users.register) return m.reply('The user has been verified.')
            const [name, age, gender] = m.text.split(',').map(words => words.trim());
            if (!(name && age && gender)) return m.reply(func.example(m.cmd, '✰Nathzz✰,22,male'));
            if (isNaN(age)) return m.reply('Age must be a number.')
            if (Number(age) < 11) return m.reply('Minimum age must be over 10 years.');
            if (Number(age) >= 50) return m.reply('Age must not be more than 50 years.');
            if (!/^(male|female)$/i.test(gender)) return m.reply('gender must be in `male` or `female` format.')
            users.name = name;
            users.age = Number(age);
            users.gender = /^male$/i.test(gender) ? 'Laki-laki' : 'Perempuan';
            users.register = true;
            await m.reply(`Successfully set the user's personal data.`)
        } else m.reply(`Reply chat target with caption ${m.prefix}`)
    },
    devs: true,
    location: 'plugins/owner/setuser.js'
}