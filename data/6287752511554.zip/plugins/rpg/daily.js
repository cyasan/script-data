const rewards = {
limit: 25000,
balance: 500000,
exp: 25000,
money: 25000,
potion: 25,
}
const cooldown = 86400000

exports.run = {
usage: ['daily', 'claim', 'klaim'],
hidden: ['rewards'],
category: 'rpg',
async: async (m, { func, mecha }) => {
let user = global.db.users[m.sender]
if (new Date - user.lastclaim < cooldown) return m.reply(`You have already claimed this daily claim!, wait for *${func.clockString((user.lastclaim + cooldown) - new Date())}*`)
let text = ''
for (let reward of Object.keys(rewards)) {
if (!(reward in user)) continue
user[reward] += rewards[reward]
text += `*+${rewards[reward]}* ${reward}\n`
}
m.reply(text.trim())
user.lastclaim = new Date * 1
},
register: true
}