const toMs = require('ms');

exports.run = {
    usage: ['addowner', 'delowner', 'listowner'],
    use: 'mention or reply',
    category: 'owner',
    async: async (m, {
        func,
        mecha,
        froms
    }) => {
        switch (m.command) {
            case 'addowner':
                if (global.db.owner.length >= 50) return m.reply('Jumlah owner sudah max.')
                const [target, duration] = m.text.split(',');
                if (m.quoted) {
                    let user = global.db.users[m.quoted.sender]
                    let expire = m.text ? Date.now() + toMs(m.text) : Date.now() + 31557600000;
                    if (typeof user == 'undefined') return m.reply('User data not found.')
                    if (global.db.owner.includes(user.jid)) return m.reply(`@${user.jid.split('@')[0]} already in the database.`)
                    global.db.owner.push(user.jid);
                    user.expired.owner = expire;
                    m.reply(`Successfully added @${user.jid.replace(/@.+/, '')} as owner.`)
                } else if (m.text) {
                    if (!target) return m.reply(`Contoh : ${m.cmd} 628xxx,30d`)
                    let number = isNaN(target) ? (target.startsWith('+') ? target.replace(/[()+\s-]/g, '') : target.replace(/@.+/g, '')) : target;
                    if (isNaN(number)) return m.reply('Invalid number.')
                    if (number.length > 15) return m.reply('Invalid format.')
                    let userId = target.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
                    let user = global.db.users[userId]
                    let expire = duration ? Date.now() + toMs(duration) : Date.now() + 31557600000;
                    if (typeof user == 'undefined') return m.reply('User data not found.')
                    if (global.db.owner.includes(user.jid)) return m.reply(`@${user.jid.split('@')[0]} already in the database.`)
                    global.db.owner.push(user.jid);
                    user.expired.owner = expire;
                    m.reply(`Successfully added @${user.jid.replace(/@.+/, '')} as owner.`)
                } else m.reply('Mention or Reply chat target.')
                break
            case 'delowner':
                if (!froms) return m.reply('Mention or Reply chat target.')
                if (!global.db.owner.includes(froms)) return m.reply(`@${froms.split('@')[0]} not in database.`)
                if (global.devs.includes(froms)) return mecha.sendReact(m.chat, '🚫', m.key);
                let user = global.db.users[froms];
                if (typeof user == 'undefined') return m.reply('User data not found.')
                user.expired.owner = 0;
                global.db.owner.splice(global.db.owner.indexOf(user.jid), 1)
                m.reply(`Successfully removed @${user.jid.split('@')[0]} from owner.`)
                break
            case 'listowner':
                if (global.db.owner.length == 0) return m.reply('Empty data.')
                let caption = `乂  *L I S T - O W N E R*\n\nTotal : ${global.db.owner.length}\n`
                global.db.owner.forEach((jid, index) => {
                    let userData = global.db.users[jid]
                    caption += `\n${index + 1}. @${jid.split('@')[0]}\n◦  Expire: ${userData.expired?.owner === 'PERMANENT' ? 'PERMANENT' : func.expireTime(userData.expired?.owner)}`
                })
                mecha.reply(m.chat, caption, m, {
                    expiration: m.expiration
                })
                break
        }
    },
    devs: true,
    location: 'plugins/developer/setowner.js'
}