const {
    proto
} = require('@whiskeysockets/baileys');

exports.run = {
    usage: ['sendch'],
    hidden: ['sendchannel'],
    use: 'text',
    category: 'developer',
    async: async (m, {
        func,
        mecha,
        setting
    }) => {
        if (!m.text) return m.reply(func.example(m.cmd, 'halo'))
        async function sendMessageToChannel(text) {
            let messages = {
                extendedTextMessage: {
                    text: text,
                    mentions: mecha.ments(text),
                    contextInfo: {
                        mentionedJid: mecha.ments(text),
                        externalAdReply: {
                            title: 'System Notification',
                            body: global.header,
                            thumbnail: await func.fetchBuffer(setting.cover),
                            sourceUrl: '',
                            mediaType: 1,
                            renderLargerThumbnail: false
                        }
                    }
                }
            };
            let messageToChannel = proto.Message.encode(messages).finish();
            let result = {
                tag: 'message',
                attrs: {
                    to: '120363294067531884@newsletter',
                    type: 'text'
                },
                content: [{
                    tag: 'plaintext',
                    attrs: {},
                    content: messageToChannel
                }]
            };
            return mecha.query(result);
        }
        await sendMessageToChannel(m.text)
            .then(() => mecha.sendReact(m.chat, '✅', m.key))
            .catch(() => mecha.sendReact(m.chat, '❌', m.key))
    },
    devs: true,
    location: 'plugins/developer/sendch.js'
}