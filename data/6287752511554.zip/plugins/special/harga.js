exports.run = {
usage: ['buyprem', 'sewabot', 'buyjadibot', 'buyowner'],
hidden: ['premium', 'sewa', 'jadibot', 'owner'],
category: 'special',
async: async (m, { func, mecha, setting }) => {
let caption;
if (func.somematch(['buyprem', 'premium'], m.command)) {
caption =  `『 *LIST HARGA PREMIUM* 』

  𝐏𝐑𝐄𝐌𝐈𝐔𝐌 𝐍𝐄𝐊𝐎𝐂𝐇𝐀𝐍 𝐌𝐃
▰▱▰▱▰▱▰▱▰▱▰▱▰▱

➪ 𝐏𝐑𝐄𝐌𝐈𝐔𝐌 𝟏        :  Rp 5.000 / 7 Hari
➪ 𝐏𝐑𝐄𝐌𝐈𝐔𝐌 𝟐        :  Rp 10.000 / 10 Hari
➪ 𝐏𝐑𝐄𝐌𝐈𝐔𝐌 𝟑        :  Rp 15.000 / 30 Hari
➪ 𝐏𝐑𝐄𝐌𝐈𝐔𝐌 𝟒        :  Rp 25.000 / 60 Hari
➪ 𝐏𝐑𝐄𝐌𝐈𝐔𝐌 𝐕𝐕𝐈𝐏 : Rp 80.000 / 365 Hari

╔═══☆♡☆═══╗
       𝐏𝐀𝐘𝐌𝐄𝐍𝐓
╚═══☆♡☆═══╝

➣ DANA   : 082278088233
➣ GOPAY : 082278088233
➣ OVO     : 082278088233
➣ QRIS     : ( All Payment )

*INFORMATION*
> 1. Melakukan pembelian artinya anda setuju dengan segala kebijakan kami.
> 2. Semua pembelian bergaransi.
> 3. Tidak puas dengan layanan kami? Kami kembalikan uang Anda 100% dalam jangka waktu 1 jam setelah pembelian.
> 4. Jika bot mengalami kendala atau perbaikan hingga 24 jam atau lebih, kami berikan kompensasi berupa penambahan waktu sewa.
> 5. Perpanjangan hanya berlaku jika masa aktif tersisa kurang dari 3 hari.

Berminat? Hubungi :
wa.me/${global.owner.replace(/[^0-9]/g, '')}`
} else if (func.somematch(['sewabot', 'sewa', 'buysewa'], m.command)) {
caption = `『  *LIST HARGA SEWA BOT* 』

𝐒𝐄𝐖𝐀 𝐍𝐄𝐊𝐎𝐂𝐇𝐀𝐍 𝐌𝐃 
══════ ⋆★⋆ ══════

➾ 𝐒𝐄𝐖𝐀 𝐇𝐀𝐑𝐈𝐀𝐍
↳ Sewa  : 7 Hari / Grup 
↳ Harga : Rp 5.000
↳ Sewa  : 7 Hari / Grup ( VIP )
↳ Harga : Rp 10.000

➾ 𝐒𝐄𝐖𝐀 𝐁𝐔𝐋𝐀𝐍𝐀𝐍 
↳ Sewa  : 30 Hari / Grup
↳ Harga : Rp 25.000
↳ Sewa  : 30 Hari / Grup ( VIP )
↳ Harga : Rp 35.000

➾ 𝐒𝐄𝐖𝐀 𝐁𝐔𝐋𝐀𝐍𝐀𝐍
↳ Sewa  : 90 Hari / Grup 
↳ Harga : Rp 50.000 
↳ Sewa  : 90 Hari / Grup ( VIP )
↳ Harga : Rp 65.000

➾ 𝐒𝐄𝐖𝐀 𝐓𝐀𝐇𝐔𝐍𝐀𝐍
↳ Sewa  : 365 Hari / Grup
↳ Harga : Rp 100.000
↳ Sewa  : 365 Hari / Grup ( VIP )
↳ Harga : Rp 115.000

╔═══☆♡☆═══╗
       𝐏𝐀𝐘𝐌𝐄𝐍𝐓
╚═══☆♡☆═══╝

➣ DANA   : 082278088233
➣ GOPAY : 082278088233
➣ OVO     : 082278088233
➣ QRIS     : ( All Payment )

*INFORMATION*
> 1. Melakukan pembelian artinya anda setuju dengan segala kebijakan kami.
> 2. Semua pembelian bergaransi.
> 3. Tidak puas dengan layanan kami? Kami kembalikan uang Anda 100% dalam jangka waktu 1 jam setelah pembelian.
> 4. Jika bot mengalami kendala atau perbaikan hingga 24 jam atau lebih, kami berikan kompensasi berupa penambahan waktu sewa.
> 5. Perpanjangan hanya berlaku jika masa aktif tersisa kurang dari 3 hari.

Berminat? Hubungi :
wa.me/${global.owner.replace(/[^0-9]/g, '')}`
} else if (func.somematch(['buyjadibot'], m.command)) {
caption =  `「 *LIST HARGA JADIBOT* 」

┏━[ 𝐉𝐀𝐃𝐈 𝐁𝐎𝐓 ]━
┃☍ 𝟕 𝐇𝐚𝐫𝐢 = 𝟐𝟎𝐤     [𝐕𝐈𝐏❌]
┃☍ 𝟏 𝐁𝐮𝐥𝐚𝐧 = 𝟓𝟎𝐤   [𝐕𝐈𝐏❌]
┃☍ 𝟑 𝐁𝐮𝐥𝐚𝐧 = 𝟏𝟎𝟎𝐤 [𝐕𝐈𝐏✅]
┃━━━━━━━━━━━━
┃𝖪𝖾𝗎𝗇𝗍𝗎𝗇𝗀𝖺𝗇 ⨾
┃• 𝖫𝗂𝗆𝗂𝗍 𝖴𝗇𝗅𝗂𝗆𝗂𝗍𝖾𝖽
┃• 𝖡𝗂𝗌𝖺 𝖠𝖽𝖽 𝖯𝗋𝖾𝗆/𝖣𝖾𝗅
┃• 𝖡𝗂𝗌𝖺 𝖠𝖽𝖽 𝖪𝗈𝗂𝗇/𝖫𝗂𝗆𝗂𝗍
┃• 𝖡𝗂𝗌𝖺 𝖡𝖺𝗇 𝖴𝗌𝖾𝗋
┃• 𝖡𝗂𝗌𝖺 𝖢𝗁𝖾𝖺𝗍 𝖪𝗈𝗂𝗇/𝖫𝗂𝗆𝗂𝗍
┃• 𝖴𝗇𝗅𝗈𝖼𝗄 𝖠𝗅𝗅 𝖥𝗂𝗍𝗎𝗋 𝖮𝗐𝗇𝖾𝗋
┃• 𝖢𝗎𝗌𝗍𝗈𝗆𝗂𝗓𝖾 ✅
┗━━━━━━━━━━━━━━━

╔═══☆♡☆═══╗
       𝐏𝐀𝐘𝐌𝐄𝐍𝐓
╚═══☆♡☆═══╝

➣ DANA   : 082278088233
➣ GOPAY : 082278088233
➣ OVO     : 082278088233
➣ QRIS     : ( All Payment )

*INFORMATION*
> 1. Melakukan pembelian artinya anda setuju dengan segala kebijakan kami.
> 2. Semua pembelian bergaransi.
> 3. Tidak puas dengan layanan kami? Kami kembalikan uang Anda 100% dalam jangka waktu 1 jam setelah pembelian.
> 4. Jika bot mengalami kendala atau perbaikan hingga 24 jam atau lebih, kami berikan kompensasi berupa penambahan waktu sewa.
> 5. Perpanjangan hanya berlaku jika masa aktif tersisa kurang dari 3 hari.

Berminat? Hubungi :
wa.me/${global.owner.replace(/[^0-9]/g, '')}`
} else if (func.somematch(['buyowner'], m.command)) {
caption =  `「 *LIST HARGA JADI OWNER* 」

┏━[ 𝐉𝐀𝐃𝐈 𝐎𝐖𝐍𝐄𝐑 ]━
┃☍ 𝟕 𝐇𝐚𝐫𝐢 = 𝟏𝟓𝐤   [𝐕𝐈𝐏❌]
┃☍ 𝟏 𝐁𝐮𝐥𝐚𝐧 = 𝟑𝟓𝐤 [𝐕𝐈𝐏❌]
┃☍ 𝟑 𝐁𝐮𝐥𝐚𝐧 = 𝟓𝟎𝐤 [𝐕𝐈𝐏✅]
┃━━━━━━━━━━━━
┃𝖪𝖾𝗎𝗇𝗍𝗎𝗇𝗀𝖺𝗇 ⨾
┃• 𝖫𝗂𝗆𝗂𝗍 𝖴𝗇𝗅𝗂𝗆𝗂𝗍𝖾𝖽
┃• 𝖡𝗂𝗌𝖺 𝖠𝖽𝖽 𝖯𝗋𝖾𝗆/𝖣𝖾𝗅
┃• 𝖡𝗂𝗌𝖺 𝖠𝖽𝖽 𝖪𝗈𝗂𝗇/𝖫𝗂𝗆𝗂𝗍
┃• 𝖡𝗂𝗌𝖺 𝖡𝖺𝗇 𝖴𝗌𝖾𝗋
┃• 𝖡𝗂𝗌𝖺 𝖢𝗁𝖾𝖺𝗍 𝖪𝗈𝗂𝗇/𝖫𝗂𝗆𝗂𝗍
┃• 𝖴𝗇𝗅𝗈𝖼𝗄 𝖠𝗅𝗅 𝖥𝗂𝗍𝗎𝗋 𝖮𝗐𝗇𝖾𝗋
┃• 𝖢𝗎𝗌𝗍𝗈𝗆𝗂𝗓𝖾 ❌
┗━━━━━━━━━━━━━━━

╔═══☆♡☆═══╗
       𝐏𝐀𝐘𝐌𝐄𝐍𝐓
╚═══☆♡☆═══╝

➣ DANA   : 082278088233
➣ GOPAY : 082278088233
➣ OVO     : 082278088233
➣ QRIS     : ( All Payment )

*INFORMATION*
> 1. Melakukan pembelian artinya anda setuju dengan segala kebijakan kami.
> 2. Semua pembelian bergaransi.
> 3. Tidak puas dengan layanan kami? Kami kembalikan uang Anda 100% dalam jangka waktu 1 jam setelah pembelian.
> 4. Jika bot mengalami kendala atau perbaikan hingga 24 jam atau lebih, kami berikan kompensasi berupa penambahan waktu sewa.
> 5. Perpanjangan hanya berlaku jika masa aktif tersisa kurang dari 3 hari.

Berminat? Hubungi :
wa.me/${global.owner.replace(/[^0-9]/g, '')}`
}
mecha.sendMessage(m.chat, {
image: {
url: global.qrisUrl
}, 
caption: caption
}, {quoted: m, ephemeralExpiration: m.expiration});
}
}