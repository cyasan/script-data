exports.run = {
usage: ['database'],
hidden: ['db'],
category: 'special',
async: async (m, { func, mecha }) => {
const user = Object.values(global.db.users)
let caption = `Jumlah database saat ini \`${user.length}\` user
Dan user register saat ini \`${user.filter(x => x.register).length}\` user`
mecha.reply(m.chat, caption, m, {
expiration: m.expiration
})
}
}