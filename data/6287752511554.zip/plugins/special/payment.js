exports.run = {
    usage: ['qris', 'payment'],
    category: 'topup',
    async: async (m, {
        func,
        mecha,
        setting
    }) => {
        const fchannel = {
            key: {
                remoteJid: 'status@broadcast',
                fromMe: false,
                participant: '0@s.whatsapp.net'
            },
            message: {
                newsletterAdminInviteMessage: {
                    newsletterJid: '120363294067531884@newsletter',
                    newsletterName: 'Powered by WhatsApp',
                    jpegThumbnail: null,
                    caption: 'Powered By SuryaDev',
                    inviteExpiration: Date.now() + 1814400000
                }
            }
        }
        if (/^payment$/i.test(m.command)) {
            mecha.sendMessage(m.chat, {
                text: `Hai Kak ${m.sender.split('@')[0]} 👋🏻, Ingin Melakukan Pembayaran?, Silahkan Lanjutkan Transaksi Kepada No Yang Tertera Di Bawah..


━━━//━━━━━━━━
*⚘ PAYMENT :*
 *⋄ Gopay:* 082278088233
 *⋄ Ovo:* 082278088233
 *⋄ Dana:* 082278088233
 *⋄ Qris:* Ketik .Qris
 *⋄ Owner:* wa.me/6285757500181


Terima Kasih Yang Sudah Melakukan Pembayaran, Jangan Lupa Kirim Bukti Transaksinya Ya Kak >,<`,
                mentions: [m.sender]
            }, {
                quoted: fchannel,
                ephemeralExpiration: m.expiration
            });
        } else if (/^qris$/i.test(m.command)) {
            mecha.sendMessage(m.chat, {
                image: {
                    url: 'https://files.catbox.moe/1md5j5.jpg'
                },
                caption: '*QRIS ALL PAYMENT*\n\n_pembayaran via `QRIS` + 300p untuk biaya admin_\n\n*SERTAKAN BUKTI TRANSFER*',
                mentions: [m.sender]
            }, {
                quoted: fchannel,
                ephemeralExpiration: m.expiration
            });
        }
    },
    location: 'plugins/special/payment.js'
}