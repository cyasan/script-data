const axios = require('axios');

exports.run = {
    usage: ['pinterest2'],
    hidden: ['pin2'],
    use: 'text',
    category: 'searching',
    async: async (m, { func, mecha }) => {
        if (!m.text) return m.reply(func.example(m.cmd, 'nakano miku'));
        if (m.text.startsWith('@62')) return m.reply('Stress ??');

        mecha.sendMessage(m.chat, { text: '🔍 Searching...' }, { quoted: m });

        try {
            let { data } = await axios.get(`https://api-kuromi-jet.vercel.app/pinterest/search?apikey=API-yn9dxsl9w4&query=${encodeURIComponent(m.text)}`);
            
            if (!data || !data.result || !data.result.pins || data.result.pins.length === 0) 
                return m.reply('Tidak ditemukan.');

            shuffleArray(data.result.pins); // Acak hasil pencarian
            let pin = data.result.pins[0]; // Ambil hasil pertama setelah diacak

            let imageUrl = pin.media.images.large?.url || pin.media.images.orig?.url;
            if (!imageUrl) return m.reply('Gambar tidak ditemukan.');

            let caption = `🔎 *Hasil pencarian:* ${m.text}\n\n📌 *Judul:* ${pin.title}\n📜 *Deskripsi:* ${pin.description || 'Tidak ada deskripsi'}\n🔗 *Link:* ${pin.pin_url}\n👤 *Uploader:* ${pin.uploader.full_name} (@${pin.uploader.username})\n🔗 *Profil:* ${pin.uploader.profile_url}`;

            await mecha.sendMessage(m.chat, {
                image: { url: imageUrl },
                caption: caption
            }, { quoted: m });

        } catch (error) {
            m.reply(`Terjadi kesalahan: ${error.message}`);
        }
    }
};

// Fungsi untuk mengacak array
function shuffleArray(array) {
    for (let i = array.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [array[i], array[j]] = [array[j], array[i]];
    }
}