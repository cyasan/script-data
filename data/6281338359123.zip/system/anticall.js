const func = require('./functions');

module.exports = async (mecha, extra) => {
    try {
        const {
            id,
            from
        } = extra
        const botId = mecha.user.id ? mecha.user.id.split(':')[0] + '@s.whatsapp.net' : mecha.user.jid;
        if (global.db.setting[botId] && global.db.setting[botId].anticall) {
            await mecha.rejectCall(id, from);
            if (!global.db.users[from] || global.db.users[from].premium || [...global.devs, ...global.developer, global.owner].includes(from)) return;
            await mecha.sendMessage(from, {
                    text: `*${mecha.user.name || mecha.user.verifiedName || 'mecha-bot'}* tidak bisa menerima telfon.\n${from !== global.owner ? 'Kamu telah melanggar rules bot, maaf kamu akan diblokir.\n\nJika ingin membuka blokir akan dikenakan biaya sebesar Rp. 5.000,-' : ''}`,
                    mentions: [from]
                }, {
                    quoted: func.fstatus('System Notification'),
                    ephemeralExpiration: 86400 * 7
                })
                .then(msg => mecha.sendkontak(from, global.owner, global.ownerName, msg))
            setTimeout(async () => {
                global.db.users[from].banned = true;
                global.db.users[from].expired.banned = 'PERMANENT';
                await mecha.updateBlockStatus(from, 'block');
            }, 3000)
        }
    } catch (err) {
        console.error(err);
    }
}

func.reloadFile(__filename)