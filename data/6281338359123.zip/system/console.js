const {
    green,
    greenBright,
    cyanBright,
    redBright
} = require('chalk');
const fs = require('fs'),
    path = require('path'),
    moment = require('moment-timezone'),
    func = require('./functions.js');
moment.tz.setDefault('Asia/Jakarta').locale('id');

module.exports = async (mecha, m, isMSG = false) => {
    let who = m.fromMe ? 'Bot' : m.pushname || 'Tanpa nama';
    let time = m.messageTimestamp;
    if (!m.budy) return (m.mtype ? console.log('\n' + greenBright.bold('[ TYPE ]'), m.mtype) : null)
    if (m.setting.online && m.budy && m.isPc && ![...global.devs].includes(m.sender) && !m.isBot && !m.fromMe && (mecha.user && !mecha.user.jadibot)) {
        let room = Object.values(global.db.menfes).find(room => [room.a, room.b].includes(m.sender) && room.status === 'CHATTING')
        if (!room) {
            await mecha.reply(global.owner, `• WhatsApp\nFrom: @${m.sender.split('@')[0]}\nChat: ${m.budy}`, null, {
                expiration: 604800
            })
        }
    }
    if (m.isGc && typeof global.db.groups[m.chat] !== 'undefined' && !global.db.groups[m.chat].mute) {
        const groups = global.db.groups[m.chat];
        const metadata = global.db.metadata[m.chat];
        const subject = metadata?.subject || 'anonymous';
        const ephemeralDuration = metadata?.ephemeralDuration || 0;
        if (groups.name != subject) groups.name = subject;
        if (groups.expiration != ephemeralDuration) groups.expiration = ephemeralDuration;
        let groupName = cyanBright.bold(subject);
        if (m.isPrefix) return console.log('\n' + greenBright.bold('[ CMD ]'), moment(time * 1000).format('DD/MM/YY HH:mm:ss'), green.bold('from'), func.color('[' + m.sender.split('@')[0] + '] ', 'orange') + cyanBright.bold(who), green.bold('in'), func.color('[' + m.chat + '] ', 'orange') + groupName, `\n${m.budy}`)
        if (isMSG) console.log('\n' + greenBright.bold('[ MSG ]'), moment(time * 1000).format('DD/MM/YY HH:mm:ss'), green.bold('from'), func.color('[' + m.sender.split('@')[0] + '] ', 'orange') + cyanBright.bold(who), green.bold('in'), func.color('[' + m.chat + '] ', 'orange') + groupName, `\n${m.budy}`)
    } else if (m.isPc) {
        if (m.setting.online) {
            await mecha.sendPresenceUpdate('available', m.chat);
            await mecha.readMessages([m.key]);
        } else {
            await mecha.sendPresenceUpdate('unavailable', m.chat);
        }
        if (m.isPrefix) return console.log('\n' + greenBright.bold('[ CMD ]'), moment(time * 1000).format('DD/MM/YY HH:mm:ss'), green.bold('from'), func.color('[' + m.sender.split('@')[0] + '] ', 'orange') + cyanBright.bold(who), green.bold('in'), func.color('[' + m.chat + ']', 'orange'), `\n${m.budy}`)
        if (isMSG) console.log('\n' + greenBright.bold('[ MSG ]'), moment(time * 1000).format('DD/MM/YY HH:mm:ss'), green.bold('from'), '[' + m.sender.split('@')[0] + '] ' + cyanBright.bold(who), func.color('<' + m.mtype + '>', 'orange'), `\n${m.budy}`)
    }
}

func.reloadFile(__filename)