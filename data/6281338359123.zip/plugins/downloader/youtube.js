exports.run = {
    usage: ["yta", "ytv"],
    use: "link",
    category: "downloader",
    async: async (t, {
        func: a,
        mecha: e
    }) => {
        try {
            if (/yt?(a|mp3)/i.test(t.command)) {
                if (!t.args || !t.args[0]) return t.reply(a.example(t.cmd, "https://youtu.be/1fOBgosDo7s?si=_8VLb2NqwyICoEhY"));
                if (!/^(?:https?:\/\/)?(?:www\.|m\.|music\.)?youtu\.?be(?:\.com)?\/?.*(?:watch|embed)?(?:.*v=|v\/|\/)([\w\-_]+)\&?/.test(t.args[0])) return t.reply(global.mess.error.url);
                e.sendReact(t.chat, "🕒", t.key);
                var i = await a.fetchJson(`https://api.siputzx.my.id/api/d/ytmp3?url=${encodeURIComponent(t.args[0])}`);
                e.sendMessage(t.chat, {
                    audio: {
                        url: i.data.dl
                    },
                    mimetype: "audio/mpeg",
                    fileName: i.data.title + ".mp3"
                }, {
                    quoted: t,
                    ephemeralExpiration: t.expiration
                })
            } else if (/yt?(v|mp4)/i.test(t.command)) {
                if (!t.args || !t.args[0]) return t.reply(a.example(t.cmd, "https://youtu.be/1fOBgosDo7s?si=_8VLb2NqwyICoEhY"));
                if (!/^(?:https?:\/\/)?(?:www\.|m\.|music\.)?youtu\.?be(?:\.com)?\/?.*(?:watch|embed)?(?:.*v=|v\/|\/)([\w\-_]+)\&?/.test(t.args[0])) return t.reply(global.mess.error.url);
                e.sendReact(t.chat, "🕒", t.key);
                var s = await a.fetchJson(`https://api.siputzx.my.id/api/d/ytmp4?url=${encodeURIComponent(t.args[0])}`);
                e.sendMessage(t.chat, {
                    video: {
                        url: s.data.dl
                    },
                    mimetype: "video/mp4",
                    caption: s.data.title
                }, {
                    quoted: t,
                    ephemeralExpiration: t.expiration
                })
            }
        } catch (a) {
            return e.reply(t.chat, a.message, t, {
                expiration: t.expiration
            })
        }
    },
    limit: 3,
    location: "plugins/downloader/youtube.js"
};