const {
    areJidsSameUser
} = require('@whiskeysockets/baileys');

exports.run = {
    usage: ['toplevel'],
    category: 'games',
    async: async (m, { func, mecha }) => {
        const userEntries = Object.entries(global.db.users).map(([key, value]) => ({
            ...value,
            jid: key
        }));

        const sortedUsers = userEntries.sort((a, b) => (b.level || 0) - (a.level || 0));
        const userJids = sortedUsers.map(user => user.jid);

        const rank = userJids.indexOf(m.sender) + 1;
        let txt = `You are Top *${rank}* Level out of *${userJids.length}* Users\n`;

        txt += sortedUsers.slice(0, 10).map(({
            jid,
            level,
            role
        }, i) => {
            const name = m.isGc && m.members.some(x => areJidsSameUser(jid, x.id)) ?
                (global.db.users[jid]?.name || mecha.getName(jid)).replaceAll('\n', '\t') :
                '@' + jid.split('@')[0];
            return `${i + 1}. ${name}: ${level} (${role})`;
        }).join('\n');

        mecha.reply(m.chat, txt, m, {
            expiration: m.expiration
        });
    },
    location: 'plugins/games/toplevel.js'
}