const toMs = require('ms');
const jimp = require('jimp');

exports.run = {
usage: ['uno'],
use: 'options',
category: 'games',
async: async (m, { func, mecha, setting }) => {
if (!global.db.hasOwnProperty('uno')) {
global.db.uno = {};
}

let example = `*U N O - G A M E*\n
${m.prefix}uno create
${m.prefix}uno join
${m.prefix}uno exit
${m.prefix}uno delete
${m.prefix}uno start
${m.prefix}uno play
${m.prefix}uno draw
${m.prefix}uno skip`

if (!m.text) return m.reply(example)

try {
const command = (m.args[0] || '').toLowerCase();
const args = m.text.slice(command.length).trim();

switch (command) {
case 'create':
var caption = createUNOGame(m.chat, m.sender, m.prefix);
mecha.reply(m.chat, caption, m, {
expiration: m.expiration
})
break
case 'join':
var caption = joinUNOGame(m.chat, m.sender, m.pushname, m.prefix);
mecha.reply(m.chat, caption, m, {
expiration: m.expiration
})
break
case 'exit':
var caption = leaveUNOGame(m.chat, m.sender);
mecha.reply(m.chat, caption, m, {
expiration: m.expiration
})
break
case 'delete':
var caption = deleteUNOGame(m.chat, m.sender);
mecha.reply(m.chat, caption, m, {
expiration: m.expiration
})
break
case 'start':
var caption = startUNOGame(m.chat);
mecha.reply(m.chat, caption, m, {
expiration: m.expiration
})
break
case 'play':
if (!args) return m.reply('Sebutkan kartu yang ingin Anda mainkan!');
var caption = playUNOCard(m.chat, m.sender, args);
mecha.reply(m.chat, caption, m, {
expiration: m.expiration
})
break
case 'draw':
var caption = drawUNOCard(m.chat, m.sender);
mecha.reply(m.chat, caption, m, {
expiration: m.expiration
})
break
case 'skip':
var caption = skipUNOTurn(m.chat);
mecha.reply(m.chat, caption, m, {
expiration: m.expiration
})
break
default:
mecha.reply(m.chat, example, m, {
expiration: m.expiration
})
}
} catch (error) {
console.error(error);
m.reply('Terjadi kesalahan: ' + error.message);
}
},
group: true
};

const createUNOGame = (chatId, userId, prefix) => {
if (global.db.uno[chatId]) return 'Room UNO sudah ada!';

global.db.uno[chatId] = {
status: 'waiting',
players: [{ id: userId, name: '', cards: [] }],
deck: shuffleDeck(createDeck()),
discardPile: [],
currentPlayer: 0,
direction: 1,
host: userId,
};

return `Room UNO telah dibuat! Ketik \`${prefix}uno join\` untuk bergabung.`;
};

const joinUNOGame = (chatId, userId, userName, prefix) => {
const game = global.db.uno[chatId];
if (!game) return `Room UNO belum dibuat! Ketik \`${prefix}uno create\` untuk membuat room.`;

if (game.status !== 'waiting') return 'Permainan sudah dimulai, tidak bisa bergabung lagi!';

if (game.players.find(item => item.id === userId)) {
return 'Anda sudah bergabung!';
}

game.players.push({ id: userId, name: userName, cards: [] });
return `${userName} telah bergabung ke permainan!`;
};

const startUNOGame = (chatId) => {
const game = global.db.uno[chatId];
if (game.players.length < 2) return 'Minimal 2 pemain untuk memulai!';

game.status = 'playing';

game.players.forEach(player => {
player.cards = game.deck.splice(0, 7);
sendPrivateMessage(player.id, `Kartu Anda: ${player.cards.join(', ')}`);
});

game.discardPile.push(game.deck.pop());

return `Permainan dimulai! Kartu di atas deck: ${game.discardPile[0]}. Giliran ${game.players[0].name}.`;
};

const nextTurn = (chatId) => {
const game = global.db.uno[chatId];
game.currentPlayer = (game.currentPlayer + game.direction) % game.players.length;

return `Giliran ${game.players[game.currentPlayer].name}.`;
};

const sendPrivateMessage = (userId, message) => {
console.log(`PM ke ${userId}: ${message}`);
};

const playUNOCard = (chatId, userId, card) => {
const game = global.db.uno[chatId];
const currentPlayer = game.players[game.currentPlayer];

if (currentPlayer.id !== userId) return 'Sekarang bukan giliran Anda!';

if (!currentPlayer.cards.includes(card)) {
return `Anda tidak memiliki kartu ${card}!`;
}

currentPlayer.cards = currentPlayer.cards.filter(c => c !== card);
game.discardPile.push(card);

return `${currentPlayer.name} memainkan kartu ${card}. ${nextTurn(chatId)}`;
};

const drawUNOCard = (chatId, userId) => {
const game = global.db.uno[chatId];
const currentPlayer = game.players[game.currentPlayer];

if (currentPlayer.id !== userId) return 'Sekarang bukan giliran Anda!';

const drawnCard = game.deck.pop();
currentPlayer.cards.push(drawnCard);

return `${currentPlayer.name} menarik kartu ${drawnCard}. ${nextTurn(chatId)}`;
};

const leaveUNOGame = (chatId, userId) => {
const game = global.db.uno[chatId];

if (!game) return 'Room UNO tidak ditemukan!';

const playerIndex = game.players.findIndex(user => user.id === userId);
if (playerIndex === -1) return 'Anda belum bergabung ke permainan!';

if (game.host === userId) {
delete global.db.uno[chatId];
return 'Room UNO telah dihapus karena host meninggalkan permainan.';
}

game.players.splice(playerIndex, 1);

if (game.players.length === 0) {
delete global.db.uno[chatId];
return 'Semua pemain meninggalkan room, room dihapus.';
}

return `${game.players[playerIndex].name} telah meninggalkan permainan.`;
};

const deleteUNOGame = (chatId, userId) => {
const game = global.db.uno[chatId];

if (!game) return 'Room UNO tidak ditemukan!';

if (game.host !== userId) {
return 'Hanya pembuat room yang bisa menghapus room!';
}

delete global.db.uno[chatId];
return 'Room UNO telah dihapus!';
};

const shuffleDeck = (deck) => {
for (let i = deck.length - 1; i > 0; i--) {
const j = Math.floor(Math.random() * (i + 1));
[deck[i], deck[j]] = [deck[j], deck[i]];
}
return deck;
};

const createDeck = () => {
const colors = ['Merah', 'Biru', 'Hijau', 'Kuning'];
const values = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'Skip', 'Reverse', 'Draw Two'];
const deck = [];

colors.forEach(color => {
values.forEach(value => {
deck.push(`${color} ${value}`);
});
});

return deck;
};