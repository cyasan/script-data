const formData = require('form-data'),
    axios = require('axios'),
    cheerio = require('cheerio');

async function tiktok3(url) {
    const bodyForm = new formData();
    bodyForm.append("q", url);
    bodyForm.append("lang", "id");
    try {
        const {
            data
        } = await axios(`https://savetik.co/api/ajaxSearch`, {
            method: "post",
            data: bodyForm,
            headers: {
                "content-type": "application/x-www-form-urlencoded",
                "User-Agent": "PostmanRuntime/7.32.2",
            },
        });
        const $ = cheerio.load(data.data);
        const result = {
            status: true,
            title: $("div.video-data > div > .tik-left > div > .content > div > h3").text(),
            video: $("div.video-data > div > .tik-right > div > p:nth-child(1) > a").attr("href"),
            audio: $("div.video-data > div > .tik-right > div > p:nth-child(3) > a").attr("href"),
        };
        return result;
    } catch (error) {
        console.log(error);
        return {
            status: false,
            message: error.message
        }
    }
}

exports.run = {
    usage: ['tiktok3'],
    hidden: ['tt3'],
    use: 'link tiktok',
    category: 'downloader',
    async: async (m, {
        func,
        mecha
    }) => {
        if (!m.text) return m.reply(func.example(m.cmd, 'https://vt.tiktok.com/ZSF4cWcA2/'))
        if (!m.args[0].includes('tiktok.com')) return m.reply(global.mess.error.url)
        mecha.sendReact(m.chat, '🕒', m.key)
        let result = await tiktok3(m.args[0]);
        if (!result.status) return m.reply(result.message)
        mecha.sendMessage(m.chat, {
                video: {
                    url: result.video
                },
                caption: result.title
            }, {
                quoted: m,
                ephemeralExpiration: m.expiration
            })
            .then((q) => mecha.sendMessage(m.chat, {
                audio: {
                    url: result.audio
                },
                mimetype: 'audio/mpeg',
                ptt: false
            }, {
                quoted: q,
                ephemeralExpiration: m.expiration
            }))
    },
    limit: 5,
    location: 'plugins/downloader/tiktok3.js'
}