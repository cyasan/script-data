const axios = require("axios");
const https = require("node:https");
const fake = require("fake-useragent");
const crypto = require("node:crypto");

const MSEC = "https://igram.world/msec";
const USER_INFO = "https://api-wh.igram.world/api/v1/instagram/userInfo";
const POST = "https://api-wh.igram.world/api/v1/instagram/posts";
const URL_STORY = "https://api-wh.igram.world/api/v1/instagram/stories"
const URL_HIGHLIGHT = "https://api-wh.igram.world/api/v1/instagram/highlights"
const URL_CONVERT = "https://api.igram.world/api/convert"

const SECRECT_KEY = "3526501d956b1c95459de077386711c0529330544d2d57ad6781cc33fa03c7a3";
const FIXED_TIMESTAMP = 1740129810449;

const agent = https.Agent({
    keepAlive: true,
    rejectUnauthorized: false
})

let headersList = {
    "authority": "igram.world",
    "accept": "*/*",
    "accept-encoding": "gzip, deflate, br, zstd",
    "accept-language": "id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7,ru;q=0.6",
    "cache-control": "no-cache",
    "pragma": "no-cache",
    "priority": "u=1, i",
    "referer": "https://igram.world/",
    "sec-ch-ua": '"Not(A:Brand";v="99", "Google Chrome";v="133", "Chromium";v="133"',
    "sec-ch-ua-mobile": "?0",
    "sec-ch-ua-platform": '"Windows"',
    "sec-fetch-dest": "empty",
    "sec-fetch-mode": "cors",
    "sec-fetch-site": "same-origin",
    "user-agent": fake()
    // "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36"
}

async function request({
    url,
    method = "GET",
    data = null,
    params = null,
    head = null,
    response = "json"
}) {
    try {
        var headers = {};
        var param;
        var datas;

        if (head && head == "original" || head == "ori") {
            const uri = new URL(url);
            headers = {
                authority: uri.hostname,
                origin: "https://" + uri.hostname,
                'Cache-Control': 'no-cache',
                "user-agent": fake()
            }
        } else if (head && typeof head == "object") {
            headers = head;
        }
        if (params && typeof params == "object") {
            param = params;
        } else {
            param = "";
        }
        if (data) {
            datas = data
        } else {
            datas = "";
        }

        const options = {
            url: url,
            method: method,
            headers,
            timeout: 30_000,
            responseType: response,
            httpsAgent: agent,
            validateStatus: (status) => {
                return status <= 500;
            },
            ...(!datas ? {} : {
                data: datas
            }),
            ...(!params ? {} : {
                params: param
            })
        }
        const res = await axios.request(options);

        return res;
    } catch (error) {
        console.log(error)
    }
}

function _sort(inputObject) {
    return Object.keys(inputObject).sort().reduce(function(accumulator, key) {
        accumulator[key] = inputObject[key];
        return accumulator;
    }, {});
}

async function getSignature(payload) {
    const response = await request({
        url: MSEC,
        head: headersList
    })
    const {
        msec
    } = response.data

    let timestampInMilliseconds = 0;
    timestampInMilliseconds = Math.floor(msec * 1000);

    let timeDifference = timestampInMilliseconds ? Date.now() - timestampInMilliseconds : 0;
    if (Math.abs(timeDifference) < 60000) {
        timeDifference = 0;
    }

    const currentTime = Date.now() - timeDifference;

    const digestString = `${typeof payload == "string" ? payload : JSON.stringify(_sort(payload))}${currentTime}${SECRECT_KEY}`;
    let encodedDigest = new TextEncoder().encode(digestString);
    const hashBuffer = await crypto.subtle.digest("SHA-256", encodedDigest);
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    const signature = hashArray.map(function(byte) {
        return byte.toString(16).padStart(2, "0");
    }).join('')

    return {
        ts: currentTime,
        _ts: FIXED_TIMESTAMP,
        _tsc: timeDifference,
        _s: signature
    }
}


function getUsername(link) {
    let username = /https\:\/\/|http\:\/\//i.test(link) ? new URL(link) : link;
    if (username instanceof URL) {
        username = username.pathname.replace(/\//gi, "");
    }

    return username;
}

async function getInfo(url) {
    const username = getUsername(url);
    const payload = {
        username
    }

    const sign = await getSignature(payload);
    const res = await request({
        url: USER_INFO,
        method: "POST",
        data: {
            username,
            ...sign
        },
        head: headersList
    });
    return res.data;
}

async function getPosts(url) {
    const username = getUsername(url);
    const payload = {
        maxId: "",
        username
    }

    const sign = await getSignature(payload);
    const res = await request({
        url: POST,
        method: "POST",
        data: {
            ...payload,
            ...sign
        },
        head: headersList
    });
    return res.data;
}

async function getStories(url) {
    const username = getUsername(url);
    const payload = {
        username
    }

    const sign = await getSignature(payload);
    const res = await request({
        url: URL_STORY,
        method: "POST",
        data: {
            ...payload,
            ...sign
        },
        head: headersList
    });
    return res.data;
}

async function getHighlights(url) {
    const info = await getInfo(url);
    const payload = {
        userId: info?.result?.[0]?.user?.id
    }

    const sign = await getSignature(payload);
    const res = await request({
        url: URL_HIGHLIGHT,
        method: "POST",
        data: {
            ...payload,
            ...sign
        },
        head: headersList
    });
    return res.data;
}

async function Download(url) {
    const sign = await getSignature(url);
    const pay = {
        url,
        ...sign
    }
    const res = await request({
        url: URL_CONVERT,
        method: "POST",
        data: pay,
        head: headersList
    });
    return res.data;
}

exports.run = {
    usage: ['instagram4'],
    hidden: ['igdl4', 'ig4'],
    use: 'link instagram',
    category: 'downloader',
    async: async (m, {
        func,
        mecha
    }) => {
        if (!m.text) return m.reply('Masukkan linknya!')
        let url = func.isUrl(m.args[0])
        const regex = /https?:\/\/(www\.|m\.|)instagram\.com\/(p|reel|([a-zA-Z0-9-_.]+\/(p|reel)))\/[a-zA-Z0-9]{1,11}/i
        const regex2 = /https?:\/\/(www\.|)instagram\.com\/tv\/[A-z0-9-_]{1,11}/i
        const regex3 = /https?:\/\/(www\.)?instagram\.com\/(p|reel|tv)\/[A-Za-z0-9_-]+/g;
        if (!url || !regex3.test(url[0])) return m.reply(`*Link salah! Perintah ini untuk mengunduh postingan ig/reel/tv, bukan untuk highlight/story!*\n\ncontoh:\n${m.cmd} https://www.instagram.com/p/BmjK1KOD_UG/?utm_medium=copy_link`)
        mecha.sendReact(m.chat, '🕒', m.key)
        try {
            const result = await Download(url[0])
            const {
                title,
                source,
                comments,
                comment_count,
                like_count,
                username
            } = result.meta;
            const caption = `*INSTAGRAM DOWNLOADER*

- Username: ${username}
- Title: ${title}
- Like count: ${like_count}
- Comment count: ${comment_count}

*Comments:*\n\n${formatComments(comments)}`
            for (let [index, item] of result.url.entries()) {
                await mecha.sendMedia(m.chat, item.url, index == 0 ? m : null, {
                    caption: index == 0 ? caption : '',
                    expiration: m.expiration
                })
                await new Promise(resolve => setTimeout(resolve, 500));
            }
        } catch (error) {
            console.error(error)
            m.reply(`Something went wrong: ${error.message}`);
        }
    },
    premium: true,
    limit: 5,
    location: 'plugins/downloader/instagram4.js'
}

function formatComments(comments) {
    return comments.map((comment, index) => `${index + 1}. ${comment.username}\n- ${comment.text}`).join('\n\n');
}