const ffmpeg = require('fluent-ffmpeg');
const path = require('path');

/**
 * Menstabilkan video
 * @param {string} inputPath - Path ke file video input
 * @param {string} outputPath - Path ke file video output
 * @returns {Promise<string>} - Path ke file video yang dihasilkan
 */

async function stabilizeVideo(inputPath, outputPath) {
    return new Promise((resolve, reject) => {
        ffmpeg(inputPath)
            .videoFilters('deshake')
            .save(outputPath)
            .on('end', () => resolve(outputPath))
            .on('error', (err) => reject(err));
    });
}

exports.run = {
    usage: ['stabilizevideo'],
    hidden: ['hdvid2'],
    use: 'reply video',
    category: 'ai',
    async: async (m, {
        func,
        mecha,
        quoted
    }) => {
        mecha.stabilizevideo = mecha.stabilizevideo ? mecha.stabilizevideo : {};
        if (m.sender in mecha.stabilizevideo) return m.reply('Masih ada proses yang sedang dijalankan, silahkan tunggu.');
        if (!/video|mp4/.test(quoted.mime)) return m.reply(`Kirim/Reply video dengan caption *${m.cmd}*`)
        else mecha.stabilizevideo[m.sender] = true;
        m.reply('Tunggu sebentar, proses ini memakan waktu cukup lama...')
        const inputVideoPath = await mecha.downloadAndSaveMediaMessage(m);
        const outputVideoPath = path.join('media', `output_${Date.now()}.mp4`);
        try {
            const result = await stabilizeVideo(inputVideoPath, outputVideoPath);
            await mecha.sendMessage(m.chat, {
                video: {
                    url: result
                },
                mimetype: 'video/mp4',
                caption: 'Video berhasil distabilkan!'
            });
            delete mecha.stabilizevideo[m.sender];
        } catch (error) {
            delete mecha.stabilizevideo[m.sender];
            mecha.reply(m.chat, `Terjadi kesalahan saat menstabilkan video: ${error.message}`, m, {
                expiration: m.expiration
            });
        }
    },
    premium: true
}