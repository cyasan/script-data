const axios = require('axios');

const api = {
url: 'https://api.shannmoderz.xyz/ai/claude',
key: 'free-trial'
};

const apiRequest = async (query) => {
const response = await axios.get(api.url, { params: { query, key: api.key } });
if (response.data && response.data.result) {
return response.data.result;
}
throw new Error('Failed.');
};

exports.run = {
usage: ['claude'],
hidden: ['cd'],
use: 'question',
category: 'ai',
async: async (m, { mecha }) => {
try {
await mecha.sendReact(m.chat, '🕒', m.key);
const replyText = await apiRequest(m.text);
await mecha.sendReact(m.chat, '✅', m.key);
mecha.reply(m.chat, replyText, m);
} catch (error) {
await mecha.sendReact(m.chat, '❌', m.key);
mecha.reply(m.chat, `Terjadi kesalahan: ${error.message}`, m);
}
},
limit: true
};