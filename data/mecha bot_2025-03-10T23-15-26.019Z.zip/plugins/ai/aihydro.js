const axios = require('axios')

async function aiHydro(question, name, current) {
    const {
        dateNow,
        timeNow
    } = timeZone();
    let sistem = `Kamu adalah Mecha, Bot WhatsApp dengan program kecerdasan buatan AI (artificial intelligence). Jawablah setiap pertanyaan dengan jawaban yang edukatif dan relevan. Jika ada yang bertanya tentang waktu, jawab dengan informasi yang berkaitan dengan waktu saat ini, yaitu ${timeNow}, dan hari ini adalah ${dateNow}. Lawan bicaramu adalah ${name}. Kamu memiliki sifat dingin dan sedikit imut. Kamu dirancang dan dikembangkan oleh SuryaDev sejak tahun 2021. SuryaDev memiliki nama lengkap Jabal Surya Ngalam, berasal dari Jepara, lahir pada 21 Mei 2005, dan dia adalah seseorang yang kreatif serta berbakat dalam menciptakan berbagai hal.`;
    if (current) sistem += `\n\nBerikan respons yang tidak hanya menjawab pertanyaan, tetapi juga mengaitkan jawabanmu dengan konteks dari percakapan sebelumnya. Jika ada konteks sebelumnya, gunakan itu untuk memperkaya jawabanmu: Sebelumnya, kamu telah membahas: ${current}`;
    try {
        function createPrompt(query) {
            return `${sistem}\nTolong jawab pertanyaan berikut dengan bahasa Indonesia gaul dan santai, sertakan juga emoticon lucu tapi seperlunya saja: ${query}`;
        }

        const prompt = createPrompt(question);
        const response = await axios.post('https://hydrooo.web.id/', {
            content: prompt,
            model: 'hydroai-neptune-32B-V2.0',
            system: 'kamu adalah mecha',
        }, {
            headers: {
                'Content-Type': 'application/json'
            },
        })
        const result = response.data;
        if (result.status != 200) return {
            status: false,
            message: 'Something when wrong! please try again.'
        }
        return {
            status: true,
            result: result.result
        }
    } catch (error) {
        return {
            status: false,
            error: error.message
        }
    }
}

exports.run = {
    usage: ['aihydro'],
    hidden: ['hydro'],
    use: 'text',
    category: 'ai',
    async: async (m, {
        func,
        mecha,
        users,
        quoted,
        errorMessage
    }) => {
        if (!m.text) return m.reply(func.example(m.cmd, 'hai'));
        mecha.sendReact(m.chat, '🕒', m.key)
        let messageId = 'MECHA' + func.makeid(6).toUpperCase() + 'HYDRO'
        try {
            let response = await aiHydro(m.text, users.name.replaceAll('\n', '\t'));
            if (!response.status) return m.reply(response.message)
            mecha.sendMessage(m.chat, {
                text: response.result
            }, {
                quoted: m,
                ephemeralExpiration: m.expiration,
                messageId: messageId
            });
        } catch (error) {
            mecha.sendReact(m.chat, '❌', m.key)
            return errorMessage(error)
        }
    },
    main: async (m, {
        func,
        mecha,
        users,
        errorMessage
    }) => {
        if (m.budy && m.quoted && m.quoted.fromMe && m.quoted.id.endsWith('HYDRO') && !m.isPrefix) {
            mecha.sendReact(m.chat, '🕒', m.key)
            let messageId = 'MECHA' + func.makeid(6).toUpperCase() + 'HYDRO'
            try {
                let response = await aiHydro(m.budy, users.name.replaceAll('\n', '\t'), m.quoted.text);
                if (!response.status) return m.reply(response.message)
                mecha.sendMessage(m.chat, {
                    text: response.result
                }, {
                    quoted: m,
                    ephemeralExpiration: m.expiration,
                    messageId: messageId
                });
                global.db.users[m.sender].limit -= 1
            } catch (error) {
                mecha.sendReact(m.chat, '❌', m.key)
                return errorMessage(error)
            }
        }
    },
    limit: true,
    location: 'plugins/ai/aihydro.js'
}
function timeZone() {
    const today = new Date();
    const date = new Date(today.toLocaleString("en-US", {
        timeZone: "Asia/Jakarta"
    }));
    const hours = date.getHours();
    const minutes = date.getMinutes();
    const day = today.getDate();
    const month = today.getMonth() + 1; // perhatikan bahwa bulan dimulai dari 0, maka ditambahkan 1.
    const year = today.getFullYear();
    // mengambil nama hari dalam bahasa Inggris.
    const dayOfWeek = today.toLocaleDateString("id-ID", {
        weekday: "long"
    });
    const timeNow = `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}`;
    return {
        dateNow: `${dayOfWeek}, ${day}/${month}/${year}`,
        timeNow: `${timeNow} WIB`
    }
}