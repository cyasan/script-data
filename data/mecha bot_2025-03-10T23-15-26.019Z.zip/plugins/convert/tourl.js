const fetch = require('node-fetch');
const FormData = require('form-data');
const {
    fromBuffer
} = require('file-type');
const axios = require('axios');

async function tmpfiles(buffer) {
    const {
        ext,
        mime
    } = (await fromBuffer(buffer)) || {};
    const form = new FormData();
    form.append("file", buffer, {
        filename: `tmp.${ext}`,
        contentType: mime
    });
    try {
        const {
            data
        } = await axios.post("https://tmpfiles.org/api/v1/upload", form, {
            headers: form.getHeaders()
        });
        const match = /https?:\/\/tmpfiles.org\/(.*)/.exec(data.data.url);
        return `https://tmpfiles.org/dl/${match[1]}`;
    } catch (error) {
        return false;
    }
}

exports.run = {
    usage: ['tourl', 'tourl2'],
    use: 'reply photo',
    category: 'convert',
    async: async (m, {
        func,
        mecha,
        quoted
    }) => {
        switch (m.command) {
            case 'tourl': {
                if (/image|video|audio|webp/.test(quoted.mime)) {
                    mecha.sendReact(m.chat, '🕒', m.key)
                    /**
                     * Upload image to catbox.moe
                     * Supported mimetype:
                     * - `image/jpeg`
                     * - `image/jpg`
                     * - `image/png`
                     * - `image/gif`
                     * @param {Buffer} buffer Image Buffer
                     */
                    let buffer = await quoted.download()
                    let {
                        ext
                    } = await fromBuffer(buffer);
                    let bodyForm = new FormData();
                    bodyForm.append("fileToUpload", buffer, "file." + ext);
                    bodyForm.append("reqtype", "fileupload");

                    let res = await fetch("https://catbox.moe/user/api.php", {
                        method: "POST",
                        body: bodyForm,
                    });

                    let url = await res.text();
                    mecha.reply(m.chat, '' + url, m, {
                        expiration: m.expiration
                    })
                } else m.reply('Input media dengan benar!')
            }
            break
            case 'tourl2': {
                if (/image|video|audio|webp/.test(quoted.mime)) {
                    mecha.sendReact(m.chat, '🕒', m.key)
                    let media = await quoted.download();
                    if (!media) return false
                    let url = await tmpfiles(media)
                    mecha.reply(m.chat, '' + url, m, {
                        expiration: m.expiration
                    })
                } else m.reply('Input media dengan benar!')
            }
            break
        }
    },
    limit: true,
    location: 'plugins/convert/tourl.js'
}