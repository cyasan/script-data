exports.run = {
usage: 'listpanel',
hidden: 'listpnl',
category: 'developer',
async: async (m, { func, mecha, setting }) => {
const data = Object.values(global.db.server).filter(server => server.data.length > 0);
if (data.length == 0) return m.reply('*Empty data.*')
let caption = '乂  *L I S T - P A N E L*\n\n'
caption += convertObjToText(global.db.server)
await (setting.fakereply ? mecha.sendMessageModify(m.chat, caption, m, {
title: global.header,
body: global.footer,
thumbnail: await (await fetch(setting.cover)).buffer(),
largeThumb: true,
expiration: m.expiration
}) : mecha.reply(m.chat, caption, m, {
expiration: m.expiration
}))
},
devs: true
}

function convertObjToText(obj) {
let result = '';
let index = 1;
for (const jid in obj) {
const serverData = obj[jid];
const totalServers = serverData.data.length;
if (totalServers < 1) continue
result += `${index}. @${jid.replace(/@.+/, '')}\n*Total Server* : ${totalServers}\n*Server* :\n`;
serverData.data.forEach((item, i) => {
const expireTime = calculateExpireTime(item.expired);
result += `${i + 1}. ${item.username}\n- ID: ${item.id}\n- RAM: ${item.ram}\n- Expire: ${expireTime}\n\n`;
});
index++;
}
return result.trim();
}

function calculateExpireTime(expiredTimestamp) {
const now = Date.now();
const diff = expiredTimestamp - now;
const seconds = Math.floor((diff / 1000) % 60);
const minutes = Math.floor((diff / (1000 * 60)) % 60);
const hours = Math.floor((diff / (1000 * 60 * 60)) % 24);
const days = Math.floor(diff / (1000 * 60 * 60 * 24));
return `${days}D ${hours}H ${minutes}M ${seconds}S`;
}