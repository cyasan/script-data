const path = require('path')
const fs = require('fs')

exports.run = {
    usage: ['savefile'],
    hidden: ['sf'],
    use: 'path file',
    category: 'owner',
    async: async (m, {
        func,
        mecha,
        quoted
    }) => {
        if (!m.text) return m.reply(func.example(m.cmd, 'config.js'))
        if (!m.quoted) return m.reply(`Mau simpan plugin dengan command apa? reply teks script nya!`);
        try {
            let fileContent;
            let fileName = m.text.trim().toLowerCase();
            let filePath = path.join(process.cwd(), fileName);
            if (/application\/javascript/.test(quoted.mime)) fileContent = await quoted.download()
            else fileContent = m.quoted.text;
            fs.writeFileSync(filePath, fileContent);
            await mecha.sendReact(m.chat, '✅', m.key)
        } catch (error) {
            console.log(error)
            mecha.sendReact(m.chat, '❌', m.key)
        }
    },
    devs: true,
    location: 'plugins/developer/savefile.js'
}