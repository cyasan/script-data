const fetch = require('node-fetch');

exports.run = {
usage: ['nfree'],
hidden: ['notif-free'],
category: 'owner',
async: async (m, { func, mecha }) => {
let apiUrl = 'https://suryadev.vercel.app'
let response = await fetch(`${apiUrl}/notif/get`).then(data => data.json())
if (response.result.length > 0) {
try {
response.result.forEach(async (data) => {
let notification = global.db.notif.find(x => x.number === data.number && x.version === data.version)
if (!notification) {
global.db.notif.push({
"number": data.number,
"version": data.version,
"name": data.name,
"date": data.date,
"time": data.time,
"connect": 1
});
if (m.bot.includes('62882003321562@s.whatsapp.net')) await mecha.notify(`• Notification Script (v${data.version || '9.1.7'})\nFrom: @${data.number}\nName: ${data.name}\nDate: ${data.date}\nTime: ${data.time}`);
} else {
notification.name = data.name;
notification.version = data.version;
notification.date = data.date;
notification.time = data.time;
notification.connect++;
}
fetch(`${apiUrl}/notif/reset`).then(data => data.json())
})
} catch (err) {
await mecha.sendMessage(global.owner, {text: String(err)}, {quoted: func.fstatus('System Notification'), ephemeralExpiration: m.expiration});
}
}
},
devs: true
}