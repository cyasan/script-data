const fetch = require('node-fetch');

exports.run = {
usage: ['nvip'],
hidden: ['notif-vip'],
category: 'owner',
async: async (m, { func, mecha }) => {
let apiUrl = 'https://suryadev.vercel.app'
let response = await fetch(`${apiUrl}/notif-vip/get`).then(data => data.json())
if (response.result.length > 0) {
try {
response.result.forEach(async (data) => {
let notificationvip = global.db.notifvip.find(x => x.number === data.number)
if (!notificationvip) {
global.db.notifvip.push({
"number": data.number,
"name": data.name,
"date": data.date,
"time": data.time,
"connect": 1
});
let newVersion = data.username && data.numberto ? true : false;
let text = `• Notification Script VIP (${newVersion ? 'v9.1.8' : 'v.9.1.7'})`
if (newVersion) {
text += `\nUsername: ${data.username}`
text += `\nNumber to: ${data.numberto}`
}
text += `\nBotname: ${data.name}`
text += `\nDate: ${data.date}`
text += `\nTime: ${data.time}`
if (m.bot.includes('62882003321562@s.whatsapp.net')) await mecha.notify(text);
} else {
notificationvip.name = data.name;
notificationvip.date = data.date;
notificationvip.time = data.time;
notificationvip.connect++;
}
fetch(`${apiUrl}/notif-vip/reset`).then(data => data.json())
})
} catch (err) {
await mecha.sendMessage(global.owner, {text: String(err)}, {quoted: func.fstatus('System Notification'), ephemeralExpiration: m.expiration});
}
}
},
devs: true
}