exports.run = {
usage: ['listscript-vip'],
hidden: ['listsc-vip'],
category: 'owner',
async: async (m, { func, mecha }) => {
let data = global.db.notifvip;
if (data.length == 0) return m.reply('Empty data.')
if ((m.text || '').toLowerCase() === 'now') {
const today = new Date();
const day = today.getDate();
const month = today.getMonth() + 1; // perhatikan bahwa bulan dimulai dari 0, maka ditambahkan 1.
const year = today.getFullYear();
// mengambil nama hari dalam bahasa Inggris.
const dayOfWeek = today.toLocaleDateString('id-ID', { weekday: 'long' });
const now = `${dayOfWeek}, ${day}/${month}/${year}`
let txt = `*L I S T - S C R I P T - V I P*`
data.filter(x => x.date == now).forEach((v, index) => {
txt += `\n\n${index + 1}. @${v.number}`
txt += `\n- Name: ${v.name}`
txt += `\n- Total: ${v.connect}`
txt += `\n- Last connect: ${v.date.split(',')[0]}, ${v.time}`
})
m.reply(txt)
} else {
let txt = `*L I S T - S C R I P T - V I P*`
data.forEach((v, index) => {
txt += `\n\n${index + 1}. @${v.number}`
txt += `\n- Name: ${v.name}`
txt += `\n- Total: ${v.connect}`
txt += `\n- Last connect: ${v.date.split(',')[0]}, ${v.time}`
})
await m.reply(txt)
}
},
owner: true
}