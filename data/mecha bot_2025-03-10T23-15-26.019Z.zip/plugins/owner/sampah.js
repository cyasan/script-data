const fs = require('fs')
const path = require('path')

exports.run = {
usage: ['sampah', 'delsampah'],
category: 'owner',
async: async (m, { func, mecha }) => {
switch (m.command) {
case 'sampah':
let data = fs.readdirSync('./sampah').filter(v => ['gif', 'png', 'mp3', 'm4a', 'opus', 'mp4', 'jpg', 'jpeg', 'webp', 'webm', 'bin'].some(x => v.endsWith(x)))
if (data.length == 0) return m.reply('Empty trash.')
let caption = `乂  JUMLAH SAMPAH SYSTEM\n\n`
caption += `Total : ${data.length} Sampah\n\n`
caption += data.map(v => v).join('\n');
mecha.reply(m.chat, caption, m, {
expiration: m.expiration
})
break
case 'delsampah':
let directoryPath = path.join('./sampah')
fs.readdir(directoryPath, async function (err, files) {
if (err) {
return m.reply('Unable to scan directory: ' + err);
} 
let filteredArray = await files.filter(v => ['gif', 'png', 'mp3', 'm4a', 'opus', 'mp4', 'jpg', 'jpeg', 'webp', 'webm', 'bin'].some(x => v.endsWith(x)))
let caption = `Detected ${filteredArray.length} junk file\n`
if (filteredArray.length == 0) return m.reply(caption)
filteredArray.map(function(a, b){
caption += `\n${b + 1}. ${a}`
})
let { key } = await mecha.reply(m.chat, caption, m, {
expiration: m.expiration
})
await func.delay(2000)
await mecha.reply(m.chat, 'Delete junk files...', m, {
edit: key,
expiration: m.expiration
})
await filteredArray.forEach(function (file) {
fs.unlinkSync(`./sampah/${file}`)
});
await func.delay(2000)
await mecha.reply(m.chat, 'Successfully removed all trash', m, {
edit: key,
expiration: m.expiration
})
})
break
}
},
owner: true,
location: 'plugins/owner/sampah.js'
}