exports.run = {
    main: async (m, {
        func,
        mecha
    }) => {
        /* Function Anti Tag By SuryaDev */
        if (m.isGc && !m.isPrefix && !m.isOwner) {
            let tags = [...new Set([...(m.mentionedJid || [])])]
            for (let jid of tags) {
                if (jid == '62895415497664@s.whatsapp.net') await mecha.sendMessage(m.chat, {
                    // text: 'Jangan tag² ownerku kak, dia lagi sibuk.',
                    sticker: {
                        url: 'https://files.catbox.moe/jv9p9g.webp'
                    },
                    contextInfo: {
                        forwardingScore: 9999999,
                        isForwarded: true
                    }
                }, {
                    quoted: m,
                    ephemeralExpiration: m.expiration
                })
            }
        }
    },
    group: true
}