const axios = require('axios');
const yts = require('yt-search');

async function downloadImage(url) {
try {
const response = await axios.get(url, { responseType: 'arraybuffer' })
return Buffer.from(response.data, 'binary')
} catch (error) {
return null
}
}

exports.run = {
usage: ['play2'],
use: 'judul lagu',
category: 'downloader',
async: async (m, { func, mecha }) => {
if (!m.text) return m.reply(func.example(m.cmd, 'melukis senja'))
mecha.sendReact(m.chat, '🕒', m.key)
try {
const data = (await yts(m.text)).videos[0];
let caption = '*Y O U T U B E - P L A Y*\n'
caption += `\n∘ Title : ${data?.title || '-'}`
caption += `\n∘ Duration : ${data?.timestamp || data?.duration?.timestamp || '-'}`
caption += `\n∘ Views : ${data?.views || '-'}`
caption += `\n∘ Upload : ${data?.ago || '-'}`
caption += `\n∘ Author : ${data?.author?.name || '-'}`
caption += `\n∘ URL : ${data.url}`
caption += `\n∘ Description: ${data?.description || '-'}`
caption += `\n\nPlease wait, the audio file is being sent...`
const thumbnailBuffer = await downloadImage(data.thumbnail)
const response = await axios.post('https://cobalt.botwa.space', {
url: data.url,
downloadMode: 'audio'
}, {
headers: {
'Accept': 'application/json',
'Content-Type': 'application/json'
},
}).catch(error => error.response);
const audioUrl = response.data.url;
if (!audioUrl) return m.reply('Gagal mengambil data audio.');
await mecha.relayMessage(m.chat, {
extendedTextMessage: {
text: caption,
contextInfo: {
externalAdReply: {
title: data.title,
mediaType: 1,
previewType: 0,
renderLargerThumbnail: true,
thumbnail: thumbnailBuffer,
sourceUrl: data.url
}
},
mentions: [m.sender]
}
}, {
quoted: m,
ephemeralExpiration: m.expiration
})
await mecha.sendMessage(m.chat, {
audio: {
url: audioUrl
},
mimetype: 'audio/mpeg',
fileName: data.title + '.mp3',
contextInfo: {
externalAdReply: {
title: data.title,
body: data?.timestamp || '-',
thumbnail: thumbnailBuffer,
mediaType: 2,
mediaUrl: data.url,
sourceUrl: data.url
}
}
}, {
quoted: m,
ephemeralExpiration: m.expiration
})
mecha.sendReact(m.chat, '✅', m.key)
} catch (error) {
mecha.sendReact(m.chat, '❌', m.key)
return mecha.reply(m.chat, error.message, m, {
expiration: m.expiration
})
}
},
restrict: true,
limit: 3
}