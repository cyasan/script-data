const axios = require('axios');
async function fetchVideoData(videoId) {
const response = await axios.request({
method: 'GET',
url: 'https://yt-api.p.rapidapi.com/dl',
params: { id: videoId },
headers: {
'x-rapidapi-key': '1e30005f51msh6c612a2bd86806dp1dbed2jsne6909db8e4c9',
'x-rapidapi-host': 'yt-api.p.rapidapi.com'
}
});
return response.data;
}
function extractVideoId(url) {
const match = url.match(/(?:https?:\/\/)?(?:www\.)?(?:youtube\.com\/(?:[^\/\n\s]+\/\S+\/|(?:v|e(?:mbed)?)\/|\S*?[?&]v=)|youtu\.be\/)([\w\-_]{11})/);
return match ? match[1] : null;
}
exports.run = {
usage: ['ytvideo'],
hidden: ['ytmp4', 'ytv'],
use: 'link youtube',
category: 'downloader',
async: async (m, { mecha }) => {
const videoId = extractVideoId(m.text);
if (!videoId) return;
await mecha.sendReact(m.chat, '🕒', m.key);
try {
const videoData = await fetchVideoData(videoId);
const title = videoData.title || 'Unknown Title';
const videoUrl = videoData.formats[0].url;
const caption = `*Judul*: ${title}`;
await mecha.sendMessage(m.chat, {
video: { url: videoUrl },
mimetype: 'video/mp4',
fileName: 'video.mp4',
caption: caption
}, { quoted: m, ephemeralExpiration: m.expiration });
await mecha.sendReact(m.chat, '✅', m.key);
} catch (e) {
}
},
premium: false,
limit: 5
};