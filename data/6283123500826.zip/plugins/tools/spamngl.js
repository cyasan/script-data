const axios = require('axios');
const crypto = require('crypto');
const fetch = require('node-fetch');

exports.run = {
    usage: 'spamngl',
    use: 'parameter',
    category: 'tools',
    async: async (m, {
        func,
        mecha
    }) => {
        if (!m.text) return m.reply(func.example(m.cmd, 'https://ngl.link/tataa83152 100 bocah seleb'))
        if (!m.text.match('https://ngl.link/')) return m.reply(func.example(m.cmd, 'https://ngl.link/tataa83152 100 bocah seleb'))
        let [url, amount, ...message] = m.text.split(' ');
        if (!(url && amount && message.length > 0)) return m.reply(func.example(m.cmd, 'https://ngl.link/tataa83152 100 bocah seleb'))
        if (isNaN(amount)) return m.reply('Amount harus berupa angka.');
        mecha.sendReact(m.chat, '🕒', m.key)
        let username = url.split('https://ngl.link/')[1];
        amount = parseInt(amount);
        message = message.join(' ');
        let success = 0,
            failed = 0,
            delay = 3000;
        /*for (let index = 0; index < amount; index++) {
            try {
                let ngl = await axios.post("https://ngl.link/api/submit", `username=${username}&question=${message}&deviceId=18d7b980-ac6a-4878-906e-087dfec6ea1b&gameSlug=&referrer=`);
                success++;
                if (index % 10 === 0) {
                    delay += 500; // Tambah 1 detik jika kelipatan 10
                    console.log('Jeda bertambah 1 detik untuk kelipatan 10..');
                }
                if (index == 0) {
                    await mecha.reply(m.chat, `_Pesan terkirim..._\nID: ${ngl.data.questionId}\nRegion: ${ngl.data.userRegion}`, m, {
                        expiration: m.expiration
                    })
                }
            } catch (error) {
                console.log(error)
                failed++;
            }
            await new Promise(resolve => setTimeout(resolve, delay));
        }*/

    while (success < amount) {
        try {
            const date = new Date();
            const minutes = date.getMinutes();
            const hours = date.getHours();
            const formattedDate = `${hours}:${minutes}`;
            const deviceId = crypto.randomBytes(21).toString('hex');
            const url = 'https://ngl.link/api/submit';
            const headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/109.0',
                'Accept': '*/*',
                'Accept-Language': 'en-US,en;q=0.5',
                'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
                'X-Requested-With': 'XMLHttpRequest',
                'Sec-Fetch-Dest': 'empty',
                'Sec-Fetch-Mode': 'cors',
                'Sec-Fetch-Site': 'same-origin',
                'Referer': `https://ngl.link/${username}`,
                'Origin': 'https://ngl.link'
            };
            const body = `username=${username}&question=${message}&deviceId=${deviceId}&gameSlug=&referrer=`;

            const response = await fetch(url, {
                method: 'POST',
                headers,
                body,
                mode: 'cors',
                credentials: 'include'
            });

            if (response.status !== 200) {
                console.log(`[${formattedDate}] [ERR] Ratelimited`);
                await new Promise(resolve => setTimeout(resolve, 25000));
            } else {
                success++;
                console.log(`[${formattedDate}] [MSG] Sent: ${success}`);
            }
        } catch (error) {
            failed++;
            console.error(`[${formattedDate}] [ERR] ${error}`);
            await new Promise(resolve => setTimeout(resolve, 5000));
        }
    }
        mecha.reply(m.chat, `Successfully spammed NGL to \`${username}\` for ${amount + ' times' + (failed > 0 ? `\nSuccess: ${success}\nFailed: ${failed}` : '')}`, m, {
            expiration: m.expiration
        })
    },
    owner: true
}