const fetch = require('node-fetch')

/*
This feature created by Lorenzo 
Don't delete credits ok 🙂‍↔️ 
*/

exports.run = {
usage: ['valorant-maps'],
hidden: ['vmaps'],
use: 'tempat',
category: 'tools',
async: async (m, { func, mecha }) => {
if (!m.text) return m.reply(func.example(m.cmd, 'Ascent'))
try {
let response = await fetch('https://valorant-api.com/v1/maps');
let data = await response.json();
let maps = data.data;
let map = maps.find(map => map.displayName.toLowerCase() === m.text.toLowerCase());
if (!map) return m.reply(`Map dengan nama "${m.text}" tidak ditemukan`);
let caption = `UUID: ${map.uuid || 'N/A'}
Name: ${map.displayName || 'N/A'}
Tactical Description: ${map.tacticalDescription || 'N/A'}
Coordinates: ${map.coordinates || 'N/A'}`;
mecha.sendMessage(m.chat, {
image: {
url: map.splash
},
caption: caption.trim()
}, {quoted: m, ephemeralExpiration: m.expiration});
} catch (error) {
return mecha.reply(m.chat, String(error), m);
}
},
limit: true
}