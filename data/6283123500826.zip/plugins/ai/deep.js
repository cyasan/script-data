const axios = require('axios');

async function deepseekLLMChat(question, name, current) {
  const { dateNow, timeNow } = timeZone();
  let sistem = `Kamu adalah notfound, Bot WhatsApp dengan program kecerdasan buatan AI (artificial intelligence). Jawablah setiap pertanyaan dengan jawaban yang edukatif dan relevan. Jika ada yang bertanya tentang waktu, jawab dengan informasi yang berkaitan dengan waktu saat ini, yaitu ${timeNow}, dan hari ini adalah ${dateNow}. Lawan bicaramu adalah ${name}. Kamu memiliki sifat dingin dan sedikit imut. Kamu dirancang dan dikembangkan oleh SuryaDev sejak tahun 2021. SuryaDev memiliki nama lengkap Jabal Surya Ngalam, berasal dari Jepara, lahir pada 21 Mei 2005, dan dia adalah seseorang yang kreatif serta berbakat dalam menciptakan berbagai hal.`;
  if (current) sistem += `\n\nBerikan respons yang tidak hanya menjawab pertanyaan, tetapi juga mengaitkan jawabanmu dengan konteks dari percakapan sebelumnya. Jika ada konteks sebelumnya, gunakan itu untuk memperkaya jawabanmu: Sebelumnya, kamu telah membahas: ${current}`;
  try {
    const response = await axios.get(`https://api.siputzx.my.id/api/ai/deepseek-llm-67b-chat?content=${encodeURIComponent(question)}`);
    return response.data;
  } catch (error) {
    console.log(error);
    return error.message;
  }
}

exports.run = {
  usage: ['deepai'],
  use: 'question',
  category: 'ai',
  async: async (m, { func, mecha, users }) => {
    if (!m.text) return m.reply(func.example(m.cmd, 'Hai'));
    mecha.sendReact(m.chat, '🕒', m.key);
    try {
      let messageId = 'MECHA' + func.makeid(5).toUpperCase() + 'OPENAI';
      let response = await deepseekLLMChat(m.text, users.name.replaceAll('\n', '\t'));
      mecha.sendMessage(m.chat, { text: `${response}` }, { quoted: m, ephemeralExpiration: m.expiration, messageId: messageId });
    } catch (error) {
      mecha.sendReact(m.chat, '❌', m.key);
      return errorMessage(error);
    }
  },
  main: async (m, { func, mecha, users }) => {
    if (m.budy && m.quoted && m.quoted.fromMe && m.quoted.id.endsWith('OPENAI') && !m.isPrefix) {
      mecha.sendReact(m.chat, '🕒', m.key);
      try {
        let messageId = 'MECHA' + func.makeid(5).toUpperCase() + 'OPENAI';
        let response = await deepseekLLMChat(m.budy, users.name.replaceAll('\n', '\t'), m.quoted.text);
        mecha.sendMessage(m.chat, { text: `${response}` }, { quoted: m, ephemeralExpiration: m.expiration, messageId: messageId });
        users.limit -= 1;
      } catch (error) {
        mecha.sendReact(m.chat, '❌', m.key);
        return errorMessage(error);
      }
    }
  },
  limit: true,
  location: 'plugins/ai/ai.js'
}

function timeZone() {
  const today = new Date();
  const date = new Date(today.toLocaleString("en-US", { timeZone: "Asia/Jakarta" }));
  const hours = date.getHours();
  const minutes = date.getMinutes();
  const day = today.getDate();
  const month = today.getMonth() + 1;
  const year = today.getFullYear();
  const dayOfWeek = today.toLocaleDateString("id-ID", { weekday: "long" });
  const timeNow = `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}`;
  return { dateNow: `${dayOfWeek}, ${day}/${month}/${year}`, timeNow: `${timeNow} WIB` }
}