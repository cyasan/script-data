exports.run = {
usage: ['meta'],
hidden: ['metaai'],
use: 'question',
category: 'ai',
async: async (m, { func, mecha }) => {
if (!m.text) return m.reply(func.example(m.cmd, 'siapa namamu?'))
mecha.sendReact(m.chat, '🕒', m.key);
let data = await func.fetchJson(`https://api.siputzx.my.id/api/ai/meta-llama-33-70B-instruct-turbo?content=${m.text}`)
if (!data.status) return m.reply(global.mess.error.api)
m.reply(`${data.result}`)
},
limit: true
}