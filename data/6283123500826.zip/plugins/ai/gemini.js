exports.run = {
usage: ['gemini'],
hidden: ['g'],
use: 'query',
category: 'ai',
async: async (m, { func, mecha, quoted }) => {
let text;
if (m.args.length >= 1) {
text = m.args.slice(0).join(" ");
} else if (m.quoted && m.quoted.text) {
text = m.quoted.text;
} else return m.reply(func.example(m.cmd, 'halo'));
let { key } = await mecha.sendMessage(m.chat, {text: global.mess.wait}, {quoted: m, ephemeralExpiration: m.expiration});
if (/image\/(png|jpe?g)/.test(quoted.mime)) {
try {
let media = await mecha.downloadAndSaveMediaMessage(m)
let anu = await func.UploadFileUgu(media);
let res = await Image(text, anu.url);
await mecha.sendMessage(m.chat, {
text: `${res.result.data}`, 
edit: key
}, {quoted: m, ephemeralExpiration: m.expiration});
} catch (error) {
return m.reply(String(error));
}
} else {
try {
let res = await Query(text);
await mecha.sendMessage(m.chat, {
text: `${res.result.data}`,
edit: key
}, {quoted: m, ephemeralExpiration: m.expiration});
} catch (error) {
return m.reply(String(error));
}
}

async function Query(query) {
return func.fetchJson("https://api.siputzx.my.id/api/ai/gemini-pro?content= " + query);
}

async function Image(query, url) {
return func.fetchJson(`https://api.siputzx.my.id/api/ai/gemini-pro?content=${query}&url=${url}`);
}

},
premium: true
}