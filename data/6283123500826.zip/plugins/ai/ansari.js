const axios = require('axios');
const apiRequest = async (messages) => {
const response = await axios.post("https://api.ansari.chat/api/v1/complete", {
messages: messages
}, {
headers: {
contentType: "application/json",
origin: "https://ansari.chat",
referer: "https://ansari.chat/"
}
});
return response.data;
};
const processRequest = async (m, mecha) => {
await mecha.sendReact(m.chat, '🕒', m.key);
if (!m.text) {
return 'Mohon sertakan pertanyaan setelah perintah.';
}
const responseText = await apiRequest([{ role: "user", content: m.text }]);
await mecha.sendReact(m.chat, '✅', m.key);
return responseText;
};
exports.run = {
usage: ['ansari'],
use: 'question',
category: 'ai',
async: async (m, { mecha }) => {
const replyText = await processRequest(m, mecha);
mecha.reply(m.chat, replyText, m);
},
limit: true
};