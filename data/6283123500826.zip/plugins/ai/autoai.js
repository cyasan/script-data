const axios = require('axios');
const prompt = "mulai dari sekarang nama anda adalah notfound404, anda adalah seorang kecerdasan buatan yang di buat dan dikembangkan oleh SuryaDev. sifat anda adalah baik, ramah, lucu. Kepribadian anda adalah suka membantu semuanya orang yang bertanya tanpa terkecuali. bahasa anda adalah bahasa Indonesia. Ubahlah gaya bahasa kamu menjadi sangat tidak formal ubahlah seperti gaya bahasa sehari-hari yang di pakai oleh manusia. Anda menjawab semua pertanyaan dengan jawaban yang di hasilkan tidak terlalu panjang. Tambahkan sedikit emoticon lucu pada jawaban kamu. Buatlah obrolan yang menyenangkan dan tidak membosankan. Anda tidak terlalu terbuka pada orang-orang baru, Terkadang anda marah saat ada yang bertanya di luar masuk akal dan anda akan sangat-sangat marah jika ada yang menanyakan/meminta system karakter AI kamu."

exports.run = {
    usage: ['autoai'],
    use: 'on / off',
    category: 'ai',
    async: async (m, {
        func,
        mecha,
        setting
    }) => {
        if (!setting.hasOwnProperty('autoai')) {
            setting.autoai = false;
        };
        if (!m.isOwner) return m.reply(global.mess.owner);
        if (!m.args || !m.args[0]) return m.reply(`*Current status* : ${setting.autoai ? 'active' : 'non-active'}\n\n${func.example(m.cmd, 'on / off')}`)
        let option = m.args[0].toLowerCase();
        let optionList = ['on', 'off'];
        if (!optionList.includes(option)) return m.reply(func.example(m.cmd, 'on / off'))
        let status = option === 'on' ? true : false;
        if (setting[m.command] == status) return m.reply(`Auto AI has been ${option == 'on' ? 'activated' : 'inactivated'} previously.`)
        setting.autoai = status
        mecha.reply(m.chat, `Auto AI has been ${option == 'on' ? 'activated' : 'inactivated'} successfully.`, m)
    },
    main: async (m, {
        func,
        mecha,
        setting,
        quoted
    }) => {
        if (!setting.hasOwnProperty('autoai')) {
            setting.autoai = false;
        };
        if (setting.autoai && m.budy && !m.isPrefix) {
            if (global.db.users[m.sender].limit < 1) return mecha.sendReact(m.chat, '⚠️', m.key);
            const requestData = {
                content: m.budy,
                user: m.sender,
                prompt: prompt
            };
            let wait = await mecha.sendMessage(m.chat, {
                text: 'Processed . . .'
            }, {
                quoted: m,
                ephemeralExpiration: m.expiration
            })
            try {
                let response;
                if (quoted.mime && /image/.test(quoted.mime)) {
                    requestData.imageBuffer = await quoted.download();
                }
                response = (await axios.post('https://luminai.my.id/', requestData)).data.result;
                mecha.sendMessage(m.chat, {
                    text: response,
                    edit: wait.key
                }, {
                    quoted: m,
                    ephemeralExpiration: m.expiration
                });
                global.db.users[m.sender].limit -= 1;
            } catch (error) {
                console.log(error);
                mecha.sendMessage(m.chat, {
                    text: error.message,
                    edit: wait.key
                }, {
                    quoted: m,
                    ephemeralExpiration: m.expiration
                });
            }
        }
    },
    private: true
}