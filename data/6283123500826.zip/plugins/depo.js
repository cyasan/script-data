const axios = require('axios');
const qrcode = require('qrcode');
const FormData = require('form-data');

const maupedia = {
key: '8CLlF9XP888t30tPJp1Pxkp7YKN9WoabF67AJDQaglbdIPoF4fROOXj4Dq7oPPgD',
signature: 'cedacaacec3e14505893bc56be9f94be79346a29',
secret: 'alok2020',
}

exports.run = {
usage: ['deposit'],
hidden: ['depo'],
use: 'amount',
category: 'topup',
async: async (m, { func, mecha }) => {
let isProcess = false;
if (!m.text) return m.reply(func.example(m.cmd, 'amount'))
let amount = m.text;
let metode = m.text.slice(amount.length + 1);
if (isNaN(amount)) return m.reply('Masukkan angka, bukan huruf')
var conf = new FormData(); 
if (!metode) {
conf.append('key', maupedia.key); 
conf.append('sign', maupedia.signature); 
conf.append('secret', maupedia.secret); 
conf.append('type', 'method');
var config = { 
method: 'post', 
maxBodyLength: Infinity, 
url: 'https://maupedia.com/api/deposit', 
headers: { 
...conf.getHeaders() 
}, 
data: conf 
};
let { data } = await axios(config).catch((e) => e?.response);
if (!data.result) return m.reply(JSON.stringify(data, null, 2))
let rows = []; 
let list = data.data.filter(a => a.type === "qris");
for (let i of list) {
rows.push({
title: "• " + i.name,
description: `• Min : ${func.formatNumber(i.min)}\n• Max : ${func.formatNumber(i.max)}`,
id: `${m.cmd} ${amount} ${i.code}`
})
}
let sections = [{
title: 'PILIH APLIKASI DIBAWAH',
rows: rows
}]
let buttons = [
['list', 'Click Here ⎙', sections],
]
mecha.sendButton(m.chat, `D E P O S I T - A T L A N T I C`, 'Silahkan pilih metode Deposit anda dibawah', `${m.cmd} ${amount} *code_method*`, buttons, m, {
expiration: m.expiration
})
} else if (metode === "cancel") {
conf.append('key', maupedia.key); 
conf.append('sign', maupedia.signature); 
conf.append('secret', maupedia.secret); 
conf.append('type', 'cancel'); 
conf.append('trxid', amount);
var config = { 
method: 'post', 
maxBodyLength: Infinity, 
url: 'https://maupedia.com/api/deposit', 
headers: { 
...conf.getHeaders() 
}, 
data: conf 
};
let response = await axios(config);
isProcess = true;
m.reply(response.data.message); 
} else {
conf.append('key', maupedia.key);
conf.append('sign', maupedia.signature);
conf.append('secret', maupedia.secret); 
conf.append('type', 'request'); 
conf.append('method', metode); 
conf.append('quantity', amount);
var config = { 
method: 'post', 
maxBodyLength: Infinity, 
url: 'https://maupedia.com/api/deposit', 
headers: { 
...conf.getHeaders() 
}, 
data: conf 
};
let response = await axios(config);
let hasil = response.data; 
if (!hasil.result) return m.reply(hasil.message); 
const qrCodeData = await qrcode.toDataURL(hasil.data.qr_string.slice(0, 2048), {
scale: 10
});
const buffer = Buffer.from(qrCodeData.substring(22), "base64");
let txt = `*• Name :* ${hasil.data.name}
*• TrxId :* ${hasil.data.trxid}
*• Status :* ${hasil.data.status.toUpperCase()}
*• Amount :* ${func.formatNumber(hasil.data.amount)}
*• Fee :* ${hasil.data.fee}
*• Note :* ${hasil.data.pay_note}
*• Checkout :* ${hasil.data.qr_url}
*• Create at :* ${hasil.data.created_at}
*• Expired at :* ${hasil.data.expired_at}`; 
let q = await mecha.sendMessage(m.chat, {
image: buffer,
caption: txt
}, {quoted: m, ephemeralExpiration: m.expiration});
while (!isProcess) {
var data = new FormData();
data.append('key', maupedia.key);
data.append('sign', maupedia.signature);
data.append('secret',maupedia.secret);
data.append('type', 'status');
data.append('trxid', hasil.data.trxid);
var config = {
method: 'post',
maxBodyLength: Infinity,
url: 'https://maupedia.com/api/deposit',
headers: { 
...data.getHeaders()
},
data : data
};

let status = await (await axios(config)).data
console.log("Detail Deposit : " + status.data[0].status);
if (status.data[0].status === "paid") {
let user = global.db.data.users[m.sender]
isProcess = true;
console.log("Deposit Berhasil!");
user.saldo += parseInt(amount);
await mecha.reply(m.chat, `*[ TRANSAKSI SUCCESS ]*\n
*• TrxId :* ${status.data[0].trxid}
*• Amount :* ${func.formatNumber(status.data[0].amount)}
*• Status :* ${status.data[0].status.toUpperCase()}
*• Update at :* ${status.data[0].updated_at}

Saldo Sudah masuk ke akun anda!, Total saldo kamu sekarang *Rp ${func.formatNumber(user.saldo)}*`, q);
}
}
}
}
}