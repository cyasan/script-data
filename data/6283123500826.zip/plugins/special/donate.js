exports.run = {
usage: ['donate'],
hidden: ['donasi'],
category: 'special',
async: async (m, { mecha, fpayment }) => {
let caption = `Halo ${m.pushname}👋🏻

Kamu bisa mendukung agar bot ini tetap aktif dengan
⭝ Dana : 6285931248430 
⭝ Ovo : 6285931248430
⭝ Gopay : 6285931248430
⭝ Pulsa : 6283123500826
⭝ Saweria : https://saweria.co/
⭝ Sociabuzz : https://sociabuzz.com/

Hasil donasi akan digunakan untuk membeli *Server Bot* agar bot dapat aktif 24 jam tanpa kendala.
Berapapun donasi kamu akan sangat berarti, Terimakasih!`
mecha.sendMessage(m.chat, {
image: {
url: global.qrisUrl
}, 
caption: caption
}, {quoted: m, ephemeralExpiration: m.expiration});
}
}