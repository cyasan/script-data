exports.run = {
usage: ['buyprem'],
hidden: ['premium'],
category: 'special',
async: async (m, { func, mecha, setting }) => {
let caption;
if (func.somematch(['buyprem', 'premium'], m.command)) {
caption =  `「 *LIST HARGA PREMIUM* 」

*PAKET P1*
- Rp5.000 / 7 Day
- Unlock Feature Premium
- Unlimited Limit

*PAKET P2*
- Rp10.000 / 15 Day
- Unlock Feature Premium
- Unlimited Limit

*PAKET P3*
- Rp20.000 / 30 Day
- Perpanjang Rp15.000 (hemat 25%)
- Unlock Feature Premium
- Unlimited Limit

*PAKET P4*
- Rp30.000 / 60 Day
- Perpanjang Rp25.000 (hemat 17%)
- Unlock Feature Premium
- Unlimited Limit

*PAYMENT*
> • Dana : 085931248430
> • Ovo : 085931248430
> • Gopay : 085931248430
> • QRIS (All Payment)

*INFORMATION*
> 1. Melakukan pembelian artinya anda setuju dengan segala kebijakan kami.
> 2. Semua pembelian bergaransi.
> 3. Tidak puas dengan layanan kami? Kami kembalikan uang Anda 100% dalam jangka waktu 1 jam setelah pembelian.
> 4. Jika bot mengalami kendala atau perbaikan hingga 24 jam atau lebih, kami berikan kompensasi berupa penambahan waktu sewa.
> 5. Perpanjangan hanya berlaku jika masa aktif tersisa kurang dari 3 hari.

Berminat? Hubungi :
wa.me/${global.owner.replace(/[^0-9]/g, '')}`
}
mecha.sendMessage(m.chat, {
image: {
url: global.qrisUrl
}, 
caption: caption
}, {quoted: m, ephemeralExpiration: m.expiration});
}
}