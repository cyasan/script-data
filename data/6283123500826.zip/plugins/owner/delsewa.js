exports.run = {
usage: ['delsewa'],
use: 'link group',
category: 'owner',
async: async (m, { func, mecha }) => {
if (m.isPc){
if (!m.text) return m.reply(func.example(m.cmd, 'https://chat.whatsapp.com/codeInvite'))
let link = /chat.whatsapp.com\/([0-9A-Za-z]{20,24})/i
let [_, code] = m.args[0].match(link) || []
if (!code) return m.reply('No invite url detected.');
let res = await mecha.groupQueryInvite(code)
if (!res) return m.reply(func.jsonFormat(res))
let groups = global.db.groups[res.id];
let statuses = (m.args[1] || '').toLowerCase() === '--vip' ? true : false;
if (!groups.sewa.status) return m.reply('Grup tersebut tidak ada di list sewa!')
if (statuses && !groups.sewa.vip) return m.reply('Grup tersebut sudah ada di list sewa VIP!')
groups.sewa.expired = 0;
groups.sewa.status = false;
if (statuses) groups.sewa.vip = false;
m.reply(`Successfully deleted rent${statuses ? ' VIP' : ''} to this group.`)
} else if (m.isGc){
let groups = global.db.groups[m.chat];
let statuses = (m.args[0] || '').toLowerCase() === '--vip' ? true : false;
if (!groups.sewa.status) return m.reply('Grup ini tidak ada di list sewa!')
if (statuses && !groups.sewa.vip) return m.reply('Grup ini tidak ada di list sewa VIP!')
groups.sewa.expired = 0;
groups.sewa.status = false;
if (statuses) groups.sewa.vip = false;
m.reply(`Successfully deleted rent${statuses ? ' VIP' : ''} to this group.`)
}
},
devs: true
}