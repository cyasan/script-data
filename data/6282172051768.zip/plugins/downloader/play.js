let axios=require("axios"),yts=require("yt-search");async function downloadImage(e){try{var a=await axios.get(e,{responseType:"arraybuffer"});return Buffer.from(a.data,"binary")}catch(e){return null}}async function download(e){return(await axios.get("https://api.ryzendesu.vip/api/downloader/ytmp3?url="+encodeURIComponent(e))).data}exports.run={usage:["play"],use:"judul lagu",category:"downloader",async:async(a,{func:e,mecha:t,isPrem:i})=>{if(t.play=t.play||{},t.play[a.sender]&&!i)return a.reply("Masih ada proses yang belum selesai BODOH.");if(!a.text)return a.reply(e.example(a.cmd,"melukis senja"));t.play[a.sender]=a.text.trim(),t.sendReact(a.chat,"🕒",a.key);try{var r,o,n,l,s,u,d;a.args[0].match(/(?:https?:\/\/)?(?:www\.)?(?:youtube\.com\/(?:watch\?v=|embed\/|v\/)|youtu\.be\/)([\w-]{11})/)?(o=await downloadImage((r=await download(a.args[0])).thumbnail),n="*Y O U T U B E - D O W N L O A D E R*\n",n=(n=(n=(n=(n=(n=(n+=`
∘ Title : `+(r.title||"-"))+`
∘ Duration : `+(r.lengthSeconds||"-"))+`
∘ Views : `+(r.views||"-"))+`
∘ Upload : `+(r.uploadDate||"-"))+`
∘ Author : `+(r.author||"-"))+`
∘ URL : `+r.videoUrl)+`
∘ Description: `+(r.description||"-")+`

Please wait, the audio file is being sent...`,await t.sendMessageModify(a.chat,n,a,{title:r.title,body:r.author||"-",largeThumb:!0,thumbnail:o,url:r.videoUrl,expiration:a.expiration}),await t.sendMessage(a.chat,{audio:{url:r.url},fileName:r.filename,mimetype:"audio/mpeg",ptt:!1},{quoted:a,ephemeralExpiration:a.expiration})):(s=await downloadImage((l=(await yts(a.text)).videos[0]).thumbnail),u="*Y O U T U B E - P L A Y*\n",u=(u=(u=(u=(u=(u=(u+=`
∘ Title : `+(l?.title||"-"))+`
∘ Duration : `+(l?.timestamp||l?.duration?.timestamp||"-"))+`
∘ Views : `+(l?.views||"-"))+`
∘ Upload : `+(l?.ago||"-"))+`
∘ Author : `+(l?.author?.name||"-"))+`
∘ URL : `+l.url)+`
∘ Description: `+(l?.description||"-")+`

Please wait, the audio file is being sent...`,await t.sendMessageModify(a.chat,u,a,{title:l.title,body:l?.author?.name||"-",largeThumb:!0,thumbnail:s,url:l.url,expiration:a.expiration}),d=await download(l.url),await t.sendMessage(a.chat,{audio:{url:d.url},fileName:l.title+".mp3",mimetype:"audio/mpeg",ptt:!1},{quoted:a,ephemeralExpiration:a.expiration})),delete t.play[a.sender]}catch(e){return delete t.play[a.sender],t.sendReact(a.chat,"❌",a.key),t.reply(a.chat,e.message,a,{expiration:a.expiration})}},restrict:!0,limit:3,location:"plugins/downloader/play.js"};