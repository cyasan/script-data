// nomor owner ubah nomor lu
global.owner = '6282172051768@s.whatsapp.net' // 62882003321562
// nama owner ubah nama lu
global.ownerName = '𝟔𝟔𝟔𝖈𝖍𝖗𝖎𝖘'
// nama bot lu
global.botName = '𝟔𝟔𝟔𝖈𝖍𝖗𝖎𝖘 [𝔟𝔬𝔱 𝔬𝔫𝔩𝔶]'
// fake pada beberapa fitur
global.fake = 'copyright © 1945 𝟔𝟔𝟔𝖈𝖍𝖗𝖎𝖘'
// header pada beberapa fitur
global.header = `© mecha-bot v${require('./package.json').version}`
// footer pada beberapa fitur
global.footer = '𝐬𝐢𝐦𝐩𝐥𝐞 𝐰𝐡𝐚𝐭𝐬𝐚𝐩𝐩 𝐦𝐚𝐝𝐞 𝐛𝐲 𝟔𝟔𝟔𝖈𝖍𝖗𝖎𝖘' 
// jeda anti spam / detik
global.cooldown = 1
// ram maksimal untuk auto restart / gb
global.max_ram = 3
// blacklist nomor dengan kode negara tersebut
global.blocks = ['91', '92', '212']
// multi prefix default
global.prefixes = /^[°•π÷×¶∆£¢€¥®™+✓_=|/~!?@#%^&.©^]/i
// qris url di beberapa fitur seperti donate, buyprem dan sewabot
global.qrisUrl = 'https://telegra.ph/file/91ec74ba6a45936c0c127.jpg'
// audio url yang ada di menu
global.audioUrl = 'https://files.catbox.moe/hgvl9x.mp4';
// url database mongodb (daftar di https://www.mongodb.com/)
global.mongoUrl = ''
// setting pairing code
global.pairing = {
status: true, // ubah false jika ingin menggunakan qr
number: '6282172051768' // ubah jadi nomor bot lu
}
// setting configuration baileys
global.config = {
session: 'session',
online: false,
version: [2, 3000, 1015901307],
browser: ['Windows', 'Chrome', '20.0.04']
}
// teks welcome default
global.tekswelcome = 'Hello, +user Thank you for joining the group +group\n\nPlease intro first :\nName :\nAge :\nHome town :'
// teks leave default
global.teksleft = 'Goodbye +user'
// apikey fitur quickchat
global.quoteApi = 'https://bot.lyo.su/quote/generate'
// setting message
global.mess = {
wait: 'sabar ya pantek ngentot',
ok: 'done kontol ambil tuh ajg',
limit: '*MAMPUS LU NGENTOT HAHAHAHA LIMIT LU HABIS YA?😹*\n\n*MAU LIMIT? MINTA BALANCE KE* https://wa.me/6282172051768?text=haiiii+king+win+😈+bagi+balance+buat+buylimit',
premium: '*EH KONTOL LU MAU NGAPAIN AJG? FITUR INI CUMA BISA DI GUNAIN SAMA PREMIUM DOANG YA DEK😹*',
jadibot: 'This feature only for jadibot user.',
owner: '𝐟𝐢𝐭𝐮𝐫 𝐢𝐧𝐢 𝐜𝐮𝐦𝐚 𝐛𝐢𝐬𝐚 𝐝𝐢 𝐩𝐚𝐤𝐚𝐢 𝐤𝐢𝐧𝐠 𝟔𝟔𝟔𝖈𝖍𝖗𝖎𝖘',
group: 'OI KONTOL KHUSUS GRUP DOANG BABI',
private: 'Use this feature in private chat.',
admin: '*KASIAN GABISA😹 LU ITU CUMA MEMBER DEK FITUR INI KHUSUS ATMIN DOANG😂*',
botAdmin: '*EH PEPEK MINIMAL ADMININ GW AJG*',
gconly: 'LU MAU NGAPAIN? KHUSUS GRUP DOANG',
wrong: 'Wrong format!',
error: {
url: 'URL is Invalid!', 
api: 'Sorry an error occurred!'
},
block: {
owner: `𝐥𝐮 𝐦𝐚𝐮 𝐧𝐠𝐚𝐩𝐚𝐢𝐧 𝐧𝐠𝐞𝐧𝐭𝐨𝐭? 𝐟𝐢𝐭𝐮𝐫 𝐢𝐧𝐢 𝐮𝐝𝐚𝐡 𝐝𝐢 𝐛𝐥𝐨𝐤 𝐤𝐢𝐧𝐠 𝐰𝐢𝐧 😈`,
system: `This feature is being blocked by system because an error occurred!`
},
query: 'Enter search text',
search: 'Searching . . .',
scrap: 'Scrapping . . .',
wrongFormat: 'Incorrect format, please look at the menu again',
}
// menghapus cache setelah update
require('./system/functions.js').reloadFile(__filename);