let axios=require("axios"),stalkff=async r=>{try{return{status:!0,...(await axios.get("https://freefireinfo.vercel.app/profile?region=SG&uid="+r+"&key=SHAHG")).data}}catch(r){return console.error(r),{status:!1,message:r.message}}};exports.run={usage:["ffstalk"],hidden:["stalkff"],use:"id free fire",category:"searching",async:async(r,{func:e,mecha:a})=>{if(!r.text)return r.reply(e.example(r.cmd,"382948365"));var o=Number(r.args[0]);if(isNaN(o))return r.reply("ID harus berupa angka!");a.sendReact(r.chat,"🕒",r.key);o=await stalkff(o);if("success"!=o.status)return r.reply("Error ID tidak ditemukan\nSilahkan kirim ID yang valid!");var i,n,t,f,s,c,l,{ProfileInfo:u,CollectionInfo:d,GuildInfo:I,captainBasicInfo:g,HonorScoreInfo:p,PetInfo:y,ProfilePage:k}=o.data;let h="乂  *STALKER FREE FIRE*\n";for(i in h=(h=(h+=`
◦  *ID:* `+o.PlayerUID)+(`
◦  *Rule:* `+o.rule))+(`
◦  *Region:* `+o.region)+`

◦  *Profile Info:*`,u)h+=`
◦  *${e.ucword(i)}:* `+u[i];for(n in h+=`

◦  *Collection Info:*`,d){var m=d[n];h+=`
◦  *${e.ucword(n)}:* `+(Array.isArray(m)&&m.join(", "))}for(t in h+=`

◦  *Guild Info:*`,I)h+=`
◦  *${e.ucword(t)}:* `+I[t];for(f in h+=`

◦  *Captain Basic Info:*`,g)h+=`
◦  *${e.ucword(f)}:* `+g[f];for(s in h+=`

◦  *Honor Score Info:*`,p)h+=`
◦  *${e.ucword(s)}:* `+p[s];for(c in h+=`

◦  *Pet Info:*`,y)h+=`
◦  *${e.ucword(c)}:* `+y[c];for(l in h+=`

◦  *Profile Page:*`,k)h+=`
◦  *${e.ucword(l)}:* `+k[l];a.reply(r.chat,h,r,{expiration:r.expiration})},limit:!0,location:"plugins/searching/ffstalk.js"};