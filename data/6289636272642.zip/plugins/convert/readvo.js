exports.run = {
    usage: ['readviewonce'],
    hidden: ['rvo'],
    use: 'reply viewonce',
    category: 'convert',
    async: async (m, {
        func,
        mecha,
        store,
        quoted
    }) => {
        try {
            if (quoted?.viewOnce) {
                let buffer = await quoted.download();
                let type = quoted.mime;
                let caption = quoted.caption;
                if (/video/.test(type)) {
                    await mecha.sendMessage(m.chat, {
                        video: buffer,
                        caption: caption,
                        mentions: mecha.ments(caption)
                    }, {
                        quoted: m,
                        ephemeralExpiration: m.expiration
                    })
                } else if (/image/.test(type)) {
                    await mecha.sendMessage(m.chat, {
                        image: buffer,
                        caption: caption,
                        mentions: mecha.ments(caption)
                    }, {
                        quoted: m,
                        ephemeralExpiration: m.expiration
                    })
                }
            } else m.reply('Reply view once message to use this command.')
        } catch (e) {
            m.reply(e.message);
        }
    },
    premium: true,
    location: 'plugins/convert/readvo.js'
}