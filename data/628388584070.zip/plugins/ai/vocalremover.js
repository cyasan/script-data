const axios = require('axios')
const FormData = require('form-data')

const api = axios.create({ baseURL: 'https://aivocalremover.com' })
const getKey = async () => (await api.get('/')).data.match(/key:"(\w+)/)[1]

const vocalRemover = async (audioBuffer) => {
const form = new FormData()
const fileName = Math.random().toString(36) + '.mpeg'
form.append('fileName', audioBuffer, fileName)

const [key, fileUpload] = await Promise.all([
await getKey(),
await api.post('/api/v2/FileUpload', form, { headers: form.getHeaders() }).catch(e => e.response)
])
if (fileUpload.status !== 200) throw fileUpload.data || fileUpload.statusText

const processFile = await api.post('/api/v2/ProcessFile', new URLSearchParams({
file_name: fileUpload.data.file_name,
action: 'watermark_video', key, web: 'web' 
})).catch(e => e.response)

return processFile.data
}

exports.run = {
usage: ['aivocalremover'],
hidden: ['vocalremover', 'avr'],
use: 'reply audio',
category: 'ai',
async: async (m, { func, mecha, quoted }) => {
if (/audio/.test(quoted.mime)) {
mecha.sendReact(m.chat, '🕒', m.key)
let media = await quoted.download()
let result = await vocalRemover(media)
if (result.error) return m.reply(result.message)
mecha.reply(m.chat, result.message, m, {
expiration: m.expiration
})
await mecha.sendMessage(m.chat, {
audio: {
url: result.vocal_path
},
mimetype: 'audio/mpeg'
}, {quoted: m, ephemeralExpiration: m.expiration})
await mecha.sendMessage(m.chat, {
audio: {
url: result.instrumental_path
},
mimetype: 'audio/mpeg'
}, {quoted: m, ephemeralExpiration: m.expiration})
} else m.reply(`Reply audio dengan caption ${m.cmd}`)
},
premium: true
}