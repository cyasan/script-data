let moment=require("moment-timezone");exports.run={usage:["approve"],hidden:["accept","acc"],category:"group",async:async(e,{func:t,mecha:a})=>{let[i]=e.args,r=[],p=`乂  *LIST REQUEST JOIN*
`;p=(p+=`
*${e.prefix}acc 1* untuk approve peserta 1`)+`
*${e.prefix}acc all* untuk approve semua peserta`;var s=await a.groupRequestParticipantsList(e.chat);if(0==s.length)return e.reply("Tidak ada pending request.");if(s.forEach((e,t)=>{r.push({index:t+1,jid:e.jid,request_method:e.request_method,request_time:e.request_time}),p=(p=(p+=`

${t+1}. @`+e.jid.split("@")[0])+`
◦  *Request method:* `+e.request_method)+`
◦  *Time:* `+moment(1e3*e.request_time).tz("Asia/Jakarta").format("DD/MM/YY HH:mm:ss")}),i&&/^(all|semua)$/i.test(i)){for(var o of s)await a.groupRequestParticipantsUpdate(e.chat,[o.jid],"approve"),await t.delay(1e3);a.reply(e.chat,`Successfully approved ${s.length} participants.`,e,{expiration:e.expiration})}else i&&r.some(e=>e.index==i)?(s=r[i-1].jid,await a.groupRequestParticipantsUpdate(e.chat,[s],"approve"),a.sendReact(e.chat,"✅",e.key)):await a.reply(e.chat,p,e,{expiration:e.expiration})},group:!0,admin:!0,botAdmin:!0};