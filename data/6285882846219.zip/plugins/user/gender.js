exports.run = {
usage: ['gender'],
use: 'male / female',
category: 'user',
async: async (m, { func, mecha }) => {
if (global.db.users[m.sender].gender !== '') return m.reply('Kamu sudah memiliki gender!')
if (/^(male)$/i.test(m.args[0])) {
global.db.users[m.sender].gender = 'Laki-laki'
m.reply('Kamu telah memilih jenis kelamin `Laki-laki`.')
} else if (/^(female)$/i.test(m.args[0])) {
global.db.users[m.sender].gender = 'Perempuan'
m.reply('Kamu telah memilih jenis kelamin `Perempuan`.')
} else m.reply(`Mohon masukkan keyword dengan benar!\nContoh: ${m.prefix}gender male\n\n${m.prefix}gender male untuk \`Laki-laki\`.\n${m.prefix}gender female untuk \`Perempuan\`.`)
}
}