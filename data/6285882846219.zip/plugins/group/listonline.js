exports.run = {
    usage: ['listonline'],
    category: 'group',
    async: async (m, {
        func,
        mecha,
        store
    }) => {
        try {
            let id = m.args[0] && /\d+\-\d+@g.us/.test(m.args[0]) ? m.args[0] : m.chat;
            if (typeof store.presences[id] == 'undefined') return m.reply('Tidak ada peserta yang sedang online.');
            let online = [...Object.keys(store.presences[id]), m.bot];
            if (online.length > 0) {
                m.reply('Daftar peserta yang sedang online:\n\n' + online.map(v => '- @' + v.replace(/@.+/, '')).join('\n'))
            } else {
                m.reply('Tidak ada peserta yang sedang online.');
            }
        } catch {
            m.reply('Data kosong.');
        }
    },
    group: true
}