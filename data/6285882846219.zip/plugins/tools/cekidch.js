let database = {};

exports.run = {
usage: ['cekidch'],
hidden: ['getidch'],
category: 'tools',
async: async (m, { func, mecha }) => {
let sender = m.sender;
database[sender] = Date.now()
mecha.reply(m.chat, `Kirim pesan yang diteruskan dari saluran...`, m, {
expiration: m.expiration
})
},
main: async (m, { func, mecha }) => {
let sender = m.sender;
if (m.budy && (sender in database) && (Date.now() - database[sender]) < 3600000) {
const newsletterMessage = m.msg?.contextInfo?.forwardedNewsletterMessageInfo;
if (newsletterMessage) {
let caption = `- Jid: ${newsletterMessage.newsletterJid}
- Name: ${newsletterMessage.newsletterName}`
mecha.reply(m.chat, caption, m, {
expiration: m.expiration
})
delete database[sender];
} else {
mecha.reply(m.chat, 'Pesan tersebut tidak mengandung newsletter!\nKirim pesan yang diteruskan dari saluran!', m, {
expiration: m.expiration
})
}
}
},
limit: true
}