// nomor owner ubah nomor lu
global.owner = '62895370719121@s.whatsapp.net' // 6285669013738
// nama owner ubah nama lu
global.ownerName = 'fayyra'
// nomor pengembang yang bisa akses fitur saveplugin, delplugin, getplugin dan eval
global.developer = [ 
// ganti nomor lu tapi jangan asal add nomor, nanti bisa curi kode bot
    '6285169180909',
    '6285669013738',
    '62895415497664',

].map(number => number.replace(/[^0-9]/g, '') + '@s.whatsapp.net')
// nama bot lu
global.botName = 'Paybot'
// fake pada beberapa fitur
global.fake = 'Copyright © 2024 Exyu'
// header pada beberapa fitur
global.header = `© exter-bot v${require('./package.json').version}`
// footer pada beberapa fitur
global.footer = 'ꜱɪᴍᴘʟᴇ ᴡʜᴀᴛꜱᴀᴘᴘ ʙᴏᴛ ᴍᴀᴅᴇ ʙʏ ᴇxyu'
// jeda anti spam / detik
global.cooldown = 1
// ram maksimal untuk auto restart / gb
global.max_ram = 3
// blacklist nomor dengan kode negara tersebut
global.blocks = ['91', '92', '212']
// multi prefix default
global.prefixes = /^[°•π÷×¶∆£¢€¥®™+✓_=|/~!?@#%^&.©^]/i
// setting id channel (cara ambil: ketik .getidch lalu teruskan pesan dari saluranmu ke bot.
global.newsletter = '120363388841695216@newsletter'
// qris url di beberapa fitur seperti donate, buyprem dan sewabot
global.qrisUrl = 'https://telegra.ph/file/080cbdedf32c6c84ff435.jpg'
// audio url yang ada di menu
global.audioUrl = 'https://cdn.filestackcontent.com/2r7cSUozTQ2tTS15NfFj';
// setting pairing code
global.pairing = {
    copyFromLink: true, // ubah true jika ingin salin pairing via link https://iyaudah-iya.vercel.app/pairing
    status: true, // ubah false jika ingin menggunakan qr
    number: '6285602467071' // ubah jadi nomor bot lu 6285669013738
}
// setting configuration baileys
global.config = {
    session: 'session',
    online: true,
    version: [2, 3000, 1015901307],
    browser: ['Windows', 'Chrome', '22.04.4']
}
// apikey fitur quickchat
global.quoteApi = 'https://bot.lyo.su/quote/generate'
// url database mongodb (daftar di https://www.mongodb.com/)
global.mongoUrl = ''
// setting message
global.mess = {
    wait: 'Processed . . .',
    ok: 'Successfully.',
    limit: 'Anda telah mencapai limit dan akan disetel ulang pada pukul 00.00\n\n> untuk mendapatkan limit tak terbatas, tingkatkan ke paket premium.',
    premium: 'beli premium dulu 7k sebulan.',
    jadibot: 'This feature only for jadibot user.',
    owner: 'owner doang yg bisa.',
    devs: 'This feature is only for developers.',
    group: 'This feature will only work in groups.',
    private: 'Use this feature in private chat.',
    admin: 'dih padahal bukan admin, ngemis jadi admin sana.',
    botAdmin: 'This feature will work when I become an admin',
    gconly: 'Bot hanya dapat digunakan di dalam grup.',
    bot: 'This feature can only be accessed by bots',
    wrong: 'Wrong format!',
    error: {
        url: 'URL is Invalid!',
        api: 'Sorry an error occurred!'
    },
    block: {
        owner: `cuma owner yang bisa!`,
        system: `This feature is being blocked by system because an error occurred!`
    },
    query: 'Enter search text',
    search: 'Searching . . .',
    scrap: 'Scrapping . . .',
    wrongFormat: 'Incorrect format, please look at the menu again',
    game: 'Bermain game di obrolan pribadi hanya untuk pengguna premium, tingkatkan ke paket premium hanya Rp. 7.000 selama 1 bulan.'
}

// menghapus cache setelah update
require('./system/functions.js').reloadFile(__filename);