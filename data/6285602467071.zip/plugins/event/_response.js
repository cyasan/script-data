const multidb = new(require('../../system/multidb.js'))();

exports.run = {
    main: async (m, {
        func,
        mecha,
        users,
        groups,
        setting
    }) => {
        /* Anti Toxic Kepada Bot By SuryaDev
        if (users && !users.banned && !users.premium && !m.isOwner) {
            function runWarning() {
                users.warning += 1
                let warning = users.warning
                if (warning >= 3) return m.reply(`Anda melanggar *Syarat & Ketentuan* penggunaan bot dengan menggunakan kata kunci yang masuk daftar hitam, sebagai hukuman atas pelanggaran Anda diblokir dan dibanned. Untuk membuka blokir dan unbanned Anda harus membayar *Rp. 10.000,-*`).then(() => {
                    users.banned = true
                    users.expired.banned = 'PERMANENT'
                    mecha.updateBlockStatus(m.sender, 'block')
                })
                return m.reply(`乂  *W A R N I N G* \n\nAnda Mendapat Peringatan : [ ${warning} / 3 ]\n\nJika Anda mendapatkan 3 peringatan, Anda akan otomatis diblokir dan dibanned oleh system.`)
            }
            if (m.isGc && m.budy && Array.isArray(setting.toxic) && setting.toxic.length > 0 && (new RegExp('\\b' + setting.toxic.map(v => 'bot ' + v).join('\\b|\\b') + '\\b')).test(m.budy?.toLowerCase())) {
            return runWarning();
            } else if (m.isPc) {
                let array = m.budy.toLowerCase().split(' ');
                let status = removeDuplicateLetters(array).map(words => setting.toxic.some(badword => badword == words)).filter(state => state);
                if (status.length > 0) return runWarning();
            }
        }*/

        /* respon ketika ada yang ketik bot */
        if (m.budy && /^(bot|exter)$/i.test(m.budy)) {
            if (m.isGc && groups.mute && !m.isOwner) return;
            if (users && users.banned && !m.isOwner) return;
            let old = new Date()
            let messageId = 'MECHA' + func.makeid(8).toUpperCase() + 'GPT'
            await mecha.sendMessage(m.chat, {
                text: `Halo ${users.name} 👋🏻, Aku adalah Exter, Bot WhatsApp dengan program kecerdasan AI.\n_Ketik ${m.prefix}menu jika ingin melihat fitur bot ini_`
            }, {
                quoted: m,
                ephemeralExpiration: m.expiration,
                messageId: messageId
            })
        }

        if (!mecha.autorestart && !mecha?.user?.jadibot) mecha.autorestart = setInterval(async () => {
            let seconds = Number(process.uptime());
            let menit = Math.floor(seconds / 60);
            let timeset = 180;
            if (menit >= timeset) {
                clearInterval(mecha.autorestart);
                await multidb.init.save(global.db);
                if (process.send) return process.send('reset');
            }
        }, 30 * 1000)

        /* respon ketika ada yang mengirim group invite */
        if ((m.mtype === 'groupInviteMessage' || ['Undangan untuk bergabung', 'Invitation to join', 'Buka tautan ini', 'chat.whatsapp.com'].includes(m.budy)) && !setting.link.includes(m.budy) && !m.isGc && !m.fromMe && !m.isOwner) {
            let invite = `Halo, sepertinya Anda ingin mengundang bot ke grup Anda.
    
◦ 15 day - Rp 10k
◦ 30 day - Rp 20k
◦ 60 day - Rp 35k
◦ 90 day - Rp 50k

Jika berminat hubungi: wa.me/${global.owner.replace(/[^0-9]/g, '')} untuk order :)`
            return mecha.sendMessageModify(m.chat, invite, m, {
                largeThumb: true,
                thumbnail: await mecha.resize('https://telegra.ph/file/0b32e0a0bb3b81fef9838.jpg', 300, 175),
                url: `https://wa.me/${global.owner.replace(/[^0-9]/g, '')}?text=sewa+bot`
            })
        }

    }
}

function removeDuplicateLetters(array) {
    let newArray = array.map(word => {
        return word.replace(/(.)\1+/g, '$1');
    });
    return newArray
}

function somematch(data, id) {
    let status = data.some((x) => x === id)
    return status ? true : false;
}

/*setInterval(async () => {
    let seconds = Number(process.uptime());
    let menit = Math.floor(seconds / 60);

    if (menit >= 30) {
        console.log('Bot sudah berjalan lebih dari 30 menit, memulai restart...');
        await multidb.init.save(global.db);
        if (process.send) {
            process.send('reset');
        }
    }
}, 60000);*/ // Mengecek setiap 1 menit