exports.run = {
    usage: ['pol'],
    category: 'special',
    async: async (m, { mecha }) => {
        mecha.sendPoll(m.chat, 'okeh', ['ping', 'status'])
    },
    location: 'plugins/pol.js'
}