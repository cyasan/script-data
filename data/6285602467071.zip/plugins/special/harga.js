exports.run = {
usage: ['buyprem', 'sewabot'],
hidden: ['premium', 'sewa'],
category: 'special',
async: async (m, { func, mecha, setting }) => {
let caption;
if (func.somematch(['buyprem', 'premium'], m.command)) {
caption =  `「 *LIST HARGA PREMIUM* 」

*PAKET P1*
- Rp3.000 / 7 Day
- Unlimited Limit

*PAKET P2*
- Rp 7.000 / 30 Day 
- Unlimitid limit

 Tiap pembelian gratis 500.000 balance, informasi lebih lanjut hubungi owner

*NOTED*
> 1. Melakukan pembelian artinya anda setuju dengan segala kebijakan kami.
> 2. Semua pembelian bergaransi.
> 3. Tidak puas dengan layanan kami? Kami kembalikan uang Anda 100% dalam jangka waktu 1 jam setelah pembelian.
> 4. Jika bot mengalami kendala atau perbaikan hingga 24 jam atau lebih, kami berikan kompensasi berupa penambahan waktu sewa.
> 5. Perpanjangan hanya berlaku jika masa aktif tersisa kurang dari 3 hari.

Berminat? Hubungi :
wa.me/${global.owner.replace(/[^0-9]/g, '')}`
} else if (func.somematch(['sewabot', 'sewa'], m.command)) {
caption = `「 *LIST HARGA SEWA BOT* 」

*PAKET S1*
- Rp10.000 / Group
- Masa aktif 30 Hari

*PAKET S2*
- Rp20.000 / Group
- Bonus blc 500.000
- Masa aktif 2 Bulan


*KEUNTUNGAN*
- Fast respon
- Bot on 24 jam
- Antilink (auto kick yg kirim link)
- Antivirtex (auto kick yg kirim virtex)
- Welcome (menyambut member baru)
- Games
- Menfess
- Downloader
- Ai (artificial intelligence)
- Dan masih banyak lagi


*INFORMATION*
> 1. Melakukan pembelian artinya anda setuju dengan segala kebijakan kami.
> 2. Semua pembelian bergaransi. Kecuali Bot terkick sewa hangus
> 3. Tidak puas dengan layanan kami? Kami kembalikan uang Anda 100% dalam jangka waktu 1 jam setelah pembelian.
> 4. Jika bot mengalami kendala atau perbaikan hingga 24 jam atau lebih, kami berikan kompensasi berupa penambahan waktu sewa.
> 5. Perpanjangan hanya berlaku jika masa aktif tersisa kurang dari 3 hari.

Berminat? Hubungi :
wa.me/${global.owner.replace(/[^0-9]/g, '')}`
}
mecha.sendMessage(m.chat, {
image: {
url: global.qrisUrl
}, 
caption: caption
}, {quoted: m, ephemeralExpiration: m.expiration});
}
}