exports.run = {
    usage: ['listvipgc'],
    hidden: ['listgcvip'],
    category: 'developer',
    async: async (m, {
        func,
        mecha
    }) => {
        const groupData = Object.values(global.db.groups).filter(x => x.vip)
        if (!groupData || groupData.length == 0) return m.reply('Empty data.');
        let caption = '*V I P  G R O U P  L I S T*'
        groupData.forEach((group, index) => {
            caption += `\n\n${index + 1}. ${group.name}\n- ${group.jid}`
        })
        mecha.reply(m.chat, caption, m, {
            expiration: m.expiration
        })
    },
    // devs: true,
    location: 'plugins/special/listvipgc.js'
}