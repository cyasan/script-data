const ms = require('parse-ms');

function timeReverse(duration) {
let cek = ms(duration - Date.now())
let d = cek.days
let h = cek.hours
let m = cek.minutes
let s = cek.seconds
var dDisplay = d > 0 ? d + 'd' : '';
var hDisplay = h > 0 ? (d > 0 ? ' ' : '') + h + 'h' : '';
var mDisplay = m > 0 ? (h > 0 ? ' ' : '') + m + 'm' : '';
var sDisplay = s > 0 ? (m > 0 ? ' ' : '') + s + 's' : '';
return dDisplay + hDisplay + mDisplay + sDisplay;
}

exports.run = {
usage: ['listadmin'],
hidden: ['adminlist'],
category: 'group',
async: async (m, { func, mecha }) => {
let groupsadmin = m.metadata.participants.filter(v => v.admin)
let member = global.db.groups[m.chat].member
let listadmin = groupsadmin.map((v, i) => `${i + 1}. @${v.id.split('@')[0]} ${(typeof member[v.id] != 'undefined' && member[v.id].admin && member[v.id].expired != 0) ? `_*(${timeReverse(member[v.id].expired)})*_` : ''}`).join('\n')
let txt = '乂  *L I S T - A D M I N*\n\n'
txt += `Total : ${groupsadmin.length}`
txt += `\n${listadmin}`
m.reply(txt)
},
group: true
}