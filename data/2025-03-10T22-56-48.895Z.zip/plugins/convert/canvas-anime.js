// Module
const {
    createCanvas,
    loadImage,
    registerFont
} = require('canvas');
const fs = require('fs');

exports.run = {
    usage: ['canvas-anime'],
    hidden: ['c-anime'],
    use: 'input or reply text',
    category: 'convert',
    async: async (m, {
        func,
        mecha
    }) => {
        let text;
        if (m.args.length >= 1) {
            text = m.args.slice(0).join(' ');
        } else if (m.quoted && m.quoted.text) {
            text = m.quoted.text;
        } else return m.reply('Input atau reply text!')
        if (!text) return m.reply(func.example(m.cmd, 'yaudah iya'));
        if (text.length > 250) return m.reply('Max 250 character!')
        mecha.sendReact(m.chat, '🕒', m.key)
        try {

            // Font Path
            registerFont('./media/winkle.ttf', {
                family: 'Winkle'
            });

            // Image Path
            loadImage('./media/anime.jpg').then((image) => {
                const canvas = createCanvas(image.width, image.height);
                const ctx = canvas.getContext('2d');

                ctx.drawImage(image, 0, 0, image.width, image.height);

                const maxWidth = image.width * 0.4;
                const maxHeight = image.height * 0.4;
                const x = image.width / 1.5;
                const y = image.height * 0.715;

                ctx.textAlign = 'center';
                ctx.textBaseline = 'middle';

                function fitText(text, maxWidth, maxHeight) {
                    let fontSize = 60;
                    ctx.font = `${fontSize}px Winkle`;

                    while (true) {
                        const lines = wrapText(ctx, text, maxWidth, fontSize);
                        const textHeight = lines.length * fontSize;

                        if (textHeight <= maxHeight) {
                            return fontSize;
                        }

                        fontSize--;
                        ctx.font = `${fontSize}px Winkle`;
                    }
                }

                function wrapText(ctx, text, maxWidth, fontSize) {
                    const words = text.split(' ');
                    const lines = [];
                    let line = '';

                    for (const word of words) {
                        const testLine = line + word + ' ';
                        const testWidth = ctx.measureText(testLine).width;

                        if (testWidth > maxWidth && line) {
                            lines.push(line.trim());
                            line = word + ' ';
                        } else {
                            line = testLine;
                        }
                    }

                    lines.push(line.trim());
                    return lines;
                }

                const fontSize = fitText(text, maxWidth, maxHeight);
                ctx.font = `${fontSize}px Winkle`;

                const lines = wrapText(ctx, text, maxWidth, fontSize);
                const lineHeight = fontSize;

                ctx.save();
                ctx.translate(x, y);
                ctx.rotate((3 * Math.PI) / 180);

                lines.forEach((line, index) => {
                    ctx.fillText(line, 0, (index - lines.length / 2) * lineHeight, maxWidth);
                });

                ctx.restore();

                const buffer = canvas.toBuffer('image/png');
                fs.writeFileSync('output.png', buffer);
                mecha.sendMessage(m.chat, {
                    image: fs.readFileSync('./output.png')
                }, {
                    quoted: m,
                    ephemeralExpiration: m.expiration
                });
                fs.unlinkSync('output.png');
            });
        } catch (error) {
            console.error(error);
            mecha.reply(m.chat, 'Nice Try Dev:\n' + error.message, m, {
                expiration: m.expiration
            })
        }
    },
    limit: 5,
    location: 'plugins/convert/canvas-anime.js'
}