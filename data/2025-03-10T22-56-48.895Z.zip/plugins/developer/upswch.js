exports.run = {
    usage: ['upswch'],
    category: 'developer',
    async: async (m, {
        func,
        mecha
    }) => {
        const {
            generateWAMessage,
            STORIES_JID,
            generateWAMessageFromContent
        } = require('@whiskeysockets/baileys');

        const sendStatusMention = async (content, groupData, statusJidList) => {
            let success = 0,
                failed = 0,
                index = 0;
            const media = await generateWAMessage(STORIES_JID, content, {
                upload: mecha.waUploadToServer,
            });
            const groupStages = itemStages(groupData);
            for (const groupId of groupStages) {
                const additionalNodes = [{
                    tag: "meta",
                    attrs: {},
                    content: [{
                        tag: "mentioned_users",
                        attrs: {},
                        content: groupId.map((jid) => ({
                            tag: "to",
                            attrs: {
                                jid
                            },
                            content: undefined,
                        })),
                    }],
                }];

                await mecha.relayMessage(STORIES_JID, media.message, {
                    messageId: media.key.id,
                    statusJidList: statusJidList,
                    additionalNodes,
                });
                for (const jid of groupId) {
                    try {
                        await mecha.relayMessage(jid, {
                            groupStatusMentionMessage: {
                                message: {
                                    protocolMessage: {
                                        key: media.key,
                                        type: 25,
                                    },
                                },
                            },
                        }, {
                            userJid: mecha.user.jid,
                            additionalNodes: [{
                                tag: "meta",
                                attrs: {
                                    is_status_mention: "true"
                                },
                                content: undefined,
                            }],
                        });
                        success++;
                    } catch (error) {
                        console.log(`Error pada: ${jid}`, error);
                        failed++;
                    }

                    index++;
                    const delay = (index % 10 === 0) ? 30000 : 3000;
                    await new Promise(resolve => setTimeout(resolve, delay));
                }
                await new Promise(resolve => setTimeout(resolve, 5000));
            }
            return {
                success,
                failed
            };
        };

        let groups = Object.values(await mecha.groupFetchAllParticipating()).filter(v => v.participants.find(p => p.id == mecha.user.jid) && !v.announce);
        let groupData = groups.map(x => x.id);
        let statusJidList = groups.flatMap(group => group.participants.map(v => v.id));
        let content = {
            "image": {
                "url": "https://mmg.whatsapp.net/o1/v/t62.7118-24/f2/m239/AQPhlgdU3U0Q6BPKq_9jdxBzC8yGekZSxxidGQhJhhbb7xNqwOjrBKcTLrhBh1ohUgsIFlGnqJXPSPGpL7HIqXmdLM8bFjjzPwrzInQWmg?ccb=9-4&oh=01_Q5AaIGrb8KLTj03kPFI8hi_QmFVtraZzohXyDHYDyNEXqtHy&oe=67E201F2&_nc_sid=e6ed6c&mms3=true",
            },
            "mimetype": "image/jpeg",
            "fileSha256": "CZew/zWdFqAJoqx9I6iAkvB7xYJ62df0zRaD09tKU2Q=",
            "fileLength": "28476",
            "height": 1280,
            "width": 720,
            "mediaKey": "KxL2nRSTgQuQSWumSgHSRDRbHceqL2cFYnSUHzwkGB8=",
            "fileEncSha256": "KK0/it73cGOuizdWHCUCoD/gaQFbLCYBs2WJqdituFc=",
            "directPath": "/o1/v/t62.7118-24/f2/m239/AQPhlgdU3U0Q6BPKq_9jdxBzC8yGekZSxxidGQhJhhbb7xNqwOjrBKcTLrhBh1ohUgsIFlGnqJXPSPGpL7HIqXmdLM8bFjjzPwrzInQWmg?ccb=9-4&oh=01_Q5AaIGrb8KLTj03kPFI8hi_QmFVtraZzohXyDHYDyNEXqtHy&oe=67E201F2&_nc_sid=e6ed6c&_nc_hot=1740280113",
            "mediaKeyTimestamp": "1740280112",
            "contextInfo": {
                "forwardingScore": 1,
                "isForwarded": true
            },
            "scansSidecar": "LQs0+bnNYzwXPIStxbyEOUo1p1N2pDIDwZ9AnImZw6KwBkGDsA+yAg==",
            "scanLengths": [
                4208,
                14252,
                4422,
                5594
            ],
            "midQualityFileSha256": "GBcjPcDuW8Yffzwc3Lku0pvQ1j+Gk0FPrITP5ncg7bg=",
            "annotations": [{
                    "polygonVertices": [{
                            "x": 0.13333334028720856,
                            "y": 0.675000011920929
                        },
                        {
                            "x": 0.8666666746139526,
                            "y": 0.675000011920929
                        },
                        {
                            "x": 0.8666666746139526,
                            "y": 0.737500011920929
                        },
                        {
                            "x": 0.13333334028720856,
                            "y": 0.737500011920929
                        }
                    ],
                    "newsletter": {
                        "newsletterJid": "120363261409301854@newsletter",
                        "newsletterName": "𝗈𝖿𝖿ꪱ𝖼ꪱα𝗅 ⴗα𝗎𝖽α𝗁 ꪱⴗα",
                        "contentType": "LINK_CARD",
                        "accessibilityText": "𝗈𝖿𝖿ꪱ𝖼ꪱα𝗅 ⴗα𝗎𝖽α𝗁 ꪱⴗα"
                    },
                    "shouldSkipConfirmation": true
                },
                {
                    "polygonVertices": [{
                            "x": 0.06666667014360428,
                            "y": 0.22447916865348816
                        },
                        {
                            "x": 0.9333333373069763,
                            "y": 0.22447916865348816
                        },
                        {
                            "x": 0.9333333373069763,
                            "y": 0.7749999761581421
                        },
                        {
                            "x": 0.06666667014360428,
                            "y": 0.7749999761581421
                        }
                    ],
                    "newsletter": {
                        "newsletterJid": "120363261409301854@newsletter",
                        "newsletterName": "𝗈𝖿𝖿ꪱ𝖼ꪱα𝗅 ⴗα𝗎𝖽α𝗁 ꪱⴗα",
                        "contentType": "LINK_CARD",
                        "accessibilityText": "𝗈𝖿𝖿ꪱ𝖼ꪱα𝗅 ⴗα𝗎𝖽α𝗁 ꪱⴗα"
                    }
                }
            ]
        }
        mecha.sendReact(m.chat, '🕒', m.key);
        await sendStatusMention(content, groupData, statusJidList);
        mecha.sendReact(m.chat, '✅', m.key)
    },
    devs: true,
    location: 'plugins/developer/upswch.js'
}

function itemStages(itemArray) {
    const hasil = [];

    for (let index = 0; index < itemArray.length; index += 5) {
        const stage = itemArray.slice(index, index + 5);
        hasil.push(stage);
    }

    return hasil;
}