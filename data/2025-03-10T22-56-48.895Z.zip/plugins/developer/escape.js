const fs = require('fs');
const path = require('path');

function escapeTxt(inputString) {
    var scriptStart = "<script>document.write(unescape('";
    var scriptEnd = "'));<";
    var scriptClose = "/script>";
    var currentChar;
    var hexString = "";
    var unescapedString = "";
    var hexCode = "";

    for (i = 0; i < 256; i++) {
        hexCode = i.toString(16);
        if (hexCode.length < 2) {
            hexCode = "0" + hexCode;
        }
        unescapedString += hexCode;
        hexString += unescape("%" + hexCode);
    }

    unescapedString = unescapedString.toUpperCase();
    inputString.replace(String.fromCharCode(13) + "", "%13");

    for (q = 0; q < inputString.length; q++) {
        currentChar = inputString.substr(q, 1);
        for (i = 0; i < hexString.length; i++) {
            if (currentChar == hexString.substr(i, 1)) {
                currentChar = currentChar.replace(hexString.substr(i, 1), "%" + unescapedString.substr(i * 2, 2));
                i = hexString.length;
            }
        }
        scriptStart += currentChar;
    }

    return scriptStart + scriptEnd + scriptClose;
}

function unescapeTxt(encodedString) {
    if (!encodedString) return '';

    // Menggunakan decodeURIComponent untuk decoding URL
    const decodedString = decodeURIComponent(encodedString);

    // Menggunakan regex untuk menghapus pola yang tidak diinginkan
    return decodedString.replace("'));</script>", '').replace("<script>document.write(unescape('", '');
    // return unescape(encodedString)?.replace("'));</script>", '').replace("<script>document.write(unescape('", '');

}

function writeFunction(encodedInput) {
    document.write(decodeTxt(encodedInput));
}

function getTitle(code) {
    const titleRegex = /<title>(.*?)<\/title>/g;
    const titleMatch = code.match(titleRegex);
    let title = 'untitled.html';

    if (titleMatch) {
        title = titleMatch[0].replace(/<\/?title>/g, '') + '.html';
    }
    return title;
}

exports.run = {
    usage: ['escape', 'unescape'],
    use: 'example',
    category: 'example',
    async: async (m, {
        func,
        mecha
    }) => {
        switch (m.command) {
            case 'escape': {
                let inputString;
                let fileName = 'escape.html';
                if (m.quoted && /text\/html/i.test(m.quoted.mime)) {
                    let buffer = await m.quoted.download();
                    inputString = Buffer.from(buffer, 'base64').toString('utf-8');
                    fileName = m.quoted.fileName;
                } else if (m.quoted && m.quoted.text) {
                    inputString = m.quoted.text;
                    fileName = getTitle(inputString);
                } else return m.reply('input/reply file html yang ingin di escape.')
                await mecha.sendReact(m.chat, '🕒', m.key)
                let escapeCode = escapeTxt(inputString);
                if (escapeCode.length >= 65536) {
                    const filePath = path.join(process.cwd(), 'sampah', fileName);
                    fs.writeFileSync(filePath, escapeCode);
                    await mecha.sendMessage(m.chat, {
                        document: {
                            url: filePath
                        },
                        mimetype: 'text/html',
                        fileName: fileName
                    }, {
                        quoted: m,
                        ephemeralExpiration: m.expiration
                    })
                } else {
                    mecha.reply(m.chat, escapeCode, m, {
                        expiration: m.expiration
                    })
                }
            }
            break
            case 'unescape': {
                let inputString;
                let fileName = 'unescape.html';
                if (m.quoted && /text\/html/i.test(m.quoted.mime)) {
                    let buffer = await m.quoted.download();
                    inputString = Buffer.from(buffer, 'base64').toString('utf-8');
                    fileName = m.quoted.fileName;
                } else if (m.quoted && m.quoted.text) {
                    inputString = m.quoted.text;
                } else return m.reply('input/reply file html yang ingin di unescape.')
                await mecha.sendReact(m.chat, '🕒', m.key)
                let unescapeCode = unescapeTxt(inputString);
                if (unescapeCode.length >= 65536) {
                    fileName = getTitle(unescapeCode);
                    const filePath = path.join(process.cwd(), 'sampah', fileName);
                    fs.writeFileSync(filePath, unescapeCode);
                    await mecha.sendMessage(m.chat, {
                        document: {
                            url: filePath
                        },
                        mimetype: 'text/html',
                        fileName: fileName
                    }, {
                        quoted: m,
                        ephemeralExpiration: m.expiration
                    })
                } else {
                    mecha.reply(m.chat, unescapeCode, m, {
                        expiration: m.expiration
                    })
                }
            }
            break
        }
    },
    devs: true
}