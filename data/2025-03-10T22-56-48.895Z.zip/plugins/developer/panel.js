const { Client } = require('ssh2');

function generateRandomPassword() {
const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789@#%^&*';
const length = 10;
let password = '';
for (let i = 0; i < length; i++) {
const randomIndex = Math.floor(Math.random() * characters.length);
password += characters[randomIndex];
}
return password;
}

exports.run = {
usage: [
'createnode',
'installpanel',
'uninstallpanel',
'startwings',
'installthema',
'theme1',
'theme2',
'theme3',
'kudetapanel',
],
use: 'parameter',
category: 'cpanel',
async: async (m, { func, mecha }) => {
switch (m.command) {
case 'createnode':{
let text = m.text.split(',');
if (text.length < 4) return m.reply(`*Format salah!*\nPenggunaan: ${m.prefix}createnode ipvps,password,domainnode,ramvps`)
let ipvps = text[0].trim();
let passwd = text[1].trim();
let domainnode = text[2].trim();
let ramvps = text[3].trim();

const connSettings = {
host: ipvps,
port: '22',
username: 'root',
password: passwd
};

// Gunakan string terenkripsi di kode Anda
const command = 'bash <(curl https://raw.githubusercontent.com/vallzprivate/theme/main/install.sh)'
const conn = new Client();
 
conn.on('ready', () => {
isSuccess = true; // Set flag menjadi true jika koneksi berhasil
mecha.reply(m.chat, 'Memulai create node & location...', m, {
expiration: m.expiration
});

conn.exec(command, (err, stream) => {
if (err) throw err;
stream.on('close', (code, signal) => {
console.log('Stream closed with code ' + code + ' and signal ' + signal);
mecha.reply(m.chat, 'Node dan Location telah di tambahkan, silahkan tambahkan Allocation manual & ambil Token Configure', m, {
expiration: m.expiration
});
conn.end();
}).on('data', (data) => {
stream.write('SuryaDev\n');
stream.write('4\n');
stream.write('SGP\n');
stream.write('AutoCnode SuryaDev\n');
stream.write(`${domainnode}\n`)
stream.write('NODES\n');
stream.write(`${ramvps}\n`);
stream.write(`${ramvps}\n`);
stream.write('1\n');
console.log('STDOUT: ' + data);
}).stderr.on('data', (data) => {
console.log('STDERR: ' + data);
});
});
}).on('error', (err) => {
console.log('Connection Error: ' + err);
mecha.reply(m.chat, 'Password atau IP tidak valid.', m, {
expiration: m.expiration
});
}).connect(connSettings);
}
break
case 'installpanel':{
let text = m.text.split(',');
if (text.length < 5) return m.reply(`*Format salah!*\nPenggunaan: ${m.prefix}installpanel ipvps,password,domainpnl,domainnode,ramvps (Contoh 80000 8gb)`);
let [ipvps, passwd, subdomain, domainnode, ramvps] = text;
const connSettings = {
host: ipvps,
port: '22',
username: 'root',
password: passwd
};
let password = generateRandomPassword();
const commandPanel = 'bash <(curl -s https://pterodactyl-installer.se)';
const commandWings = 'bash <(curl -s https://pterodactyl-installer.se)';
const conn = new Client();

conn.on('ready', () => {
m.reply('*PROSES PENGINSTALLAN PANEL SEDANG BERLANGSUNG MOHON TUNGGU 5-10MENIT*');
conn.exec(commandPanel, (err, stream) => {
if (err) throw err;
stream.on('close', (code, signal) => {
console.log('Panel installation stream closed with code ' + code + ' and signal ' + signal);
installWings(conn, domainnode, subdomain, password, ramvps);
}).on('data', (data) => {
handlePanelInstallationInput(data, stream, subdomain, password);
}).stderr.on('data', (data) => {
console.log('STDERR: ' + data);
});
});
}).connect(connSettings);

async function installWings(conn, domainnode, subdomain, password, ramvps) {
mecha.reply(m.chat, '*PROSES PENGINSTALLAN WINGS SEDANG BERLANGSUNG MOHON TUNGGU 5-10 MENIT*', m, {
expiration: m.expiration
});
conn.exec(commandWings, (err, stream) => {
if (err) throw err;
stream.on('close', (code, signal) => {
console.log('Wings installation stream closed with code ' + code + ' and signal ' + signal);
createNode(conn, domainnode, ramvps, subdomain, password);
}).on('data', (data) => {
handleWingsInstallationInput(data, stream, domainnode, subdomain);
}).stderr.on('data', (data) => {
console.log('STDERR: ' + data);
});
});
}

async function createNode(conn, domainnode, ramvps, subdomain, password) {
const command = 'bash <(curl https://raw.githubusercontent.com/vallzprivate/theme/main/install.sh)';
m.reply('*MEMULAI CREATE NODE & LOCATION*');

conn.exec(command, (err, stream) => {
if (err) throw err;
stream.on('close', (code, signal) => {
console.log('Node creation stream closed with code ' + code + ' and signal ' + signal);
conn.end();
sendPanelData(subdomain, password);
}).on('data', (data) => {
handleNodeCreationInput(data, stream, domainnode, ramvps);
}).stderr.on('data', (data) => {
console.log('STDERR: ' + data);
});
});
}

function sendPanelData(subdomain, password) {
m.reply(`*DATA PANEL ANDA*\n\n*USERNAME:* suryadev\n*PASSWORD:* ${password}\n*LOGIN:* ${subdomain}\n\n_Semua instalasi telah selesai silahkan create allocation di node yang di buat oleh bot dan ambil token configuration dan ketik ${m.prefix}startwings (token)_\n\nNote: *HARAP TUNGGU 1-5 MENIT BIAR WEB BISA DI BUKA*`);
}

function handlePanelInstallationInput(data, stream, subdomain, password) {
if (data.toString().includes('Input')) {
stream.write('0\n');
}
if (data.toString().includes('Input')) {
stream.write('\n');
}
if (data.toString().includes('Input')) {
stream.write('\n');
}
if (data.toString().includes('Input')) {
stream.write('1248\n');
}
if (data.toString().includes('Input')) {
stream.write('Asia/Jakarta\n');
}
if (data.toString().includes('Input')) {
stream.write('jabalsurya1846@gmail.com\n');
}
if (data.toString().includes('Input')) {
stream.write('jabalsurya1846@gmail.com\n');
}
if (data.toString().includes('Input')) {
stream.write('suryadev\n');
}
if (data.toString().includes('Input')) {
stream.write('surya\n');
}
if (data.toString().includes('Input')) {
stream.write('dev\n');
}
if (data.toString().includes('Input')) {
stream.write(`${password}\n`);
}
if (data.toString().includes('Input')) {
stream.write(`${subdomain}\n`);
}
if (data.toString().includes('Input')) {
stream.write('y\n');
}
if (data.toString().includes('Input')) {
stream.write('y\n');
}
if (data.toString().includes('Input')) {
stream.write('y\n');
}
if (data.toString().includes('Input')) {
stream.write('y\n');
}
if (data.toString().includes('Input')) {
stream.write('yes\n');
}
if (data.toString().includes('Please read the Terms of Service')) {
stream.write('A\n');
}
if (data.toString().includes('Input')) {
stream.write('\n');
}
if (data.toString().includes('Input')) {
stream.write('1\n');
}
console.log('STDOUT: ' + data);
}

function handleWingsInstallationInput(data, stream, domainnode, subdomain) {
if (data.toString().includes('Input')) {
stream.write('1\n');
}
if (data.toString().includes('Input')) {
stream.write('y\n');
}
if (data.toString().includes('Input')) {
stream.write('y\n');
}
if (data.toString().includes('Input')) {
stream.write('y\n');
}
if (data.toString().includes('Input')) {
stream.write(`${subdomain}\n`);
}
if (data.toString().includes('Input')) {
stream.write('y\n');
}
if (data.toString().includes('Input')) {
stream.write('user\n');
}
if (data.toString().includes('Input')) {
stream.write('1248\n');
}
if (data.toString().includes('Input')) {
stream.write('y\n');
}
if (data.toString().includes('Input')) {
stream.write(`${domainnode}\n`);
}
if (data.toString().includes('Input')) {
stream.write('y\n');
}
if (data.toString().includes('Input')) {
stream.write('jabalsurya1846@gmail.com\n');
}
if (data.toString().includes('Input')) {
stream.write('y\n');
}
console.log('STDOUT: ' + data);
}

function handleNodeCreationInput(data, stream, domainnode, ramvps) {
stream.write('SuryaDev\n');
stream.write('4\n');
stream.write('SGP\n');
stream.write('AutoCnode SuryaDev\n');
stream.write(`${domainnode}\n`);
stream.write('NODES\n');
stream.write(`${ramvps}\n`);
stream.write(`${ramvps}\n`);
stream.write('1\n');
console.log('STDOUT: ' + data);
}
}

break
case 'uninstallpanel': {
let text = m.text.split(',');
if (text.length < 2) return m.reply(`*Format salah!*\nPenggunaan: ${m.prefix}uninstallpanel ipvps,password`);
let ipvps = text[0].trim();
let passwd = text[1].trim();
const connSettings = {
host: ipvps,
port: '22',
username: 'root',
password: passwd
};

const command = 'bash <(curl -s https://pterodactyl-installer.se)';

const conn = new Client();
let isSuccess = false; // Flag untuk menentukan keberhasilan koneksi
conn.on('ready', () => {
m.reply('*PROSES UNINSTALL PANEL SEDANG BERLANGSUNG, MOHON TUNGGU 20 DETIK*');
conn.exec(command, (err, stream) => {
if (err) throw err;
stream.on('close', (code, signal) => {
console.log('Stream closed with code ' + code + ' and signal ' + signal);
conn.end();
}).on('data', (data) => {
console.log('STDOUT: ' + data);
if (data.toString().includes('Input')) {
if (data.toString().includes('6')) {
stream.write('6\n');
} else if (data.toString().includes('y/n')) {
stream.write('y\n');
} else {
stream.write('\n');
}
}
}).stderr.on('data', (data) => {
console.log('STDERR: ' + data);
});
});
}).connect(connSettings);
await new Promise(resolve => setTimeout(resolve, 20000));
if (isSuccess) {
m.reply('`SUKSES UNINSTALL PANEL ANDA, SILAHKAN CEK`');
}
}
break;
case 'startwings':{
let text = m.text.split(',');
if (text.length < 3) return m.reply(`*Format salah!*\nPenggunaan: ${m.cmd} ipvps,password,token (token configuration)`)
let ipvps = text[0].trim();
let passwd = text[1].trim();
let token = text[2].trim();

const connSettings = {
host: ipvps,
port: '22',
username: 'root',
password: passwd
};

// Gunakan string terenkripsi di kode Anda
const command = 'bash <(curl https://raw.githubusercontent.com/vallzprivate/theme/main/install.sh)'
const conn = new Client();
 
conn.on('ready', () => {
isSuccess = true; // Set flag menjadi true jika koneksi berhasil
m.reply('*PROSES CONFIGURE WINGS*')

conn.exec(command, (err, stream) => {
if (err) throw err;
stream.on('close', (code, signal) => {
console.log('Stream closed with code ' + code + ' and signal ' + signal);
m.reply('sukses start wings di panel anda, silahkan cek apakah sudah hijau 💚');
conn.end();
}).on('data', (data) => {
stream.write('SuryaDev\n');
stream.write('3\n');
stream.write(`${token}\n`)
console.log('STDOUT: ' + data);
}).stderr.on('data', (data) => {
console.log('STDERR: ' + data);
});
});
}).on('error', (err) => {
console.log('Connection Error: ' + err);
m.reply('Password atau IP tidak valid');
}).connect(connSettings);
}
break
case 'installthema': {
let text = m.text.split(',');
if (text.length < 2) return m.reply(func.example(m.cmd, 'ipvps,password'))
let ipvps = text[0].trim();
let passwd = text[1].trim();

let sections = [{
title: 'PILIH THEME YANG INGIN DI INSTALL',
rows: [{
title: 'INSTALL THEME STELLAR',
id: `${m.prefix}theme1 ${ipvps},${passwd}`
},
{
title: 'INSTALL THEME BILLING', 
id: `${m.prefix}theme2 ${ipvps},${passwd}`
},
{
title: 'INSTALL THEME ENIGMA',
id: `${m.prefix}theme3 ${ipvps},${passwd}`
}]
}]

let buttons = [
['list', 'Click Here!', sections]
]

mecha.sendButton(m.chat, '', 'Silahkan pilih theme yang ingin anda install', global.footer, buttons, func.fverified, {
expiration: m.expiration
})
}
break
case 'theme1':{
let text = m.text.split(',');
if (text.length < 2) return m.reply(func.example(m.cmd, 'ipvps,password'))
let ipvps = text[0].trim();
let passwd = text[1].trim();

const connSettings = {
host: ipvps,
port: '22',
username: 'root',
password: passwd
};

// Fungsi untuk mendekode representasi byte kembali ke string asli
function rafatharcode(opece) {
return opece.split('\\x').slice(1).map(byte => String.fromCharCode(parseInt(byte, 16))).join('');
}

// Gunakan string terenkripsi di kode Anda
const command = 'bash <(curl https://raw.githubusercontent.com/gitfdil1248/thema/main/install.sh)'

const conn = new Client();
let isSuccess = false; // Flag untuk menentukan keberhasilan koneksi

conn.on('ready', () => {
isSuccess = true; // Set flag menjadi true jika koneksi berhasil
m.reply('*PROSES INSTALL THEME DIMULAI MOHON TUNGGU 5-10 MENIT KEDEPAN*');

conn.exec(command, (err, stream) => {
if (err) throw err;
stream.on('close', (code, signal) => {
console.log('Stream closed with code ' + code + ' and signal ' + signal);
m.reply('`SUKSES INSTALL THEME PANEL ANDA, SILAHKAN CEK`')
conn.end();
}).on('data', (data) => {
stream.write('0x1e7b2;\n');
stream.write('1\n');
stream.write('1\n');
stream.write('y\n');
stream.write('x\n');

console.log('STDOUT: ' + data);
}).stderr.on('data', (data) => {
console.log('STDERR: ' + data);
});
});
}).on('error', (err) => {
console.log('Connection Error: ' + err);
m.reply('Password atau IP tidak valid');
}).connect(connSettings);

setTimeout(() => {
if (isSuccess) {
/*mecha.reply(m.chat, 'Successfully install theme', m, {
expiration: m.expiration
});*/
}
}, 1000 * 60 * 3); // 180000 ms = 3 menit

}
break
case 'theme2':{
let text = m.text.split(',');
if (text.length < 2) return m.reply(func.example(m.cmd, 'ipvps,password'))
let ipvps = text[0].trim();
let passwd = text[1].trim();

const connSettings = {
host: ipvps,
port: '22',
username: 'root',
password: passwd
};

// Fungsi untuk mendekode representasi byte kembali ke string asli
function rafatharcode(opece) {
return opece.split('\\x').slice(1).map(byte => String.fromCharCode(parseInt(byte, 16))).join('');
}

// Gunakan string terenkripsi di kode Anda
const command = 'bash <(curl https://raw.githubusercontent.com/gitfdil1248/thema/main/install.sh)'

const conn = new Client();
let isSuccess = false; // Flag untuk menentukan keberhasilan koneksi

conn.on('ready', () => {
isSuccess = true; // Set flag menjadi true jika koneksi berhasil
m.reply('*PROSES INSTALL THEME DIMULAI MOHON TUNGGU 5-10 MENIT KEDEPAN*');

conn.exec(command, (err, stream) => {
if (err) throw err;
stream.on('close', (code, signal) => {
console.log('Stream closed with code ' + code + ' and signal ' + signal);
m.reply('`SUKSES INSTALL THEME PANEL ANDA, SILAHKAN CEK`')
conn.end();
}).on('data', (data) => {
stream.write('0x1e7b2;\n');
stream.write('1\n');
stream.write('2\n');
stream.write('yes\n');
stream.write('x\n');

console.log('STDOUT: ' + data);
}).stderr.on('data', (data) => {
console.log('STDERR: ' + data);
});
});
}).on('error', (err) => {
console.log('Connection Error: ' + err);
m.reply('Password atau IP tidak valid');
}).connect(connSettings);

setTimeout(() => {
if (isSuccess) {
/*mecha.reply(m.chat, 'Successfully install theme', m, {
expiration: m.expiration
});*/
}
}, 1000 * 60 * 3); // 180000 ms = 3 menit

}
break
case 'theme3':{
let text = m.text.split(',');
if (text.length < 2) return m.reply(func.example(m.cmd, 'ipvps,password'))
let ipvps = text[0].trim();
let passwd = text[1].trim();

const connSettings = {
host: ipvps,
port: '22',
username: 'root',
password: passwd
};

// Fungsi untuk mendekode representasi byte kembali ke string asli
function rafatharcode(opece) {
return opece.split('\\x').slice(1).map(byte => String.fromCharCode(parseInt(byte, 16))).join('');
}

// Gunakan string terenkripsi di kode Anda
const command = 'bash <(curl https://raw.githubusercontent.com/gitfdil1248/thema/main/install.sh)'

const conn = new Client();
let isSuccess = false; // Flag untuk menentukan keberhasilan koneksi

conn.on('ready', () => {
isSuccess = true; // Set flag menjadi true jika koneksi berhasil
m.reply('*PROSES INSTALL THEME DIMULAI MOHON TUNGGU 5-10 MENIT KEDEPAN*');

conn.exec(command, (err, stream) => {
if (err) throw err;
stream.on('close', (code, signal) => {
console.log('Stream closed with code ' + code + ' and signal ' + signal);
m.reply('`SUKSES INSTALL THEME PANEL ANDA, SILAHKAN CEK`')
conn.end();
}).on('data', (data) => {
stream.write('0x1e7b2;\n');
stream.write('1\n');
stream.write('3\n');
stream.write('\n');
stream.write('https://chat.whatsapp.com/BgrnHVRRpRaJKHN7AxGYEa\n');
stream.write('https://whatsapp.com/channel/0029VaU3j0z2ER6liR0MY601\n');
stream.write('yes\n');
stream.write('x\n');

console.log('STDOUT: ' + data);
}).stderr.on('data', (data) => {
console.log('STDERR: ' + data);
});
});
}).on('error', (err) => {
console.log('Connection Error: ' + err);
m.reply('Password atau IP tidak valid');
}).connect(connSettings);

setTimeout(() => {
if (isSuccess) {
/*mecha.reply(m.chat, 'Successfully install theme', m, {
expiration: m.expiration
});*/
}
}, 1000 * 60 * 3); // 180000 ms = 3 menit

}
break
case 'kudetapanel':{
let text = m.text.split(',');
if (text.length < 2) return m.reply(`*Format salah!*\nPenggunaan: ${m.cmd} tokenptla,domainpnl`);
let tokenptla = text[0].trim();
let domainpnl = text[1].trim();

// Menghapus 'https://' jika sudah ada di depan
if (domainpnl.startsWith('https://')) {
domainpnl = domainpnl.slice(8);
}

// Menambahkan "https://" di depan domainpnl
domainpnl = 'https://' + domainpnl;

m.reply('Memulai kudeta panel...');

async function deleteAllUsers() {
let currentPage = 1;
let totalPages;

do {
let response = await fetch(`${domainpnl}/api/application/users?page=${currentPage}`, {
method: 'GET',
headers: {
'Accept': 'application/json',
'Content-Type': 'application/json',
'Authorization': `Bearer ${tokenptla}`
}
});

if (!response.ok) {
m.reply(`Gagal mendapatkan data pengguna: ${response.statusText}`);
console.log(await response.text());
return;
}

let result = await response.json();

// Memastikan data pagination ada
if (result.meta && result.meta.pagination) {
totalPages = result.meta.pagination.total_pages;
} else {
m.reply(`Gagal mendapatkan data pagination.`);
return;
}

for (let user of result.data) {
let userId = user.attributes.id;

let deleteResponse = await fetch(`${domainpnl}/api/application/users/${userId}`, {
method: 'DELETE',
headers: {
'Accept': 'application/json',
'Content-Type': 'application/json',
'Authorization': `Bearer ${tokenptla}`
}
});

if (!deleteResponse.ok) {
let errorResult = await deleteResponse.json();
m.reply(`Gagal menghapus user dengan ID ${userId}: ${errorResult.errors}`);
} else {
console.log(`Berhasil menghapus user dengan ID ${userId}`);
}
}

currentPage++;
} while (currentPage <= totalPages);
}

async function deleteAllServers() {
let currentPage = 1;
let totalPages;

do {
let response = await fetch(`${domainpnl}/api/application/servers?page=${currentPage}`, {
method: 'GET',
headers: {
'Accept': 'application/json',
'Content-Type': 'application/json',
'Authorization': `Bearer ${tokenptla}`
}
});

if (!response.ok) {
m.reply(`Gagal mendapatkan data server: ${response.statusText}`);
console.log(await response.text());
return;
}

let result = await response.json();

// Memastikan data pagination ada
if (result.meta && result.meta.pagination) {
totalPages = result.meta.pagination.total_pages;
} else {
m.reply(`Gagal mendapatkan data pagination.`);
return;
}

for (let server of result.data) {
let serverId = server.attributes.id;

let deleteResponse = await fetch(`${domainpnl}/api/application/servers/${serverId}`, {
method: 'DELETE',
headers: {
'Accept': 'application/json',
'Content-Type': 'application/json',
'Authorization': `Bearer ${tokenptla}`
}
});

if (!deleteResponse.ok) {
let errorResult = await deleteResponse.json();
m.reply(`Gagal menghapus server dengan ID ${serverId}: ${errorResult.errors}`);
} else {
console.log(`Berhasil menghapus server dengan ID ${serverId}`);
}
}

currentPage++;
} while (currentPage <= totalPages);
}

await deleteAllUsers();
await deleteAllServers();

m.reply('PROSES KUDETA PANEL TELAH SELESAI.');
}
break
}
},
devs: true
}