const {
    areJidsSameUser
} = require('@whiskeysockets/baileys');

exports.run = {
    usage: ['topbalance'],
    category: 'games',
    async: async (m, {
        func,
        mecha
    }) => {
        const userEntries = Object.entries(global.db.users).map(([key, value]) => ({
            ...value,
            jid: key
        }));

        const sortedUsers = userEntries.sort((a, b) => (b.balance || 0) - (a.balance || 0));
        const userJids = sortedUsers.map(user => user.jid);

        const rank = userJids.indexOf(m.sender) + 1;
        let txt = `Kamu Top *${rank}* Balance dari *${userJids.length}* Users\n`;

        txt += sortedbalance.slice(0, 10).map(({
            jid,
            balance
        }, i) => {
            const name = m.isGc && m.members.some(x => areJidsSameUser(jid, x.id)) ?
                (global.db.users[jid]?.name || mecha.getName(jid)).replaceAll('\n', '\t') :
                '@' + jid.split('@')[0];
            return `${i + 1}. ${name}: $${func.rupiah(balance)}`;
        }).join('\n');

        mecha.reply(m.chat, txt, m, {
            expiration: m.expiration
        });
    },
    location: 'plugins/games/topbalance.js'
}