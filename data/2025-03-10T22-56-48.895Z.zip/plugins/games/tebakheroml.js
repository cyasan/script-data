const fetch = require('node-fetch');
const axios = require('axios');
const similarity = require('similarity');
const gamesUrl = 'https://raw.githubusercontent.com/Jabalsurya2105/database/master/games/tebakheroml.json';
const sensitive = 0.75;
let voiceHeroData = [];
let alreadyAnswered = new Set();
let askedQuestions = []; // Array untuk menyimpan soal yang sudah dikeluarkan

// Fungsi untuk mendapatkan soal baru
const getNewQuestion = async (language = 'id') => { // language 'id' or 'en'
    if (voiceHeroData.length == 0) {
        const data_voice_heroml = await fetch(gamesUrl).then(response => response.json())
        voiceHeroData.push(...new Set(data_voice_heroml.result));
    }
    const questions = voiceHeroData.filter(x => x.language === language);

    if (askedQuestions.length === questions.length) {
        // Jika semua soal sudah dikeluarkan, reset array
        askedQuestions = [];
    }
    let randomIndex;
    do {
        randomIndex = Math.floor(Math.random() * questions.length);
    } while (askedQuestions.includes(randomIndex)); // Pastikan soal belum dikeluarkan
    askedQuestions.push(randomIndex); // Tambahkan soal yang dikeluarkan ke array
    let random = questions[randomIndex]; // Kembalikan soal yang dipilih
    const response = await axios({
        method: 'GET',
        url: random.audio,
        responseType: 'arraybuffer'
    });
    const base64 = Buffer.from(response.data, 'base64');
    return {
        status: true,
        creator: 'SuryaDev',
        name: random.name,
        audio: base64
    }
}

exports.run = {
    usage: ['tebakheroml'],
    hidden: ['tebakvoiceml', 'tebakml'],
    category: 'games',
    async: async (m, {
        func,
        mecha,
        setting
    }) => {
        mecha.tebakheroml = mecha.tebakheroml || {};
        if (func.ceklimit(m.sender, 1)) return m.reply(global.mess.limit)
        if (m.chat in mecha.tebakheroml) return mecha.reply(m.chat, 'Masih ada soal belum terjawab di chat ini', mecha.tebakheroml[m.chat].msg, {
            expiration: m.expiration
        })
        let language = /en|id/i.test(m.args[0]) ? m.args[0].toLowerCase() : 'id';
        let {
            name,
            audio
        } = await getNewQuestion(language)
        let hadiah = func.hadiah(setting.hadiah);
        let id = Date.now();
        alreadyAnswered.clear();
        let caption = `乂 *TEBAK HEROML GAMES*\n${m.isPrem || m.isVIP ? '\nPetunjuk: ' + func.createClue(name) : ''}\nHadiah: $${hadiah} balance\nWaktu: ${setting.gamewaktu} detik`
        let expiration = m.expiration;
        let msg = await mecha.sendMessage(m.chat, {
            audio: audio,
            mimetype: 'audio/mpeg',
            /*contextInfo: {
                mentionedJid: [m.sender],
                externalAdReply: {
                    title: 'GAME TEBAK-HEROML',
                    body: `Hadiah: $${hadiah} ( ${setting.gamewaktu} detik )`,
                    mediaType: 1,
                    previewType: 'PHOTO',
                    thumbnailUrl: 'https://files.catbox.moe/il681g.jpg',
                    sourceUrl: null,
                    renderLargerThumbnail: false
                }
            }*/
        }, {
            quoted: m,
            ephemeralExpiration: expiration
        }).then(async (q) => await mecha.reply(m.chat, caption, q, {
            expiration
        }))
        mecha.tebakheroml[m.chat] = {
            id: id,
            jawaban: name.toLowerCase(),
            hadiah: hadiah,
            nextQuestion: 1,
            language,
            timeout: setTimeout(async function() {
                let gameData = mecha.tebakheroml[m.chat];
                if (gameData.id == id) {
                    mecha.reply(m.chat, `Waktu habis!\n\nJawabannya adalah: ${func.texted('monospace', name)}`, gameData.msg, {
                        expiration: m.expiration
                    }).then(async () => {
                        if (gameData.msg) {
                            await func.delay(1500).then(async () => await mecha.sendMessage(m.chat, {
                                delete: gameData.msg.key
                            }));
                        }
                    });
                    delete mecha.tebakheroml[m.chat];
                }
            }, setting.gamewaktu * 1000),
            msg: msg ? {
                key: msg.key,
                message: msg.message
            } : null
        }
    },
    main: async (m, {
        func,
        mecha,
        setting,
        users
    }) => {
        // Games Tebak Gambar By SuryaDev
        mecha.tebakheroml = mecha.tebakheroml || {};
        if ((m.chat in mecha.tebakheroml) && !m.fromMe && !m.isPrefix) {
            let gameData = mecha.tebakheroml[m.chat];
            if (similarity(gameData.jawaban, m.budy.toLowerCase()) >= sensitive) {
                if (alreadyAnswered.has(gameData.jawaban)) return mecha.sendReact(m.chat, '🥴', m.key);
                alreadyAnswered.add(gameData.jawaban);
                console.log(Array.from(alreadyAnswered));
                // await mecha.sendReact(m.chat, '✅', m.key)
                users.balance += gameData.hadiah;
                users.game.tebakheroml++;
                gameData.nextQuestion++;
                if (gameData.timeout) clearTimeout(gameData.timeout);
                let key;
                if (users.limit < 1) {
                    let price = setting.limit.price;
                    if (users.balance > price) {
                        users.balance -= price;
                        key = await mecha.reply(m.chat, `Sistem otomatis mengambil \`${price} balance\` kamu sebagai pengganti limit.`, m, {
                            expiration: m.expiration
                        })
                        await new Promise(resolve => setTimeout(resolve, 1000));
                    } else {
                        delete mecha.tebakheroml[m.chat];
                        return await mecha.reply(m.chat, 'Soal dihentikan karena limit & balance kamu sudah habis.', m, {
                            expiration: m.expiration
                        })
                    }
                } else {
                    users.limit -= 1;
                    /*if (gameData.msg) await mecha.sendMessage(m.chat, {
                        delete: gameData.msg.key
                    })
                    await new Promise(resolve => setTimeout(resolve, 1500));*/
                }
                let {
                    audio,
                    name
                } = await getNewQuestion(gameData.language);
                let hadiah = func.hadiah(setting.hadiah);
                let id = Date.now();
                alreadyAnswered.clear();
                let caption = `*LANJUT SOAL KE-${gameData.nextQuestion}*\n${m.isPrem || m.isVIP ? '\nPetunjuk: ' + func.createClue(name) : ''}\nHadiah: $${hadiah} balance\nWaktu: ${setting.gamewaktu} detik`
                let expiration = m.expiration;
                let msg = await mecha.sendMessage(m.chat, {
                    audio: audio,
                    mimetype: 'audio/mpeg',
                    /*contextInfo: {
                        mentionedJid: [m.sender],
                        externalAdReply: {
                            title: 'NEXT GUESS HEROML',
                            body: `Hadiah: $${hadiah} ( ${setting.gamewaktu} detik )`,
                            mediaType: 1,
                            previewType: 'PHOTO',
                            thumbnailUrl: 'https://files.catbox.moe/il681g.jpg',
                            sourceUrl: null,
                            renderLargerThumbnail: false
                        }
                    }*/
                }, {
                    quoted: m,
                    ephemeralExpiration: expiration
                }).then(async (q) => await mecha.reply(m.chat, caption, q, {
                    expiration
                }))
                Object.assign(gameData, {
                    id: id,
                    soal: audio,
                    jawaban: name.toLowerCase(),
                    hadiah: hadiah,
                    timeout: setTimeout(function() {
                        if (gameData.id == id) {
                            mecha.reply(m.chat, `Waktu habis!\n\nJawabannya adalah: ${func.texted('monospace', name)}`, gameData.msg, {
                                expiration: m.expiration
                            }).then(async () => {
                                if (gameData.msg) {
                                    await func.delay(1500).then(async () => await mecha.sendMessage(m.chat, {
                                        delete: gameData.msg.key
                                    }))
                                }
                            })
                            delete mecha.tebakheroml[m.chat];
                        }
                    }, setting.gamewaktu * 1000),
                    msg: msg ? {
                        key: msg.key,
                        message: msg.message
                    } : null
                })
                if (mecha.tebakheroml[m.chat]) return false;
            } else if (/conversation|extendedTextMessage/.test(m.mtype) && setting.incorrect) {
                await mecha.sendReact(m.chat, '❌', m.key)
            }
        }
    },
    location: 'plugins/games/tebakheroml.js'
}