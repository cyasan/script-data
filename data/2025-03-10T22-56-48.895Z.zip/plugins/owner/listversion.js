const { exec } = require('child_process');

exports.run = {
usage: ['listversion'],
use: 'module',
category: 'owner',
async: async (m, { func, mecha }) => {
if (!m.text) return m.reply(func.example(m.cmd, 'fs'))
exec(`npm view ${m.args[0]} versions --json`, async (err, stdout) => {
if (err) return m.reply(`${err}`)
let txt = `*LIST VERSION MODULE*\n\nResult From : ${m.args[0]}\n`
//let module = m.text.split('view')[1].replace(" versions",'').replace(' --json','').replace(' ','')
let pkg = JSON.parse(stdout)
for (let i of pkg) {
txt += `\n$ npm i ${m.args[0]}@${i}`
}
mecha.sendMessage(m.chat, {text: txt}, {quoted: m, ephemeralExpiration: m.expiration})
})
},
owner: true
}