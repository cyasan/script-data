exports.run = {
usage: ['sendgc'],
use: 'text',
category: 'owner',
async: async (m, { func, mecha, setting }) => {
if (!m.text) return m.reply('Teksnya mana?')
let meta = await (await mecha.groupMetadata(setting.idgroup));
let members = meta.participants.map(x => x.id);
await mecha.sendMessage(setting.idgroup, {
text: m.text, 
mentions: members
}, {quoted: func.fstatus('System Notification'), ephemeralExpiration: m.expiration}).then(() => m.reply(global.mess.ok))
},
owner: true,
private: true
}