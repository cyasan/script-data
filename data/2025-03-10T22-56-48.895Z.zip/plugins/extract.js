exports.run = {
usage: ['extract'],
hidden: ['ekstrak'],
use: 'reply kontak',
category: 'developer',
async: async (m, { func, mecha }) => {
let data = JSON.parse(JSON.stringify(m.quoted)); // Convert and parse the quoted message
const extractedNumbers = [];

if (!data.contacts || !Array.isArray(data.contacts)) {
return m.reply("No contacts found in the quoted message.");
}

data.contacts.forEach(contact => {
const vcard = contact.vcard;
const telMatch = vcard.match(/waid=(\d+)/);
if (telMatch) {
extractedNumbers.push({
name: contact.displayName,
number: `${telMatch[1]}@s.whatsapp.net`
});
}
});

if (extractedNumbers.length === 0) {
m.reply("No WhatsApp numbers found in the contacts.");
} else {
m.reply(JSON.stringify(extractedNumbers, null, 2));
}
},
devs: true
}