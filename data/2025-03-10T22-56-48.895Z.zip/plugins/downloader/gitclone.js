const fetch = require('node-fetch');

let regexRepo = /(?:https|git)(?::\/\/|@)github\.com[\/:]([^\/:]+)\/([^\/:]+)(?:\/tree\/[^\/]+|\/blob\/[^\/]+)?(?:\/(.+))?/i;
let regexGist = /https:\/\/gist\.github\.com\/([^\/]+)\/([a-zA-Z0-9]+)/i;
let regexRawGitHub = /https:\/\/raw\.githubusercontent\.com\/([^\/]+)\/([^\/]+)\/([^\/]+)\/(.+)/i;

// ©Mputz Don't Delete this wm
exports.run = {
    usage: ['gitclone'],
    hidden: ['clonegit'],
    use: 'link repository',
    category: 'downloader',
    async: async (m, {
        func,
        mecha
    }) => {
        if (!m.text) return m.reply('Link GitHub nya mana?');
        let isRepo = regexRepo.test(m.args[0]);
        let isGist = regexGist.test(m.args[0]);
        let isRawGitHub = regexRawGitHub.test(m.args[0]);
        if (!isRepo && !isGist && !isRawGitHub) return m.reply('Link salah!');
        if (isRepo) {
            let [, user, repo] = m.args[0].match(regexRepo) || [];
            repo = repo.replace(/.git$/, '');
            let url = `https://api.github.com/repos/${user}/${repo}/zipball`;
            let filename = (await fetch(url, {
                method: 'HEAD'
            })).headers.get('content-disposition').match(/attachment; filename=(.*)/)[1];
            m.reply(`*Mohon tunggu, sedang mengirim repository..*`);
            await mecha.sendMessage(m.chat, {
                document: {
                    url: url
                },
                fileName: filename,
                mimetype: "application/zip",
                caption: `*Result From*: ${m.args[0]}`
            }, {
                quoted: m,
                ephemeralExpiration: m.expiration
            });
        } else if (isGist) {
            let [, user, gistId] = m.args[0].match(regexGist) || [];
            let url = `https://gist.github.com/${user}/${gistId}/download`;
            m.reply(`*Mohon tunggu, sedang mengirim Gist..*`);
            await mecha.sendMessage(m.chat, {
                document: {
                    url: url
                },
                fileName: `${gistId}.zip`,
                mimetype: "application/zip",
                caption: `*Result From*: ${m.args[0]}`
            }, {
                quoted: m,
                ephemeralExpiration: m.expiration
            });
        } else if (isRawGitHub) {
            let [, user, repo, branch, filepath] = m.args[0].match(regexRawGitHub) || [];
            let url = `https://raw.githubusercontent.com/${user}/${repo}/${branch}/${filepath}`;
            let filename = filepath.split('/').pop();
            m.reply(`*Mohon tunggu, sedang mengirim file dari RawGitHub..*`);
            await mecha.sendMessage(m.chat, {
                document: {
                    url: url
                },
                fileName: filename,
                mimetype: "application/octet-stream",
                caption: `*Result From*: ${m.m.args[0]}`
            }, {
                quoted: m,
                ephemeralExpiration: m.expiration
            });
        }
    }
}