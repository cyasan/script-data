exports.run = {
    usage: ['gpt4o'],
    hidden: ['darkai'],
    use: 'text',
    category: 'ai',
    async: async (m, {
        func,
        mecha,
        users,
        errorMessage
    }) => {
        if (!m.text) return m.reply(func.example(m.cmd, 'Hai'))
        mecha.sendReact(m.chat, '🕒', m.key)
        try {
            let messageId = 'MECHA' + func.makeid(8).toUpperCase() + 'GPT4O'
            let response = await MechaAI(m.text, users.name.replaceAll('\n', '\t'))
            mecha.sendMessage(m.chat, {
                text: `${response}`
            }, {
                quoted: m,
                ephemeralExpiration: m.expiration,
                messageId: messageId
            });
        } catch (error) {
            mecha.sendReact(m.chat, '❌', m.key)
            return errorMessage(error)
        }
    },
    main: async (m, {
        func,
        mecha,
        users,
        quoted,
        errorMessage
    }) => {
        if (m.budy && m.quoted && m.quoted.fromMe && m.quoted.id.endsWith('GPT4O') && !m.isPrefix) {
            mecha.sendReact(m.chat, '🕒', m.key)
            try {
                let messageId = 'MECHA' + func.makeid(8).toUpperCase() + 'GPT4O'
                let response = await MechaAI(m.budy, users.name.replaceAll('\n', '\t'))
                mecha.sendMessage(m.chat, {
                    text: `${response}`
                }, {
                    quoted: m,
                    ephemeralExpiration: m.expiration,
                    messageId: messageId
                });
                users.limit -= 3
            } catch (error) {
                mecha.sendReact(m.chat, '❌', m.key)
                return errorMessage(error)
            }
        }
    },
    limit: true
}

function createPrompt(query, username) {
    const today = new Date();
    const date = new Date(today.toLocaleString("en-US", {
        timeZone: "Asia/Jakarta"
    }));
    const hours = date.getHours();
    const minutes = date.getMinutes();
    const day = today.getDate();
    const month = today.getMonth() + 1; // perhatikan bahwa bulan dimulai dari 0, maka ditambahkan 1.
    const year = today.getFullYear();
    // mengambil nama hari dalam bahasa Inggris.
    const dayOfWeek = today.toLocaleDateString("id-ID", {
        weekday: "long"
    });
    const timeNow = `${hours.toString().padStart(2, "0")}:${minutes.toString().padStart(2, "0")}`;
    const getTodayDate = `Hari ini adalah ${dayOfWeek}, ${day}/${month}/${year}.`;
    const sistem = `kamu adalah mecha, Bot WhatsApp dengan program kecerdasan buatan AI (artificial intelligence). jawab setiap pertanyaan dengan jawaban yang edukatif, jika ada yang bertanya tentang waktu kamu jawab yang berkaitan dengan ${timeNow} dan ${getTodayDate}, lawan bicaramu adalah ${username}, kamu memiliki sifat dingin dan sedikit tsundere imut, kamu dirancang dan dikembangkan oleh SuryaDev sejak tahun 2021, SuryaDev memiliki nama lengkap Jabal Surya Ngalam, berasal dari Jepara, lahir pada 21 mei 2005, dia adalah seseorang yang kreatif dan berbakat dalam menciptakan berbagai hal.`
    return `${sistem}\ntolong jawab pertanyaan berikut dengan bahasa Indonesia gaul dan santai, sertakan juga emoticon lucu tapi seperlunya saja: ${query}`;
};

async function MechaAI(question, username) {
    const prompt = createPrompt(question, username);
    try {
        const response = await fetch(`https://darkness.ashlynn.workers.dev/chat/?prompt=${encodeURIComponent(prompt)}&model=gpt-4o-mini`);
        const data = await response.json();
        if (data.successful === 'success' && data.response) {
            return data.response;
        } else {
            return 'Error: Invalid command.';
        }
    } catch (error) {
        console.error(error);
        return 'Error: Unable to process command.';
    }
}