const axios = require('axios');

exports.run = {
usage: ['create-user', 'delete-user', 'get-password', 'change-password', 'list-username'],
use: 'parameter',
category: 'owner',
async: async (m, { func, mecha }) => {
const nickname = 'username108995561';
const token = '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';
const branch = 'main';
const repo = 'User';
const pathName = 'key.json';

async function getFileContent() {
const { data: fileData } = await axios.get(`https://api.github.com/repos/${nickname}/${repo}/contents/${pathName}`, {
headers: {
Authorization: `Bearer ${token}`,
},
});
const fileContent = Buffer.from(fileData.content, 'base64').toString('utf8');
return { fileData, jsonArray: JSON.parse(fileContent) };
}

async function updateFileContent(jsonArray, sha) {
const newFileContent = JSON.stringify(jsonArray, null, 2);
const base64Content = Buffer.from(newFileContent).toString('base64');
await axios.put(`https://api.github.com/repos/${nickname}/${repo}/contents/${pathName}`, {
message: `Update ${pathName}`,
content: base64Content,
sha: sha,
branch: branch
}, {
headers: {
Authorization: `Bearer ${token}`,
},
});
}

const [username, password] = m.text.split(',')
switch (m.command) {
case 'create-user':{
if (!(username && password)) return m.reply(func.example(m.cmd, 'SuryaDev,SuryaDev05'))
const { fileData, jsonArray } = await getFileContent();
if (jsonArray.find(x => x.username === username)) return m.reply('This username already in database.')
jsonArray.push({
username: username,
password: password
});
await updateFileContent(jsonArray, fileData.sha);
m.reply(`User created successfully.`);
}
break
case 'delete-user':{
if (!username) return m.reply(func.example(m.cmd, 'SuryaDev'))
const { fileData, jsonArray } = await getFileContent();
if (!jsonArray.find(x => x.username === username)) return m.reply('User data not found.')
const indexToRemove = jsonArray.findIndex(x => x.username === username);
if (indexToRemove !== -1) {
jsonArray.splice(indexToRemove, 1);
await updateFileContent(jsonArray, fileData.sha);
m.reply(`User removed successfully.`);
} else m.reply('User data not found.')
}
break
case 'get-password':{
if (!username) return m.reply(func.example(m.cmd, 'SuryaDev'))
const { fileData, jsonArray } = await getFileContent();
const response = jsonArray.find(x => x.username === username)
if (!response) return m.reply('User data not found.')
m.reply(response.password)
}
break
case 'change-password':{
if (!(username && password)) return m.reply(func.example(m.cmd, 'SuryaDev,628xxx'))
const { fileData, jsonArray } = await getFileContent();
const response = jsonArray.find(x => x.username === username)
if (!response) return m.reply('User data not found.')
response.password = password;
await updateFileContent(jsonArray, fileData.sha);
m.reply(`Successfully changed password on username '${username}'`)
}
break
case 'list-username':{
const { fileData, jsonArray } = await getFileContent();
if (jsonArray.length === 0) {
m.reply('Empty data.')
} else {
let caption = '*L I S T - U S E R N A M E*'
caption += jsonArray.map((data, index) => {
return `\n\n${index + 1}. ${data.username}
- Password: ${sensorPassword(data.password)}`
});
m.reply(caption)
}
}
break
}
},
devs: true
}

function sensorPassword(password, jumlahKarakter = 2) {
/**
* Fungsi untuk menyensor password setelah jumlah karakter tertentu.
* @param {string} password - Password asli.
* @param {number} jumlahKarakter - Jumlah karakter yang tidak disensor. Defaults to 2.
* @returns {string} Password yang telah disensor.
*/
return password.substring(0, jumlahKarakter) + '*'.repeat(password.length - jumlahKarakter);
}