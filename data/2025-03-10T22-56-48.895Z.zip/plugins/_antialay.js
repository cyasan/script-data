exports.run = {
main: async (m, { func, mecha, groups }) => {
if (!m.fromMe && m.budy.match(/(😍|🥰|😘|😊|🤭|🤗)/gi) && !groups.sewa.status && !m.isOwner) {
await mecha.sendMessage(m.chat, {
delete: {
remoteJid: m.chat,
fromMe: false,
id: m.key.id,
participant: m.sender
}
})
await func.delay(1000)
}
},
group: true,
botAdmin: true
}