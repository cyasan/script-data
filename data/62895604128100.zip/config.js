// nomor owner ubah nomor lu
global.owner = '6285137899566@s.whatsapp.net' // 62882003321562
// nama owner ubah nama lu
global.ownerName = 'KeyaruZNX'
//scraper
global.scraper = require('./lib/scrap.js')
global.axios = require("axios")
//global.hanime = require('./lib/scrap2.js')
// nomor pengembang yang bisa akses fitur saveplugin, delplugin, getplugin dan eval
global.developer = [
'6285137899566', // ganti nomor lu
//'62895415497664',
//'6285702691440',
'62881012877712',
'6285135388677'
// jangan asal add nomor, nanti bisa curi kode bot
].map(number => number.replace(/[^0-9]/g, '') + '@s.whatsapp.net')
// nama bot lu
global.botName = 'LunoXyZ Bot'
// announcement default
global.announ = '120363254428603104@g.us'
// fake pada beberapa fitur
global.fake = `Okay keep smile, you're the best`
// header pada beberapa fitur
global.header = 'GPT Bot Here For You'
// footer pada beberapa fitur
//global.footer = 'ꜱɪᴍᴘʟᴇ ᴡʜᴀᴛꜱᴀᴘᴘ ʙᴏᴛ ᴍᴀᴅᴇ ʙʏ sᴜʀʏᴀ' 
global.footer = 'ᴏᴡɴᴇᴅ ʙʏ ᴋᴇʏᴀʀᴜᴢɴx'
// jeda anti spam / detik
global.cooldown = 3
// ram maksimal untuk auto restart / gb
global.max_ram = 5
// blacklist nomor dengan kode negara tersebut
global.blocks = ['91', '92', '212']
// multi prefix default
global.prefixes = /^[°•π÷×¶∆£¢€¥®™+✓_=|/~!?@#%^&.©^]/i
// setting id channel (cara ambil: invite bot menjadi admin channel lalu balas pesan undangan dengan perintah .getnewsletter
global.newsletter = '120363337677901946@newsletter'
//'120363261409301854@newsletter'
// qris url di beberapa fitur seperti donate, buyprem dan sewabot
global.qrisUrl = 'https://telegra.ph/file/080cbdedf32c6c84ff435.jpg'
// audio url yang ada di menu
global.audioUrl = 'https://a.uguu.se/eAMfYduj.mp3';
// setting pairing code
global.pairing = {
    copyFromLink: false, // ubah true jika ingin salin pairing via link https://iyaudah-iya.vercel.app/pairing
    status: true, // ubah false jika ingin menggunakan qr
    number: '62895604128100' // ubah jadi nomor bot lu
}
// setting configuration baileys
global.config = {
    session: 'session',
    online: false,
    version: [2, 3000, 1015901307],
    browser: ['Windows', 'Chrome', '22.04.4']
}
// apikey fitur quickchat
global.quoteApi = 'https://qc.botcahx.eu.org/generate'
// url database mongodb (daftar di https://www.mongodb.com/)
global.mongoUrl = ''//'mongodb+srv://keya:ciledug57@cluster0.srcdv.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0'
// setting message
global.mess = { 
wait: 'Diproses. . .', 
ok: 'Berhasil.', 
limit: 'Anda telah mencapai batas dan akan mengatur ulang pada pukul 00.00\n\n> untuk mendapatkan limit tak terbatas, tingkatkan ke paket premium.', 
premium: 'Fitur ini hanya untuk pengguna premium.', 
jadibot: 'Fitur ini hanya untuk pengguna jadibot.', 
owner: 'Fitur ini hanya untuk pemilik.', 
devs: 'Fitur ini hanya untuk pengembang.', 
group: 'Fitur ini hanya akan berfungsi dalam grup.', 
private: 'Gunakan fitur ini dalam obrolan pribadi.', 
admin: 'Fitur ini hanya untuk admin grup.', 
botAdmin: 'Fitur ini akan berfungsi ketika saya menjadi admin', 
gconly: 'Bot hanya dapat digunakan di dalam grup.', 
bot: 'Fitur ini hanya dapat diakses oleh bot', 
wrong: 'Format salah!', 
error: { url: 'URL Tidak Valid!', api: 'Maaf, terjadi kesalahan!' }, 
block: { 
owner: 'Fitur ini diblokir oleh pemilik!', 
system: 'Fitur ini diblokir oleh sistem karena terjadi kesalahan!' 
}, 
query: 'Masukkan teks pencarian', 
search: 'Mencari . . .', 
scrap: 'Scrapping. . .', 
wrongFormat: 'Format salah, silakan lihat lagi menunya', 
game: 'Bermain game di obrolan pribadi hanya untuk pengguna premium, tingkatkan ke paket premium hanya Rp. 20.000 selama 1 bulan.' 
}

// menghapus cache setelah update
require('./system/functions.js').reloadFile(__filename);