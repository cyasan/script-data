exports.run = {
usage: [],
hidden: ['abc'],
use: '', 
category: '',
async: async (m, { mecha, func }) => {
let count = m.args[0] ? !isNaN(m.args[0]) ? parseInt(m.args[0]) : 50 : 50
let abc = (arr) => {
let a = `Iil!¡Iil!¡Iil!¡Iil!¡Iil!¡.,·;:;:;:'"°•••`, b = ''
for (let c = 0; c < arr; c++) b += func.pickRandom(a)
return b
}
mecha.reply(m.chat, abc(count), m, {expiration: m.expiration})
}}