exports.run = {
usage: ['totag'],
use: 'reply chat',
category: 'admin tools',
async: async (m, { func, mecha }) => {
if (!m.quoted) return m.reply(`Reply pesan dengan caption ${m.cmd}`)
let members = m.members ? m.members.map(x => x.id) : await mecha.groupMetadata(m.chat).then(x => x.participants.map(x => x.id))
mecha.sendMessage(m.chat, {
forward: m.quoted.fakeObj, 
mentions: members
}, {ephemeralExpiration: m.expiration})
},
group: true,
admin: true
}