exports.run = {
usage: ['culikmember'],
use: 'jid',
category: 'owner',
async: async (m, { mecha, func }) => {
try {
if (!m.args[0] || !m.args[0].startsWith('120') || !m.args[0].endsWith('@g.us')) return m.reply(func.example(m.cmd, '120xxxxx@g.us'))
mecha.sendReact(m.chat, '🕒', m.key)
let users = await mecha.groupMetadata(m.args[0]).then(x => x.participants.map(x => x.id).join(','))
await mecha.groupParticipantsUpdate(m.chat, [users], 'add').then(async (res) => {
for (let i of res) {
if (i.status == 403){
mecha.sendMessage(m.chat, {text: `Diprivasi. mengirimkan groupInvite kepada @${i.jid.split('@')[0]}`, mentions: [i.jid]}, {quoted: m, ephemeralExpiration: m.expiration})
mecha.sendGroupInvite(m.chat, i.jid, {
inviteCode: i.content.content[0].attrs.code,
inviteExpiration: i.content.content[0].attrs.expiration,
groupName: m.groupName,
jpegThumbnail: await mecha.profilePictureUrl(m.chat, 'image').catch(_ => 'https://telegra.ph/file/0d25a520bfa0909c74466.jpg'),
caption: 'Undangan untuk bergabung ke grup WhatsApp saya',
quoted: null
})
} else if (i.status == 409){
m.reply(`@${i.jid.split('@')[0]} already in this group`)
} else if (i.status == 408){
m.reply(`@${i.jid.split('@')[0]} has left the group recently`)
} else if (i.status == 401){
m.reply(`Bot blocked by @${i.jid.split('@')[0]}`)
} else m.reply(`Successfully added member`)
await func.delay(5000)
}
mecha.sendReact(m.chat, '✅', m.key)
})
} catch (e) {
return mecha.reply(m.chat, String(e), m);
}
},
group: true,
owner: true
}