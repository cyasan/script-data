exports.run = {
usage: ['scrap'],
hidden: [],
use: '', 
category: 'owner',
async: async (m, { mecha }) => {
let data = [
  'const coba = async (url) => {',
  'const { data } = await axios.get(url)',
  'const $ = cheerio.load(data)',
  'let result = []',
  '$().each(() => {})',
  'return result',
  '}',
  'return coba(url)'
]
mecha.reply(m.chat, data.join('\n'), m)
}, owner: true}