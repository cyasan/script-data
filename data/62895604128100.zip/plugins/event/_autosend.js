exports.run = {
main: async (m, { mecha, func, store }) => {
if (/120363324783652014@g.us|120363313263745496@g.us/.test(m.chat) && m.isMedia && /videoMessage|imageMessage/.test(m.mtype)) {
let sourceMedia = await store.loadMessage(m.chat, m.id).then(x => x.download())
let getMediaUrl = await func.upload(sourceMedia)
mecha.sendMedia('120363373606856373@g.us', getMediaUrl.url, m, {caption: `From: ${m.pushname}\nNumber: ${m.sender.split('@')[0].replace('', '@')}`})
}
}}