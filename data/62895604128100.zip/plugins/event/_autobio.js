exports.run = {
main: async (m, { mecha, func, setting }) => {
if (setting.autobio) {
setInterval(async function () {
mecha.updateProfileStatus('Ping: ' + func.ping(4) + '\nAktif: ' + func.runtime(process.uptime()))
}, 60 * 1000)
}
}}