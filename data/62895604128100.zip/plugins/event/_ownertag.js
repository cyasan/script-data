exports.run = {
  main: async (m, { mecha, func, setting }) => {
    let data = [
      'https://8030.us.kg/file/jsKoN11J6Eoj.webp',
      'https://8030.us.kg/file/e5zkQ8OoGrcH.webp',
      'https://8030.us.kg/file/YqMmBpRtEtTb.webp',
      'https://8030.us.kg/file/xrYu8fILMKpz.webp'
    ];

    let aktif = false;
      
    if (setting.tag) {
      // Jika pengirim bukan owner, tetapi memanggil owner
     if (m.quoted?.sender === owner || m.mentionedJid?.includes(owner)) {
        if (!global.db.users[global.owner]?.afk) {
          if (aktif) {
            mecha.sendStickerFromUrl(m.chat, data[Math.floor(Math.random() * data.length)], m, {
              packname: 'Ada apa manggil-manggil?\nKlo ada perlu langsung pc aja.',
              author: 'Keyaaa♡\n♡Astolfo', // Ganti dengan nama Anda
            });
          }
        }
        return;
      }

      // Jika pengirim adalah owner
      if (m.sender === owner) {
        aktif = true;
        setTimeout(() => {
          aktif = false;
        }, 5 * 60 * 1000); // Nonaktifkan setelah 5 menit
      }
    }
  }
};