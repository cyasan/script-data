const { downloadContentFromMessage } = require('@whiskeysockets/baileys');
const yts = require('yt-search');
const fs = require('fs');

async function download(url) {
const apikey = '0TIrhCdZ7U2s1fX6Jzs0K0k056kyG7YQ0'
try {
const apiUrl = `https://api.betabotz.eu.org/api/download/yt?url=${encodeURIComponent(url)}&apikey=${apikey}`
const response = await axios.get(apiUrl)
if (response.data.status && response.data.result) {
return response.data.result
} else {
return null
}
} catch (error) {
return null
}
}

exports.run = {
usage: ['getreact', 'addreact'],
async: async (m, { mecha, func, }) => {
switch (m.command) {

case 'getreact': {
if (!m.isOwner) return m.reply(mess.owner)
if (!m.text) return m.reply(func.example(m.cmd, '😂'))
const getreact = (text) => { 
    return `case '${text}'${fs.readFileSync('plugins/event/_autoreact.js').toString().split('case \'' + text + '\'')[1].split('break')[0]}break` 
}
//const getcase = 'case ' + `'${text}'` + fs.readFileSync('plugins/event/_autoreact.js').toString().split(`case '` + m.text + `'`)[1].split("break")[0] + "break"
m.reply(`${getreact(m.text)}`)
} break

}
},
main: async (m, { mecha, setting, store, func, isPrem, packname, author }) => {
if (m.isOwner && setting.autoreact && m.mtype === 'reactionMessage') {
switch (m.message.reactionMessage.text) {

case '🚫': {
if ((m.isGc && !m.isAdmin) && !isPrem && !m.isOwner) return;
let key = m.msg.key;
if (m.isGc) {
mecha.sendMessage(key.remoteJid, {delete: {remoteJid: m.chat, id: key.id, fromMe: key.fromMe, participant: key.participant }})
} else if (m.isPc && key.fromMe) {
mecha.sendMessage(key.remoteJid, {delete: {remoteJid: m.chat, id: key.id, fromMe: key.fromMe, participant: key.participant }})
}
} break

case '👍': {
let msg = await store.loadMessage(m.chat, m.msg.key.id)
const viewOnceMessage = msg?.message?.viewOnceMessageV2?.message;
let type = Object.keys(viewOnceMessage)[0];
let msgType = viewOnceMessage[type];
let media = await downloadContentFromMessage(msgType, type == 'imageMessage' ? 'image' : 'video')
let buffer = Buffer.from([])
for await (const chunk of media) {
buffer = Buffer.concat([buffer, chunk])
}
return await mecha.sendMedia(m.chat, buffer, msg, { mentions: mecha.ments(msgType.caption), ephemeralExpirantion: msg.expiration })
} break

case '▶️': {
let msg = await store.loadMessage(m.chat, m.msg.key.id);
mecha.reply(msg.chat, 'Wait, music will be sent....', msg, { expiration: m.expiration });
var search = await yts(msg.budy);
let convert = search.videos[0];
if (!convert) return m.reply('Video/Audio tidak ditemukan.');
if (convert.seconds >= 3600) return mecha.reply(m.chat, 'Video is longer than 1 hour!', msg);
let res = await download(convert.url).then(a => a.mp3)
mecha.sendMessage(msg.chat, {
audio: { url: res },
mimetype: 'audio/mpeg',
contextInfo: {
externalAdReply: {
title: convert.title, 
body: `Duration: ${convert.timestamp}`, 
thumbnail: await mecha.resize(convert.image, 300, 175), 
thumbnailUrl: convert.thumbnail,
mediaType: 1, 
mediaUrl: convert.url, 
sourceUrl: convert.url
}
}
}, { quoted: null, ephemeralExpirantion: m.expiration })
} break
        
case '🔎': case '🔍': {
let msg = await store.loadMessage(m.chat, m.msg.key.id);
let ke = msg.isPrefix ? msg.cmd.length + 1 : msg.command ? msg.command.length + 1 : null
let text = ke ? msg.budy.substring(ke).trim() : msg.budy
let result = await func.fetchJson('https://meitang.xyz/openai?text=' + text).then(x => x.result)
return mecha.reply(m.chat, result, msg)
} break

case '❗': case '‼️': {
let msg = await store.loadMessage(m.chat, m.msg.key.id);
let tag = m.message.reactionMessage.text === '‼️' ? true : false
let members = (await mecha.groupMetadata(m.chat)).participants.filter(x=>tag?x:!x.admin).map(x=>x.id)
mecha.sendMessage(m.chat, {
forward: msg, 
mentions: members
}, {quoted: func.ftext('Ini bukan hidetag sayangku♡'), ephemeralExpiration: m.expiration})
} break

case '😂': {
let msg = await store.loadMessage(m.chat, m.msg.key.id)
if (/video/.test(msg.mime) && msg.seconds > 9) return msg.reply('Maximum video duration is 9 seconds.')
let media = await msg.download()
return await mecha.sendSticker(m.chat, media, msg, {
packname: packname,
author: author,
avatar: m.text.includes('avatar'),
expiration: m.expiration
})
} break
        
case '': {
} break

}}}}