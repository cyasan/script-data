exports.run = {
usage: ['hneko', 'hwaifu', 'trap', 'blowjob'],
category: 'haram',
async: async (m, { mecha, func, groups }) => {
if (!m.isOwner && !groups.nsfw) return m.reply('Astaghfirullahalazim');
mecha.sendReact(m.chat, '🕒', m.key);
let res = m.command.startsWith('h') ? m.command.substring(1).trim() : m.command
await func.fetchJson('https://api.waifu.pics/nsfw/' + res).then(async a => {
/*let buttons = [
['button', 'Next pic', m.cmd],
['button', 'Del Pic', `${m.prefix}delete`]
//['url', 'Source Pic', a.url]
]
mecha.sendButton(m.chat, '', 'This your want...', global.footer, buttons, m, {
media: a.url,
expiration: m.expiration,
})*/
mecha.sendMedia(m.chat, a.url, m, { caption: 'This your want...', expiration: m.expiration })
})
//mecha.sendReact(m.chat, '', m.key)
},
premium: true,
group: true,
limit: true
}