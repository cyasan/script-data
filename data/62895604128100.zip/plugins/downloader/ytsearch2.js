const yts = require('yt-search');
const { proto, generateWAMessageFromContent, generateWAMessageContent, prepareWAMessageMedia } = require('@whiskeysockets/baileys');

exports.run = {
usage: ['ytsearch'],
hidden: ['yts'],
use: 'judul lagu',
category: 'downloader',
async: async (m, { func, mecha }) => {
if (!m.text) return m.reply(func.example(m.cmd, 'legends never die'))
mecha.sendReact(m.chat, '🕒', m.key)
let data = await yts(m.text).then(x => x.videos)
//if (!data.status) return m.reply(data.message)
//if (data.result.length == 0) return m.reply('Data empty.')
let txt = '*Y O U T U B E - S E A R C H*\n\n `Result From : ' + m.text + '`'
let cards = [];
/*for (let i of data.result) {
listSearch.push({
title: i?.title || 'N/A', 
highlight_label: i.channel || 'N/A',
rows: [
{
header: 'Audio',
title: `${i.publish} • ${i.duration.timestamp} • ${func.formatNumber(i.views)} views`, 
id: `${m.prefix}yta ${i.url}`, 
description: `${i.description}`
},
{
header: 'Video',
title: `${i.publish} • ${i.duration.timestamp} • ${func.formatNumber(i.views)} views`, 
id: `${m.prefix}ytv ${i.url}`, 
description: `${i.description}`
}
]
})
}*/
for (let i of data.slice(0, 10)) {
let text = `*Title:* ${i.title}` 
text += `\n*Views:* ${func.formatNumber(i.views)} penonton`
text += `\n*Creator:* ${i.author.name}`
text += `\n*Duration:* ${i.timestamp} menit`
text += `\n*Upload at:* ${i.ago}`
//text += `\n*Description:* ${i.description}`
let section = [{
    title: i?.title || 'N/A',
    highlight_label: i.channel || 'N/A',
    rows: [
        {
            header: 'Download Audio',
            title: `${i.publish} • ${i.duration.timestamp} • ${func.formatNumber(i.views)} views`, 
            id: `${m.prefix}yta ${i.url}`, 
            description: `${i.description}`
        },
        {
            header: 'Download Video',
            title: `${i.publish} • ${i.duration.timestamp} • ${func.formatNumber(i.views)} views`, 
            id: `${m.prefix}ytv ${i.url}`, 
            description: `${i.description}`
        }
    ]
}]
cards.push({
header: { hasMediaAttachment: true, ...(await prepareWAMessageMedia({ image: {url: i.image} }, { upload: mecha.waUploadToServer })) },
body: { text: text },
nativeFlowMessage: {
buttons: [
{ name: 'cta_copy', buttonParamsJson: JSON.stringify({ display_text: 'Download Video', copy_code: `${m.prefix}ytv ${i.url}` }) },
{ name: 'cta_copy', buttonParamsJson: JSON.stringify({ display_text: 'Download Audio', copy_code: `${m.prefix}yta ${i.url}` }) }
],
/*buttons: [
{ name: 'quick_reply', buttonParamsJson: JSON.stringify({ display_text: 'Download Video', id: `${m.prefix}ytv ${i.url}` }) },
{ name: 'quick_reply', buttonParamsJson: JSON.stringify({ display_text: 'Download Audio', id: `${m.prefix}yta ${i.url}` }) }
    { name: 'single_select', buttonParamsJson: JSON.stringify({ title: 'Download', sections: section })}
],*/
}, })
}
let msg = generateWAMessageFromContent(m.chat, { viewOnceMessage: { message: { interactiveMessage: { footer: { text: txt }, carouselMessage: { cards: cards, messageVersion: 1, }, }, }, }, }, {} )
await mecha.relayMessage(msg.key.remoteJid, msg.message, { messageId: msg.key.id, }).then(() => mecha.sendReact(m.chat, '✅', m.key))
/*mecha.sendButton(m.chat, `Y O U T U B E - S E A R C H`, `Result From : ${m.text}\n\nSelect the list button below.`, global.footer, buttons, m, {
expiration: m.expiration
})*/
},
limit: 2
}