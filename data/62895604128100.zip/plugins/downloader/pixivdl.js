exports.run = {
usage: ['pixivdl'],
use: 'link',
category: 'downloader',
async: async (m, { mecha, func }) => {
if (!m.text) return m.reply(global.mess.query)
if (!/www.pixiv.net/.test(m.text)) return m.reply('Itu bukan url pixiv')
mecha.sendReact(m.chat, '🕒', m.key)
let id = m.text.split('artworks/')[1]
let data = await func.fetchBuffer('https://aemt.uk.to/pixivdl?id='+id+'&ext=.jpg')
mecha.sendMedia(m.chat, data, m, { caption: global.mess.ok, expiration: m.expiration })
.then(() => mecha.sendReact(m.chat, '✅', m.key))
}, limit: 5, premium: true }