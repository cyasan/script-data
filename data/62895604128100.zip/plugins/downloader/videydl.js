exports.run = {
usage: ['videydl'],
hidden: ['videy'],
use: 'link videy',
category: 'downloader',
async: async (m, { mecha, groups }) => {

let urls = m.quoted ? m.quoted.text : m.text
if (!urls && !/^https?:\/\//.test(urls)) return m.reply(mess.wrong)
mecha.sendReact(m.chat, '🕒', m.key)

/*await axios.get('https://btch.us.kg/download/videy?url=' + urls)
.then(res => mecha.sendMedia(m.chat, res.data.result, m, {
    caption: mess.ok, 
    viewOnce: m.isGc ? groups.nsfw ? false : true : true,
    
}))*/
    
    let id = urls.split('id=')[1]
    if (!id) return m.reply(mess.error.url)
    let vid = 'https://cdn.videy.co/' + id + '.mp4'
    mecha.sendMedia(m.chat, vid, m, {
        caption: "Successfully: " + vid,
        viewOnce: m.isGc ? groups.nsfw ? false : true : false,
        expiration: m.expiration
    })
    
.then(() => mecha.sendReact(m.chat, '✅', m.key))
.catch(() => mecha.sendReact(m.chat, '❌', m.key))

}, premium: true, limit: 5}