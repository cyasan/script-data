exports.run = {
usage: ['mangadex'],
hidden: ['manga'],
use: 'manga dan chapternya', 
category: 'downloader',
async: async (m, { mecha, func }) => {
const { search, chapters, images } = scraper.mangadex, { imagesToPdf } = scraper
if (m.args.length < 2) return m.reply('Tolong masukkan judul manga dan chapter yang ingin dicari (contoh: .mangad One Piece 10).');
const mangaTitle = m.args.slice(0, -1).join(' ');
const chapterRequested = m.args[m.args.length - 1];
try {
const manga = await search(mangaTitle);
const mangaId = manga.id;
mecha.reply(m.chat, `Manga ditemukan:\n*${manga.attributes.title.en}*`);
const chapter = await chapters(mangaId);
const chapterData = chapter.find(ch => ch.attributes.chapter === chapterRequested);
if (!chapterData) return mecha.reply(m.chat, `Chapter ${chapterRequested} tidak ditemukan untuk manga ${mangaTitle}.`);
const imageUrls = await images(chapterData.id);
let urlPdf = await imagesToPdf(imageUrls, func);
await mecha.sendMessage(m.chat, {
document: { url: urlPdf },
fileName: `${manga.attributes.title.en} - Chapter ${chapterRequested}.pdf`,
mimetype: 'application/pdf',
}, { quoted: m, ephemeralExpirantion: m.expiration });
} catch (error) {
mecha.reply(m.chat, `⚠️ Error: ${error.message}`);
}
}};