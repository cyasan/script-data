exports.run = {
usage: ['instagram3'],
hidden: ['igdl3', 'ig'],
use: 'link instagram',
category: 'downloader',
async: async (m, { func, mecha }) => {
if (!m.text) return m.reply(func.example(m.cmd, 'https://www.instagram.com/reel/DBLzn9RvK_K/?igsh=MTh3YTByMjhnZXJ0aA=='));
if (!m.args[0].match(/https:\/\/www.instagram.com\/(p|reel|tv)/gi)) return m.reply(`*Link salah! Perintah ini untuk mengunduh postingan ig/reel/tv, bukan untuk highlight/story!*\n\ncontoh:\n${m.cmd} https://www.instagram.com/p/BmjK1KOD_UG/?utm_medium=copy_link`)
await mecha.sendReact(m.chat, '🕒', m.key)
const data = await func.fetchJson(`https://aemt.uk.to/download/igdl?url=${m.args[0]}`);
if (!data.status || data.code != 200) return m.reply('Tejadin kesalahan.')
if (data.result.length < 1) return m.reply('Data empty.');
for (let i of data.result) {
await mecha.sendMedia(m.chat, i.url, m, {
expiration: m.expiration
})
}
await mecha.sendReact(m.chat, '✅', m.key)
},
premium: true,
limit: 5
}