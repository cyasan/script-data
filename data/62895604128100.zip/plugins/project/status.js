exports.run = {
  usage: ['status'],
  hidden: [],
  use: '',
  category: '',
  async: async (m, { mecha, func, users }) => {
    // Cek apakah pengguna sudah terdaftar
    if (!users.project || !users.project.terdaftar) {
      return m.reply('Kamu belum terdaftar! Ketik `.daftar` untuk memulai petualanganmu.');
    }

    // Ambil data pengguna
    const user = users.project;
    const itemDetails = user.items
      .map(item => `- ${item.name} (Amount: ${item.amount}, Durability: ${item.durability})`)
      .join('\n');

    // Tampilkan status karakter
    const statusText = `*Kartu Karakter*\n\n` +
      `> Nama: ${user.name}\n` +
      `> Umur: ${user.age}\n` +
      `> Class: ${user.class}\n\n` +
      `*Stat Karakter*\n` +
      `- Strength: ${user.stat.str}\n` +
      `- Dexterity: ${user.stat.dex}\n` +
      `- Intelligence: ${user.stat.int}\n` +
      `- Vitality: ${user.stat.vit}\n` +
      `- Agility: ${user.stat.agi}\n` +
      `- Luck: ${user.stat.luk}\n\n` +
      `*Inventory*\n${itemDetails}\n\n` +
      `> “Tetaplah bertarung dan jadilah legenda!”`;

    mecha.reply(m.chat, statusText, func.fstatus('Status Karakter'));
  },
  owner: true
};