exports.run = {
  usage: ['daftar'],
  hidden: [],
  use: '',
  category: '',
  async: async (m, { mecha, func, users }) => {
    if (users.project?.terdaftar) return m.reply('Kamu sudah terdaftar! Tidak perlu mendaftar lagi.');
    if (m.isGc) return m.reply('Pendaftaran hanya dapat dilakukan melalui chat pribadi.');

    mecha.reply(m.chat, 'Baiklah, mari kita mulai! Sebutkan namamu dengan jelas.', func.fstatus('Pendaftaran (1/4)'), { expiration: m.expiration });

    global.db.project[m.sender] = {
      id: m.sender,
      name: '',
      age: 0,
      class: '',
      items: [],
      stat: {},
      status: 'name',
      timeout: setTimeout(() => delete global.db.project[m.sender], 120000)
    };
  },
  main: async (m, { mecha, func, users }) => {
    if (!m.isPc || users?.project?.terdaftar || !global.db.project[m.sender]) return;

    let data = global.db.project[m.sender];
    const classData = global.db.rpgClass;
    const classNames = Object.keys(classData);
    const classList = classNames.map((x, i) => `${i + 1}. ${x}`).join('\n');

    switch (data.status) {
      case 'name':
        if (!m.budy) return m.reply('Sebutkan namamu dengan benar!');
        data.name = m.budy;
        data.status = 'age';
        mecha.reply(m.chat, 'Terima kasih! Sekarang sebutkan umurmu dalam angka.', func.fstatus('Pendaftaran (2/4)'), { expiration: m.expiration });
        break;

      case 'age':
        if (isNaN(m.budy)) return m.reply('Sebutkan umurmu dengan benar!');
        data.age = parseInt(m.budy);
        data.status = 'class';
        mecha.reply(m.chat, `Bagus! Sekarang pilih class yang kamu inginkan:\n\n${classList}`, func.fstatus('Pendaftaran (3/4)'), { expiration: m.expiration });
        break;

      case 'class':
        if (!classNames.includes(m.budy)) return m.reply(`Pilihan class tidak valid!\nHarap pilih salah satu di bawah ini:\n${classList}`);
        const selectedClass = classData[m.budy];
        data.class = m.budy;
        data.items = selectedClass[0];
        data.stat = selectedClass[1];
        delete data.status;

        mecha.reply(m.chat, 'Pendaftaranmu hampir selesai! Tunggu Guildmaster memverifikasi datamu.', func.fstatus('Pendaftaran (4/4)'), { expiration: m.expiration });

        clearTimeout(data.timeout);
        setTimeout(() => {
          users.project = {
            name: data.name,
            age: data.age,
            class: data.class,
            items: data.items,
            stat: data.stat,
            terdaftar: true
          };

          const itemDetails = data.items
            .map(item => `- ${item.name} (Amount: ${item.amount}, Durability: ${item.durability})`)
            .join('\n');

          mecha.reply(
            m.chat,
            `Selamat, pendaftaranmu berhasil!\n\nNama: ${data.name}\nUmur: ${data.age}\nClass: ${data.class}\n\nItems:\n${itemDetails}\n\nStat:\n` +
            `- Strength: ${data.stat.str}\n- Dexterity: ${data.stat.dex}\n- Intelligence: ${data.stat.int}\n` +
            `- Vitality: ${data.stat.vit}\n- Agility: ${data.stat.agi}\n- Luck: ${data.stat.luk}\n\n` +
            '> “Petualangan baru telah dimulai. Ketik .status kapan saja untuk melihat kartu ini lagi."',
            func.fverified, { expiration: m.expiration }
          );

          delete global.db.project[m.sender];
        }, 60000);
        break;

      default:
        return;
    }
  },
  owner: true
};
