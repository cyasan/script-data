exports.run = {
usage: ['build'],
hidden: ['building'],
use: '[item] [count]',
category: 'rpg',
async: async (m, { func, mecha }) => {
let user = global.db.users[m.sender]
let txt = `乂  *B U I L D I N G - L I S T*

%🏥 rumahsakit%
%🏭 restoran%
%🏯 pabrik%
%⚒️ tambang%
%🛳️ pelabuhan%

Format: *${m.cmd} [item] [jumlah]*
Contoh: *${m.cmd} restoran 2*`

const item = (m.args[0] || '').toLowerCase()
const total = Math.floor(isNumber(m.args[1]) ? Math.min(Math.max(parseInt(m.args[1]), 1), Number.MAX_SAFE_INTEGER) : 1) * 1
if (item == 'rumahsakit') {
if (user.rumahsakit == 0) {
if (total > 1) return m.reply(`Kamu belum memiliki *🏥 Rumah Sakit*, hanya dapat build 1 bangunan`)
if (user.money < 2000000 * total || user.sand < 1200 * total) return m.reply(`Diperlukan ${2000000 * total} money, ${1200 * total} sand.\n\nAnda memiliki :\n- ${user.money} money\n- ${user.sand} sand`)
user.money -= 2000000 * total
user.sand -= 1200 * total
user.rumahsakit += total
user.rumahsakitlvl += 1
m.reply(`Berhasil membangun *${total} 🏥 Rumah Sakit* level ${user.rumahsakitlvl}.\n\ncommand *${m.prefix}stat* untuk mengecek bonus stat pet / building`)
} else {
if (user.rumahsakit + total > 2 * user.rumahsakitlvl) return m.reply(`Perlu upgrade 🏥 rumahsakit ke level ${2 * user.rumahsakitlvl} terlebih dahulu.`)
if (user.money < 2000000 * total * user.rumahsakitlvl || user.sand < 1200 * total * user.rumahsakitlvl) return m.reply(`Diperlukan ${2000000 * total * user.rumahsakitlvl} money, ${1200 * total * user.rumahsakitlvl} sand.\n\nAnda memiliki :\n- ${user.money} money\n- ${user.sand} sand`)
user.money -= 2000000 * total * user.rumahsakitlvl
user.sand -= 1200 * total * user.rumahsakitlvl
user.rumahsakit += total
m.reply(`Berhasil membangun *${total} 🏥 Rumah Sakit* level ${user.rumahsakitlvl}.\n\ncommand *${m.prefix}stat* untuk mengecek bonus stat pet / building`)
}
} else if (item == 'restoran') {
if (user.restoran == 0) {
if (total > 1) return m.reply(`Kamu belum memiliki *🏭 Restoran*, hanya dapat build 1 bangunan`)
if (user.money < 4000000 * total || user.sand < 999 * total || user.steel < 150 * total || user.masakcount < 150 * total) return m.reply(`Diperlukan ${4000000 * total} money, ${999 * total} sand, ${150 * total} steel, dan pengalaman masak ${150 * total} kali.\n\nAnda memiliki :\n- ${user.money} money\n- ${user.sand} sand\n- ${user.steel} steel\n- pengalaman masak : ${user.masakcount} kali`)
user.money -= 4000000 * total
user.sand -= 999 * total
user.steel -= 150 * total
user.restoran += 1 * total
user.restoranlvl += 1
m.reply(`Berhasil membangun *${total} 🏭 Restoran* level ${user.restoranlvl}.\n\ncommand *${m.prefix}stat* untuk mengecek bonus stat pet / building`)
} else {
if (user.restoran + total > 2 * user.restoranlvl) return m.reply(`Perlu upgrade 🏭 restoran ke level ${2 * user.restoranlvl} terlebih dahulu.`)
if (user.money < 3750000 * total || user.sand < 999 * total || user.steel < 150 * total || user.masakcount < 150 * total) return m.reply(`Diperlukan ${3750000 * total} money, ${999 * total} sand, ${150 * total} steel, dan pengalaman masak ${150 * total} kali.\n\nAnda memiliki :\n- ${user.money} money\n- ${user.sand} sand\n- ${user.steel} steel\n- pengalaman masak : ${user.masakcount} kali`)
user.money -= 3750000 * total
user.sand -= 999 * total
user.steel -= 150 * total
user.restoran += 1 * total
m.reply(`Berhasil membangun *${total} 🏭 Restoran* level ${user.restoranlvl}.\n\ncommand *${m.prefix}stat* untuk mengecek bonus stat pet / building`)
}
} else if (item == 'pabrik') {
if (user.pabrik == 0) {
if (total > 1) return m.reply(`Kamu belum memiliki *🏯 Pabrik*, hanya dapat build 1 bangunan`)
if (user.money < 2000000 * total || user.sand < 466 * total || user.steel < 100 * total || user.craftcount < 150 * total) return m.reply(`Diperlukan ${2000000 * total} money, ${466 * total} sand, ${100 * total} steel, dan pengalaman crafting ${150 * total} kali.\n\nAnda memiliki :\n- ${user.money} money\n- ${user.sand} sand\n- ${user.steel} steel\n- pengalaman crafting : ${user.craftcount} kali`)
user.money -= 2000000 * total
user.sand -= 466 * total
user.steel -= 100 * total
user.pabrik += 1 * total
user.pabriklvl += 1
m.reply(`Berhasil membangun *${total} 🏯 Pabrik* level ${user.pabriklvl}.\n\ncommand *${m.prefix}stat* untuk mengecek bonus stat pet / building`)
} else {
if (user.pabrik + total > 2 * user.pabriklvl) return m.reply(`Perlu upgrade 🏯 pabrik ke level ${2 * user.pabriklvl} terlebih dahulu.`)
if (user.money < 2000000 * total || user.sand < 466 * total || user.steel < 100 * total || user.craftcount < 150 * total) return m.reply(`Diperlukan ${2000000 * total} money, ${466 * total} sand, ${100 * total} steel, dan pengalaman crafting ${150 * total} kali.\n\nAnda memiliki :\n- ${user.money} money\n- ${user.sand} sand\n- ${user.steel} steel\n- pengalaman crafting : ${user.craftcount} kali`)
user.money -= 2000000 * total
user.sand -= 466 * total
user.steel -= 100 * total
user.pabrik += 1 * total
m.reply(`Berhasil membangun *${total} 🏯 Pabrik* level ${user.pabriklvl}.\n\ncommand *${m.prefix}stat* untuk mengecek bonus stat pet / building`)
}
} else if (item == 'tambang') {
if (user.tambang == 0) {
if (total > 1) return m.reply(`Kamu belum memiliki *⚒️ Tambang*, hanya dapat build 1 bangunan`)
if (user.money < 4000000 * total || user.iron < 466 * total || user.steel < 99 * total || user.adventurecount < 150 * total) return m.reply(`Diperlukan ${4000000 * total} money, ${466 * total} iron, ${99 * total} steel, dan pengalaman adventure ${150 * total} kali.\n\nAnda memiliki :\n- ${user.money} money\n- ${user.iron} iron\n- ${user.steel} steel\n- pengalaman adventure : ${user.adventurecount} kali`)
user.money -= 4000000 * total
user.iron -= 466 * total
user.steel -= 99 * total
user.tambang += 1 * total
user.tambanglvl += 1
m.reply(`Berhasil membangun *${total} ⚒️ tambang* level ${user.tambanglvl}.\n\ncommand *${m.prefix}stat* untuk mengecek bonus stat pet / building`)
} else {
if (user.tambang + total > 2 * user.tambanglvl) return m.reply(`Perlu upgrade ⚒️ tambang ke level ${2 * user.tambanglvl} terlebih dahulu.`)
if (user.money < 4000000 * total || user.iron < 466 * total || user.steel < 99 * total || user.adventurecount < 150 * total) return m.reply(`Diperlukan ${4000000 * total} money, ${466 * total} iron, ${99 * total} steel, dan pengalaman adventure ${150 * total} kali.\n\nAnda memiliki :\n- ${user.money} money\n- ${user.iron} iron\n- ${user.steel} steel\n- pengalaman adventure : ${user.adventurecount} kali`)
user.money -= 4000000 * total
user.iron -= 466 * total
user.steel -= 99 * total
user.tambang += 1 * total
m.reply(`Berhasil membangun *${total} ⚒️ Tambang* level ${user.tambanglvl}.\n\ncommand *${m.prefix}stat* untuk mengecek bonus stat pet / building`)
}
} else if (item == 'pelabuhan') {
if (user.pelabuhan == 0) {
if (total > 1) return m.reply(`Kamu belum memiliki *🛳️ Pelabuhan*, hanya dapat build 1 bangunan`)
if (user.money < 2000000 * total || user.kargo < 23 * total || user.kapal < 23 * total || user.mancingcount < 150 * total) return m.reply(`Diperlukan ${2000000 * total} money, ${23 * total} kargo, ${23 * total} kapal, dan pengalaman mancing ${150 * total} kali.\n\nAnda memiliki :\n- ${user.money} money\n- ${user.kargo} kargo\n- ${user.kapal} kapal\n- pengalaman mancing : ${user.mancingcount} kali`)
user.money -= 2000000 * total
user.kargo -= 23 * total
user.kapal -= 23 * total
user.pelabuhan += 1 * total
user.pelabuhanlvl += 1
m.reply(`Berhasil membangun *${total} 🛳️ Pelabuhan* level ${user.pelabuhanlvl}.\n\ncommand *${m.prefix}stat* untuk mengecek bonus stat pet / building`)
} else {
if (user.pelabuhan + total > 2 * user.pelabuhanlvl) return m.reply(`Perlu upgrade 🛳️ pelabuhan ke level ${2 * user.pelabuhanlvl} terlebih dahulu.`)
if (user.money < 2000000 * total || user.kargo < 23 * total || user.kapal < 23 * total || user.mancingcount < 150 * total) return m.reply(`Diperlukan ${2000000 * total} money, ${23 * total} kargo, ${23 * total} kapal, dan pengalaman mancing ${150 * total} kali.\n\nAnda memiliki :\n- ${user.money} money\n- ${user.kargo} kargo\n- ${user.kapal} kapal\n- pengalaman mancing : ${user.mancingcount} kali`)
user.money -= 2000000 * total
user.kargo -= 23 * total
user.kapal -= 23 * total
user.pelabuhan += 1 * total
m.reply(`Berhasil membangun *${total} 🛳️ pelabuhan* level ${user.pelabuhanlvl}.\n\ncommand *${m.prefix}stat* untuk mengecek bonus stat pet / building`)
}
}
else {
m.reply(txt.replaceAll('%', '```'))
}
},
register: true,
limit: true
}

function isNumber(number) {
if (!number) return number
number = parseInt(number)
return typeof number == 'number' && !isNaN(number)
}