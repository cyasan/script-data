const rewards = {
limit: 2,
balance: 800,
exp: 400,
money: 900,
potion: 1,
}
const cooldown = 86400000

exports.run = {
usage: ['daily'],
hidden: ['claim'],
category: 'rpg',
async: async (m, { func, mecha }) => {
let user = global.db.users[m.sender]
if (new Date - user.lastclaim < cooldown) return m.reply(`You have already claimed this daily claim!, wait for *${func.clockString((user.lastclaim + cooldown) - new Date())}*`)
let text = ''
for (let reward of Object.keys(rewards)) {
if (!(reward in user)) continue
user[reward] += rewards[reward]
text += `*+${rewards[reward]}* ${reward}\n`
}
m.reply(text.trim()).then(() => {
if (user.pelabuhan || user.tambang || user.pabrik || user.restoran || user.rumahsakit) {
    let txt = "";

    // Pelabuhan
    if (user.pelabuhan) {
        let kp = Math.floor(Math.random() * 20), 
            kf = Math.floor(Math.random() * 12), 
            kk = Math.floor(Math.random() * 8), 
            ks = Math.floor(Math.random() * 5), 
            kt = Math.floor(Math.random() * 4);

        let money = ((kp + kt) / 2) * 28000, 
            limit = kt + ks, 
            balance = kf * 25000;
        
        user.money += money
        user.limit += limit
        user.balance += balance

        txt += `%</>\t\tLaporan Pelabuhan\t\t</>%
Kapal yang berlayar:
- Kapal Pesiar : ${kp} kapal
- Kapal Ferry  : ${kf} kapal
- Kapal Kargo  : ${kk} kapal
- Kapal Selam  : ${ks} kapal
- Kapal Tanker : ${kt} kapal

Upah Tambahan:
- Money    : ${money} money
- Balance  : ${balance} balance
- Limit    : ${limit} limit\n`;
    }

    // Tambang
    if (user.tambang) {
        let tm = Math.floor(Math.random() * 30), 
            tb = Math.floor(Math.random() * 20), 
            tk = Math.floor(Math.random() * 10),
            tj = Math.floor(Math.random() * 15), 
            th = Math.floor(Math.random() * 5);

        let money = ((tm + tj) / 2) * 27500, 
            limit = th * 5, 
            balance = (tb + tk) * 12300;
        
        user.money += money
        user.limit += limit
        user.balance += balance

        txt += `%</>\t\tLaporan Tambang\t\t</>%
Material tambang yang dijual:
- Tambang Mineral     : ${tm} ton
- Tambang Batu Bara   : ${tb} ton
- Tambang Khusus      : ${tk} ton
- Tambang Emas        : ${tj} ton
- Tambang Perhiasan   : ${th} ton

Upah Tambahan:
- Money    : ${money} money
- Balance  : ${balance} balance
- Limit    : ${limit} limit\n`;
    }

    // Pabrik
    if (user.pabrik) {
        let pb = Math.floor(Math.random() * 40), 
            pm = Math.floor(Math.random() * 25), 
            pk = Math.floor(Math.random() * 15),
            pf = Math.floor(Math.random() * 10), 
            pe = Math.floor(Math.random() * 8);

        let money = ((pb + pf) / 2) * 21200, 
            limit = pe * 3, 
            balance = (pm + pf) * 14000;
        
        user.money += money
        user.limit += limit
        user.balance += balance

        txt += `%</>\t\tLaporan Pabrik\t\t</>%
Produksi selesai:
- Barang Harian : ${pb} unit
- Produk Mesin  : ${pm} unit
- Produk Khusus : ${pk} unit
- Produk Furnitur: ${pf} unit
- Produk Elektronik : ${pe} unit

Upah Tambahan:
- Money    : ${money} money
- Balance  : ${balance} balance
- Limit    : ${limit} limit\n`;
    }

    // Restoran
    if (user.restoran) {
        let rp = Math.floor(Math.random() * 50), 
            rm = Math.floor(Math.random() * 30), 
            rd = Math.floor(Math.random() * 20), 
            rs = Math.floor(Math.random() * 15), 
            rc = Math.floor(Math.random() * 10);

        let money = ((rp + rs) / 2) * 15000, 
            limit = rc * 3, 
            balance = (rm + rd) * 20000;
        
        user.money += money
        user.limit += limit
        user.balance += balance

        txt += `%</>\t\tLaporan Restoran\t\t</>%
Jumlah pesanan yang diselesaikan:
- Prasmanan       : ${rp} pesanan
- Makanan Cepat   : ${rm} pesanan
- Makanan Premium : ${rd} pesanan
- Makanan Siap Saji: ${rs} pesanan
- Camilan         : ${rc} pesanan

Upah Tambahan:
- Money    : ${money} money
- Balance  : ${balance} balance
- Limit    : ${limit} limit\n`;
    }

    // Rumah Sakit
    if (user.rumahsakit) {
        let plr = Math.floor(Math.random() * 79), 
            plp = Math.floor(Math.random() * 50), 
            pls = Math.floor(Math.random() * 10),
            pob = Math.floor(Math.random() * 20), 
            pik = Math.floor(Math.random() * 30);

        let money = ((plr + pob) / 2) * 12000, 
            limit = pls * 3, 
            balance = ((plp + pik) / 2) * 22000;
        
        user.money += money
        user.limit += limit
        user.balance += balance

        txt += `%</>\tLaporan Rumah Sakit\t</>%
Pasien yang dirawat:
- Luka Ringan  : ${plr} orang
- Luka Parah   : ${plp} orang
- Luka Serius  : ${pls} orang
- Operasi Berat: ${pob} orang
- Infeksi Khusus: ${pik} orang

Upah Tambahan:
- Money    : ${money} money
- Balance  : ${balance} balance
- Limit    : ${limit} limit\n`;
    }

    // Penutup
    txt += "`</>\t\tTERIMA KASIH!\t\t</>`";
    m.reply(txt.replaceAll('%', '`'));
}
user.lastclaim = new Date * 1 
})
},
register: true
}