exports.run = {
usage: ['attacktitan'],
hidden: ['atktitan'],
use: '', 
category: 'rpg',
async: async (m, { mecha, func, users }) => {
try {
        // Check if the user has both sword and armor
        if (!users.sword) {
            mecha.reply(m.chat, '⚔️ Kamu belum memiliki sword, ketik *' + m.prefix + 'craft sword* untuk memulai adventure', m)
            return
        }

        if (!users.armor) {
            mecha.reply(m.chat, '🛡️ Kamu belum memiliki armor, ketik *' + m.prefix + 'craft armor* untuk memulai adventure', m)
            return
        }

        let __timers = (new Date - users.lastadventure)
        let _timers = (600000 - __timers) // 10 minutes in milliseconds
        let timers = func.clockString(_timers)
        if (users.health > 79) {
            if (new Date - users.lastadventure > 600000) { // 10 minutes cooldown
                // Define Titans
                let monsters = [
                    { name: 'Pure Titan', health: 20, attack: 5 },
                    { name: 'Abnormal Titan', health: 50, attack: 10 },
                    { name: 'Armored Titan', health: 100, attack: 20 },
                    { name: 'Female Titan', health: 30, attack: 7 },
                    { name: 'Colossal Titan', health: 40, attack: 15 },
                    { name: 'Beast Titan', health: 70, attack: 17 },
                    { name: 'Cart Titan', health: 25, attack: 8 },
                    { name: 'Jaw Titan', health: 60, attack: 12 },
                    { name: 'War Hammer Titan', health: 45, attack: 14 },
                    { name: 'Attack Titan', health: 80, attack: 18 },
                    { name: 'Founding Titan', health: 120, attack: 25 },
                    { name: 'Ymir’s Titan', health: 150, attack: 30 },
                    { name: 'Rod Reiss Titan', health: 200, attack: 35 },
                    { name: 'Mindless Titan', health: 250, attack: 40 },
                    { name: 'Dina Fritz Titan', health: 300, attack: 45 },
                    { name: 'Smiling Titan', health: 350, attack: 50 },
                    { name: 'Grisha Yeager Titan', health: 400, attack: 55 },
                    { name: 'Frieda Reiss Titan', health: 450, attack: 60 },
                    { name: 'Eren Yeager Titan', health: 500, attack: 65 },
                    { name: 'Armin Arlert Titan', health: 550, attack: 70 }
                ]

                // Define Boss Titans
                let bosses = [
                    { name: 'Eren Yeager (Founding Titan)', health: 1000, attack: 100 },
                    { name: 'Zeke Yeager (Beast Titan)', health: 1200, attack: 120 },
                    { name: 'Reiner Braun (Armored Titan)', health: 1500, attack: 150 },
                    { name: 'Bertholdt Hoover (Colossal Titan)', health: 2000, attack: 200 }
                ]

                // Pick a random Titan or Boss Titan
                let isBoss = Math.random() < 0.1 // 10% chance to encounter a boss
                let enemy = isBoss ? bosses[Math.floor(Math.random() * bosses.length)] : monsters[Math.floor(Math.random() * monsters.length)]
                let enemyHealth = enemy.health
                let enemyAttack = enemy.attack

                // Simulate battle
                let userAttack = 10 // Example user attack power
                while (users.healt > 0 && enemyHealth > 0) {
                    enemyHealth -= userAttack
                    func.delay(500)
                    if (enemyHealth > 0) {
                        users.healt -= enemyAttack
                        func.delay(500)
                    }
                }

                if (users.healt <= 0) {
                    mecha.reply(m.chat, `😵 Kamu kalah dalam pertarungan melawan ${enemy.name}. Sehatkan diri terlebih dahulu.`, m)
                    return
                }

                let _money = `${Math.floor(Math.random() * 100001)}`.trim()
                let money = (_money * 1)
                let exp = `${Math.floor(Math.random() * 10001)}`.trim()
                let kayu = `${Math.floor(Math.random() * 51)}`.trim()
                let batu = `${Math.floor(Math.random() * 51)}`.trim()
                let limit = `${Math.floor(Math.random() * 50) + 1}`.trim() // Random limit between 1 and 50
                let _stamina = `${Math.floor(Math.random() * 51)}`.trim()
                let stamina = (_stamina * 1)
                let _mythic = `${func.pickRandom(['1', '3', '1', '1', '2'])}`
                let mythic = (_mythic * 1)
                let _legendary = `${func.pickRandom(['1', '3', '1', '1', '2'])}`
                let legendary = (_legendary * 1)
                let itemrand = [`*Selamat anda mendapatkan item rare yaitu*\n${mythic} 🎁 Mythic Crate`, `*Selamat kamu mendapatkan item rare yaitu*\n${legendary} 🎁 Legendary Crate`]
                let rendem = itemrand[Math.floor(Math.random() * itemrand.length)]
                let peta = func.pickRandom([
                    'Wall Maria', 'Wall Rose', 'Wall Sina', 'Shiganshina District', 'Trost District', 'Stohess District', 
                    'Ragako Village', 'Utgard Castle', 'Forest of Giant Trees', 'Warriors District', 'Yeagerist Base',
                    'Liberio', 'Marley', 'Paths', 'Fort Slava', 'Paradise Island', 'Mahr Headquarters', 'Odiha', 
                    'Port of Kiyomi', 'Hizuru', 'Port of Marley', 'Underground City', 'Southern Slums', 'Northern Slums',
                    'Eastern Slums', 'Western Slums', 'Training Grounds', 'Orvud District', 'Utopia District', 
                    'Klorva District', 'Karanes District', 'Kolkhoz Village'
                ])
                let str = `
🩸 *Nyawa* mu berkurang -${userAttack * 1} karena Kamu telah berpetualang sampai *${peta}* dan melawan *${enemy.name}*. Kamu mendapatkan:
⚗️ *Exp:* ${exp}
💵 *Uang:* ${money}
🎟️ *Tiketcoin:* 1
🪵 *Kayu:* ${kayu}
🪨 *Batu:* ${batu}
🏷️ *Limit:* ${limit}
⚡ *Stamina berkurang:* -${stamina}
`.trim()

                setTimeout(() => {
                    mecha.reply(m.chat, str, m, {
                        contextInfo: {
                            externalAdReply: {
                                mediaType: 1,
                                title: 'FITUR RPG',
                                thumbnailUrl: 'https://telegra.ph/file/e615e0a6000ff647b4314.jpg',
                                renderLargerThumbnail: true,
                                sourceUrl: ''
                            }
                        }
                    })
                }, 0)
                setTimeout(() => {
                    mecha.reply(m.chat, rendem, m)
                    .then(() => rendem.includes('Mythic') ? users.mythic += mythic : users.legendary += legendary)
                }, 1000)
                
                users.health -= userAttack * 1
                users.exp += exp * 1
                users.tiketcoin += 1
                users.money += money * 1
                users.kayu += kayu * 1
                users.batu += batu * 1
                users.stamina -= stamina // Decrease stamina by random value
                users.limit += limit * 1 // Increase limit
                users.lastadventure = new Date * 1

                // Decrease sword and armor durability
                users.sworddurability -= 1
                users.armordurability -= 1

                // Check for broken sword or armor
                if (users.sworddurability <= 0) {
                    users.sword = false
                    mecha.reply(m.chat, '⚔️ Sword kamu telah rusak, craft lagi untuk melanjutkan adventure.', m)
                }
                if (users.armordurability <= 0) {
                    users.armor = false
                    mecha.reply(m.chat, '🛡️ Armor kamu telah rusak, craft lagi untuk melanjutkan adventure.', m)
                }

            } else {
                mecha.reply(m.chat, `💧 Anda sudah berpetualang dan kelelahan, silahkan coba *${timers}* lagi`, m)
            }
        } else {
            mecha.reply(m.chat, '🩸 Minimal 80 health untuk bisa berpetualang, beli nyawa dulu dengan ketik *' + m.prefix + 'shop buy potion <jumlah>*\ndan ketik *' + m.prefix + 'heal* <jumlah>', m)
        }
    } catch (e) {
        console.log(e)
        mecha.reply(m.chat, String(e), m)
    }
}}