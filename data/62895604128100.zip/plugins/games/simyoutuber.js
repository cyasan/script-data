/*
 • Fitur By Anomaki Team
 • Created : Nazand Code
 • Game Simulasi Youtube
 • Jangan Hapus Wm
 • https://whatsapp.com/channel/0029Vaio4dYC1FuGr5kxfy2l
 
  - NOTE : ! 
   Bagi yang Recode dan yang menyesuaikan lagi ni code, mohon untuk jangan dihapus wm pertama, atau beri credit link ch yang share code ini.

Fitur ini masih seri 1, kalau ada waktu gw kembangin lagi:v
  
   Ada yang error contact me:
   6283856730698 (wa)
*/

const fs = require('fs');
const sessions = {};
const contentTypes = ['gaming', 'tutorial', 'vlog', 'reaction', 'music'];
let trendingContent = {
    type: null,
    timestamp: 0
};
let users = global.db.users || {};

const getTrendingContent = () => {
    const currentTime = Date.now();
    const oneDay = 24 * 60 * 60 * 1000;

    if (!trendingContent.type || currentTime - trendingContent.timestamp > oneDay) {
        trendingContent.type = contentTypes[Math.floor(Math.random() * contentTypes.length)];
        trendingContent.timestamp = currentTime;
    }

    return trendingContent.type;
};

const getTrendingRanking = () => {
    const ranking = [...contentTypes].sort(() => Math.random() - 0.5).slice(0, 3);
    return ranking;
};

exports.run = {
usage: ['simulatoryoutuber'],
hidden: ['syt', 'simyoutuber', 'simyt'],
use: '', 
category: 'games',
async: async (m, { mecha }) => {
const chatId = m.chat;
    const senderId = m.sender;
    const sessionId = `${chatId}-${senderId}`;
    const args = m.text ? m.text.split(' ') : [];
    const action = args[0]?.toLowerCase();

    if (!sessions[sessionId]) {
        sessions[sessionId] = {
            username: null,
            subs: 0,
            views: 0,
            videos: [],
            money: 0,
            hoursWatched: 0,
            penalized: false,
            spamCount: 0,
            lastUpload: null,
        };
    }

    const session = sessions[sessionId];

    if (!session.username && action !== 'start' && action !== 'trending' && action !== 'top') {
        await mecha.reply(
            m.chat,
            `⛔ Kamu harus membuat akun terlebih dahulu untuk memulai permainan.\n➹ Gunakan perintah:\n${m.cmd} start [username] ➷`,
            m
        );
        return;
    }

    switch (action) {
        case 'start':
            if (!args[1]) {
                await mecha.reply(
                    m.chat,
                    `❗ Gunakan perintah berikut untuk membuat akun:\n${m.cmd} start [username] ➷`,
                    m
                );
                break;
            }

            const username = args.slice(1).join(' ');
            session.username = username;

            await mecha.reply(
                m.chat,
                `✥ Selamat datang di YouTube Simulator, ♡ ${username}! ➷\n◇ Mulailah unggah video pertama dengan perintah:\n${m.cmd} upload [jenis_konten] ➹\nJenis konten: ♠︎ ${contentTypes.join(', ')} ➷`,
                m
            );
            break;

        case 'upload':
            const contentType = args[1]?.toLowerCase();

            if (!contentTypes.includes(contentType)) {
                await mecha.reply(
                    m.chat,
                    `⛔ Jenis konten tidak valid! Pilih salah satu dari: ♧ ${contentTypes.join(', ')} ➷`,
                    m
                );
                break;
            }

            const currentTime = Date.now();

            if (session.lastUpload && currentTime - session.lastUpload < 60000) {
                session.spamCount++;
                if (session.spamCount >= 3) {
                    session.penalized = true;
                }
            } else {
                session.spamCount = 0;
            }

            session.lastUpload = currentTime;

            let baseSubs = Math.floor(Math.random() * 10) + 2;
            let views = Math.floor(Math.random() * 50) + 20;
            const hoursGained = Math.floor(views / 10);

            if (contentType === getTrendingContent()) {
                baseSubs = Math.floor(baseSubs * 1.8);
                views = Math.floor(views * 2.0);
            }

            if (session.penalized) {
                baseSubs = Math.floor(baseSubs * 0.5);
                views = Math.floor(views * 0.3);
            }

            session.subs += baseSubs;
            session.views += views;
            session.hoursWatched += hoursGained;
            session.money += views * 0.01;
            session.videos.push({
                type: contentType,
                subsGained: baseSubs,
                views,
                hoursGained
            });

            // Check if the user reached 1000 subscribers
            if (session.subs >= 1000 && !users[senderId].limit) {
                users[senderId].limit = (users[senderId].limit || 0) + 10; // limit
                await mecha.reply(
                    m.chat,
                    `🎉 Selamat! Akun ${session.username} telah mencapai 1.000 subscriber! ➹\nLimit kamu telah ditambah menjadi ${users[senderId].limit} ➷`,
                    m
                );
            }

            await mecha.reply(
                m.chat,
                `✔️ Video "${contentType}" berhasil diunggah!\n☆ Views: ${views}\n☆ Subscriber baru: ${baseSubs}\n☆ Jam Tayang: ${hoursGained}\n\nStatistik sekarang:\n- Total Subscriber: ${session.subs}\n- Total Jam Tayang: ${session.hoursWatched}\n- Total Pendapatan: $${session.money.toFixed(2)} ➹`,
                m
            );
            break;

        case 'trending':
            const trending = getTrendingContent();
            const ranking = getTrendingRanking();

            const trendingMessage = `
📈 *Konten Trending Hari Ini* ➷:
1️⃣ ${ranking[0]} ${ranking[0] === trending ? '🔥' : ''}
2️⃣ ${ranking[1]} ${ranking[1] === trending ? '🔥' : ''}
3️⃣ ${ranking[2]} ${ranking[2] === trending ? '🔥' : ''}

🎯 *Jenis Konten Trending Utama*: ➷ ${trending.toUpperCase()} 🔥
            `;

            await mecha.reply(m.chat, trendingMessage, m);
            break;

        case 'top':
            const allUsers = Object.values(sessions);

            if (allUsers.length === 0) {
                await mecha.reply(m.chat, '❌ Belum ada data pemain.', m);
                break;
            }

            const topSubs = allUsers.sort((a, b) => b.subs - a.subs)[0];
            const topViews = allUsers.sort((a, b) => b.views - a.views)[0];
            const topMoney = allUsers.sort((a, b) => b.money - a.money)[0];

            const message = `
📊 *Leaderboard YouTube Simulator* ➹

👑 *Subscriber Terbanyak* ➷:
◇ Username: ${topSubs.username}
◇ Subscriber: ${topSubs.subs}

👑 *Views Terbanyak* ➷:
◇ Username: ${topViews.username}
◇ Views: ${topViews.views}

👑 *Pendapatan Tertinggi* ➷:
◇ Username: ${topMoney.username}
◇ Pendapatan: $${topMoney.money.toFixed(2)}
            `;

            await mecha.reply(m.chat, message, m);
            break;

        case 'status':
            const statusMessage = `
🌟 *Statistik Akun Kamu* ➷:
◇ Username: ${session.username}
◇ Subscriber: ${session.subs}
◇ Views: ${session.views}
◇ Jam Tayang: ${session.hoursWatched}
◇ Pendapatan: $${session.money.toFixed(2)}

➷ Gunakan perintah berikut untuk bermain lebih lanjut:
- ${m.cmd} upload [jenis_konten]
- ${m.cmd} trending
- ${m.cmd} top
            `;

            await mecha.reply(m.chat, statusMessage, m);
            break;

        default:
            await mecha.reply(
                m.chat,
                `❓ Perintah tidak dikenal. Gunakan:\n➹ ${m.cmd} start [username] ➷ (buat akun)\n➹ ${m.cmd} upload [jenis_konten] ➷ (unggah video)\n➹ ${m.cmd} status ➷ (cek statistik)\n➹ ${m.cmd} top ➷ (lihat leaderboard)\n➹ ${m.cmd} trending ➷ (cek konten trending)`,
                m
            );
            break;
    }
}}