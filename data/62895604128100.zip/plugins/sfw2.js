exports.run = {
usage: ['bully', 'cuddle', 'cry', 'hug', 'awoo', 'kiss', 'lick', 'pat', 'smug', 'bonk', 'yeet', 'blush', 'smile', 'wave', 'highfive', 'handhold', 'nom', 'bite', 'glomp', 'slap', 'kill', 'kick', 'happy', 'wink', 'poke', 'dance', 'cringe'],
category: 'anime',
async: async (m, { func, mecha, command }) => {
mecha.sendReact(m.chat, '🕒', m.key)
await func.fetchJson(`https://api.waifu.pics/sfw/${m.command}`).then(res => {
mecha.sendSticker(m.chat, res.url, m, { packname: m.command, author: global.header, expiration: m.expiration })
//mecha.sendMedia(m.chat, res.url, m, { expiration: m.expiration })
.then(() => mecha.sendReact(m.chat, '✅', m.key))
}).catch((e) => mecha.sendReact(m.chat, '❌', m.key))
},
restrict: true,
limit: true
}