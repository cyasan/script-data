/*
[AI CHAT BAGOODEX]
Scrape: Avosky
*/
const axios = require('axios');
const cleanResponse = (text) => {
return text
.replace(/\*\*(.*?)\*\*/g, '$1')
.replace(/__(.*?)__/g, '$1')
.replace(/\*(.*?)\*/g, '$1')
.replace(/_(.*?)_/g, '$1')
.replace(/`(.*?)`/g, '$1')
.replace(/\[(.*?)\]\(.*?\)/g, '$1')
.replace(/~~(.*?)~~/g, '$1')
.replace(/#+\s*(.*)/g, '$1')
.replace(/!\[.*?\]\(.*?\)/g, '')
.replace(/<[^>]+>/g, '')
.replace(/[ \t]+/g, ' ')
.replace(/\$@\$(.*?)\$@\$/g, '')
.trim();
};
const headers = {
"Content-Type": "application/json",
"User-Agent": "Mozilla/5.0 (Linux; Android 12; Infinix HOT 40 Pro Build/SKQ1.210929.001; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/96.0.4664.45 Mobile Safari/537.36",
"Accept": "application/json", 
"Accept-Language": "en-US,en;q=0.9,id;q=0.8",
"Connection": "keep-alive",
"Host": "bagoodex.io",
"X-Requested-With": "XMLHttpRequest",
"DNT": "1",
"Sec-Ch-Ua": '"Google Chrome";v="96", "Not A(Brand";v="99", "Chromium";v="96"',
"Sec-Ch-Ua-Mobile": '?1',
"Sec-Ch-Ua-Platform": '"Android"',
"Referer": "https://bagoodex.io/",
"Origin": "https://bagoodex.io",
"Accept-Encoding": "gzip, deflate, br",
"Cache-Control": "no-cache"
};
const processRequest = async (m, mecha) => {
const payload = {
prompt: "kamu adalah asisten yang baik sopan dan banyak humoris, menjawab pertanyaan apapun dengan bahasa indonesia gaul dan santai, sertakan juga emoticon lucu seperlunya saja.",
messages: [{
content: "hai! aku siap membantu! apa yang bisa aku bantu? (*＾▽＾)／",
role: "system"
}],
input: m.text
};
const response = await axios.post('https://bagoodex.io/front-api/chat', payload, { headers });
const cleanedResponse = cleanResponse(response.data);
return cleanedResponse;
};
exports.run = {
usage: ['ai3'],
hidden: [],
use: 'question', 
category: 'ai',
async: async (m, { mecha }) => {
if (!m.text) return mecha.reply(m.chat, '_Tanya apa?_', m);
mecha.sendReact(m.chat, '🕒', m.key);
const replyText = await processRequest(m, mecha);
mecha.sendReact(m.chat, '✅', m.key);
mecha.reply(m.chat, replyText, m);
},
limit: true
};