exports.run = { 
    usage: ["ai"], 
    use: "query", 
    category: "ai", 
    async: async (a, { mecha: t }) => { 
        if (!a.text) return a.reply("Mau cari apa?");
        a.react("🕒");
        let res = await axios.get("https://api.siputzx.my.id/api/ai/meta-llama-33-70B-instruct-turbo", { 
            params: { 
                content: a.text 
            } 
        });
        if (!res.data.status) return a.react("❌");
        a.reply(res.data.data);
    }
}