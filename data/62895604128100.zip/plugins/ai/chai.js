exports.run = {
usage: ['chai'],
use: ['option'], 
category: ['ai'], 
async: async (m, { func, mecha }) => {
mecha.id = mecha.id ? mecha.id : {}
const value = (m.args[0] || '').toLowerCase();
switch (value) {
case 'create':{
if (!mecha.id[m.sender]) {
let messageId = 'MECHA' + func.makeid(22).toUpperCase() + 'REG1'
await mecha.sendMessage(m.chat, {text: 'Reply pesan ini dan ketik namamu!'}, {quoted: func.fstatus('CREATE ACCOUNT (1/2)'), ephemeralExpiration: m.expiration, messageId: messageId}).then(() => {
mecha.id[m.sender] = {
name: '',
promot: '',
status: 'create'
}
})
} else {
mecha.reply(m.chat, 'Kamu sudah memiliki akun!', m)
}
}
break
case 'prompt':{
if (mecha.id[m.sender]) {
if (mecha.id[m.sender].status === 'create') return mecha.reply(m.chat, 'Selesaikan pembuatan akunmu dulu!', m)
if (mecha.id[m.sender].status === 'start') return mecha.reply(m.chat, 'Kamu masih berada dalam obrolan!', m)
if (mecha.id[m.sender].status === 'prompt') return mecha.reply(m.chat, 'Kamu masih harus mengisi prompt!', m)
let messageId = 'MECHA' + func.makeid(22).toUpperCase() + 'PROMPT'
await mecha.sendMessage(m.chat, {text: 'Reply pesan ini dan ketik prompt yang kamu punya!'}, {quoted: func.fstatus('FILL THE PROMPT'), ephemeralExpiration: m.expiration, messageId: messageId}).then(() => mecha.id[m.sender].status = 'prompt')
} else {
mecha.reply(m.chat, 'Kamu belum mempunyai sebuah akun!', m)
}
} 
break
case 'delete':{
if (mecha.id[m.sender]) {
if (mecha.id[m.sender].status === 'create') return mecha.reply(m.chat, 'Selesaikan pembuatan akunmu dulu!', m)
if (mecha.id[m.sender].status === 'start') return mecha.reply(m.chat, 'Kamu masih berada dalam obrolan!', m)
if (mecha.id[m.sender].status === 'prompt') return mecha.reply(m.chat, 'Kamu masih harus mengisi prompt!', m)
mecha.sendReact(m.chat, '✅', m.key).then(() => delete mecha.id[m.sender])
} else {
mecha.reply(m.chat, 'Kamu belum mempunyai sebuah akun!', m)
}
}
break 
case 'start':{
if (mecha.id[m.sender]) {
if (mecha.id[m.sender].status === 'create') return mecha.reply(m.chat, 'Selesaikan pembuatan akunmu dulu!', m)
if (mecha.id[m.sender].status === 'start') return mecha.reply(m.chat, 'Kamu masih berada dalam obrolan!', m)
if (mecha.id[m.sender].status === 'prompt') return mecha.reply(m.chat, 'Kamu masih harus mengisi prompt!', m)
mecha.sendMessage(m.chat, {text: 'Sesi obrolan sudah dimulai!'}, {quoted: m, ephemeralExpirantion: m.expiration}).then(() => mecha.id[m.sender].status = 'start' )
} else {
mecha.reply(m.chat, 'Kamu belum mempunyai sebuah akun!', m)
}
}
break
case 'stop':{
if (mecha.id[m.sender]) {
if (mecha.id[m.sender].status === 'create') return mecha.reply(m.chat, 'Selesaikan pembuatan akunmu dulu!', m)
if (mecha.id[m.sender].status === 'prompt') return mecha.reply(m.chat, 'Kamu masih harus mengisi prompt!', m)
if (mecha.id[m.sender].status === 'ready') return mecha.reply(m.chat, 'Kamu sedang tidak berada dalam obrolan!', m)
mecha.sendReact(m.chat, '✅', m.key).then(() => mecha.id[m.sender].status = 'ready')
} else {
mecha.reply(m.chat, 'Kamu belum mempunyai sebuah akun!', m)
}
}
break
default:{
let txt = `*Chat Ai With Session and Prompt*\n\nBefore you start, please make sure you have an account. Create *your account* first! After creating an account, enter the *prompt* as needed!\n\n${m.cmd} create *(Buat Akun)*\n${m.cmd} prompt *(Karakter AI Milikmu)*\n${m.cmd} delete *(Hapus Akun)*\n${m.cmd} start *(Mulai Obrolan)*\n${m.cmd} stop *(Stop Obrolan)*\n\n${global.footer}`
mecha.reply(m.chat, txt, m, {
expiration: m.expiration
})
}
}
},
main: async (m, { func, mecha }) => {
mecha.id = mecha.id ? mecha.id : {}
if (mecha.id[m.sender] && mecha.id[m.sender].status === 'create' && m.budy && m.quoted && m.quoted.fromMe && m.quoted.id.endsWith('REG1') && !m.isPrefix) {
mecha.id[m.sender].name = m.budy
let messageId = 'MECHA' + func.makeid(22).toUpperCase() + 'REG2'
await mecha.sendMessage(m.chat, {text: 'Reply pesan ini dan ketik prompt yang kamu punya!\n(karakteristik lawan bicara yang kamu inginkan)'}, {quoted: func.fstatus('CREATE PROMPT (2/2)'), ephemeralExpiration: m.expiration, messageId: messageId})
}
if (mecha.id[m.sender] && mecha.id[m.sender].status === 'create' && m.budy && m.quoted && m.quoted.fromMe && m.quoted.id.endsWith('REG2') && !m.isPrefix) {
mecha.id[m.sender].prompt = m.budy
mecha.id[m.sender].status = 'ready'
mecha.reply(m.chat, 'Success...', m)
}
if (mecha.id[m.sender] && mecha.id[m.sender].status === 'prompt' && m.budy && m.quoted && m.quoted.fromMe && m.quoted.id.endsWith('PROMPT') && !m.isPrefix) {
mecha.reply(m.chat, 'Success...', m)
mecha.id[m.sender].prompt = m.budy
}
if (mecha.id[m.sender] && mecha.id[m.sender].status === 'start' && m.budy && m.quoted && m.quoted.fromMe && !m.quoted.id.startsWith('MECHA') && !m.isPrefix) { 
if (mecha.id[m.sender].status === 'start') {
await func.fetchJson('https://nue-api.vercel.app/api/lgpt?user=' + mecha.id[m.sender].name + '&systemPrompt=' + mecha.id[m.sender].prompt + '&text=' + m.budy).then(async res => {
mecha.sendMessage(m.chat, {text: res.result}, {quoted: m, ephemeralExpirantion: m.expiration})
})
}
}
},
premium: true,
private: true
}