let char = [
  'Airi',    'Akane',    'Akari',   'Ako',      'Aris',    'Arona',
  'Aru',     'Asuna',    'Atsuko',  'Ayane',    'Azusa',   'Cherino',
  'Chihiro', 'Chinatsu', 'Chise',   'Eimi',     'Erica',   'Fubuki',
  'Fuuka',   'Hanae',    'Hanako',  'Hare',     'Haruka',  'Haruna',
  'Hasumi',  'Hibiki',   'Hihumi',  'Himari',   'Hina',    'Hinata',
  'Hiyori',  'Hoshino',  'Iori',    'Iroha',    'Izumi',   'Izuna',
  'Juri',    'Kaede',    'Karin',   'Kayoko',   'Kazusa',  'Kirino',
  'Koharu',  'Kokona',   'Kotama',  'Kotori',   'Main',    'Maki',
  'Mari',    'Marina',   'Mashiro', 'Michiru',  'Midori',  'Miku',
  'Mimori',  'Misaki',   'Miyako',  'Miyu',     'Moe',     'Momoi',
  'Momoka',  'Mutsuki',  'NP0013',  'Natsu',    'Neru',    'Noa',
  'Nodoka',  'Nonomi',   'Pina',    'Rin',      'Saki',    'Saori',
  'Saya',    'Sena',     'Serika',  'Serina',   'Shigure', 'Shimiko',
  'Shiroko', 'Shizuko',  'Shun',    'ShunBaby', 'Sora',    'Sumire',
  'Suzumi',  'Tomoe',    'Tsubaki', 'Tsurugi',  'Ui',      'Utaha',
  'Wakamo',  'Yoshimi',  'Yuuka',   'Yuzu',     'Zunko'
]

exports.run = {
  usage: ['huggingface'],
  hidden: ['hf'],
  use: 'char + text',
  category: 'ai',
  async: async (m, { mecha, func }) => {
    if (!m.text) return m.reply(`${m.cmd} [char] [text]`);
    const model = m.args[0].capitalize();
    const text = m.args.slice(1).join(' ') || m.quoted?.text;
    if (!model && !text) return m.reply(`${m.cmd} [char] [text]`);
    if (!char.includes(model)) return m.reply('Karakter tersebut tidak ada dalam database\nChar hanya ada segini:' + func.readmore + '\n' + char.map((v,i)=>`${i+1}. ${v}`).join("\n"))

    try {
      let res = await Scraper.list()
      .huggingface.blueArchiveVoice({ text, model, speed: 1.2 });
        
      if (!res) return m.reply(mess.error.url);
      m.react("🕒")
      mecha.sendMessage(m.chat, {audio:{url:res.result.url},mimetype:'audio/mpeg',ptt:false}, {quoted:m});
    } catch (e) {
      m.reply(e);
    }
  },
  limit: 5,
  premium: true,
};