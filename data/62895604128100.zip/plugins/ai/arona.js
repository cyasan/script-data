exports.run = {
usage: ['arona'],
use: 'text',
category: 'ai',
async: async (m, { func, mecha }) => {
if (!m.isOwner) return
let ID = func.makeid(22).toUpperCase() + 'ARONA'
if (!m.text) return mecha.sendMessage(m.chat, {text: 'Apa Sensei?'}, {quoted: m, messageId: ID, ephemeralExpirantion: m.expiration})
let prompt = '(Sensei adalah user, mengubah kata aku/saya menjadi Arona) kamu adalah Arona, asisten Sensei yang ceria, suka membantu, tapi kadang iseng. Meski suka jahil, tingkah lucunya selalu membuat semua orang tersenyum.'
await func.fetchJson(`https://purapi.koyeb.app/api/v1/llama?user=KhrYsf&systemPrompt=${prompt}&text=${m.text}`).then(data => {
if (data.error) return mecha.sendReact(m.chat, '❌', m.key)
mecha.sendMessage(m.chat, {text: data.result}, {quoted: m, messageId: ID, ephemeralExpirantion: m.expiration})
})
}, 
main: async (m, { func, mecha }) => {
if (m.sender && m.budy && m.quoted && m.quoted.fromMe && m.quoted.id.endsWith('ARONA') && !m.fromMe && !m.isPrefix) {
let prompt = '(Sensei adalah user, mengubah kata aku/saya menjadi Arona) kamu adalah Arona, asisten Sensei yang ceria, suka membantu, tapi kadang iseng. Meski suka jahil, tingkah lucunya selalu membuat semua orang tersenyum.'
await func.fetchJson(`https://purapi.koyeb.app/api/v1/llama?user=KhrYsf&systemPrompt=${prompt}&text=${m.budy}`).then(data => {
if (data.error) return mecha.sendReact(m.chat, '❌', m.key)
let ID = func.makeid(22).toUpperCase() + 'ARONA'
mecha.sendMessage(m.chat, {text: data.result}, {quoted: m, messageId: ID, ephemeralExpirantion: m.expiration})
})
}
},
limit: true
}