const x = require("axios"),
  u = "https://api.siputzx.my.id/api/ai/llama33";
exports.run = {
  usage: ['openai'],
  hidden: ['cai'],
  use: 'text',
  category: 'ai',
  async: async (m, { mecha: e, func: f, quoted: q }) => {
    global.db.prompt = global.db.prompt ? global.db.prompt : {}
    if (q.text) { 
        if (m.text && m.args[0].includes('prompt')) {
            global.db.prompt[m.sender] = m.args.splice(1).join(' ')
            e.sendReact(m.chat, '✅', m.key)
        } else {
            //if (!global.db.prompt[m.sender]) return e.reply(m.chat, `Kamu belum mengisi prompt untuk ${m.command}\nAwali cmd dengan kata 'prompt' untuk mengisi prompt-mu\n${f.example(m.cmd, 'prompt <dilanjut prompt-mu>')}`, m)
        let w = await e.sendMessage(m.chat, { 
            text: global.mess.wait 
        }, { 
            quoted: m, ephemeralExpirantion: m.expiration 
        }); 
        try { 
            let r = (await x(u, { 
                params: { 
                    prompt: global.db.prompt[m.sender] ? global.db.prompt[m.sender] : 'You are a friendly ai.', 
                    text: m.text ? q.text + '\n\n' + m.text : q.text 
                } 
            })).data;
        e.sendMessage(m.chat, { 
            text: r.data, 
            edit: w.key 
        }, { 
            quoted: m, ephemeralExpirantion: m.expiration 
        }) 
        } catch (e) { 
            m.reply(e) 
        } 
        }
    } else {
        e.reply(m.chat, f.example(m.cmd, "apa itu coding?"), m, { expiration: m.expiration }) 
    }
  },
  limit: 3
}
