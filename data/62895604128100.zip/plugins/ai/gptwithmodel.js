exports.run = {
usage: ['gpt'],
hidden: [],
use: 'options', 
category: 'ai',
async: async (m, { mecha, axios }) => {

//================================

const chatbot = {
  send: async (message, model = "gpt-4o-mini") => {
    try {
      const validModels = ["gpt-3.5-turbo", "gpt-3.5-turbo-0125", "gpt-4o-mini", "gpt-4o"];
      if (!validModels.includes(model)) {
        throw new Error(`❌ Model tidak valid! Pilih salah satu: ${validModels.join(', ')}`);
      }
      const payload = {
        messages: [{
          role: "user",
          content: message
        }],
        model: model
      };
      const response = await axios.post("https://mpzxsmlptc4kfw5qw2h6nat6iu0hvxiw.lambda-url.us-east-2.on.aws/process", payload, {
        headers: {
          'Content-Type': 'application/json',
          'User-Agent': 'Postify/1.0.0'
        }
      });
      return response.data;
    } catch (error) {
      console.error("❌ Terjadi kesalahan saat mengirim pesan:", error.message);
      throw new Error('❌ Tidak dapat memproses permintaan chatbot.');
    }
  },
  getModels: () => {
    return ["gpt-3.5-turbo", "gpt-3.5-turbo-0125", "gpt-4o-mini", "gpt-4o"];
  }
};

//================================

if (!m.text) return m.reply('Liat model .gpt getmodels\nContoh: .gpt hai --gpt-4o')
let models = chatbot.getModels()
if (m.args[0].includes('model')) return m.reply('- '+models.join('\n- '))
let [text, model] = m.text.split('--')
if (!text) return m.reply('Mau ngomong apa?')
mecha.sendReact(m.chat, '🕒', m.key)
let result = await chatbot.send(text, model ? model : 'gpt-4p-mini')
if (!result || !result.choices || result.choices.length == 0) return mecha.sendReact(m.chat, '❌', m.key)
let reply = result.choices[0].message.content
mecha.reply(m.chat, `${model ? model+':\n\n' : ''}${reply}`, m)
.then(() => mecha.sendReact(m.chat, '', m.key))

}}