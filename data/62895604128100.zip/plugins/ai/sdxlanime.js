// * Code By Nazand Code
// * Fitur txt2anime (Dibuat Krn Gabut)
// * Hapus Wm Denda 500k Rupiah
// * https://whatsapp.com/channel/0029Vaio4dYC1FuGr5kxfy2l

const axios = require('axios');

  async function sdxlAnime(prompt) {
    try {
      return await new Promise(async (resolve, reject) => {
        if (!prompt) return reject("Failed to read undefined prompt!");

        axios.post("https://aiimagegenerator.io/api/model/predict-peach", {
          prompt,
          key: "Soft-Anime",
          width: 512,
          height: 768,
          quantity: 1,
          size: "512x768"
        }).then(res => {
          const data = res.data;
          if (data.code !== 0) return reject(data.message);
          if (data.data.safetyState === "Soraa") return reject("NSFW image detected. Please try another prompt.");
          if (!data.data?.url) return reject("Failed to generate the image!");
          

          return resolve({
            status: true,
            image: data.data.url
          });
        }).catch(reject);
      });
    } catch (e) {
      return {
        status: false,
        message: e
      };
    }
  }

exports.run = {
usage: ['sdxlanime'],
hidden: ['sdxl'],
use: global.mess.query,
category: 'ai',
async: async (m, { mecha, func }) => {
if (!m.text) return mecha.sendReact(m.chat, '❓', m.key)
mecha.sendReact(m.chat, '🕒', m.key)
let res = await sdxlAnime(m.text)
if (!res.status) return mecha.reply(m.chat, global.mess.error.api, m)
mecha.sendMedia(m.chat, res.image, m, { caption: global.mess.ok, expiration: m.expiration }).then(() => mecha.sendReact(m.chat, '✅', m.key))
}}

// * Code By Nazand Code
// * Fitur txt2anime (Dibuat Krn Gabut)
// * Hapus Wm Denda 500k Rupiah
// * https://whatsapp.com/channel/0029Vaio4dYC1FuGr5kxfy2l