const axios = require('axios');

async function cimg(prompt) {
  try {
    const response = await axios.get(`https://imgen.duck.mom/prompt/anime%20${prompt}`);
    const imageUrl = response.request.res.responseUrl;
    return imageUrl;
  } catch (error) {
    console.error(error);
    return null;
  }
}

exports.run = {
usage: ['cimg'],
hidden: [],
use: 'prompt', 
category: 'ai',
async: async (m, { mecha }) => {
if (!m.text) return m.reply(mess.query)
mecha.sendReact(m.chat, '🕒', m.key)
await cimg(m.text).then(x => mecha.sendMedia(m.chat, x, m, { caption: mess.ok, expiration: m.expiration }))
}, limit: 5 }