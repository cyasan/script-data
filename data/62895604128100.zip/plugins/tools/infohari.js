const axios = require('axios');

async function nextLibur() {
const { data } = await axios.get("https://itzpire.com/information/nextLibur");
const hari = data.data;
return hari
}

exports.run = {
usage: ['infohari'],
category: 'tools',
async: async (m, { mecha }) => {
let res = await nextLibur()
let text = `${res.nextLibur.replace('urbe', 'ur be')}\n`
let abc = res.libnas_content
for (let i = 0; i < abc.length; i++) {
text += `\n${i + 1}. ${abc[i].summary} (${abc[i].days}, ${abc[i].dateMonth})`
}
}
//main: async (m, { mecha }) => {}
}