const fs = require("fs/promises");
const { minify } = require("terser");

exports.run = {
  usage: ['minify'],
  use: "file/text",
  category: "tools",
  async: async (m, { mecha, func }) => {
    if (m.text || m.quoted) {
      if (m.quoted) {
        // Minify quoted text
        minify(m.quoted.text)
          .then(result => {
            mecha.reply(m.chat, result.code, m);
          })
          .catch(err => {
            mecha.reply(m.chat, "Failed to minify quoted text: " + err.message, m);
          });
      } else {
        // Minify a file
        let filePath = `plugins/${m.text}.js`;
        fs.readFile(filePath, "utf-8")
          .then(data => {
            return minify(data);
          })
          .then(result => {
            return fs.writeFile(filePath, result.code);
          })
          .then(() => {
            mecha.reply(m.chat, "File successfully minified!", m);
          })
          .catch(err => {
            mecha.reply(m.chat, "An error occurred: " + err.message, m);
          });
      }
    } else {
      mecha.reply(m.chat, mess.wrong, m);
    }
  },
  owner: true,
};