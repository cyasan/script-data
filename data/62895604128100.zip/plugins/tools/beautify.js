const beautify = require('js-beautify');
const fs = require('fs');

// Konfigurasi opsi beautify
const options = {
  indent_size: 2, // Ukuran indentasi 2 spasi
  space_in_empty_paren: true, // Tambahkan spasi di dalam tanda kurung kosong
  max_preserve_newlines: 2, // Maksimal baris kosong yang dipertahankan
  brace_style: 'collapse-preserve-inline', // Kurung di baris yang sama, kecuali untuk kurung sebaris
  end_with_newline: true, // Akhiri file dengan baris baru
  keep_array_indentation: false, // Jangan pertahankan indentasi dalam array
  space_before_conditional: true, // Tambahkan spasi sebelum ekspresi kondisi
  jslint_happy: false, // Gaya mirip JSLint (opsional, nonaktifkan jika tidak suka)
  unescape_strings: false, // Jangan decode karakter dalam string
};


exports.run = {
  usage: ['beautify'],
  hidden: ['beauty'],
  use: 'name file',
  category: 'tools',
  async: async (m, { mecha, func }) => {
    if (!m.text && !m.quoted) return m.reply(func.example(m.cmd, 'menu'))
    if (m.quoted) {
      let text = m.quoted.text, type = m.text && m.text.includes('--') ? m.text.split('--')[1] : 'js'
      const beautified = beautify[type](text, options);
      mecha.reply(m.chat, beautified, m);
    } else {
    let text, type
    if (m.text.split('--')) [text, type] = m.text.split('--')
    else text = m.text, type = 'js'
    let filePath = `plugins/${m.text}.js`
    try {
      fs.readFile(filePath, 'utf-8', (err, data) => {
        if (err) return m.reply('Failed to read file: ' + err);

        // Memperbagus dan menyimpan kembali file
        const beautified = beautify(data, options);
        fs.writeFile(filePath, beautified, (err) => {
          if (err) return m.reply('Failed to save file: ' + err);
          mecha.reply(m.chat, 'File successfully beautified!', m);
        });
      });
    } catch (err) {
      m.reply('Failed to beautify: ' + err);
    }
   }
  },
  owner: true
}