const axios = require('axios');
const cheerio = require('cheerio');
const { proto, generateWAMessageFromContent, generateWAMessageContent, prepareWAMessageMedia } = require('@whiskeysockets/baileys');

exports.run = {
usage: ['latestanime', 'animesearch'],
hidden: ['anisearch'],
category: 'anime',
async: async (m, { mecha, func }) => {
switch (m.command) {
case 'latestanime': {
mecha.sendReact(m.chat, '🕒', m.key)
let cest = await latestAnime()
let cards = []
for (let i of cest.slice(0, 10)) {
let text = `*${i.title.split('\n')[0]}*\n` 
//text += `${i.synopsis}\n\n`
text += `${i.studio} (${i.rating})`
cards.push({
header: { hasMediaAttachment: true, ...(await prepareWAMessageMedia({ image: {url: i.image} }, { upload: mecha.waUploadToServer })) },
body: { text: text },
nativeFlowMessage: {
buttons: [{ name: 'cta_url', buttonParamsJson: JSON.stringify({ display_text: 'Source Url', url: i.link }) }],
}, })
}
let msg = generateWAMessageFromContent(m.chat, { viewOnceMessage: { message: { interactiveMessage: { footer: { text: '`L A T E S T - A N I M E`' }, carouselMessage: { cards: cards, messageVersion: 1, }, }, }, }, }, {} )
await mecha.relayMessage(msg.key.remoteJid, msg.message, { messageId: msg.key.id, })
}
break
case 'animesearch': case 'anisearch': {
if (!m.text) return m.reply(global.mess.query)
mecha.sendReact(m.chat, '🕒', m.key)
let res = await animeSearch(m.text)
let cards = []
for (let ani of res) {
let text = `*Judul:* ${ani.title}\n*Genre:* ${ani.genre}\n*Rating:* ${ani.score}`
cards.push({
header: { hasMediaAttachment: true, ...(await prepareWAMessageMedia({ image: {url: ani.thumbnail} }, { upload: mecha.waUploadToServer })) },
body: { text: text },
nativeFlowMessage: {
buttons: [{ name: 'cta_url', buttonParamsJson: JSON.stringify({ display_text: ani.trailer ? 'Trailer' : 'Source Thumbnail', url: ani.trailer ? ani.trailer : ani.thumbnail }) }],
}, })
}
let msg = generateWAMessageFromContent(m.chat, { viewOnceMessage: { message: { interactiveMessage: { footer: { text: '`A N I M E - S E A R C H`' }, carouselMessage: { cards: cards, messageVersion: 1, }, }, }, }, }, {} )
await mecha.relayMessage(msg.key.remoteJid, msg.message, { messageId: msg.key.id, }).then(() => mecha.sendReact(m.chat, '✅', m.key))
}
break
}
}, limit: true }

async function latestAnime() {
const malUrl = 'https://myanimelist.net/anime/season';
const response = await axios.get(malUrl);
const $ = cheerio.load(response.data);
const latestAnime = [];
$('.seasonal-anime').each((index, element) => {
const title = $(element).find('.title').text().trim();
const image = $(element).find('img').attr('data-src') || $(element).find('img').attr('src');
const link = $(element).find('a').attr('href');
const synopsis = $(element).find('.synopsis').text().trim();
const studio = $(element).find('.studio').text().trim() || 'Studio tidak tersedia';
const rating = $(element).find('.score').text().trim() || 'Rating tidak tersedia';

if (title && image && link) {
latestAnime.push({ title, image, link, synopsis, studio, rating });
}
});
return latestAnime
}

async function animeSearch(query) {
const Base_Url = "https://purapi.koyeb.app/api/v1/anime-search?q=";
const { data } = await axios.get(Base_Url + query);
const aniSearch = [];
for (let ani of data.slice(0, 10)) {
aniSearch.push({
title: ani.title,
genre: ani.genre,
score: ani.score,
synopsis: ani.synopsis,
thumbnail: ani.thumbnail,
trailer: ani.trailer
});
};
return aniSearch
}