exports.run = {
  usage: ['ocr'],
  use: 'reply to an image',
  category: 'tools',
  async: async (m, { mecha: e, func: f, quoted: q }) => {
    try {
      // Memastikan pesan yang dibalas adalah gambar
      if (!/image/.test(q.mime)) {
        return m.reply('Please reply to an image for OCR processing.');
      }

      // Menunjukkan proses sedang berjalan
      await m.react('🕒');

      // Mengunggah gambar dan melakukan OCR
      const ocrSpace = require("ocr-space-api-wrapper");
      const imageBuffer = await q.download();
      const uploadResult = await f.upload(imageBuffer);
      const ocrResult = await ocrSpace(uploadResult.url);

      // Mengambil teks dari hasil OCR
      const parsedText = ocrResult.ParsedResults[0]?.ParsedText;

      // Jika tidak ada teks yang ditemukan
      if (!parsedText) {
        return m.reply('No text detected in the image.');
      }

      // Mengirim hasil OCR ke chat
      await e.reply(m.chat, parsedText, m, { expiration: m.expiration });
      await m.react('');
    } catch (error) {
      // Penanganan kesalahan
      console.error('Error in OCR command:', error);
      await m.reply('An error occurred while processing the image. Please try again later.');
      await m.react('❌');
    }
  }
};