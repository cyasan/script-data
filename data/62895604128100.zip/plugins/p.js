exports.run = {
main: async (m, { func, setting, store, quoted, plugins, mecha, packname, author }) => {
if (m.budy && m.budy.toLowerCase() === 'p') mecha.sendReact(m.chat, '✔️', m.key);
else if (/wkwk/.test(m.command)) {
mecha.sendStickerFromUrl(m.chat, 'https://files.catbox.moe/g6lmif.webp', null, {
packname: '',
author: author,
expiration: m.expiration 
})
}
}}