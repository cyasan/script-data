const main = {
  prem: {
    Paket1: 'Rp5.000 / 7 Hari - Pilihan hemat untuk akses singkat.',
    Paket2: 'Rp10.000 / 15 Hari - Cocok untuk pengguna reguler.',
    Paket3: 'Rp20.000 / 30 Hari - Perpanjang hanya Rp15.000, hemat 25%.',
    Paket4: 'Rp30.000 / 60 Hari - Perpanjang hanya Rp25.000, hemat 17%.',
    Informasi: 'Semua paket mencakup Unlock Fitur Premium dan Unlimited Limit untuk pengalaman terbaik.'
  },
  sewa: {
    Paket1: 'Rp15.000 / Grup (15 Hari) - Durasi pendek untuk coba-coba.',
    Paket2: 'Rp25.000 / Grup (1 Bulan) - Perpanjang hanya Rp20.000, hemat 25%.',
    Paket3: 'Rp40.000 / Grup (2 Bulan) - Perpanjang hanya Rp35.000, hemat 15%.',
    Paket4: 'Rp50.000 / Grup (3 Bulan) - Perpanjang hanya Rp45.000, hemat 10%.',
    Informasi: 'Semua paket memberikan akses penuh ke fitur bot selama durasi aktif.'
  },
  prof: {
    1: 'Fast Respon - Kami siap membantu kapan saja.',
    2: 'Bot Aktif 24 Jam - Tanpa jeda, selalu online.',
    3: 'Antilink - Otomatis kick anggota yang mengirimkan link.',
    4: 'Antivirtex - Otomatis kick anggota yang mengirimkan pesan berlebihan (virtex).',
    5: 'Welcome Member Baru - Sambutan otomatis yang ramah.',
    6: 'Games, Menfess, Downloader, AI, dan fitur menarik lainnya yang terus diperbarui.'
  },
  info: {
    1: 'Dengan melakukan pembelian, Anda dianggap telah menyetujui semua kebijakan kami, termasuk ketentuan garansi, refund, dan layanan.',
    2: 'Garansi diberikan untuk memastikan kenyamanan Anda dalam menggunakan layanan kami.',
    3: 'Tidak puas? Refund 100% dapat diajukan dalam waktu 1 jam setelah pembelian.',
    4: 'Jika terjadi kendala teknis lebih dari 24 jam, kami akan memberikan kompensasi berupa tambahan waktu sewa.',
    5: 'Perpanjangan masa aktif hanya dapat dilakukan jika sisa masa aktif kurang dari 3 hari.'
  },
  harga: {
    PaketPremium: 'Harga 5k Dapat Premium 7 Hari',
    PaketSewaBot: 'Harga 15k Dapat Sewa Bot 15 Hari'
  }
};
const util = require('util');

exports.run={usage:['premium','sewabot'],hidden:['prem','sewa'],category:'special',async:async(m,{mecha})=>{let msg=`</> *B U Y ${m.command.toUpperCase().replaceAll('',' ').trim()}*\n\n`+Object.entries(main[m.command.toLowerCase().slice(0,4)]).map((x,i)=>`${i+1}. *${x[0]}*: ${x[1]}`).join('\n')+'\n\n'+(m.command.toLowerCase().includes('sewa')?'</> *KEUNTUNGAN*:\n\n'+Object.entries(main.prof).map(x=>`${x[0]}. ${x[1]}`).join('\n')+'\n\n':'')+'</> *SEKEDAR_INFORMASI*:\n\n'+Object.entries(main.info).map(x=>`${x[0]}. ${x[1]}`).join('\n');m.reply(msg)}}