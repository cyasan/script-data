exports.run = {
usage: ['runtime'],
hidden: ['test'],
category: 'special',
async: async (m, { func, mecha, setting, isPrem, fkon }) => {
   let kata = m.isDevs ? 'Hai, Sayangku♡' : isPrem ? 'Salam, Tuan Muda!' : 'Aktif dong! ' + m.sender.split('@')[0].replace('', '@')
   let s = m.sender
   let text = s === "6282333689838@s.whatsapp.net" ? "Halo King!" : s === "601115811980@s.whatsapp.net" ? "Hina disini, apa sayang?" : s === "62895617566464@s.whatsapp.net" ? "Yayaya terserah": s === '6281253713706@s.whatsapp.net' ? 'Haik, Honey😘' : kata
   mecha.sendMessage(m.chat, {text: text, mentions: [s]}, {quoted: func.fstatus('Aktif selama ' + func.runtime(process.uptime())), ephemeralExpirantion: m.expiration})
   //mecha.reply(m.chat)
/*mecha.sendMessageModify(m.chat, text, fkon, {
title: 'Aktif Selama :',
body: func.runtime(process.uptime()),
thumbUrl: setting.cover,
largeThumb: false,
url: null,
expiration: m.expiration
})*/
    
    
/*const { proto, generateWAMessageFromContent, prepareWAMessageMedia } = require('@whiskeysockets/baileys');
const message = generateWAMessageFromContent(m.chat, {
    viewOnceMessage: {
      message: {
        interactiveMessage: {
          header: {hasMediaAttachment: true, ...(await prepareWAMessageMedia({ image: { url: setting.cover } }, { upload: mecha.waUploadToServer }))},
          body: { text: 'Aktif selama '+func.runtime(process.uptime()) },
          footer: { text: 'Powered by KeyaruZNX.' },
          carouselMessage: {
            messageVersion: 1
          }
        }
      }
    }
  }, { quoted: null });

return await mecha.relayMessage(m.chat, message.message, { messageId: message.key.id });*/
}
}