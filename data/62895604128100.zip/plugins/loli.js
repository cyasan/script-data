exports.run = {
usage: ['loli'],
category: 'anime',
async: async (m, { func, mecha }) => {
mecha.sendReact(m.chat, '🕒', m.key)
await func.fetchJson('https://raw.githubusercontent.com/Arya-was/endak-tau/main/loli.json').then(async res => {
let url = res.random()
m.reply({image:{url},caption:"Nih lolinya!"})
//mecha.sendMedia(m.chat, loli, m, { caption: 'This is your loli', expirantion: m.expiration })
/*let buttons = [
['button', 'Next Image', m.cmd] 
]
mecha.sendButton(m.chat, '', 'This is your ' + m.command, 'Simple Fitur by KeyaruZNX', buttons, m, {
media: loli,
})*/
//mecha.sendReact(m.chat, '', m.key)
})
},
limit: true
}