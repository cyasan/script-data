exports.run = {
  usage: ['xgroovy'],
  hidden: ['groovy', 'xg'],
  use: 'options',
  category: 'haram',
  async: async (m, {
    mecha,
    func,
    groups
  }) => {
    try {

      let groovy = Object.keys(scraper.XGroovy)
      if (!m.text || !groovy.includes(m.args[0])) return m.reply(func.example(m.cmd, groovy.join('/')))
      mecha.sendReact(m.chat, '🕒', m.key)

      let arg = m.args[0]
      let result
      if (arg == 'hentaivid') {
        result = await scraper.XGroovy[arg]()
        mecha.reply(m.chat, 'Wait, memerlukan waktu yang lama,\nKarena kualitas gambar 240p.\nAtau mungkin bisa jadi gagal!!!', m)
      } else {
        result = await scraper.XGroovy[arg]().then(x => x.random())
      }
      mecha.sendMedia(m.chat, result.url, m, {
        caption: result.title,
        viewOnce: m.isgGc ? groups.nsfw ? false : true : false,
        expiration: m.expiration
      })

    } catch (err) {
      mecha.sendReact(m.chat, '❌', m.key)
      mecha.reply(owner, err, m)
    }
  },
  premium: true,
  limit: 5
}
