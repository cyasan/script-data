const fetch = require('node-fetch');

exports.run = {
usage: ['pixiv'],
use: 'query',
category: 'searching',
async: async (m, { func, mecha, setting }) => {
if (!m.text) return m.reply(func.example(m.cmd, 'hinata'));
mecha.sendReact(m.chat, '🕒', m.key);
const query = encodeURIComponent(m.text);
const url = `https://api.ryzendesu.vip/api/search/pixiv?query=${query}`;
const headers = {
'accept': 'application/json',
'User-Agent': 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1',
'Referer': 'https://api.ryzendesu.vip/'
};
try {
const response = await fetch(url, { headers, timeout: 10000 });
if (!response.ok) return;
const data = await response.json();
if (!data || !data.Media) return;
const message = `*====[ PIXIV SEARCH RESULTS ]====*\n*Artist:* ${data.artist}\n*Description:* ${data.caption}\n*Tags:${func.readmore}\n* ${data.tags.join(', ')}`;
/*const button = [
['button', 'Next', `${m.cmd} ${m.text}`],
['button', 'Delete', `${m.prefix}delete`]
];
await mecha.sendButton(m.chat, '', message, '', button, m, {
media: data.Media[0],
});*/
await mecha.sendMedia(m.chat, data.Media[0], m, { caption: message, expiration: m.expiration }).then(() => mecha.sendReact(m.chat, '✅', m.key))
} catch (e) {
return mecha.reply(m.chat, String(e), m)
}
}
};