const fetch = require('node-fetch');

exports.run = {
usage: ['gimage'],
category: 'searching',
async: async (m, { func, mecha, setting, isPrem }) => {
if (!m.text) return m.reply(func.example(m.cmd, 'query'))
mecha.sendReact(m.chat, '🕒', m.key)
try {
/*if (isPrem) {
let button = [
['button', 'Next Pic', `${m.prefix}${m.command} ${m.text}`],
]
mecha.sendButton(m.chat, '`G I M A G E`', 'Okay, This is your ' + m.text, 'Click the button below to the next pic...', button, m, {
userJid: m.sender,
media: a.random(),
expiration: m.expiration
});
} else {*/
let img = 
await mecha.sendMessage(m.chat, {image: {url: `https://btch.us.kg/gimage?query=${m.text}`}, caption: 'Okay, This is your ' + m.text}, {quoted: m, ephemeralExpirantion: m.expiration})
} catch (e) {
return m.reply(String(e));
}
},
limit: true
}