const axios = require('axios'), cheerio = require('cheerio');

const rule34 = async (query) => {
const URL = 'https://rule34.xxx'
let q = query.split(' ').join('_')
const { data } = await axios.get('https://rule34.xxx/index.php?page=post&s=list&tags=' + q)
const $ = cheerio.load(data)
let result = []
$('.thumb').each((a, b) => {
result.push(URL + $(b).find('a').attr('href'))
})
const response = await axios.get(result.random())
const $$ = cheerio.load(response.data)
return $$('.link-list').find('a[style="font-weight: bold;"]').attr('href')
}

exports.run = {
usage: ['rule34'],
hidden: ['r34'],
use: 'query', 
category: 'haram',
async: async (m, { mecha }) => {

if (!m.text) return m.reply(mess.query)
mecha.sendReact(m.chat, '🕒', m.key)
try {
let res = await rule34(m.text)
mecha.sendMedia(m.chat, res, m, { caption: 'This is your ' + m.text, expiration: m.expiration })
.then(() => mecha.sendReact(m.chat, '', m.key))
} catch {
mecha.sendReact(m.chat, '❌', m.key)
}

}, premium: true, limit: true }