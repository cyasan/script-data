exports.run = {
usage: ['meme'],
category: 'searching',
async: async (m, { func, mecha, setting }) => {
if (!m.text) return m.reply(func.example(m.cmd, 'hitam'))
mecha.sendReact(m.chat, '🕒', m.key)
  let query = m.text;
  let page = Math.floor(Math.random() * 10);
  let url = `https://lahelu.com/api/post/get-search?query=${query}&page=${page}`;
    let response = await fetch(url);
    let data = await response.json();
    let random = Math.floor(Math.random() * data.postInfos.length);
    let result = data.postInfos[random];
     let video = "https://cache.lahelu.com/" + result.media;
    let message = `*====[ MEME FROM LAHELU ]====*
*Title:* ${result.title}
*Total Comments:* ${result.totalComments}
*Create Time:* ${new Date(result.createTime).toLocaleString()}
*User Username:* ${result.userUsername}
*====[ MEME FROM LAHELU ]====*`;
   let button = [
['button', 'Next', `${m.cmd} ${m.text}`],
['button', 'Delete', `${m.prefix}delete`],
]
mecha.sendButton(m.chat, '', message, '', button, m, {
media: video,
expiration: m.expiration
})
}
}