exports.run = {
usage: ['lyrics'],
hidden: [],
use: 'option', 
category: 'searching',
async: async (m, { mecha, func }) => {

const { search, get } = scraper.lyrics;
const opsi = m.args[0], lagu = m.args.slice(1, m.args.length).join(' ');
const opt = Object.keys(scraper.lyrics)

if (!m.text || (opsi && !opt.includes(opsi)) || !lagu) return m.reply(opt.map(x => `\`${m.cmd} ${x} lagunya\``).join('\n'));
mecha.sendReact(m.chat, '🕒', m.key);

let result = await scraper.lyrics[opsi](lagu)
if (!result.status) return mecha.reply(m.chat, result.msg, m);
let text = ''

if (opsi == 'search') {
text += '『 *L Y R I C S - S E A R C H* 』\n\n'
text += 'Ditemukan ' + result.data.length + ' lagu\n\n'
text += result.data.map((x, v) => `${v+1}. ${x.title}\n- Url: ${x.url}\n- Image: ${x.imageUrl}`).join('\n\n')
text += '\n\n'
text += `${func.example(m.cmd, 'get https://www.lyrics.com/lyric/19516502/Owl+City/Fireflies')}`
}

if (opsi == 'get') {
text += '『 *L Y R I C S - G E T* 』\n\n'
text += result.data.join('')
}

mecha.reply(m.chat, text, m)
.then(() => mecha.sendReact(m.chat, '✅', m.key))

}}