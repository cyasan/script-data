const { proto, generateWAMessageFromContent, prepareWAMessageMedia } = require('@whiskeysockets/baileys');

exports.run = {
  usage: ['pinterest'],
  hidden: ['pin'],
  use: 'query',
  category: 'searching',
  async: async (m, { mecha, func }) => {
    const pin = scraper.pinterest;
    if (!m.text) return m.reply(mess.query);
    if (m.text.startsWith('@62')) return m.reply('Stress ??');

    let arg = m.args[m.args.length - 1];
    mecha.sendReact(m.chat, '🕒', m.key);

    if (!isNaN(arg)) {
      let txt = m.args.slice(0, m.args.length - 1).join(' ')
      arg = Math.max(2, Math.min(10, arg));
      const pins = Object.keys(pin).random();
      const array = await pin.v2(txt);
      func.shuffleArray(array);
      const result = array.slice(0, arg);
      
      mecha.reply(m.chat, `> Ditemukan *${result.length}* photo,\n> Wait Sedang diproses`, m);
      
      const cards = await Promise.all(result.map(async (url, index) => ({
        header: {
          hasMediaAttachment: true,
          ...(await prepareWAMessageMedia({ image: { url } }, { upload: mecha.waUploadToServer }))
        },
        body: { text: `Image *(${index + 1}/${result.length})*` },
        nativeFlowMessage: {
          buttons: [{
            name: 'cta_url',
            buttonParamsJson: JSON.stringify({ display_text: 'Source Url', url })
          }]
        }
      })));

      const msg = generateWAMessageFromContent(m.chat, {
        viewOnceMessage: {
          message: {
            interactiveMessage: {
              footer: { text: 'Powered by KeyaruZNX.' },
              carouselMessage: { cards, messageVersion: 1 }
            }
          }
        }
      }, {});

      await mecha.relayMessage(msg.key.remoteJid, msg.message, { messageId: msg.key.id });
    } else {
      const pins = Object.keys(pin).random();
      const result = (await pin.v2(m.text)).random();
      mecha.sendMedia(m.chat, result, m, { caption: `Result from:\t\`${m.text}\``, expiration: m.expiration });
    }
  },
  limit: 3
};