const axios = require('axios');
const translate = require('translate-google-api');

exports.run = {
usage: ['charasearch'],
use: 'nama waifu/husbu',
category: 'searching',
async: async (m, { mecha }) => {
if (!m.text) return m.reply(global.mess.query)
mecha.sendReact(m.chat, '🕒', m.key)
let data = await charSearch(m.text).then(x => x[0])
let result = await translate(`${data.desc}`, {
to: 'id'
})
mecha.sendMedia(m.chat, data.image, m, { caption: `ℵ ${data.name}\n\n${result}`}).then(() => mecha.sendReact(m.chat, '✅', m.key))
}, limit: true }

async function charSearch(text) {
const url = "https://purapi.koyeb.app/api/v1/char-search?q=";
const { data } = await axios.get(url + text);
const res = data.filter(x => x.desc !== 'No description available');
return res;
}