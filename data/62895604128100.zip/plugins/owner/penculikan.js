const meta = []
exports.run = {
usage: ['culik'],
use: 'link grup',
category: 'owner',
async: async (m, { func, mecha, setting }) => {
if (!m.text) return m.reply('Mana coba link grupnya!')
let url = m.text
if (url.includes('chat.whatsapp.com')) {
let res = await mecha.groupAcceptInvite(url.split('https://chat.whatsapp.com/')[1])
let data = await mecha.groupMetadata(res)
meta[m.sender].data = data.participants.filter(x => !x.admin).map(x => x.id)
mecha.reply(m.chat, 'Yakin ingin lanjut?\nTotal member ada: '+meta[m.sender].data.length, m)
//mecha.sendButton(m.chat, 'Ingin menambahkan member?', 'Beneran nih?', 'Yakin Nih?', [['button', 'Oke Gass!', '.add '+result]], null, { media: setting.cover, expiration: m.expiration})
.then(() => mecha.groupLeave(res))
} else m.reply('Masukkan link grup dengan benar!')
},
main: async (m, { mecha }) => {
    if (meta[m.sender] && m.isOwner && m.budy && m.budy.includes('yes')) {
        await mecha.groupParticipantsUpdate(m.chat, meta[m.sender].data, 'add')
        m.reply('Done✓').then(() => delete meta[m.sender])
    } else if (meta[m.sender] && m.isOwner && m.budy && m.budy.includes('no')) {
        m.reply('Oke✓').then(() => delete meta[m.sender])
    }
},
owner: true
}