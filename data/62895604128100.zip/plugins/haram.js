const axios = require('axios');
const fs = require('fs');
const sharp = require("sharp");
const fetch = require('node-fetch');
const cheerio = require('cheerio');
const path = require('path');
const sizeOf = require('image-size');
const {
  jsPDF
} = require('jspdf');
const {
  proto,
  generateWAMessageFromContent,
  generateWAMessageContent,
  prepareWAMessageMedia
} = require('@whiskeysockets/baileys');

const convImg = async (url) => {
  const {
    data
  } = await axios({
    url,
    method: "GET",
    responseType: "arraybuffer",
  });
  const buffer = Buffer.from(data);
  return sharp(buffer).jpeg().toBuffer();
}

const javdesu = async (url) => {
  const {
    data
  } = await axios.get(url)
  const $ = cheerio.load(data)
  let result = []
  $('a.thumbnail').each((a, b) => {
    result.push({
      name: $(b).attr('title'),
      url: url + $(b).attr('href'),
      thumb: $(b).find('img').attr('src')
    })
  })
  return result
}

exports.run = {
  usage: ['kodenuklir', 'nhentai', 'javdesu'],
  category: 'haram',
  async: async (m, {
    mecha,
    func
  }) => {
    switch (m.command) {

      case 'kodenuklir': {
        mecha.kodenuklir = mecha.kodenuklir ? mecha.kodenuklir : {}
        if (mecha.kodenuklir[m.chat]) return m.reply('Wait, sedang ada yang mengconvert!')
        if (!m.args[0]) return m.reply('Mana kode nuklir nya!')
        if (isNaN(m.args[0])) return m.reply(
          'Itu bukan kode nuklir!\nKodenya harus berupa angka!')
        if (m.args[0].length !== 6) return m.reply(
          'Kode nuklir harus 6 digit!')
        mecha.reply(m.chat,
          `Wait, diperlukan waktu untuk mengconvert image menjadi pdf!`, m
          ).then(() => mecha.kodenuklir[m.chat] = true)
        let data = await nhentai('https://nhentai.net/g/' + m.args[0] + '/')
        const outputPath = path.join('/tmp', `KodeNuklir ${m.args[0]}.pdf`);
        await createPdf(data.images, outputPath)
        await mecha.sendMessage(m.chat, {
            document: {
              url: outputPath
            },
            fileName: `KodeNuklir ${m.args[0]}.pdf`,
            mimetype: 'application/pdf',
          }, {
            quoted: m,
            ephemeralExpirantion: m.expiration
          })
          .then(() => mecha.sendReact(m.chat, '✅', m.key))
          .then(() => fs.unlinkSync(outputPath))
          .then(() => delete mecha.kodenuklir[m.chat])
      }
      break

      case 'nhentai': {
        mecha.sendReact(m.chat, '🕒', m.key)
        let cest = await latest()
        let cards = []
        for (let i = 0; i < 10; i++) {
          let nhn = cest[i]
          cards.push({
            header: {
              hasMediaAttachment: true,
              ...(await prepareWAMessageMedia({
                image: {
                  url: nhn.thumb
                }
              }, {
                upload: mecha.waUploadToServer
              }))
            },
            body: {
              text: nhn.title
            },
            nativeFlowMessage: {
              buttons: [{
                name: 'cta_copy',
                buttonParamsJson: JSON.stringify({
                  display_text: 'Copy Code',
                  copy_code: nhn.url.replace(/[^0-9]/g, '')
                })
              },
              {
                name: 'cta_url',
                buttonParamsJson: JSON.stringify({
                  display_text: 'Source Url',
                  url: nhn.url
                })
              }, ],
            },
          })
        }
        let msg = generateWAMessageFromContent(m.chat, {
          viewOnceMessage: {
            message: {
              interactiveMessage: {
                footer: {
                  text: '`L A T E S T - H E N T A I`'
                },
                carouselMessage: {
                  cards: cards,
                  messageVersion: 1,
                },
              },
            },
          },
        }, {})
        await mecha.relayMessage(msg.key.remoteJid, msg.message, {
          messageId: msg.key.id,
        })
      }
      break

      case 'javdesu': {
        mecha.sendReact(m.chat, '🕒', m.key)
        try {
          let res = await javdesu('https://javdesu.tv')
          let cards = []
          for (let hsl of res.filter(x => !x.thumb.startsWith('/')).slice(0,
              10)) {
            let img = await convImg(hsl.thumb).then(imgs => func.upload(
              imgs))
            cards.push({
              header: {
                hasMediaAttachment: true,
                ...(await prepareWAMessageMedia({
                  image: {
                    url: img.url
                  }
                }, {
                  upload: mecha.waUploadToServer
                }))
              },
              body: {
                text: hsl.name
              },
              nativeFlowMessage: {
                buttons: [
                  //    { name: 'cta_copy', buttonParamsJson: JSON.stringify({ display_text: 'Copy Code', copy_code: nhn.url }) },
                  {
                    name: 'cta_url',
                    buttonParamsJson: JSON.stringify({
                      display_text: 'Source Url',
                      url: hsl.url
                    })
                  },
                ],
              },
            })
          }
          let msg = generateWAMessageFromContent(m.chat, {
            viewOnceMessage: {
              message: {
                interactiveMessage: {
                  footer: {
                    text: 'Powered by javdesu.tv'
                  },
                  carouselMessage: {
                    cards: cards,
                    messageVersion: 1,
                  },
                },
              },
            },
          }, {})
          await mecha.relayMessage(msg.key.remoteJid, msg.message, {
            messageId: msg.key.id,
          })
        } catch {
          mecha.sendReact(m.chat, '❌', m.key)
        }
      }
      break
    }
  },
  premium: true,
  limit: 50
}

async function latest() {
  const {
    data
  } = await axios.get("https://nhentai.net").catch(e => e.response);
  const $ = cheerio.load(data);
  const res = [];
  $('.gallery').each((a, i) => {
    res.push({
      title: $(i).find(".caption").text(),
      url: "https://nhentai.net" + $(i).find('a').attr("href"),
      thumb: $(i).find('.lazyload').attr("data-src")
    })
  })
  return res
}

async function nhentai(url) {
  let {
    data
  } = await axios.get(url).catch(e => e.response)
  let $ = cheerio.load(data);
  const info = {
    title: $('.title.pretty').text(),
    uploaded: require("moment-timezone")(new Date($(
        '.tag-container.field-name:last-child time').attr('datetime')))
      .format("DD/MM/YYYY HH:mm"),
    images: []
  };
  let imgs = [];
  $('.thumb-container').each((a, b) => {
    imgs.push('https://nhentai.net' + $(b).find(".gallerythumb").attr(
      "href"));
  })
  for (let img of imgs) {
    let {
      data
    } = await axios.get(img).catch(e => e.response)
    let $ = cheerio.load(data);
    $("#image-container.fit-both").each((a, b) => {
      info.images.push($(b).find("img").attr("src"));
    })
  }
  return info
}

async function getImageSize(url) {
  try {
    const response = await axios.get(url, {
      responseType: 'arraybuffer'
    });
    const imageBuffer = Buffer.from(response.data, 'binary');
    const dimensions = sizeOf(imageBuffer);
    let hasil = {
      width: dimensions.width,
      height: dimensions.height
    };
    return hasil
  } catch (error) {
    console.error(`Error: ${error.message}`);
  }
}

async function createPdf(imgurl, outputPath) {
  let img1 = await getImageSize(imgurl[0])
  const doc = new jsPDF({
    orientations: 'portrait',
    unit: 'px',
    format: [img1.width, img1.height]
  });
  for (let img of imgurl) {
    try {
      if (img === imgurl[0]) {
        let imageBuffer = await fetch(img).then(x => x.blob()).then(c => c
          .arrayBuffer()).then(v => new Uint8Array(v)).then(b => Array.from(
          b)).then(n => Buffer.from(n));
        doc.addImage(imageBuffer, 'PNG', 0, 0, img1.width, img1.height);
      } else {
        const {
          width,
          height
        } = await getImageSize(img);
        doc.addPage([width, height]);
        let imageBuffer = await fetch(img).then(x => x.blob()).then(c => c
          .arrayBuffer()).then(v => new Uint8Array(v)).then(b => Array.from(
          b)).then(n => Buffer.from(n));
        doc.addImage(imageBuffer, 'PNG', 0, 0, width, height);
      }
    } catch (error) {
      console.error(`Error processing image: ${imgurl}. Skipping...`);
      continue;
    }
  }
  doc.save(outputPath);
}