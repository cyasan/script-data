exports.run = {
  usage: ['anusview', 'barefoot', 'beach', 'bed', 'bikini', 'blonde', 'bondage', 'bra', 'breast', 'breasthold', 'bunnyear', 'bunnygirl', 'catgirl', 'chain', 'close', 'demon', 'dress', 'drunk', 'fateseries', 'fingering', 'flatchest', 'food', 'gamecg', 'genshin', 'glasses', 'greenhair', 'gun', 'headband', 'headdress', 'headphone', 'hololive', 'horns', 'idol', 'foxgirl', 'maid', 'nipples', 'erectnipples', 'nobra', 'nude', 'openshirt', 'pantypull', 'pinkhair', 'ponytail', 'schoolswimsuit', 'seethrough', 'sex', 'sex2', 'sex3', 'shirtlift', 'shorts', 'spreadlegs', 'spreadpussy', 'stokings', 'sunglasses', 'swimsuit', 'tears', 'tie', 'topless', 'torncloth', 'touhou', 'tree', 'twintail', 'uncensored', 'underwear', 'uniform', 'vampire', 'weapon', 'wet', 'white', 'whitehair', 'wolfgirl'],
  category: 'haram',
  async: async (m, {
    mecha,
    func,
    groups,
    users
  }) => {
    if (!m.isOwner && !groups.nsfw && m.text.includes('@62')) return m.reply('Astagfirullahalazim!');
    if (!users.age || users.age < 18) return m.reply('Elu Masih Kecil');
    if (m.command == 'white' && m.text && m.text.includes('@')) return
    mecha.sendReact(m.chat, '🕒', m.key);
    await func.fetchJson(`https://fantox-apis.vercel.app/${m.command}`).then(url => {
      /*let buttons = [
      ['button', 'Next pic', `${m.prefix}${m.command}`],
      ['button', 'Del Pic', `${m.prefix}delete`]
      //['url', 'Source Pic', res.url]
      ]
      mecha.sendButton(m.chat, '', 'This your want...', global.footer, buttons, m, {
      media: res.url,
      ephemeralExpirantion: m.expiration,
      })*/
      m.reply({
        image: {url},
        caption: 'This your ' + m.command
      })
    }).catch((e) => mecha.sendReact(m.chat, '❌', m.key))
  },
  restrict: true,
  premium: true,
  group: true,
  limit: true
}