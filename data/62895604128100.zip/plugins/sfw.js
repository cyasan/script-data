exports.run = {
usage: ['waifu', 'neko', 'shinobu', 'megumin'],
category: 'anime',
async: async (m, { func, mecha, command }) => {
mecha.sendReact(m.chat, '🕒', m.key)
let no = 1;
if (m.text) {
if (isNaN(m.args[0])) return m.reply('Nomor harus berupa angka!')
if (Number(m.args[0]) < 2) return m.reply('Minimal 2')
if (Number(m.args[0]) > 10) return m.reply('Maximal 10')
if (func.ceklimit(m.sender, parseInt(m.args[0]))) return m.reply(global.mess.limit)
for (let i = 0; i < m.args[0]; i++) {
let res = await func.fetchJson(`https://api.waifu.pics/sfw/${m.command}`)
mecha.sendMedia(m.chat, res.url, m, { ephemeralExpiration: m.expiration })
}
} else {
if (func.ceklimit(m.sender, 1)) return m.reply(global.mess.limit)
await func.fetchJson(`https://api.waifu.pics/sfw/${m.command}`).then(async res => {
/*let buttons = [
['button', 'Next Image', m.cmd]
]
mecha.sendButton(m.chat, '', 'This is your ' + m.command, 'Simple Fitur by KeyaruZNX', buttons, m, {
media: res.url,
expiration: m.expiration 
})*/
m.reply({image:{url:res.url},caption:'This is your want...'})
//mecha.sendMedia(m.chat, res.url, m, { caption: 'This your want...', expiration: m.expiration })
})
}
//mecha.sendReact(m.chat, '✅', m.key)
},
restrict: true,
limit: true
}