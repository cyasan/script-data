exports.run = {
usage: ['jadwal'],
async: async (m, { mecha }) => {

const data = [
  {
    hari: 'Senin',
    status: true,
    piket: '1. Syakila\n2. Amanda\n3. Persana\n4. Xena\n5. Shactya\n6. Salsabila\n7. Aurel\n8. Bimasakti',
    pelajaran: '1. Seni Teater (Jam 1 - 2 )\n' +
      ' 2. Sosiologi (Jam 3 - 5 )\n' +
      '3. Bahasa Indonesia (Jam 6 - 7 )\n' +
      '4. Geografi (Jam 8 - 9 )',
    seragam: 'Seragam Putih - Celana Abu *( LENGKAP )*'
  },
  {
    hari: 'Selasa',
    status: true,
    piket: '1. Tini\n2. Ria\n3. Gamma\n4. Wildan\n5. Cindy\n6. Aditya\n7. Anindya',
    pelajaran: '1. Fisika (Jam 1 - 3 )\n' +
      '2. Biologi (Jam 4 - 6 )\n' +
      '3. PJOK (Jam 7 - 9 )',
    seragam: '1. Seragam Putih - Celana Abu *( LENGKAP JUGA )*\n2. Seragam Olahraga'
  },
  {
    hari: 'Rabu',
    status: true,
    piket: '1. Nabila\n2. Adam\n3. Jasmine\n4. Sipa\n5. Haryo\n6. Fadla\n7. Fatimah',
    pelajaran: '1. Sejarah (Jam 1 - 3 )\n' +
      '2. Kimia (Jam 4 - 6 )\n' +
      '3. Bimbingan Konseling (Jam 7 )\n' +
      '4. Bahasa Inggris (Jam 8 - 10 )',
    seragam: 'Seragam Batik Smanda - Celana Abu *(Jangan lupa DASI)*'
  },
  {
    hari: 'Kamis',
    status: true,
    piket: '1. Khadavi\n2. Keisya\n3. Dera\n4. Nazma\n5. Nonik\n6. Maya\n7. Lutfiah',
    pelajaran: '1. Matematika (Jam 1 - 2 )\n' +
      '2. Bahasa Indonesia (Jam 3 - 4 )\n' +
      '3. Ekonomi (Jam 5 - 7 )\n' +
      '4. Pendidikan Agama dan Budi Pekerti (Jam 8 - 10 )',
    seragam: 'Seragam Pramuka *(Jangan lupa pake KACU)*'
  },
  {
    hari: 'Jumat',
    status: true,
    piket: '1. Dita\n2. Khohar\n3. Risqsya\n4. Raka\n5. Asnal\n6. Aldiar\n7. Zeehan',
    pelajaran: '1. Informatika (Jam 1 - 2 )\n' +
      '2. Matematika (Jam 3 - 4 )\n' +
      '3. Bahasa Sunda (Jam 5 - 6 )\n' +
      '4. Pendidikan Pancasila (Jam 7 - 8 )',
    seragam: 'Seragam Khas Smanda - Celana Pramuka'
  },
  {
      hari: 'Minggu',
      status: false
  },
  {
      hari: 'Sabtu',
      status: false
  }
]
if (!(m.isDevs || m.chat === `120363320801304788@g.us`)) return
let hari = m.args[0] ? m.args[0] === 'senin' ? 'Senin' : m.args[0] === 'selasa' ? 'Selasa' : m.args[0] === 'rabu' ? 'Rabu' :  m.args[0] === 'kamis' ? 'Kamis' :  m.args[0] === 'jumat' ? 'Jumat' : m.args[0] === 'sabtu' ? 'Sabtu' : 'Minggu' : (new Date()).toLocaleDateString("id-ID", { weekday: "long" }); 
let ini = data.find(x => x.hari === hari);
if (!ini.status) return mecha.reply(m.chat, 'Hari Libur, WOOYYYY‼️', m);
let teks = `assalamu'alaikum wr.wb dan selamat malam untuk ${m.metadata.subject}. . . .`;
teks += '\n\n*HAII GUYSSS*👋🏻👋🏻👋🏻';
teks += '\n\n*Hanya ingin mengingatkan untuk agenda ' + hari + '* ‼️‼️';
teks += '\n\n👔 *SERAGAM*:\n' + ini.seragam;
teks += '\n\n📚 *PELAJARAN*:\n' + ini.pelajaran;
teks += '\n\n🧹 *PIKET*:\n' + ini.piket;
await mecha.sendMessage(m.chat, {image: {url: 'https://files.catbox.moe/pttil0.jpg'}, caption: teks, mentions: m.members.map(x => x.id)}, {quoted: null, ephemeralExpirantion: m.expiration})

}}