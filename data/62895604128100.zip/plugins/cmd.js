exports.run = {
  usage: ['cmd'],
  hidden: [],
  use: '',
  category: '',
  async: async (m, {
    mecha
  }) => {
    let text = [
      'exports.run = {',
      "    usage: '',",
      "    use: '',",
      "    category: '',",
      '    async: (m, { mecha, func }) => {',
      '        ',
      '    },',
      '    main: (m, { mecha, func }) => {',
      '        ',
      '    }',
      '}'
    ]
    mecha.reply(m.chat, text.join('\n'), m)
  },
  owner: true
}
