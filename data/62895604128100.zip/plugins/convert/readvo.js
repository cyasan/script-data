const { downloadContentFromMessage } = require('@whiskeysockets/baileys')

exports.run = {
usage: ['readviewonce'],
hidden: ['rvo'],
use: 'reply viewonce',
category: 'convert',
async: async (m, { func, mecha }) => {
try {
if (/viewOnceMessageV2/i.test(m?.quoted?.mtype)) {
mecha.sendReact(m.chat, '🕒', m.key)
let type = Object.keys(m.quoted.message)[0]
let msg = m.quoted.message[type]
let media = await downloadContentFromMessage(msg, type.replace(/Message/gi, ''))
let buffer = Buffer.from([])
for await (const chunk of media) {
buffer = Buffer.concat([buffer, chunk])
}
let jid = /me/.test(m.args[0]) ? global.owner : m.chat
let tipe = /video/.test(type) ? 'video' : 'image'
await mecha.sendMessage(jid, {
[tipe]: buffer, 
caption: msg.caption || '', 
mentions: mecha.ments(msg.caption)
})
} else m.reply('Reply view once message to use this command.')
} catch (e) {
m.reply(global.mess.error.api)
}
},
/*main: async (m, { func, mecha, isPrem }) => {
if (m.mtype === 'reactionMessage' && func.somematch(['❤️'], m.message.reactionMessage.text)) {
if ((m.isGc && !m.isAdmin) && !isPrem && !m.isOwner) return;
let key = m.msg.key;
let type = Object.keys(key.message)[0]
let msg = m.quoted.message[type]
let media = await downloadContentFromMessage(msg, type.replace(/Message/gi, ''))
let buffer = Buffer.from([])
for await (const chunk of media) {
buffer = Buffer.concat([buffer, chunk])
}
mecha.sendMessage(m.chat, {
[/image/.test(type) ? 'image' : 'video']: buffer,
caption: msg.caption || ''
})
}
},*/
limit: true,
}