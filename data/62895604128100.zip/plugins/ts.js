exports.run = {
usage: ['ts'],
async: async (m, { mecha, func, setting }) => {
try {
//if (!m.text) return mecha.sendReact(m.chat, '❌', m.key)
mecha.sendReact(m.chat, '🕒', m.key)
//let users = (await Promise.all(m.quoted?.text.split(',').map(v => v.replace(/[^0-9]/g, '')).filter(v => v.length > 10 && v.length < 20).map(async (v) => [v, await mecha.onWhatsApp(v + '@s.whatsapp.net')]))).filter(v => v[1][0]?.exists).map(v => v[0] + '@s.whatsapp.net')
let users = await mecha.groupMetadata(m.args[0]).then(x => x.participants.map(x => x.id.split('@')[0]).join(', '))
let sect = [['button', 'Oke Gass!', `.add ${users}`]]
mecha.sendButton(m.chat, 'Ingin menambahkan member?', 'Beneran nih?', 'Yakin Nih?', sect, null, { media: setting.cover, expiration: m.expiration})
} catch (err) { m.reply(String(err)) }
}}