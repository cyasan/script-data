let phoneNumber=require("awesome-phonenumber"),fs=require("fs"),fetch=require("node-fetch");exports.run={usage:["register"],hidden:["daftar"],category:"user",async:async(a,{mecha:r,users:n})=>{if(r.registered=r.registered||{},n.register)return a.reply("Nomor kamu sudah terverifikasi.");if(void 0!==r.registered[a.sender])return a.reply("Selesaikan register mu yang sebelumnya!");r.sendReact(a.chat,"🕒",a.key);try{var i=(await fetch("https://raw.githubusercontent.com/Jabalsurya2105/database/master/data/captcha.json").then(e=>e.json())).random();let e=(await r.sendMessage(a.chat,{image:{url:i.image},caption:"Silahkan ketik kode OTP yang ada pada gambar untuk membuktikan bahwa Anda adalah manusia."},{quoted:a,ephemeralExpiration:a.expiration})).key;r.registered[a.sender]={id:a.sender,key:e,sesi:"captcha",otp:i.value,name:"-",age:"-",gender:"-",timeout:setTimeout(()=>{r.sendMessage(a.chat,{delete:e}),delete r.registered[a.sender]},6e4)}}catch(e){n=r.registered[a.sender];n.timeout&&clearTimeout(n.timeout),delete r.registered[a.sender],r.reply(a.chat,`Something when wrong: ${e.message}
please try again.`,a,{expiration:a.expiration})}},main:async(a,{func:e,mecha:r,users:n,calender:i})=>{if(r.registered=r.registered||{},n&&!n.register&&void 0!==r.registered[a.sender]&&!a.fromMe){var t=r.registered[a.sender];if("captcha"===t.sesi)return!a.budy||a.isPrefix?a.reply("Mohon masukkan kode OTP yang benar."):void(a.budy==t.otp?(await r.reply(a.chat,`Silahkan ketik nama kamu
Contoh: Yin`,a,{expiration:a.expiration}),t.sesi="name"):(r.reply(a.chat,`❌ OTP Salah!
@${a.sender.split("@")[0]} tidak di verifikasi!`,a,{expiration:a.expiration}),t.timeout&&clearTimeout(t.timeout),r.sendMessage(a.chat,{delete:t.key}),delete r.registered[t.id]));if("name"===t.sesi)return a.budy?a.isPrefix?a.reply(`Nama tidak boleh menggunakan awalan ( ${a.prefix} )`):(t.name=e.toFirstCase(a.budy),t.sesi="age",void await r.reply(a.chat,`Silahkan ketik umur kamu
Contoh: 19`,a,{expiration:a.expiration})):a.reply("Mohon masukkan keyword yang benar.");if("age"===t.sesi)return!a.budy||a.isPrefix?a.reply("Mohon masukkan keyword yang benar."):isNaN(a.budy)?a.reply(`Umur harus berupa angka!
Contoh: 19`):60<Number(a.budy)?(global.db.users[t.id].banned=!0,global.db.users[t.id].expired.banned="PERMANENT",delete r.registered[t.id],a.reply("Maaf umur Anda terlalu tua untuk bisa menggunakan bot ini.\nSystem bot kami telah memblokir akun anda dengan alasan *old age.*\n\nJika ingin membuka banned akan dikenakan biaya sebesar Rp. 5.000.")):Number(a.budy)<6?a.reply("Bayi bisa ngetik sesuai format bjir ._."):Number(a.budy)<12?(global.db.users[t.id].banned=!0,global.db.users[t.id].expired.banned="PERMANENT",delete r.registered[t.id],a.reply("Anda belum cukup umur untuk bisa menggunakan bot ini.\nSystem bot kami telah memblokir akun anda dengan alasan *child age.*\n\nJika ingin membuka banned akan dikenakan biaya sebesar Rp. 5.000.")):(t.age=Number(parseInt(a.budy)),t.sesi="gender",void await r.reply(a.chat,`Silahkan ketik jenis kelamin kamu
Contoh: male

_ketik *male* untuk Laki-laki_
_ketik *female* untuk Perempuan_`,a,{expiration:a.expiration}));if("gender"===t.sesi){if(!a.budy)return a.reply("Mohon masukkan keyword yang benar.");if(a.isPrefix)return a.reply("Mohon masukkan keyword yang benar.");if(/^male$/i.test(a.budy))t.gender="Laki-laki";else{if(!/^female$/i.test(a.budy))return a.reply(`Mohon masukkan keyword yang benar!
ketik *male* untuk Laki-laki
ketik *female* untuk Perempuan`);t.gender="Perempuan"}var{name:t,age:s,gender:d}=t,n=(n.name=t,n.age=s,n.gender=d,n.register=!0,phoneNumber("+"+a.sender.replace("@s.whatsapp.net","")).getNumber("international")),i=`*✅ VERIFICATION SUCCESSFULLY*

» Name : ${t}
» Age : ${s}
» Gender : ${d}
» Number : ${n}
» Date : ${i}

- kirim *${a.prefix}unreg* jika data yang anda masukkan salah.`,t=`Users Registered

Name : ${t}
Age : ${s}
Gender : ${d}
Number : `+n;await r.reply(a.chat,i,e.fverified,{expiration:a.expiration}).then(e=>delete r.registered[a.sender]),a.sender!==global.owner&&await r.sendMessage(global.owner,{document:fs.readFileSync("./database/database.json"),caption:t,mimetype:"application/json",fileName:"database.json"},{quoted:e.fverified,ephemeralExpiration:0})}}},private:!1,location:"plugins/user/register.js"};