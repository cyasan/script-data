const cron = require('node-cron');
const fs = require('fs');
const func = require('./functions.js');
let statuses = true;
let alreadyRan = false;

module.exports = async (mecha) => {
/* Automatically Feature By SuryaDev */
const groups = Object.values(global.db.groups).filter(v => v.automatically).map(x => x.jid);
const bot = mecha.user.id ? mecha.user.id.split(':')[0] + '@s.whatsapp.net' : mecha.user.jid;
const setting = global.db.setting[bot];

const isBotAdmin = (member) => {
const admins = member.filter((v) => v.admin !== null)
return !!admins.find((item) => item.id === bot)
}

cron.schedule('0 0 0 * * *', async () => {
if (!alreadyRan) {
alreadyRan = true;
Object.entries(global.db.statistic).map(([_, data]) => data.hittoday = 0);
Object.values(global.db.users).filter((v) => v.limit < setting.limit.free && !v.premium).map((x) => x.limit = setting.limit.free);
setting.lastreset = Date.now();
let data = await func.backupSC();
let caption = `Berikut adalah file backup kode bot:\nNama file: ${data.name}\nUkuran file: ${data.size} MB`
await mecha.sendMessage(global.developer[0], {
document: {
url: data.name
},
caption: caption,
mimetype: 'application/zip', 
fileName: data.name
}, {quoted: func.fstatus('Auto Backup Script'), ephemeralExpiration: 0})
.then(_ => fs.unlinkSync(data.name));
}
}, { scheduled: true, timezone: 'Asia/Jakarta' });

const scheduleTask = (cronTime, startingTask, announce) => {
cron.schedule(cronTime, async () => {
if (statuses === true) {
statuses = false
let getGroups = await mecha.groupFetchAllParticipating();
let listGroups = Object.values(getGroups);
for (let x of listGroups) {
if (groups.includes(x.id) && x.announce === announce && isBotAdmin(x.participants)) {
await startingTask(x);
await new Promise(resolve => setTimeout(resolve, 3000));
}
}
setTimeout(() => (statuses = true), 1000 * 60 * 3);
}
}, { scheduled: true, timezone: 'Asia/Jakarta' });
};

scheduleTask('0 0 0 * * *', async (data) => {
// let text = 'Sistem secara otomatis menutup grup ini karena waktu tidur.';
let text = 'System automatically closing this group because sleeping time.';
await mecha.groupSettingUpdate(data.id, 'announcement')
.then((_) => mecha.sendMessage(data.id, {text: text}, {quoted: func.fstatus('System Notification'), ephemeralExpiration: 86400}));
}, false);

scheduleTask('0 45 17 * * *', async (data) => {
// let text = 'Sistem secara otomatis menutup grup ini karena waktu maghrib dan akan dibuka 20 menit dimulai dari sekarang.';
let text = 'System automatically closing this group because maghrib time and will be open 20 minutes from now.';
await mecha.groupSettingUpdate(data.id, 'announcement')
.then((_) => mecha.sendMessage(data.id, {text: text}, {quoted: func.fstatus('System Notification'), ephemeralExpiration: 86400}));
}, false);

scheduleTask('0 5 18 * * *', async (data) => {
// let text = 'Sistem otomatis membuka grup ini karena waktu maghrib telah usai.';
let text = 'System automatically opening this group because maghrib time is over.';
await mecha.groupSettingUpdate(data.id, 'not_announcement')
.then((_) => mecha.sendMessage(data.id, {text: text}, {quoted: func.fstatus('System Notification'), ephemeralExpiration: 86400}));
}, true);

scheduleTask('0 30 23 * * *', async (data) => {
// let text = 'Sistem akan secara otomatis menutup grup ini dalam waktu 30 menit dimulai dari sekarang.';
let text = 'System will automatically close this group within 30 minutes starting from now.';
await mecha.sendMessage(data.id, {text: text}, {quoted: func.fstatus('System Notification'), ephemeralExpiration: 86400});
}, false);

scheduleTask('0 0 5 * * *', async (data) => {
// let text = 'Sistem secara otomatis membuka grup ini karena pagi hari.';
let text = 'System automatically opening this group because morning time.';
await mecha.groupSettingUpdate(data.id, 'not_announcement')
.then((_) => mecha.sendMessage(data.id, {text: text}, {quoted: func.fstatus('System Notification'), ephemeralExpiration: 86400}));
}, true);

const checkExpiredUsers = () => {
let now = Date.now();
for (let [id, user] of Object.entries(global.db.users)) {
if (!user.banned && user.expired.user && now >= user.expired.user) {
console.log('Expired User:', user.name);
delete global.db.users[id];
}
}
};

const checkExpiredGroups = () => {
let now = Date.now();
for (let [id, group] of Object.entries(global.db.groups)) {
if (group.expired && now >= group.expired) {
console.log('Expired Group:', group.name);
delete global.db.groups[id];
}
}
};

const checkExpiredPremium = async () => {
let now = Date.now();
for (let [id, user] of Object.entries(global.db.users)) {
if (user.premium && user.expired.premium && now >= user.expired.premium) {
await mecha.sendMessage(id, {text: `Your premium package has expired, thank you for buying and using our service`}, {quoted: func.fstatus('System Notification'), ephemeralExpiration: 86400});
user.expired.premium = 0;
user.premium = false;
user.limit = setting.limit.free;
}
}
};

const checkExpiredJadibot = async () => {
let now = Date.now();
for (let [number, user] of Object.entries(global.db.users)) {
if (user.jadibot && user.expired.jadibot && now >= user.expired.jadibot) {
await mecha.sendMessage(number, {text: `Your jadibot package has expired, thank you for buying and using our service`}, {quoted: func.fstatus('System Notification'), ephemeralExpiration: 86400});
user.expired.jadibot = 0;
user.jadibot = false;
const client = global.jadibot[number] ? global.jadibot[number] : Object.values(global.jadibot).find(v => v.user.id.split(':')[0] == number.replace(/[^0-9]/g, ''))
let settings = global.db.jadibot.find(v => v.number === number)
if (settings && typeof client !== 'undefined') {
delete global.jadibot[number];
settings.status = false;
await client.end();
client.ws.close();
}
}
}
};

const checkExpiredBanned = async () => {
let now = Date.now();
for (let [id, user] of Object.entries(global.db.users)) {
if (user.banned && user.expired.banned && now >= user.expired.banned) {
await mecha.sendMessage(id, {text: `Banned berakhir, Jangan melanggar rules agar tidak dibanned lagi.`}, {quoted: func.fstatus('System Notification'), ephemeralExpiration: 86400});
user.expired.banned = 0;
user.banned = false;
}
}
};

const checkExpiredSewa = async () => {
let now = Date.now();
for (let [id, group] of Object.entries(global.db.groups)) {
try {
if (group.sewa && group.sewa.status && group.sewa.expired && group.sewa.expired != 0 && now >= group.sewa.expired) {
const getGroups = await mecha.groupFetchAllParticipating();
const listGroups = Object.values(getGroups).map(item => item.id);
if (listGroups.includes(id)) {
await mecha.sendMessage(id, {text: 'Bot time has expired and will leave from this group, thank you.', mentions: group.member.map(v => v.jid) }, {
quoted: func.fstatus('System Notification'),
ephemeralExpiration: 86400
}).then(() => mecha.groupLeave(id));
};
group.sewa.expired = 0;
group.sewa.status = false;
console.log('Expired Sewa:', group.name);
await new Promise(resolve => setTimeout(resolve, 3000));
}
} catch (error) {
console.log(error)
group.sewa.status = false;
delete global.db.groups[id];
}
}
}

// Schedule checks
setInterval(checkExpiredUsers, 5000);
setInterval(checkExpiredGroups, 5000);
setInterval(checkExpiredPremium, 5000);
setInterval(checkExpiredJadibot, 5000);
setInterval(checkExpiredBanned, 5000);
setInterval(checkExpiredSewa, 30000);

}

func.reloadFile(__filename)