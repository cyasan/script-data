let msg = false
module.exports = async (mecha) => {
  let setting = global.db.oldNime;
  //let int
  //if (!int) {
    int = setInterval(async () => {
    //delete int
    try {
      // Mengambil daftar anime terbaru
      let result = await Scraper.list().kuronime.latest();

      // Mengecek apakah ada anime baru
      if (result && result[0] && (!setting?.title || setting?.title !== result[0].title)) {
        console.log(`[ ! ] Anime Baru Terdeteksi: ${result[0].title}`);

        let mentions = await mecha.groupMetadata(global.announ)
                       .then(x=>x.participants.map(x=>x.id))
        let caption = `[ ♡ ] Anime Baru Telah Diupdate!\n\n` +
          Object.entries(result[0])
            .map(([key, value]) => `> *• ${key.capitalize()}:* ${value || 'Tidak tersedia'}`)
            .join("\n") +
          `\n\n[ ! ] Pesan ini dikirim oleh GPT Bot!`;

        if (!msg) await mecha.combo({image:{url:result[0].thumbnail},caption},{chat:announ}).then(()=>{
          msg = true
          global.db.oldNime = result[0];
        })

        // Menyimpan data anime terbaru
        //global.db.oldNime = result[0];
        console.log("[ + ] Pesan pembaruan anime berhasil dikirim!");
      } else {
        //console.log("[ = ] Tidak ada anime baru yang terdeteksi.");
        return;
      }
    } catch (err) {
      console.error("[ - ] Terjadi kesalahan saat memeriksa pembaruan anime:", err);
    }
  }, 60 * 1000)
  //} else return // Memeriksa pembaruan setiap 60 detik
};