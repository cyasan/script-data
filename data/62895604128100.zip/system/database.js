const func = require('./functions.js');
const toMs = require('ms');
const {
    jidNormalizedUser
} = require('@whiskeysockets/baileys');
const processedMessages = new Set();

module.exports = (mecha, chat) => {
    try {
        if (processedMessages.has(chat.key.id)) return false;
        processedMessages.add(chat.key.id);
        if (chat.key && chat.key.remoteJid === 'status@broadcast') return;
        const chatId = chat.key.remoteJid;
        const botId = jidNormalizedUser(mecha.user.id);
        const userId = chat.key.fromMe ? botId : (chat.key.participant || chat.key.remoteJid);
        const pushname = chat.pushName || '-';
        const expiration = 86400;
        const expired = Date.now() + toMs('7d');
        const welcomeText = 'Hello, +user Thank you for joining the group +group\n\nPlease intro first :\nName :\nAge :\nHome town :';
        const goodbyeText = 'Goodbye +user';
        const calendar = new Date().toLocaleDateString('id', {
            day: 'numeric',
            month: 'long',
            year: 'numeric'
        });

        const badwordList = [
            'ajg', 'anjink', 'anjg', 'anjk', 'anjim', 'anjing', 'anjrot', 'anying', 'asw', 'autis',
            'babi', 'bacod', 'bacot', 'bagong', 'bajingan', 'bangsad', 'bangsat', 'bastard', 'bego',
            'bgsd', 'biadab', 'biadap', 'bitch', 'bngst', 'bodoh', 'bokep', 'cocote', 'coli', 'colmek',
            'comli', 'dajjal', 'dancok', 'dongo', 'fuck', 'goblog', 'goblok', 'guoblog', 'guoblok',
            'henceut', 'idiot', 'jancok', 'jembut', 'jingan', 'kafir', 'kanjut', 'keparat', 'kntl',
            'kontol', 'lonte', 'meki', 'memek', 'ngentod', 'ngentot', 'ngewe', 'ngocok', 'ngtd',
            'njeng', 'njing', 'njinx', 'pantek', 'pantek', 'peler', 'pepek', 'pler', 'pucek', 'puki',
            'pukimak', 'setan', 'silit', 'telaso', 'tempek', 'tete', 'titit', 'toket', 'tolol',
            'tomlol', 'asu', 'asw', '4su', 'asww', 'kntol', 'mmk', 'mmek', 'memk'
        ];

        const models = {
            users: Object.freeze({
                jid: userId,
                name: pushname,
                date: calendar,
                register: false,
                gender: '',
                age: 0,
                limit: 15,
                balance: 10000,
                afk: 0,
                alasan: '',
                afkObj: null,
                premium: false,
                jadibot: false,
                banned: false,
                warning: 0,
                pasangan: {
                    id: '',
                    time: 0
                },
                expired: {
                    user: expired,
                    premium: 0,
                    jadibot: 0,
                    banned: 0
                },
                game: {
                    tictactoe: 0,
                    suit: 0,
                    petakbom: 0,
                    tebaklagu: 0,
                    tebakheroml: 0,
                    tebaklogo: 0,
                    tebakgambar: 0,
                    tebakkalimat: 0,
                    tebakkata: 0,
                    tebaklirik: 0,
                    tebakkimia: 0,
                    tebakbendera: 0,
                    tebakanime: 0,
                    kuis: 0,
                    siapakahaku: 0,
                    asahotak: 0,
                    susunkata: 0,
                    caklontong: 0,
                    family100: 0,
                    math: 0,
                    casino: 0
                },
                lastunreg: 0,
                exp: 0,
                level: 0,
                role: 'Gak kenal',
            }),
            groups: Object.freeze({
                jid: chatId,
                name: '-',
                tekswelcome: welcomeText,
                teksleft: goodbyeText,
                welcome: true,
                left: false,
                detect: false,
                mute: false,
                antitoxic: false,
                antilink: true,
                antivirtex: true,
                antibot: false,
                antiviewonce: false,
                antihidetag: false,
                antidelete: false,
                antiedited: false,
                expired: expired,
                sewa: {
                    status: false,
                    expired: 0
                },
                absen: {},
                list: [],
                blacklist: [],
                member: [],
            }),
            settings: Object.freeze({
                typefile: 'document',
                prefix: '.',
                multiprefix: false,
                online: true,
                verify: true,
                self: false,
                maintenance: false,
                gconly: false,
                autosticker: false,
                autoread: true,
                autoblockcmd: false,
                autoclearsession: false,
                anticall: true,
                antispam: true,
                fakereply: false,
                autolevelup: true,
                owner: [],
                packname: 'ᴄʀᴇᴀᴛᴇ ʙʏ ᴍᴇᴄʜᴀ ʙᴏᴛ\n\nᴄʀᴇᴀᴛᴇᴅ ᴀᴛ :\n+date\n+time\n\nsewa bot? pm:\n+62 895-4154-97664',
                author: '',
                cover: 'https://files.catbox.moe/z4t545.png',
                link: 'https://whatsapp.com/channel/0029VaU3j0z2ER6liR0MY601',
                style: 1,
                timer: 1800000,
                gamewaktu: 60,
                hadiah: {
                    min: 1000,
                    max: 3000
                },
                limit: {
                    premium: 99999,
                    free: 15,
                    price: 1000
                },
                max_upload: {
                    premium: 100,
                    free: 10
                },
                lastreset: Date.now(),
                max_toxic: 15,
                toxic: badwordList,
                blockcmd: [],
            })
        };

        // Database User
        if (userId.endsWith('@s.whatsapp.net')) {
            let user = global.db.users[userId];
            if (user) {
                execute(user, models.users, user.register ? {
                    money: 0,
                    atm: 0,
                    health: 10,
                    potion: 0,
                    trash: 0,
                    wood: 0,
                    rock: 0,
                    string: 0,
                    iron: 0,
                    sand: 0,
                    botol: 0,
                    kaleng: 0,
                    kardus: 0,
                    aqua: 0,
                    emerald: 0,
                    diamond: 0,
                    gold: 0,
                    steel: 0,
                    kargo: 0,
                    kapal: 0,
                    common: 0,
                    commoncount: 0,
                    uncommon: 0,
                    uncommoncount: 0,
                    mythic: 0,
                    mythiccount: 0,
                    legendary: 0,
                    legendarycount: 0,
                    pet: 0,
                    petcount: 0,
                    petfood: 0,
                    horse: 0,
                    horseexp: 0,
                    cat: 0,
                    catexp: 0,
                    fox: 0,
                    foxexp: 0,
                    dog: 0,
                    dogexp: 0,
                    wolf: 0,
                    wolfexp: 0,
                    centaur: 0,
                    centaurexp: 0,
                    phoenix: 0,
                    phoenixexp: 0,
                    dragon: 0,
                    dragonexp: 0,
                    horselvl: 0,
                    catlvl: 0,
                    foxlvl: 0,
                    doglvl: 0,
                    wolflvl: 0,
                    centaurlvl: 0,
                    phoenixlvl: 0,
                    dragonlvl: 0,
                    horsehealth: 0,
                    cathealth: 0,
                    foxhealth: 0,
                    doghealth: 0,
                    wolfhealth: 0,
                    centaurhealth: 0,
                    phoenixhealth: 0,
                    dragonhealth: 0,
                    horselastfeed: 0,
                    catlastfeed: 0,
                    foxlastfeed: 0,
                    doglastfeed: 0,
                    wolflastfeed: 0,
                    centaurlastfeed: 0,
                    phoenixlastfeed: 0,
                    dragonlastfeed: 0,
                    lastadu: 0,
                    armor: 0,
                    armordurability: 0,
                    sword: 0,
                    sworddurability: 0,
                    pickaxe: 0,
                    pickaxedurability: 0,
                    fishingrod: 0,
                    fishingroddurability: 0,
                    bow: 0,
                    bowdurability: 0,
                    lastclaim: 0,
                    lastadventure: 0,
                    lastfishing: 0,
                    lastmining: 0,
                    lasthunt: 0,
                    lastweekly: 0,
                    lastmonthly: 0,
                    lastbansos: 0,
                    lastdagang: 0,
                    lastberkebon: 0,
                    lastmasak: 0,
                    lastrampok: 0,
                    lastbunuh: 0,
                    lastnebang: 0,
                    lastmulung: 0,
                    masakcount: 0,
                    craftcount: 0,
                    adventurecount: 0,
                    mancingcount: 0,
                    bibitmangga: 0,
                    bibitapel: 0,
                    bibitpisang: 0,
                    bibitjeruk: 0,
                    bibitanggur: 0,
                    mangga: 0,
                    apel: 0,
                    pisang: 0,
                    jeruk: 0,
                    anggur: 0,
                    banteng: 0,
                    harimau: 0,
                    gajah: 0,
                    kambing: 0,
                    panda: 0,
                    buaya: 0,
                    kerbau: 0,
                    sapi: 0,
                    monyet: 0,
                    babihutan: 0,
                    babi: 0,
                    ayam: 0,
                    orca: 0,
                    paus: 0,
                    lumba: 0,
                    hiu: 0,
                    ikan: 0,
                    lele: 0,
                    bawal: 0,
                    nila: 0,
                    kepiting: 0,
                    lobster: 0,
                    gurita: 0,
                    cumi: 0,
                    udang: 0,
                    masak: 0,
                    masakrole: 0,
                    masakexp: 0,
                    masaklevel: 0,
                    bawang: 0,
                    cabai: 0,
                    kemiri: 0,
                    jahe: 0,
                    saus: 0,
                    asam: 0,
                    steak: 0,
                    sate: 0,
                    rendang: 0,
                    kornet: 0,
                    nugget: 0,
                    bluefin: 0,
                    seafood: 0,
                    sushi: 0,
                    moluska: 0,
                    squidprawm: 0,
                    rumahsakit: 0,
                    restoran: 0,
                    pabrik: 0,
                    tambang: 0,
                    pelabuhan: 0,
                    rumahsakitname: '',
                    restoranname: '',
                    pabrikname: '',
                    tambangname: '',
                    pelabuhanname: '',
                    rumahsakitexp: 0,
                    restoranexp: 0,
                    pabrikexp: 0,
                    tambangexp: 0,
                    pelabuhanexp: 0,
                    rumahsakitlvl: 0,
                    restoranlvl: 0,
                    pabriklvl: 0,
                    tambanglvl: 0,
                    pelabuhanlvl: 0,
                } : {});
            } else {
                global.db.users[userId] = {
                    jid: userId,
                    name: pushname,
                    date: calendar,
                    register: false,
                    ...(models?.users || {})
                }
            }
        }

        // Database Group
        if (chatId.endsWith('@g.us')) {
            let group = global.db.groups[chatId];
            if (group) {
                execute(group, models.groups);
            } else {
                global.db.groups[chatId] = {
                    jid: chatId,
                    name: '-',
                    tekswelcome: welcomeText,
                    teksleft: goodbyeText,
                    ...(models?.groups || {})
                }
            }
        }

        // Database Setting
        let setting = global.db.setting[botId];
        if (setting) {
            execute(setting, models.settings);
        } else {
            global.db.setting[botId] = {
                ...(models?.settings || {})
            }
        }

    } catch (e) {
        console.error(e);
    }
}

function execute(prefix, template = {}, custom = {}) {
    const isNumber = x => typeof x === 'number' && !isNaN(x);
    Object.keys(template).forEach(key => {
        const defaultValue = template[key];
        const type = typeof defaultValue;

        if (!(key in prefix) || (type === 'number' && !isNumber(prefix[key]))) {
            prefix[key] = template[key];
        }
    });

    Object.keys(custom).forEach(key => {
        const defaultValue = custom[key];
        const type = typeof defaultValue;

        if (!(key in prefix) || (type === 'number' && !isNumber(prefix[key]))) {
            prefix[key] = custom[key];
        }
    });
}

func.reloadFile(__filename);