exports.run = {

    usage: ['idgc', 'listgc2'],

    use: 'group',

    category: 'group',
premium: true,
owner: true,
admin: true,
    async: async (m, { func, mecha, quoted }) => {
        let set = global.db.groups[m.chat];

        let meta = await mecha.groupMetadata(m.chat);

        let admin = meta.participants.filter(v => v.admin);

        let pic = await func.fetchBuffer(await mecha.profilePictureUrl(m.chat, 'image').catch(_ => 'https://telegra.ph/file/320b066dc81928b782c7b.png'));

        switch (m.command) {

            case 'listgc2':

    let gcall = Object.values(await mecha.groupFetchAllParticipating().catch(_ => null));

    let listgc = `*｢ LIST ALL CHAT GRUP ｣*\n\n`;

    if (gcall.length === 0) {

        listgc += "Tidak ada grup yang ditemukan.";

    } else {

        gcall.forEach((meta) => {

            listgc += `*• Nama :* ${meta.subject}\n*• ID :* ${meta.id}\n*• Total Member :* ${meta.participants.length} Member\n*• Status Grup :* ${meta.announce ? "Tertutup" : "Terbuka"}\n*• Pembuat :* ${meta.owner ? '@' + meta.owner.split('@')[0] : 'Tidak diketahui'}\n\n`;

        });

    }

    await m.reply(listgc);

    break; // Tambahkan break untuk menghindari fall-through

            case 'idgc':

                // Mengakses data grup dari global.db.groups

                let metaid = m.chat; // ID grup saat ini

                let set = global.db.groups[m.chat] || {}; // Ambil data grup atau objek kosong jika tidak ada

                // Mengambil metadata grup

                let meta = await mecha.groupMetadata(m.chat);

                // Membuat pesan untuk dikirim

                let response = `*ID Grup:* ${meta.id}\n*Nama Grup:* ${meta.subject}\n*Total Anggota:* ${meta.participants.length} Anggota\n*Status Grup:* ${meta.announce ? "Tertutup" : "Terbuka"}\n*Pembuat:* ${meta.owner ? '@' + meta.owner.split('@')[0] : 'Tidak Diketahui'}`;

                // Mengirimkan pesan

                await m.reply(response);

                break; // Tambahkan break untuk menghindari fall-through

            // Tambahkan case lain jika diperlukan

        } // Penutupan switch

    } // Penutupan async function

}; // Penutupan exports.run