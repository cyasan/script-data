exports.run = {
main: async (m, { func, mecha, groups, errorMessage }) => {
try {

// Cek apakah fitur antilink diaktifkan

if (m.budy && groups.antilink && !m.isAdmin && !m.isOwner) {

// Menghapus pesan yang berisi tautan ke channel WhatsApp

if (m.budy.match(/(whatsapp.com\/channel)/gi)) {
return mecha.sendMessage(m.chat, {
delete: {
remoteJid: m.chat,
fromMe: false,
id: m.key.id,
participant: m.sender
}
});
}

// Menghapus pesan yang berisi tautan grup WhatsApp

if (m.budy.match(/(chat.whatsapp.com)/gi) && !m.budy.includes(await mecha.groupInviteCode(m.chat))) {
await mecha.sendMessage(m.chat, {
delete: {
remoteJid: m.chat,
fromMe: false,
id: m.key.id,
participant: m.sender
}
});
await mecha.sendMessage(m.chat, {
text: `*Anti-Link Detected* Sorry @${m.sender.split('@')[0]}, Your Message Will be Deleted From This Group.`,
mentions: [m.sender]
}, { quoted: func.fstatus('Anti-Link Group'), ephemeralExpiration: m.expiration });
await mecha.groupParticipantsUpdate(m.chat, [m.sender], 'delete');
}
}

// Cek apakah fitur antiwame diaktifkan

if (m.budy && groups.antiwame && !m.isAdmin && !m.isOwner) {

// Menghapus pesan yang berisi kata "wame"

if (m.budy.match(/(wa.me)/gi)) {
await mecha.sendMessage(m.chat, {
delete: {
remoteJid: m.chat,
fromMe: false,
id: m.key.id,
participant: m.sender
}
});
await mecha.sendMessage(m.chat, {
text: `*Anti-Wame Detected* Sorry @${m.sender.split('@')[0]}, Your Message Will be Deleted From This Group.`,
mentions: [m.sender]
}, { quoted: func.fstatus('Anti-Wame Group'), ephemeralExpiration: m.expiration });
await mecha.groupParticipantsUpdate(m.chat, [m.sender], 'delete');
}
}

// Cek apakah fitur antitagsw diaktifkan

if (m.budy && groups.antitagsw && !m.isAdmin && !m.isOwner) {

// Menghapus pesan yang menggunakan snap mention
                
if (m.budy.match(/@ Grup ini disebut\./)) {  
await mecha.sendMessage(m.chat, {
delete: {
remoteJid: m.chat,
fromMe: false,
id: m.key.id,
participant: m.sender
}
});
await mecha.sendMessage(m.chat, {
text: `*Anti-Mention Detected* Sorry @${m.sender.split('@')[0]}, Your Message Will be Deleted From This Group.`,
mentions: [m.sender]
}, { quoted: func.fstatus('Anti-Mention Group'), ephemeralExpiration: m.expiration });
await mecha.groupParticipantsUpdate(m.chat, [m.sender], 'delete');
}
}

// Jika fitur antilink dimatikan, hanya menghapus tautan

if (m.budy && !groups.antilink && !m.isAdmin && !m.isOwner) {
if (m.budy.match(/(chat.whatsapp.com)/gi) && !m.budy.includes(await mecha.groupInviteCode(m.chat))) {
return mecha.sendMessage(m.chat, {
delete: {
remoteJid: m.chat,
fromMe: false,
id: m.key.id,
participant: m.sender
}
});
}
}

// Jika fitur antiwame dimatikan, hanya menghapus pesan yang berisi "wame"
            
if (m.budy && !groups.antiwame && !m.isAdmin && !m.isOwner) {
if (m.budy.match(/(wa.me)/gi)) {
return mecha.sendMessage(m.chat, {
delete: {
remoteJid: m.chat,
fromMe: false,
id: m.key.id,
participant: m.sender
}
});
}
}
} catch (e) {
console.log(e);
return errorMessage(e);
}
},
group: true,
botAdmin: true
};   