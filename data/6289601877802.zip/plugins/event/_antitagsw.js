exports.run = {   
main: async (m, { func, mecha, groups, errorMessage }) => {
try {

// Cek apakah fitur antitagsw diaktifkan
if (m.budy && groups.antitagsw2 && !m.isAdmin && !m.isOwner) {

// Menghapus pesan yang menggunakan snap mention
if (m.budy.match(/@.+/)) {  
await mecha.sendMessage(m.chat, {
delete: {
remoteJid: m.chat,
fromMe: false,
id: m.key.id,
participant: m.sender
}
});
    
await mecha.sendMessage(m.chat, {
text: `*Anti-Mention Detected* Sorry @${m.sender.split('@')[0]}, Your Message Will be Deleted From This Group.`,
mentions: [m.sender]
}, { quoted: func.fstatus('Anti-Mention Group'), ephemeralExpiration: m.expiration });
await mecha.groupParticipantsUpdate(m.chat, [m.sender], 'delete');
}
}
} catch (e) {
console.log(e);
return errorMessage(e);
}
},
group: true,
botAdmin: true
};   