exports.run = {
usage: ['donate'],
hidden: ['donasi'],
category: 'special',
async: async (m, { mecha, fpayment }) => {
let caption = `Halo ${m.pushname}👋🏻

_Kamu bisa membayar sesuatu/mendukung kami agar bot ini tetap aktif dengan donasi kalian!_

⭝ Dana : 089514015323 
⭝ Gopay : 089624522567
⭝ Bank Jago : 108784352600
⭝ Seabank : 901701867632

_Hasil donasi akan digunakan untuk membeli sesuatu seperti *Barang Dagangan atau Untuk Kepentingan Server Bot* agar bot dapat aktif 24 jam tanpa kendala. Berapapun donasi kamu akan sangat berarti, Terimakasih!_`
mecha.sendMessage(m.chat, {
image: {
url: global.qrisUrl
}, 
caption: caption
}, {quoted: m, ephemeralExpiration: m.expiration});
}
}