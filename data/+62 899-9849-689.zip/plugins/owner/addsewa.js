const toMs = require('ms')
const {
    getBinaryNodeChild
} = require('@whiskeysockets/baileys');

exports.run = {
    usage: ['addsewa'],
    use: 'link group + waktu',
    category: 'owner',
    async: async (m, {
        func,
        mecha,
        errorMessage
    }) => {
        if (m.isPc) {
            let [url, time] = m.args;
            if (!(url && time)) return m.reply(func.example(m.cmd, 'https://chat.whatsapp.com/codeInvite 15d'))
            try {
                let link = /chat.whatsapp.com\/([0-9A-Za-z]{20,24})/i
                let [_, code] = url.match(link) || []
                if (!code) return m.reply('No invite url detected.');
                let response = await mecha.query({
                    tag: 'iq',
                    attrs: {
                        type: 'get',
                        xmlns: 'w:g2',
                        to: '@g.us'
                    },
                    content: [{
                        tag: 'invite',
                        attrs: {
                            code: code
                        }
                    }]
                })
                let group = getBinaryNodeChild(response, 'group');
                let groupId = group?.attrs?.id.includes('@') ? group?.attrs?.id : group?.attrs?.id + '@g.us';
                let groupData = global.db.groups[groupId];
                if (!groupData) {
                    global.db.groups[groupId] = {
                        jid: groupId,
                        sewa: {
                            status: false,
                            notice: false,
                            expired: 0
                        }
                    }
                } else {
                    if (!groupData.hasOwnProperty('jid')) groupData.jid = groupId;
                    if (!groupData.hasOwnProperty('sewa')) groupData.sewa = {
                        status: false,
                        notice: false,
                        expired: 0
                    }
                }
                if (groupData.sewa.hasOwnProperty('status') && groupData.sewa.status) return m.reply('Grup tersebut sudah ada di list sewa!')
                groupData.sewa.expired = time ? Date.now() + toMs(time) : Date.now() + 2592000000;
                groupData.sewa.status = true;
                groupData.sewa.notice = true;
                m.reply(`Successfully added rent to this group for ${time}`)
            } catch (error) {
                let err = String(error)
                if (err.includes('not-authorized')) return m.reply('Masukkan bot kedalam grup tersebut terlebih dahulu.')
                return errorMessage(error)
            }
        } else if (m.isGc) {
            if (!m.text) return m.reply(`Masukkan durasi sewa!\nContoh: ${m.cmd} 15d`)
            let groupData = global.db.groups[m.chat];
            if (groupData.sewa.hasOwnProperty('status') && groupData.sewa.status) return m.reply('Grup ini sudah ada di list sewa!')
            groupData.sewa.expired = m.args[0] ? Date.now() + toMs(m.args[0]) : Date.now() + 2592000000;
            groupData.sewa.status = true;
            groupData.sewa.notice = true;
            m.reply(`Successfully added rent to this group for ${m.args[0]}`)
        }
    },
    owner: true
}