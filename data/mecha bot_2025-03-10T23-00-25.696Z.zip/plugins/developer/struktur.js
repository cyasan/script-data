const fs = require('fs');
const path = require('path');

function printDirectoryStructure(dirPath, prefix = '') {
    let output = ''; // Variabel untuk menyimpan hasil struktur

    // Membaca isi direktori
    const files = fs.readdirSync(dirPath);

    files.forEach((file, index) => {
        const filePath = path.join(dirPath, file);
        const isLast = index === files.length - 1;
        const symbol = fs.statSync(filePath).isDirectory() ? '📂' : '📄';

        // Menambahkan nama file atau folder ke output
        output += `${prefix}${isLast ? '└── ' : '├── '}${symbol} ${file}\n`;

        // Jika ini adalah folder, panggil fungsi ini secara rekursif
        if (fs.statSync(filePath).isDirectory()) {
            output += printDirectoryStructure(filePath, `${prefix}${isLast ? ' ' : '│ '}`);
        }
    });

    return output; // Mengembalikan hasil struktur
}

exports.run = {
    usage: ['struktur'],
    hidden: ['stroke'],
    category: 'developer',
    async: async (m, {
        func,
        mecha
    }) => {
const directoryStructure = printDirectoryStructure('./plugins');
mecha.reply(m.chat, directoryStructure, m, {
expiration: m.expiration
})
    },
    location: 'plugins/developer/struktur.js'
}