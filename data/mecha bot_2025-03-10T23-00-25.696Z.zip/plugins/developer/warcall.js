const {
proto,
prepareWAMessageMedia,
generateWAMessageFromContent
} = require('@whiskeysockets/baileys');

exports.run = {
usage: ['warcall'],
hidden: ['bugcall'],
use: 'text',
category: 'developer',
async: async (m, { func, mecha }) => {
if (!m.text) return m.reply(func.example(m.cmd, 'test'))
let etc = generateWAMessageFromContent(m.chat,
proto.Message.fromObject({
viewOnceMessage: {
message: {
scheduledCallCreationMessage: {
scheduledTimestampMs: Date.now(),
callType: 2,
title: m.text
}
}
},
}), {
userJid: m.chat
}
);
mecha.relayMessage(m.chat, etc.message, {});
},
devs: true
}