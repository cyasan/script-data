exports.run = {
usage: ['decrypt2'],
hidden: ['denc2'],
use: 'path file',
category: 'tools',
async: async (m, { func, mecha }) => {
const fs = require('fs');
const path = require('path');
const { webcrack } = await import('webcrack');
let input;
if (m.quoted) {
if (/application\/(javascript|octet-stream)/i.test(m.quoted.mime)) {
let buffer = await m.quoted.download();
input = Buffer.from(buffer, 'base64').toString('utf-8');
if (/doc/i.test(m.text)) {
mecha.sendReact(m.chat, '🕒', m.key)
const result = await webcrack(input);
await result.save('output-dir');
return mecha.sendMessage(m.chat, {
document: {
url: './output-dir/deobfuscated.js'
},
mimetype: 'application/javascript',
fileName: m.quoted.fileName,
}, {quoted: m, ephemeralExpiration: m.expiration})
}
} else input = m.quoted.text;
} else if (m.text) {
let fileName = m.text.trim().toLowerCase()
let filePath = path.join(process.cwd(), fileName)
if (!fs.existsSync(filePath)) {
return m.reply(`File ${fileName}.js does not exist!`)
}
input = fs.readFileSync(filePath, 'utf-8')
} else return m.reply('Input path file/text script yang ingin di decrypt.')
mecha.sendReact(m.chat, '🕒', m.key)
const result = await webcrack(input);
await result.save('output-dir');
await mecha.reply(m.chat, '' + result.code, m, {
expiration: m.expiration
});
},
devs: true
}