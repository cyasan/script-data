exports.run = {
usage: ['tag'],
category: 'group',
async: async (m, { func, mecha, froms }) => {
if (!m.text) return;
mecha.reply(m.chat, `@${m.text.replace(/[^0-9]/gi, '')}`, m, {
expiration: m.expiration
})
},
group: true
}