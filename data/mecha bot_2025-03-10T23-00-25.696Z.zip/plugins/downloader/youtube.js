const fetch = require('node-fetch');
const BASE_URL = "https://www.saveyouvideo.com"
const URL_LIST = "/get_list_formats";
const URL_START = "/start_convert";
const URL_QUEUE = "/query_convert_status";
const TM = 742958;
const REG_URL = /<a\s?href=\"(.+)"\s?class="dlbtn"\s?target="_blank"\s?title=".+"\s?rel="nofollow">Download<\/a>/i;

function getFormat(info, resolution, music) {
    try {
        if (music) {
            let data = info.mp3[0];
            return {
                type: data.audio_ext,
                id: data.format_id
            }
        } else {
            const getFormatId = (height) => info.mp4.find(v => v.height == height)?.format_id;
            switch (resolution) {
                case "720":
                case "1080":
                case "1440":
                case "2160": {
                    return {
                        type: "mp4",
                        id: getFormatId(resolution)
                    };
                }
                break
                default: {
                    return {
                        type: "mp4",
                        id: getFormatId("720")
                    };
                }
                break
            }
        }
    } catch {
        return null;
    }
}

function formData(obj) {
    const boundary = `----WebKitFormBoundary${Array.from({ length: 15 }).map(_ => "abCdEfGhIjKlMnOpQrStUvWxYZ1795".charAt(Math.random() * 30)).join("")}`;
    let data = `--${boundary}\r\nContent-Disposition: form-data; name="data"\nContent-Type: application/json\n\n${JSON.stringify(obj)}\r\n`;
    data += `--${boundary}--j`;
    // console.log(data)
    return {
        data,
        boundary
    };
}

async function getInfo(url) {
    const {
        data,
        boundary
    } = formData({
        "kw": url
    });
    const response = await fetch(BASE_URL + URL_LIST, {
        method: "POST",
        body: data,
        headers: {
            "content-type": `multipart/form-data; boundary=${boundary}`
        }
    });

    const json = await response.json();
    return json;
}

function download(url, resolusi, music = false) {
    return new Promise(async (resolve, reject) => {
        try {
            const info = await getInfo(url);
            let interval;
            let formatType = 6;
            if (music) {
                formatType = 5;
            } else {
                formatType = 6;
            }

            const format = getFormat(info, resolusi, music);
            if (format == null) {
                if (interval) clearInterval(interval);
                resolve({
                    status: false,
                    message: 'Resolusi tidak tersedia'
                })
            }
            const {
                data,
                boundary
            } = formData({
                "kw": info.webpage_url,
                "type": format.type,
                "format_id": format.id
            });
            /*const response = await fetch(BASE_URL + URL_START, {
              method: "POST",
              body: data,
              headers: {
            "content-type": `multipart/form-data; boundary=${boundary}`
              }
            });
              
            const json = await response.json();
            console.log(json)*/

            interval = setInterval(async () => {
                const queue = await fetch(BASE_URL + URL_QUEUE, {
                    method: "POST",
                    body: data,
                    headers: {
                        "content-type": `multipart/form-data; boundary=${boundary}`
                    }
                });
                const jsn2 = await queue.json();
                console.log(jsn2);
                if (jsn2.progress == 100 || jsn2.progress == undefined || jsn2.progress == null && jsn2.state == 1) {
                    clearInterval(interval);
                    resolve({
                        status: true,
                        title: info.title,
                        thumbnail: info.thumbnail,
                        url: `https://www.amdcdnnodea.xyz:8443/accdf/download_file/${jsn2.videoid + "_" + String(formatType) + (Number(format.id) + TM)}.${format.type}`
                    });
                }
            }, 2000);
        } catch (error) {
            resolve({
                status: false,
                message: error.message
            })
        }
    })
}

exports.run = {
    usage: ['ytmp3', 'ytmp4'],
    hidden: ['yta', 'ytv'],
    use: 'link',
    category: 'downloader',
    async: async (m, {
        func,
        mecha,
        users,
        setting
    }) => {
        try {
            if (/yt?(a|mp3)/i.test(m.command)) {
                if (!m.args || !m.args[0]) return m.reply(func.example(m.cmd, 'https://youtu.be/1fOBgosDo7s?si=_8VLb2NqwyICoEhY'))
                if (!/^(?:https?:\/\/)?(?:www\.|m\.|music\.)?youtu\.?be(?:\.com)?\/?.*(?:watch|embed)?(?:.*v=|v\/|\/)([\w\-_]+)\&?/.test(m.args[0])) return m.reply(global.mess.error.url)
                mecha.sendReact(m.chat, '🕒', m.key)
                const result = await download(m.args[0], "720", true);
                if (!result.status) return m.reply(result.message)
                mecha.sendMessage(m.chat, {
                    audio: {
                        url: result.url
                    },
                    fileName: result.title + '.mp3',
                    mimetype: 'audio/mpeg',
                }, {
                    quoted: m,
                    ephemeralExpiration: m.expiration
                })
            } else if (/yt?(v|mp4)/i.test(m.command)) {
                if (!m.args || !m.args[0]) return m.reply(func.example(m.cmd, 'https://youtu.be/1fOBgosDo7s?si=_8VLb2NqwyICoEhY'))
                if (!/^(?:https?:\/\/)?(?:www\.|m\.|music\.)?youtu\.?be(?:\.com)?\/?.*(?:watch|embed)?(?:.*v=|v\/|\/)([\w\-_]+)\&?/.test(m.args[0])) return m.reply(global.mess.error.url)
                mecha.sendReact(m.chat, '🕒', m.key)
                const result = await download(m.args[0], "720", false);
                if (!result.status) return m.reply(result.message)
                mecha.sendMessage(m.chat, {
                    video: {
                        url: result.url
                    },
                    caption: result.title,
                    fileName: result.title + '.mp4',
                    mimetype: 'video/mp4',
                }, {
                    quoted: m,
                    ephemeralExpiration: m.expiration
                })
            }
        } catch (error) {
            return mecha.reply(m.chat, error.message, m, {
                expiration: m.expiration
            })
        }
    },
    limit: 5,
    location: 'plugins/downloader/youtube.js'
}