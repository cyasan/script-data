const toMs = require('ms');

let listharga = `乂  *P A K E T - P R E M I U M*

PAKET *P1*
- Masa aktif 7 hari
- Unlimited limit
- 1000.000 balance
PAKET *P2*
- Masa aktif 15 hari
- Unlimited limit
- 10.000.000 balance
PAKET *P3*
- Masa aktif 30 hari
- Unlimited limit
- 100.000.000 balance
PAKET *P4*
- Masa aktif 60 hari
- Unlimited limit
- 500.000.000 balance

乂  *P A K E T - S E W A B O T*

PAKET *S1*
- 15 day / Group
PAKET *S2*
- 30 day / Group
PAKET *S3*
- 60 day / Group
PAKET *S4*
- 90 day / Group`

exports.run = {
usage: ['perpanjang'],
use: '[type] [jid] [paket]',
category: 'owner',
async: async (m, { func, mecha }) => {
const [type, jid, paket] = m.text.split(',');
if (!m.text) return m.reply(`Contoh pengguna:\n${m.cmd} [type], [jid], [paket]\n\nContoh perpanjang premium:\n${m.prefix + m.command} premium, +62xxx, P1/P2/P3/P4\n\nContoh perpanjang sewabot:\n${m.prefix + m.command} sewabot, 120@g.us, S1/S2/S3/S4`)
if (!type) return m.reply(`Input type perpanjang: *premium* atau *sewabot*`)
if (!jid) return m.reply(`Input jid perpanjang: *+62xxx* atau *120@g.us*`)
if (!paket) return m.reply(`Input paket perpanjang!\n\n${listharga}`)
if (m.text && func.somematch(['prem', 'premium'], type)) {
let who = jid.replace(/[^0-9]/g, '') + '@s.whatsapp.net'
let user = global.db.users[who];
if (typeof user == 'undefined') return m.reply('User data not found.')
if (!user.premium) return m.reply(`@${who.replace(/@.+/, '')} bukan pengguna premium.`)
if (paket.trim() == 'P1') {
user.limit += 99999;
user.balance += 1000000;
user.expired.premium += toMs('7d');
m.reply(`Berhasil perpanjang premium @${who.replace(/@.+/, '')} selama 7 hari.`)
} else if (paket.trim() == 'P2') {
user.limit += 99999;
user.balance += 10000000;
user.expired.premium += toMs('15d');
m.reply(`Berhasil perpanjang premium @${who.replace(/@.+/, '')} selama 15 hari.`)
} else if (paket.trim() == 'P3') {
user.limit += 99999;
user.balance += 100000000;
user.expired.premium += toMs('30d');
m.reply(`Berhasil perpanjang premium @${who.replace(/@.+/, '')} selama 30 hari.`)
} else if (paket.trim() == 'P4') {
user.limit += 99999;
user.balance += 500000000;
user.expired.premium += toMs('90d');
m.reply(`Berhasil perpanjang premium @${who.replace(/@.+/, '')} selama 90 hari.`)
} else return m.reply('Invalid format.')
} else if (m.text && func.somematch(['sewa', 'sewabot'], type)) {
let groups;
if (jid.trim().includes('chat.whatsapp.com')) {
let link = /chat.whatsapp.com\/([0-9A-Za-z]{20,24})/i
let [_, code] = jid.trim().match(link) || []
if (code) {
let res = await mecha.groupQueryInvite(code)
groups = global.db.groups[res.id];
} else groups = global.db.groups[jid.trim()];
} else {
groups = global.db.groups[jid.trim()];
}
if (typeof groups == 'undefined') return m.reply('Group data not found.')
if (!groups.sewa.status) return m.reply(`Group tersebut tidak terdaftar di list sewabot.`)
if (paket.trim() == 'S1') {
groups.sewa.expired += toMs('15d');
m.reply(`Berhasil perpanjang sewa ${groups.name} selama 15 hari.`)
} else if (paket.trim() == 'S2') {
groups.sewa.expired += toMs('30d');
m.reply(`Berhasil perpanjang sewa ${groups.name} selama 30 hari.`)
} else if (paket.trim() == 'S3') {
groups.sewa.expired += toMs('60d');
m.reply(`Berhasil perpanjang sewa ${groups.name} selama 60 hari.`)
} else if (paket.trim() == 'S4') {
groups.sewa.expired += toMs('150d');
m.reply(`Berhasil perpanjang sewa ${groups.name} selama 150 hari.`)
} else return m.reply('Invalid format.')
}
},
owner: true
}