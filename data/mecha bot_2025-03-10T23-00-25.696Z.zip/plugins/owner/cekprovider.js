const fetch = require('node-fetch')

exports.run = {
usage: ['cekprovider'],
hidden: ['cp'],
use: '62xxx',
category: 'owner',
async: async (m, { func, mecha }) => {
if (!m.text) return m.reply(func.example(m.cmd, '628xxx'))
mecha.sendReact(m.chat, '🕒', m.key)
let number = m.text.replace(/[^0-9]/g, '')
try {
var response = await fetch(`http://apilayer.net/api/validate?access_key=4a1ede76e87d9e64682b284e8620ad68&number=+${number}&country_code=ID&format=1`);
var result = await response.json();
m.reply(JSON.stringify(result, null, 2));
} catch (error) {
m.reply(`Error: ${String(error)}`);
}
},
owner: true
}