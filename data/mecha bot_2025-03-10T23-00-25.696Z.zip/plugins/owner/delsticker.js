exports.run = {
usage: ['delsticker'],
hidden: ['delstiker', 'delstik'],
use: 'text',
category: 'owner',
async: async (m, { func, mecha }) => {
if (!m.text) return m.reply('Masukkan nama stikernya!')
try {
if (!global.db.sticker[m.text]) return m.reply(`Nama *'${m.text}'* tidak ada di dalam database.`)
delete global.db.sticker[m.text]
m.reply(`Succes delete sticker *'${m.text}'*`)
} catch (err) {
m.reply(`Gagal delete sticker *'${m.text}'*`)
}
},
owner: true
}