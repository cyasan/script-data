exports.run = {
main: async (m, { func, mecha, errorMessage }) => {
let promosi = [
'minat pm',
'promo',
'ready panel',
'ready vps',
'ready nokos',
'open reseller',
'open jasa',
'jangan lupa follow',
'https://whatsapp.com/channel',
'100% aman',
];
let regexPromosi = new RegExp(promosi.join('|'), 'i');
try {
// respon ketika ada yang ingin keluar
// if (m.budy && regexPromosi.test(m.budy.toLowerCase()) && m.isGc && m.isBotAdmin) {
if (m.budy && regexPromosi.test(m.budy.toLowerCase()) && m.isGc && m.isBotAdmin && !m.isAdmin && !m.isOwner && !m.isDevs) {
return await mecha.sendMessage(m.chat, {
delete: {
remoteJid: m.chat,
fromMe: false,
id: m.key.id,
participant: m.sender
}
})
}
} catch (e) {
return errorMessage(e)
}
},
group: true,
botAdmin: true
}