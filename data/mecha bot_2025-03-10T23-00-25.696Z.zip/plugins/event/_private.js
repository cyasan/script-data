exports.run = {
    main: async (m, {
        func,
        mecha,
        commands
    }) => {
        if (!m.fromMe & m.isPc && !(m.command && commands.includes(m.command)) && !m.isPrefix && !/protocolMessage/.test(m.mtype)) {
            let user = global.db.users[m.sender];
            if (!('private' in user)) user.private = 0;
            const cooldown = 86400000;
            if (new Date() - user.private < cooldown) return;
            let caption = `Halo @${m.sender.split('@')[0]} 👋🏻, ada yang bisa saya bantu? Ketik .sewabot jika ingin menyewa bot ini.`.trim();
            mecha.sendMessage(m.chat, {
                text: caption,
                contextInfo: {
                    forwardingScore: 10,
                    isForwarded: true,
                    mentionedJid: [m.sender],
                    businessMessageForwardInfo: {
                        businessOwnerJid: '6289504842184@s.whatsapp.net'
                    },
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: '120363261409301854@newsletter',
                        serverMessageId: null,
                        newsletterName: '𝗈𝖿𝖿ꪱ𝖼ꪱα𝗅 𝗆ᧉ𝖼𝗁α 𝖻𝗈𝗍'
                    }
                }
            }, {
                quoted: null,
                ephemeralExpiration: m.expiration
            })
            user.private = new Date() * 1;
        }
    },
    private: true,
    location: 'plugins/event/_private.js'
}