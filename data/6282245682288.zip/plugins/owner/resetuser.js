exports.run = {
  usage: ['resetuser'],
  category: 'owner',
  async: async (m, { mecha }) => {

    // Pastikan pengguna sedang merespons pesan user yang ingin di-reset
    if (!m.quoted || !m.quoted.sender) {
      return mecha.reply(m.chat, 'Silakan reply pesan user yang ingin di-reset datanya.', m);
    }

    // Ambil user yang sedang di-reply
    let user = global.db.users[m.quoted.sender];

    // Cek apakah user yang di-reply ada dalam database
    if (!user) {
      return mecha.reply(m.chat, 'User yang Anda reply tidak ditemukan di database.', m);
    }

    // Reset data user
    user.name = ''; // Reset ke nama saat ini
    user.age = 0; // Kosongkan usia
    user.gender = '';
    user.register = false; // Kosongkan gender

    // Simpan perubahan ke database
    global.db.users[m.quoted.sender] = user;

    // Kirimkan konfirmasi perubahan data
    mecha.reply(
      m.chat,
      `User data has been reset:\n\n` +
      `- *Name:* ${user.name}\n` +
      `- *Age:* (Not set)\n` +
      `- *Gender:* (Not set)`,
      m
    );
  },
  owner: true // Hanya owner yang dapat menggunakan perintah ini
};