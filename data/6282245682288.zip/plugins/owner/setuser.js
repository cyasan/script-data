exports.run = {
  usage: ['setuser'],
  use: 'name,age,gender',
  category: 'owner',
  async: async (m, { mecha, froms, prefix }) => {
    // Pastikan pengguna sedang merespons pesan user yang ingin diubah datanya
    if (!m.quoted || !m.quoted.sender) {
      return mecha.reply(m.chat, 'Silakan reply pesan user yang datanya ingin diubah.', m);
    }

    // Ambil user yang sedang di-reply
    let user = global.db.users[m.quoted.sender];

    // Cek apakah user yang di-reply ada dalam database
    if (!user) {
      return mecha.reply(m.chat, 'User yang Anda reply tidak ditemukan di database.', m);
    }

    // Ambil data yang diinputkan setelah perintah
    let data = m.text.replace(`${prefix}setuser`, '').trim();

    // Pisahkan data berdasarkan tanda koma
    let [name, age, gender] = data.split(',');

    // Validasi input
    if (!name || !age || !gender) {
      return mecha.reply(
        m.chat,
        'Format salah. Gunakan format:\n\n' +
        `${prefix}setuser name,age,gender\n\n` +
        'Contoh:\n' +
        `${prefix}setuser Alex,25,male`,
        m
      );
    }

    // Validasi umur (harus berupa angka)
    if (isNaN(age) || age <= 0) {
      return mecha.reply(m.chat, 'Umur harus berupa angka yang valid.', m);
    }

    // Validasi gender (harus male/female)
    gender = gender.trim().toLowerCase();
    if (gender !== 'male' && gender !== 'female') {
      return mecha.reply(m.chat, 'Gender harus "male" atau "female".', m);
    }

    // Konversi gender untuk disimpan ke database
    let genderInDb = gender === 'male' ? 'Laki-laki' : 'Perempuan';

    // Simpan data ke database
    user.name = name.trim();
    user.age = parseInt(age.trim());
    user.gender = genderInDb;

    // Simpan perubahan ke database
    global.db.users[m.quoted.sender] = user;

    // Kirimkan konfirmasi perubahan
    mecha.reply(
      m.chat,
      `Successfully updated user data:\n\n` +
      `Name: ${user.name}\n` +
      `Age: ${user.age}\n` +
      `Gender: ${user.gender}`,
      m
    );
  },
  owner: true, // Hanya owner yang dapat mengakses fitur ini
};