exports.run = {
    usage: ['setnamegroup'],
    hidden: ['setnamegc'],
    use: 'text + id_grup',
    category: 'owner',
    async: async (m, { func, mecha }) => {
        
        if (!m.args[0] || !m.args[1]) {
            return mecha.sendMessage(m.chat, { 
                text: `Masukkan nama baru dan ID grup!\nContoh: ${m.prefix + m.command} Official Lexy 111736183728382737@g.us` 
            }, { quoted: m })
        }

        let groupId = m.args.pop() // Ambil ID grup (argumen terakhir)
        let newName = m.args.join(' ') // Gabungkan sisanya sebagai nama baru grup

        // Ambil nama grup sebelum diubah
        let groupMetadata = await mecha.groupMetadata(groupId)
        let oldName = groupMetadata.subject || "Nama Tidak Diketahui"

        await mecha.groupUpdateSubject(groupId, newName)
            .then(async () => {
                // Kirim respons emoji di private chat owner
                mecha.sendReact(m.chat, '✅', m.key)

                // Kirim pesan ke grup dengan quoted dari func.fstatus("System Notification")
                await mecha.sendMessage(groupId, { 
                    text: `Bot mengganti Subject \`${oldName}\` menjadi \`${newName}\` atas perintah owner.` 
                }, { quoted: func.fstatus("System Notification") })
            })
            .catch(() => mecha.sendReact(m.chat, '❌', m.key))
    },
    private: true,
    owner: true,
    boAdmin: true
}