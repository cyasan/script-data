exports.run = {
usage: ['setprefix'],
use: 'symbol',
category: 'owner',
async: async (m, { func, mecha, setting }) => {
if (!m.text) return m.reply(func.example(m.cmd, '#'))
if (m.args[0] == 'multi') {
if (setting.multiprefix) return mecha.sendMessage(m.chat, { text: 'Prefix is already this.'}, { quoted: m });
setting.multiprefix = true;
mecha.sendMessage(m.chat, { text: `Prefix successfully changed to multi`}, { quoted: m });
} else {
if (setting.prefix == m.args[0] && !setting.multiprefix) return mecha.sendMessage(m.chat, { text: 'Prefix is already this.'}, { quoted: m });
setting.multiprefix = false;
setting.prefix = m.args[0];
mecha.sendMessage(m.chat, { text: `Prefix successfully changed to : ${m.args[0]}`}, { quoted: m });
}
},
owner: true
}