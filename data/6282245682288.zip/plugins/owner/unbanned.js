const toMs = require('ms');

exports.run = {
  usage: ['unbanned'],
  hidden: ['unban'],
  use: 'mention or reply',
  category: 'owner',
  async: async (m, { func, mecha, froms, setting }) => {
    if (m.quoted || m.text) {
      let user = global.db.users[froms];
      if (typeof user == 'undefined') {
        return await mecha.sendMessage(
          m.chat,
          { text: func.texted('bold', 'User data not found.') },
          { quoted: m }
        );
      }
      if (!user.banned) {
        return await mecha.sendMessage(
          m.chat,
          { text: 'Target not banned.' },
          { quoted: m }
        );
      }
      user.banned = false;
      user.expired.banned = 0;
      await mecha.sendMessage(
        m.chat,
        { text: `Successfully removed *${user.name}* from the banned list.` },
        { quoted: m }
      );
    } else {
      await mecha.sendMessage(
        m.chat,
        { text: 'Mention or reply to the chat target.' },
        { quoted: m }
      );
    }
  },
  owner: true,
};