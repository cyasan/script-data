const cron = require('node-cron');

exports.run = {
  usage: ['testreminder'],
  category: 'tools',
  async: async (m, { text, mecha, func }) => {
    try {
      const reminders = [
        { time: '07:30', message: "Jangan lupa sarapan! 🍽️" },
        { time: '10:00', message: "Jangan lupa mandi! 🛀" },
        { time: '12:00', message: "Jangan lupa makan! 🍽️" },
        { time: '12:00 (Jumat)', message: "Selamat menjalankan ibadah Sholat Jum'at bagi laki-laki!" },
        { time: '15:00', message: "Jangan lupa makan! 🍽️" },
        { time: '17:00', message: "Jangan lupa mandi! 🛀" },
        { time: '20:00', message: "Jangan lupa makan malam! 🍽️" },
        { time: '23:00', message: "Selamat beristirahat! 🛌" }
      ];

      // Ambil angka dari argumen
      let number = (m.args[0] || '').replace(/[^0-9]/g, '');
      let index = parseInt(number, 10) - 1;

      if (!isNaN(index) && reminders[index]) {
        let reminder = reminders[index];

        return mecha.sendMessage(m.chat, 
          { text: reminder.message }, // Tidak pakai func.fstatus di text
          { quoted: func.fstatus("System Notice") } // Tetap pakai func.fstatus untuk quoted
        );
      }

      // Jika tidak ada nomor, tampilkan daftar reminder
      let reminderList = reminders.map((r, i) => `*${i + 1}.* ${r.time} ➝ ${r.message.replace(/[\u{1F300}-\u{1FAD6}]/gu, '')}`).join('\n');

      mecha.sendMessage(m.chat, 
        { text: `乂 *TEST REMINDER*\n\nBerikut adalah daftar pengingat yang telah disiapkan:\n\n${reminderList}` }, 
        { quoted: m } // Tetap pakai quoted dari pesan pengguna
      );

    } catch (e) {
      console.error("Error in testreminder:", e);
    }
  },
  owner: true
};