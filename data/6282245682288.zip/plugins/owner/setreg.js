exports.run = {
  usage: ['setreg'],
  use: 'true/false',
  category: 'owner',
  async: async (m, { mecha, froms, prefix }) => {

    // Pastikan pengguna sedang merespons pesan user yang ingin diubah status registrasinya
    if (!m.quoted || !m.quoted.sender) {
      return mecha.reply(m.chat, 'Silakan reply pesan user yang ingin diubah status registrasinya.', m);
    }

    // Ambil user yang sedang di-reply
    let user = global.db.users[m.quoted.sender];

    // Cek apakah user yang di-reply ada dalam database
    if (!user) {
      return mecha.reply(m.chat, 'User yang Anda reply tidak ditemukan di database.', m);
    }

    // Ambil status register yang ingin diubah
    let statusReg = m.text.replace(`${prefix}setreg`, '').trim().toLowerCase();

    // Validasi status yang dimasukkan (true atau false)
    if (statusReg !== 'true' && statusReg !== 'false') {
      return mecha.reply(m.chat, 'Silakan masukkan status yang valid: true untuk terdaftar, false untuk tidak terdaftar.', m);
    }

    // Tentukan status register berdasarkan input
    let registerStatus = statusReg === 'true';

    // Periksa apakah status register sudah sesuai
    if (registerStatus === user.register) {
      return mecha.reply(
        m.chat,
        `User already ${registerStatus ? 'Registered' : 'Not Registered'}.`,
        m
      );
    }

    // Set tanggal perubahan status dengan format: Tanggal Bulan Tahun
    const months = [
      'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
      'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'
    ];
    let now = new Date();
    let formattedDate = `${now.getDate()} ${months[now.getMonth()]} ${now.getFullYear()}`;

    // Ganti status register user dengan status baru dan set tanggal
    user.register = registerStatus;

    if (registerStatus) {
      // Jika status true, simpan tanggal
      user.date = formattedDate;
    } else {
      // Jika status false, reset data user
      user.name = '';
      user.age = '';
      user.gender = '';
      user.date = null; // Reset tanggal ke null
    }

    // Simpan perubahan ke database
    global.db.users[m.quoted.sender] = user;

    // Kirimkan konfirmasi perubahan status register dan tanggal
    if (registerStatus) {
      mecha.reply(
        m.chat,
        `Successfully updated registration user to: Registered at ${formattedDate}`,
        m
      );
    } else {
      mecha.reply(
        m.chat,
        `Successfully updated registration user to: Not registered. User data has been reset.`,
        m
      );
    }
  },
  owner: true, // Hanya owner yang dapat mengakses fitur ini
};