exports.run = {
  usage: ['join'],
  use: 'link grup',
  category: 'owner',
  async: async (m, { func, mecha }) => {
    if (m.quoted || m.text) {
      try {
        let url = m.quoted ? m.quoted.text : m.text
        if (url.includes('chat.whatsapp.com')) {
          let inviteCode = url.split('https://chat.whatsapp.com/')[1]

          // Coba join grup
          let res = await mecha.groupAcceptInvite(inviteCode).catch(async (err) => {
            if (err?.status === 403 || err?.message?.toLowerCase()?.includes("not-authorized")) {
              return "WAITING_APPROVAL"
            } else {
              throw err
            }
          })

          if (res === "WAITING_APPROVAL") {
            return m.reply('Bot sedang menunggu persetujuan dari admin.')
          }

          // Kirim JID grup ke pengirim
          await mecha.sendMessage(m.chat, { text: `Bot berhasil join ke grup:\n*${res}*` }, { quoted: m })

          // Ambil metadata grup
          let groupMetadata = await mecha.groupMetadata(res)
          let members = groupMetadata.participants.map(p => p.id)

          // Kirim pesan perkenalan dengan hidetag
          await mecha.sendMessage(res, {
            text: `Hai member ${groupMetadata.subject} 👋🏻\nPerkenalkan saya adalah sebuah sistem otomatis (WhatsApp Bot) yang dapat membantu untuk melakukan sesuatu, mencari dan mendapatkan data/informasi hanya melalui WhatsApp.\n\n_Ketik .menu untuk melihat daftar perintah._`,
            mentions: members,
            contextInfo: { mentionedJid: members } // untuk hidetag
          }, { quoted: func.fstatus("System Notice") })

        } else {
          m.reply('Masukkan link grup dengan benar!')
        }
      } catch (e) {
        return m.reply('Bot sudah terkick, tidak dapat join.')
      }
    } else {
      m.reply(`Kirim perintah ${m.cmd} link grup`)
    }
  },
  owner: true
}