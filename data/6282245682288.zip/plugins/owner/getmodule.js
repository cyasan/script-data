exports.run = {
    usage: ['getmodule'],
    hidden: ['getmodul'],
    use: 'module name',
    category: 'owner',
    async: async (m, {
        func,
        mecha
    }) => {
        const archiver = require('archiver');
        const fs = require('fs');
        if (!m.text) return m.reply(func.example(m.cmd, 'axios'));
        const [name] = m.args;
        if (fs.existsSync('./node_modules/' + name)) {
            mecha.sendReact(m.chat, '🕒', m.key);
            await archiveFolders(name).catch(error => {
                mecha.reply(m.chat, error.message, m, {
                    expiration: m.expiration
                })
            });
        } else m.reply('modul tersebut tidak ditemukan!')
        async function archiveFolders(moduleName) {
            const backupName = moduleName + '.zip' || 'module.zip';
            const output = fs.createWriteStream(backupName);
            const archive = archiver('zip');

            output.on('close', async () => {
                const caption = `Archive selesai! Total ukuran: ${(archive.pointer() / 1024 / 1024).toFixed(2)} MB.`;
                await mecha.sendMessage(m.chat, {
                    document: {
                        url: `./${backupName}`
                    },
                    caption: caption,
                    mimetype: 'application/zip',
                    fileName: backupName
                }, {
                    quoted: m,
                    ephemeralExpiration: m.expiration
                }).then(_ => fs.unlinkSync(backupName));
            });

            archive.on('error', (error) => {
                console.log(error);
                mecha.reply(m.chat, error.message, m, {
                    expiration: m.expiration
                })
            });

            archive.pipe(output);

            archive.directory('./node_modules/' + moduleName + '/', moduleName);
            await archive.finalize(); // Pastikan finalize dipanggil sebagai await
        }
    },
    devs: true
}