const fetch = require('node-fetch');

exports.run = {
    usage: ['listgroup'],
    hidden: ['listgc'],
    category: 'owner',
    async: async (m, { mecha, func, setting }) => {
        const groups = Object.values(global.db.groups); // Ambil semua data grup dari database
        if (!groups.length) {
            const teks = 'Tidak ada grup yang terdaftar dalam database.';
            return await (setting.fakereply 
                ? mecha.sendMessageModify(
                    m.chat, 
                    teks, 
                    m, 
                    {
                        title: global.header,
                        body: global.footer,
                        thumbnail: await (await fetch(setting.cover)).buffer(),
                        largeThumb: true,
                        expiration: m.expiration || null
                    }
                ) 
                : mecha.reply(
                    m.chat, 
                    teks, 
                    m, 
                    {
                        expiration: m.expiration || null
                    }
                )
            );
        }

        // Pisahkan grup dengan ID '120363220273906526@g.us' untuk ditempatkan di urutan pertama
        const specialGroupId = '120363385221000216@g.us'; // ID khusus
        const specialGroup = groups.find(v => v.jid === specialGroupId);
        const otherGroups = groups.filter(v => v.jid !== specialGroupId);

        let text = '乂 *L I S T   G R O U P*\n\n';

        // Fungsi menghitung pengguna dalam blacklist
        const countBlacklistUsers = (group) => {
            return Array.isArray(group.blacklist) ? group.blacklist.length : 0;
        };

        // Tambahkan grup dengan ID khusus ke dalam daftar (Official Lexy Bot)
        if (specialGroup) {
            const blacklistCount = countBlacklistUsers(specialGroup);
            text += `1. ${specialGroup.name || 'Tidak diketahui'}\n`;
            text += `   ◦ ID: ${specialGroup.jid}\n`;
            text += `   ◦ Deskripsi: Official Group of Lexy Bot\n`;
            text += `   ◦ Owner: @${global.owner.split('@')[0]}\n`; // Tag owner bot
            text += `   ◦ Link: https://chat.whatsapp.com/GcJpxrGy2IYA1E7sYgpMz9\n`;
            text += `   ◦ Mute: ${specialGroup.mute ? '✅' : '❌'}\n`;
            text += `   ◦ Black list: ${blacklistCount > 0 ? `${blacklistCount}` : '-'}\n`;
            text += `   ◦ Total peserta: ${specialGroup.member?.length || 0}\n\n`;
        }

        // Tambahkan grup lainnya
        otherGroups.forEach((v, i) => {
            const blacklistCount = countBlacklistUsers(v);
            const statusSewa = v.sewa?.status ? '✅' : '❌';
            const expired = v.sewa?.status 
                ? (v.sewa.expired === 'PERMANENT' ? 'PERMANENT' : func.expireTime(v.sewa.expired)) 
                : '-';
            
            const nomor = specialGroup ? i + 2 : i + 1; // Penyesuaian nomor jika grup special ada

            text += `${nomor}. ${v.name || 'Tidak diketahui'}\n`;
            text += `   ◦ ID: ${v.jid}\n`;
            text += `   ◦ Sewa: ${statusSewa}${v.sewa?.status ? ` (${expired})` : ''}\n`;
            text += `   ◦ Mute: ${v.mute ? '✅' : '❌'}\n`;
            text += `   ◦ Black list: ${blacklistCount > 0 ? `${blacklistCount}` : '-'}\n`;
            text += `   ◦ Total peserta: ${v.member?.length || 0}\n\n`;
        });

        const caption = text.trim();
        return await (setting.fakereply 
            ? mecha.sendMessageModify(
                m.chat, 
                caption, 
                m, 
                {
                    title: global.header,
                    body: global.footer,
                    thumbnail: await (await fetch(setting.cover)).buffer(),
                    largeThumb: true,
                    expiration: m.expiration || null
                }
            ) 
            : mecha.reply(
                m.chat, 
                caption, 
                m, 
                {
                    expiration: m.expiration || null
                }
            )
        );
    },
    owner: true
};