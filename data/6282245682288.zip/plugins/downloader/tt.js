const axios = require("axios");

exports.run = {
  usage: ['tiktokslide'],
  hidden: ['ttslide'],
  use: 'link tiktok',
  category: 'downloader',
  async: async (m, { func, mecha }) => {
    if (!m.text) {
      return mecha.sendMessage(m.chat, { 
        text: func.example(m.cmd, 'https://vt.tiktok.com/ZSM1hhsNw/') 
      }, { quoted: m });
    }
    if (!m.args[0].includes('tiktok.com')) {
      return mecha.sendMessage(m.chat, { text: "URL TikTok tidak valid." }, { quoted: m });
    }

    mecha.sendReact(m.chat, '🕒', m.key);

    try {
      const apiUrl = `https://www.tikwm.com/api/?url=${encodeURIComponent(m.args[0])}`;
      let response = await axios.get(apiUrl);

      let data = response.data;
      if (!data || !data.data || !data.data.images || data.data.images.length === 0) {
        return mecha.sendMessage(m.chat, { text: "Gagal mengambil gambar dari TikTok." }, { quoted: m });
      }

      let txt = `乂 *TIKTOK SLIDE - DOWNLOADER*\n\n◦ *Title* : ${data.data.title}`;
      txt += `\n◦ *Total Images* : ${data.data.images.length}`;

      let mainMessage; // Untuk menyimpan pesan utama sebagai quoted gambar berikutnya

      for (let i = 0; i < data.data.images.length; i++) {
        console.log(`Downloading Image ${i + 1}:`, data.data.images[i]); // Log hanya saat download

        let sentMsg = await mecha.sendMessage(m.chat, {
          image: { url: data.data.images[i] },
          mimetype: 'image/jpeg',
          caption: i === 0 ? txt : null // Hanya gambar pertama yang memiliki caption
        }, { quoted: i === 0 ? m : mainMessage });

        if (i === 0) mainMessage = sentMsg; // Simpan pesan utama untuk quoted gambar berikutnya
      }
    } catch (err) {
      return mecha.sendMessage(m.chat, { text: "Terjadi kesalahan saat mengunduh gambar." }, { quoted: m });
    }
  },
  limit: 2
};