const axios = require("axios");
const cheerio = require("cheerio");
const FormData = require("form-data");

const likeeDl = {
  base: {
    download: "https://getof.net/wp-json/aio-dl/video-data/",
    token: "https://getof.net/en/likee-video-downloader/"
  },
  hash: (url, salt) => {
    return Buffer.from(url).toString('base64') + (url.length + 1000) + Buffer.from(salt).toString('base64');
  },
  token: async () => {
    const { data } = await axios.get(likeeDl.base.token);
    const $ = cheerio.load(data);
    return $("#token").val();
  },
  download: async (url) => {
    const hash = await likeeDl.hash(url, "aio-dl");
    const token = await likeeDl.token();
    const form = new FormData();
    form.append("url", url);
    form.append("token", token);
    form.append("hash", hash);

    const headers = {
      headers: {
        ...form.getHeaders()
      }
    };

    const { data } = await axios.post(likeeDl.base.download, form, headers);
    return data;
  }
};

exports.run = {
  usage: ['likee'],
  category: 'downloader',
  use: 'link likee',
  async: async (m, { func, mecha }) => {
    if (!m.text) return m.reply(func.example(m.cmd, 'https://l.likee.video/v/6qW3uQ'));
    if (!m.args[0].includes('likee.video')) return m.reply('URL tidak valid!');

    mecha.sendReact(m.chat, '🕒', m.key);

    try {
      const res = await likeeDl.download(m.args[0]);

      if (!res || !res.medias || !res.medias[0]?.url) return m.reply('Gagal mengambil video.');

      const media = res.medias[0];

      let caption = `乂 *LIKEE - DOWNLOADER*\n\n`;
      caption += `◦ *Judul* : ${res.title || '-'}\n`;
      caption += `◦ *Durasi* : ${res.duration || '-'} detik\n`;
      caption += `◦ *Resolusi* : ${media.quality || 'N/A'}\n`;

      await mecha.sendMessage(m.chat, {
        video: { url: media.url },
        caption
      }, { quoted: m });

      mecha.sendReact(m.chat, '✅', m.key);
    } catch (err) {
      console.error(err);
      m.reply('Terjadi kesalahan saat mengunduh video Likee.');
    }
  },
  limit: 5
};