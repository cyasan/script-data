const events = [
  {
    event: "Tahun Baru Hijriyah",
    tanggal: "1 Muharram",
    deskripsi: "Awal tahun dalam kalender Hijriyah yang dimulai dengan peristiwa hijrah Nabi Muhammad SAW.",
  },
  {
    event: "Hari Asyura",
    tanggal: "10 Muharram",
    deskripsi: "Hari Asyura merupakan hari yang sangat penting, di mana Nabi Musa dan umatnya diselamatkan dari kejaran Firaun, serta hari yang penuh dengan berkah dan ampunan.",
  },
  {
    event: "Maulid Nabi Muhammad SAW",
    tanggal: "12 Rabiul Awal",
    deskripsi: "Peringatan kelahiran Nabi Muhammad SAW yang penuh dengan berkah dan hikmah.",
  },
  {
    event: "Isra' Mi'raj",
    tanggal: "27 Rajab",
    deskripsi: "Peristiwa penting dalam kehidupan Nabi Muhammad SAW yang mengisahkan perjalanan malam (Isra) dan kenaikan (Mi'raj) beliau ke langit.",
  },
  {
    event: "Nuzulul Qur'an",
    tanggal: "17 Ramadhan",
    deskripsi: "Hari turunnya Al-Qur'an kepada Nabi Muhammad SAW melalui wahyu pertama yang diterima di Gua Hira.",
  },
  {
    event: "Idul Fitri",
    tanggal: "1 Syawal",
    deskripsi: "Hari Raya Idul Fitri, sebagai perayaan kemenangan setelah sebulan penuh menjalankan ibadah puasa di bulan Ramadhan.",
  },
  {
    event: "Hari Arafah",
    tanggal: "9 Dzulhijjah",
    deskripsi: "Hari Arafah, hari penting bagi jamaah haji di Arafah yang menjadi bagian dari rukun haji.",
  },
  {
    event: "Idul Adha",
    tanggal: "10 Dzulhijjah",
    deskripsi: "Hari Raya Idul Adha, sebagai perayaan untuk memperingati pengorbanan Nabi Ibrahim dan putranya, Nabi Ismail.",
  },
  {
    event: "Tasyakuran Haji",
    tanggal: "11 Dzulhijjah",
    deskripsi: "Hari Tasyakuran Haji, sebagai bagian dari rangkaian ibadah haji yang dilakukan oleh jamaah haji setelah hari Idul Adha.",
  },
  {
    event: "Hari Tasyrik",
    tanggal: "12, 13 Dzulhijjah",
    deskripsi: "Hari Tasyrik adalah hari-hari setelah Idul Adha yang juga menjadi bagian dari ibadah haji.",
  },
  {
    event: "Hari Raya Idul Fitri",
    tanggal: "1 Syawal",
    deskripsi: "Merayakan hari kemenangan setelah menjalankan ibadah puasa Ramadan, penuh dengan rasa syukur dan kebahagiaan.",
  },
  {
    event: "Perayaan Hari Waisak",
    tanggal: "Vesak",
    deskripsi: "Hari perayaan agama Buddha, namun banyak dilakukan secara bersamaan dengan kegiatan sosial yang menghormati Islam.",
  },
  {
    event: "Hari Burdah",
    tanggal: "12 Rabiul Awal",
    deskripsi: "Merayakan kelahiran Nabi Muhammad SAW, peringatan ini diperingati dalam berbagai bentuk kegiatan keagamaan.",
  },
  {
    event: "Hari Maulid Nabi",
    tanggal: "12 Rabiul Awal",
    deskripsi: "Hari penting sebagai perayaan untuk mengenang kelahiran Nabi Muhammad SAW dan keteladannya.",
  },
];

exports.run = {
  usage: ['hariislam'],
  category: 'islamic',
  async: async (m, { mecha }) => {
    let caption = "乂 *HARI BESAR - ISLAM*\n\n";
    
    events.forEach(event => {
      caption += `- Event: *${event.event}*\n`;
      caption += `◦ Tanggal: ${event.tanggal}\n`;
      caption += `◦ Deskripsi: ${event.deskripsi}\n\n`;
    });

    mecha.reply(m.chat, caption, m);
  }
};