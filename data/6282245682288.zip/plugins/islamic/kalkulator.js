const fetch = require('node-fetch');

exports.run = {
  usage: ['kalkulatorzakat'],
  use: 'nominal',
  hidden: ['kalzakat'],
  category: 'islamic',
  async: async (m, { func, mecha, text, prefix, command }) => {
    let nominal = (m.args[0] || '').replace(/[^0-9]/g, ''); // Mempertahankan format yang kamu inginkan

    if (!nominal || isNaN(nominal)) {
      let caption = `Masukkan nominal harta Anda.\n`;
      caption += `Contoh: *${m.prefix + m.command} 10000000*\n\n`;
      caption += `_Keterangan:_\n- Zakat Maal: 2.5% dari total harta.\n- Zakat Penghasilan: 2.5% dari penghasilan per bulan.\n- Zakat Fitrah: Setara 2.5 kg beras atau nominalnya per orang.\n`;
      mecha.reply(m.chat, caption, m, { expiration: m.expiration });
    } else {
      nominal = Number(nominal); // Konversi nominal menjadi angka setelah dibersihkan
      let zakatMaal = nominal * 0.025;
      let zakatPenghasilan = nominal * 0.025;
      let zakatFitrah = 45000; // Nominal tetap per orang, dapat disesuaikan.

      let caption = `乂 *KALKULATOR ZAKAT*\n\n`;
      caption += `*Nominal Harta Anda:* Rp ${nominal.toLocaleString()}\n\n`;
      caption += `*Hasil Perhitungan Zakat:*\n`;
      caption += `- *Zakat Maal (2.5%):* Rp ${zakatMaal.toLocaleString()}\n`;
      caption += `- *Zakat Penghasilan (2.5%):* Rp ${zakatPenghasilan.toLocaleString()}\n`;
      caption += `- *Zakat Fitrah (Per Orang):* Rp ${zakatFitrah.toLocaleString()}\n\n`;
      caption += `_Silakan tunaikan zakat sesuai ketentuan syariat Islam._`;

      mecha.reply(m.chat, caption, m, { expiration: m.expiration });
    }
  }
};