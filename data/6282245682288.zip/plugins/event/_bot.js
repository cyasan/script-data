exports.run = {
    main: async (m, { mecha, func, groups, users }) => {
        let mentions = [...new Set(m.mentionedJid || [])]; // Ambil hanya mention, tanpa quoted

        // Cek apakah ada yang mention bot
        for (let jid of mentions) {
            if (jid === mecha.user.jid) {
                if (m.isGc && groups.mute && !m.isOwner) return; // Cek mute group
                if (users && users.banned && !m.isOwner) return; // Cek banned user
                
                let messageId = 'MECHA' + func.makeid(8).toUpperCase() + 'GPT';

                // Format pesan awal
                let textnya = `Halo @${m.sender.split('@')[0]}!\nAda yang bisa Lexy bantu?`;

                // Kirim sapaan awal
                await mecha.sendMessage(
                    m.chat,
                    {
                        text: textnya,
                        contextInfo: {
                            mentionedJid: [m.sender]
                        }
                    },
                    { quoted: m, ephemeralExpiration: m.expiration, messageId: messageId }
                );

                // Dapatkan respon dari GPT
                let response = await mecha.gpt(m.budy);

                // Kirim jawaban dari GPT
                await mecha.sendMessage(
                    m.chat,
                    {
                        text: response,
                        contextInfo: {
                            mentionedJid: [m.sender]
                        }
                    },
                    { quoted: m, ephemeralExpiration: m.expiration, messageId: messageId }
                );

                break; // Hentikan iterasi setelah menemukan mention ke bot
            }
        }
    },
    group: true,
};