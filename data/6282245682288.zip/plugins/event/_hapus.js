const fs = require("fs");

exports.run = {
  main: async (bot, { mecha, func, update, errorMessage }) => {
    mecha.deleted = mecha.deleted || [];

    try {
      const lastMessage = update.messages[update.messages.length - 1];
      const isDeleted = mecha.deleted.find(msg => msg.key.id === lastMessage.key.id);

      // Simpan semua pesan sebelum dihapus, kecuali jika dari bot atau owner
      if (!isDeleted && !bot.isBot && !lastMessage.key.fromMe) {
        mecha.deleted.push({
          key: lastMessage.key,
          message: JSON.parse(JSON.stringify(lastMessage)),
        });
      }

      // Batasi penyimpanan agar tidak terlalu besar
      if (mecha.deleted.length > 100) {
        mecha.deleted = [];
      }

      const messageType = lastMessage.message ? Object.keys(lastMessage.message)[0] : "";

      // Jika pesan dihapus (protocolMessage)
      if (messageType === "protocolMessage") {
        const protocolKey = lastMessage?.message?.protocolMessage?.key;
        if (!protocolKey) return;

        const deletedMessage = mecha.deleted.find(msg => msg.key.id === protocolKey.id);
        if (!deletedMessage || typeof deletedMessage.message === "undefined") return;

        const sender = deletedMessage.key.remoteJid;
        const ownerJid = global.owner; // Owner bot
        const botJid = bot.user.id; // JID bot sendiri

        // Jika yang menghapus adalah owner atau bot sendiri, abaikan
        if (sender === ownerJid || sender === botJid) {
          mecha.deleted = mecha.deleted.filter(msg => msg.key.id !== protocolKey.id);
          return;
        }

        let deletedText = "";
        let mediaMessage = null;

        // Cek apakah pesan yang dihapus adalah teks atau media
        if (deletedMessage.message.conversation) {
          deletedText = deletedMessage.message.conversation;
        } else if (deletedMessage.message.extendedTextMessage) {
          deletedText = deletedMessage.message.extendedTextMessage.text;
        } else {
          // Jika bukan teks, berarti media (gambar, video, dll.)
          mediaMessage = deletedMessage.message;
          deletedText = "[Deleted media]";
        }

        // Kirim ke owner dengan format yang benar
        let teks = `*Someone deleted a message.*\n\n- *User*: @${sender.split('@')[0]}\n - Message will be forwarded...`;
        await mecha.sendMessage(ownerJid, {
          text: teks,
          contextInfo: { mentionedJid: [sender] },
        });

        // Jika yang dihapus adalah media, kirim ulang ke owner & user
        if (mediaMessage) {
          await mecha.copyNForward(ownerJid, deletedMessage.message, false);
          await mecha.copyNForward(sender, deletedMessage.message, false, { quoted: deletedMessage.message });
        } else {
          // Jika yang dihapus adalah teks, kirim ulang ke user dengan quoted
          await mecha.sendMessage(sender, { text: deletedText }, { quoted: func.fstatus("Deleted Message") });
        }

        // Hapus dari cache setelah diteruskan
        mecha.deleted = mecha.deleted.filter(msg => msg.key.id !== protocolKey.id);
      }
    } catch (error) {
      return errorMessage(error);
    }
  },
  private: true,
};