const axios = require('axios');
const fs = require('fs');
const FormData = require('form-data');
const { fromBuffer } = require('file-type');
const obj = {
nsfwImageDB: [],
sfwImageDB: [],
nsfwStickerDB: [],
sfwStickerDB: [],
}

exports.run = {
main: async (m, { func, mecha, groups }) => {
if (!groups.hasOwnProperty('antiporn')) {
groups.antiporn = false;
}

/* create antiporn database file if doesn't exist */
if (!fs.existsSync('./database/antiporn.json')) fs.writeFileSync('./database/antiporn.json', JSON.stringify(obj, null, 2))

if (groups.antiporn) {
if (m.fromMe) return
// if (/image\/(png|jpe?g|gif)|video\/mp4|webp/.test(m.mime)) {
if (/image\/(png|jpe?g|gif)|webp/.test(m.mime)) {
let json = JSON.parse(fs.readFileSync('./database/antiporn.json'))
if (m.mtype === 'stickerMessage') {
const fileSha256 = m.message.stickerMessage.fileSha256.toString('base64');
if (json.sfwStickerDB.includes(fileSha256)) return
if (json.nsfwStickerDB.includes(fileSha256)) {
await mecha.sendMessage(m.chat, { text: `*乂 ANTI - PORN*\n\nPorno terdeteksi!`}, { quoted: m })
await mecha.sendMessage(m.chat, { delete: m.key }) 
return false
}
} else if (m.mtype === 'imageMessage') {
const fileSha256 = (m.message?.imageMessage?.fileSha256 ?? m.message?.viewOnceMessageV2?.message?.imageMessage?.fileSha256).toString('base64');
if (json.sfwImageDB.includes(fileSha256)) return
if (json.nsfwImageDB.includes(fileSha256)) {
await mecha.sendMessage(m.chat, { text: `*乂 ANTI - PORN*\n\nPorno terdeteksi!`}, { quoted: m })
await mecha.sendMessage(m.chat, { delete: m.key }) 
return false
}
}
if (m.mtype === 'stickerMessage' && m.message.stickerMessage.isAnimated) {
return false
}
await mecha.sendReact(m.chat, '🕒', m.key)
let media = await m.download();
if (!media) return false
let url = await tmpfiles(media)
if (url) {
let image = await func.fetchJson(`https://api.ryzendesu.vip/api/tool/image-checker?url=${url}`)
if (!image.success) return mecha.sendReact(m.chat, '❌', m.key)
const result = image.result;
let isNsfw = result.status == 'rejected' || result.sensitivity > 0 || result.labels.length > 0 ? true : false;
if (isNsfw) {
if (m.mtype === 'stickerMessage') {
const fileSha256 = m.message.stickerMessage.fileSha256.toString('base64');
if (!json.nsfwStickerDB.includes(fileSha256)) {
json.nsfwStickerDB.push(fileSha256)
fs.writeFileSync('./database/antiporn.json', JSON.stringify(json, null, 2))
}
} else if (m.mtype === 'imageMessage') {
const fileSha256 = (m.message?.imageMessage?.fileSha256 ?? m.message?.viewOnceMessageV2?.message?.imageMessage?.fileSha256).toString('base64');
if (!json.nsfwImageDB.includes(fileSha256)) {
json.nsfwImageDB.push(fileSha256)
fs.writeFileSync('./database/antiporn.json', JSON.stringify(json, null, 2))
}
}
await mecha.sendMessage(m.chat, { text: `*乂 ANTI - PORN*\n\nPorno terdeteksi!`}, { quoted: m })
await mecha.sendMessage(m.chat, { delete: m.key }) 
} else {
await mecha.sendReact(m.chat, '✅', m.key)
if (m.mtype === 'stickerMessage') {
const fileSha256 = m.message.stickerMessage.fileSha256.toString('base64');
if (!json.sfwStickerDB.includes(fileSha256)) {
json.sfwStickerDB.push(fileSha256)
fs.writeFileSync('./database/antiporn.json', JSON.stringify(json, null, 2))
}
} else if (m.mtype === 'imageMessage') {
const fileSha256 = (m.message?.imageMessage?.fileSha256 ?? m.message?.viewOnceMessageV2?.message?.imageMessage?.fileSha256).toString('base64');
if (!json.sfwImageDB.includes(fileSha256)) {
json.sfwImageDB.push(fileSha256)
fs.writeFileSync('./database/antiporn.json', JSON.stringify(json, null, 2))
}
}
}
}
await func.delay(1000)
}
}
},
group: true,
botAdmin: true
}

async function tmpfiles (buffer) {
const { ext, mime } = (await fromBuffer(buffer)) || {};
const form = new FormData();
form.append("file", buffer, {
filename: `tmp.${ext}`,
contentType: mime
});
try {
const { data } = await axios.post("https://tmpfiles.org/api/v1/upload", form, {
headers: form.getHeaders()
});
const match = /https?:\/\/tmpfiles.org\/(.*)/.exec(data.data.url);
return `https://tmpfiles.org/dl/${match[1]}`;
} catch (error) {
return false;
}
}