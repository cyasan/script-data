exports.run = {
  main: async (m, { mecha }) => {
    // Daftar kata kunci frasa cinta
    let loveKeywords = ['love u', 'love you', 'lopyu', 'lapyu', 'i love u', 'i love you'];

    // Respon ketika ada yang mengetik salah satu kata kunci
    if (loveKeywords.includes(m.text?.toLowerCase().trim()) && !m.fromMe) {
      mecha.sendMessage(m.chat, { text: `I love you too, ${m.pushname}!` }, { quoted: m });
    }
  },
};