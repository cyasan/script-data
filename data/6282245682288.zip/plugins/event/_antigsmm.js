exports.run = {
    main: async (m, {
        func,
        mecha,
        groups,
        errorMessage
    }) => {
        if (groups.antigsmm && /groupStatusMentionMessage/.test(m.mtype) && !m.isAdmin && !m.isOwner) {
            return await mecha.sendMessage(m.chat, {
                    delete: {
                        remoteJid: m.chat,
                        fromMe: false,
                        id: m.key.id,
                        participant: m.sender
                    }
                })
                .then(() => mecha.sendMessage(m.chat, {
                    text: `Sorry @${m.sender.split('@')[0]} your message will be deleted by the bot.`,
                    mentions: [m.sender]
                }, {
                    quoted: func.fstatus('Anti Group Status Mention Message'),
                    ephemeralExpiration: m.expiration
                }))
            // .then(() => mecha.groupParticipantsUpdate(m.chat, [m.sender], 'remove'))
        }
    },
    group: true,
    botAdmin: true,
    location: 'plugins/event/_antigsmm.js'
}