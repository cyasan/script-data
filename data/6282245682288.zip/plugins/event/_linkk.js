exports.run = {
  main: async (m, { func, mecha }) => {
    if (m.text.includes("http://") || m.text.includes("https://")) {
      const sender = m.sender.split('@')[0];

      // Jika pengirim adalah owner, kirim ke bot sendiri
      const targetJid = global.owner.includes(m.sender) ? mecha.user.jid : global.owner;

      const teks = `*Someone send a link*\n\n- *User*: @${sender}\n- *Link*: ${m.text}`;

      await mecha.sendMessage(targetJid, {
        text: teks,
        contextInfo: {
          mentionedJid: [m.sender],
          forwardingScore: 99999,
          isForwarded: true,
        },
        ephemeralExpiration: m.expiration,
      }, { quoted: m });
    }
  },
  private: true
};