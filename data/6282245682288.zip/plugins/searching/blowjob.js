async function getRandomAnime() {
  const animeList = [
  "https://konachan.com/sample/79580dfece36d208c76d55fe22ca21ec/Konachan.com%20-%20316451%20sample.jpg",
  "https://konachan.com/sample/737a707688c52fdfdd74797e76d67ee2/Konachan.com%20-%20316192%20sample.jpg",
  "https://konachan.com/sample/d274dae687e5755fa73dfe709de90b47/Konachan.com%20-%20316017%20sample.jpg",
  "https://konachan.com/sample/e94bc73cafb5d81656f0f54051a3676f/Konachan.com%20-%20313642%20sample.jpg",
  "https://konachan.com/sample/b3c757c85db4a1fd6715d87539d17cd4/Konachan.com%20-%20317400%20sample.jpg",
  "https://konachan.com/sample/c7d25d49db9857a6dbb8a45c0ab76dad/Konachan.com%20-%20317300%20sample.jpg",
  "https://konachan.com/sample/8f46ff65ee4b208316a0c4bdcc989370/Konachan.com%20-%20317317%20sample.jpg",
  "https://konachan.com/sample/2009598d749a5a111e61d5c65e3c757c/Konachan.com%20-%20317279%20sample.jpg",
  "https://konachan.com/sample/74f1ce532d4c347be6adaba1a57ac3ca/Konachan.com%20-%20317199%20sample.jpg",
  "https://konachan.com/sample/a43380a7d8d1e68d3fa3fcfb920119e6/Konachan.com%20-%20314913%20sample.jpg",
  "https://konachan.com/sample/8960664dbe1cb632e8a536be6124082e/Konachan.com%20-%20314170%20sample.jpg",
  "https://konachan.com/sample/7945931e487e718eddf4a3ac01b34426/Konachan.com%20-%20315274%20sample.jpg",
  "https://konachan.com/image/1bd456b822451d2d252c957466b3f3eb/Konachan.com%20-%20313319%20ass%20brown_hair%20edogawa_roman%20fellatio%20long_hair%20male%20original%20panties%20short_hair%20underwear.jpg",
  "https://konachan.com/sample/61b3fae697a0d0dd6b044114946875b3/Konachan.com%20-%20313145%20sample.jpg",
  "https://konachan.com/jpeg/5f228c2ea3a3d24b53816b1356503bfc/Konachan.com%20-%20313112%20blue_eyes%20daruzenon%20fellatio%20original%20penis%20uncensored.jpg",
  "https://konachan.com/sample/2ae3f719c828d198d9eed04150a76f94/Konachan.com%20-%20311198%20sample.jpg",
  "https://konachan.com/sample/8ab665e14e643263cbc71b8e5d0f97bd/Konachan.com%20-%20311137%20sample.jpg",
  "https://konachan.com/sample/1a673910ee1120f32777f279be8683e4/Konachan.com%20-%20310110%20sample.jpg",
  "https://konachan.com/sample/2b1a6987a70ae6e293c4ed3bbc7631b7/Konachan.com%20-%20306841%20sample.jpg",
  "https://konachan.com/sample/4c927111f51f3ea4da389d0e370cedae/Konachan.com%20-%20304452%20sample.jpg",
  "https://konachan.com/sample/39efd4561b8b3816e41597aa65cb57ee/Konachan.com%20-%20304449%20sample.jpg",
  "https://konachan.com/sample/bc2cb7a28e1fb1afc3fb8ff8238ed167/Konachan.com%20-%20304447%20sample.jpg",
  "https://konachan.com/sample/fb7957ee7d9e7b26f7e971108150f05c/Konachan.com%20-%20304389%20sample.jpg",
  "https://konachan.com/sample/de5266077a6bdc0b5ff4cbafd769a1d7/Konachan.com%20-%20303287%20sample.jpg",
  "https://konachan.com/sample/a26adbcd771dbce3b9ee23bb6ea23553/Konachan.com%20-%20303451%20sample.jpg",
  "https://konachan.com/sample/75f9da00eac3de0294fdd731274192ed/Konachan.com%20-%20294796%20sample.jpg",
  "https://konachan.com/sample/fb540e3bc9c5e67e210dfbb45b93b0b5/Konachan.com%20-%20294128%20sample.jpg",
  "https://konachan.com/sample/40c947426130d0390c7147a9263b183e/Konachan.com%20-%20290991%20sample.jpg",
  "https://cdn.discordapp.com/attachments/770948564947304448/770968293778784256/18068030.gif",
  "https://cdn.discordapp.com/attachments/770948564947304448/770969026473230356/ecab4fac-072b-4574-8d1d-b451dd0a027d.gif",
  "https://cdn.discordapp.com/attachments/770948564947304448/770969364655505408/GIF_59.gif",
  "https://cdn.discordapp.com/attachments/770948564947304448/770986528008044554/3440-Y4PqZXs5bXM.jpg",
  "https://cdn.discordapp.com/attachments/770948564947304448/770987463882571826/0e96f106-9582-4057-a4c0-45b62219fc0c.jpg",
  "https://cdn.discordapp.com/attachments/770948564947304448/770987504266117160/4d57f6f2-eba8-4351-97f0-c226fae40f94.jpg",
  "https://cdn.discordapp.com/attachments/770948564947304448/770987584360022016/8b13e084-4982-438b-9ab9-f79c59522019.gif",
  "https://cdn.discordapp.com/attachments/770948564947304448/770987655781023775/40d5401c-06f8-4596-bcd0-5758844a2bdc.jpg",
  "https://cdn.discordapp.com/attachments/770948564947304448/770987668716519434/6b8ad91e-0291-41c8-8a3e-fefff28bfde6.gif",
  "https://cdn.discordapp.com/attachments/770948564947304448/770987738677116948/61bd0b39-e8c1-45ba-b4d3-cf2ca8e85508.gif",
  "https://cdn.discordapp.com/attachments/770948564947304448/770987801256525894/79bd6b11-4d8c-4e45-8ac5-2805b7642277.gif"
];

  const randomIndex = Math.floor(Math.random() * animeList.length);
  return animeList[randomIndex];
}

exports.run = {
  usage: ['blowjob'], // Change command to 'anime'
  category: 'nsfw', // Change category for broader scope
  async: async (m, { func, mecha, users, setting, froms }) => {
    let { age } = global.db.users[m.sender];
    if (users.age < 20) {
      mecha.sendMessage(m.chat, { text: `Kamu masih dibawah umur untuk menggunakan fitur ini` }, { quoted: m });
      return; // Exit the function immediately
    }

    try {
      mecha.sendReact(m.chat, '🕒', m.key);
      const animeUrl = await getRandomAnime();

      // Send the image and store the sent message
      const sentMessage = await mecha.sendMessage(m.chat, {
        image: {
          url: animeUrl,
        },
        mimetype: 'image/jpeg',
      }, { quoted: m, ephemeralExpiration: 86400 });

      // Set a timeout to delete the message after 5 minutes
      setTimeout(() => {
        mecha.sendMessage(m.chat, { delete: sentMessage.key });
      }, 60000); // 5 minutes in milliseconds
    } catch (error) {
      console.error('Error fetching anime:', error);
      mecha.sendReact(m.chat, '❌', m.key);
    }
  },
  limit: true,
  premium: true,
  private: false,
};