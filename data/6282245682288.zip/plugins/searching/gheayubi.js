async function getRandomAnime() {
  const animeList = [
  "https://l.top4top.io/m_1931ufrul0.mp4",
  "https://a.top4top.io/m_1931jbdpk1.mp4",
  "https://c.top4top.io/m_1931aj9nm2.mp4",
  "https://d.top4top.io/m_1931cnsal3.mp4",
  "https://e.top4top.io/m_1931d4kc74.mp4",
  "https://f.top4top.io/m_1931bih8q5.mp4",
  "https://g.top4top.io/m_1931xx7aa6.mp4",
  "https://h.top4top.io/m_1931g3zsq7.mp4",
  "https://a.top4top.io/m_1931m74wd0.mp4",
  "https://b.top4top.io/m_1931p8tfm1.mp4",
  "https://e.top4top.io/m_1931aj8iv0.mp4",
  "https://f.top4top.io/m_1931szguy1.mp4",
  "https://g.top4top.io/m_1931l73ry2.mp4",
  "https://h.top4top.io/m_1931yhznj3.mp4",
  "https://i.top4top.io/m_1931kmtp34.mp4",
  "https://j.top4top.io/m_1931snhdg5.mp4",
  "https://k.top4top.io/m_1931ay1jz6.mp4",
  "https://l.top4top.io/m_1931x70mk7.mp4",
  "https://a.top4top.io/m_19319mvvf8.mp4",
  "https://b.top4top.io/m_1931icmzd9.mp4",
  "https://h.top4top.io/m_19316oo0s0.mp4",
  "https://i.top4top.io/m_1931cvvpt1.mp4"
];

  const randomIndex = Math.floor(Math.random() * animeList.length);
  const randomAnime = animeList[randomIndex];

  return randomAnime;
}

// Helper function to generate random source and date
function getRandomSource() {
  const sources = ['Twitter', 'Telegram', 'TikTok'];
  return sources[Math.floor(Math.random() * sources.length)];
}

function getRandomDate() {
  const startDate = new Date('2023-10-13');
  const endDate = new Date('2024-01-06');
  const randomDate = new Date(startDate.getTime() + Math.random() * (endDate - startDate));
  return randomDate.toLocaleDateString('id-ID');
}

exports.run = {
  usage: ['gheayubi'],
  category: 'asupan',
  async: async (m, { func, mecha, users, setting, froms }) => {
    if (users.age < 28) {
      mecha.sendMessage(m.chat, { text: `Kamu masih di bawah umur untuk menggunakan fitur ini.` }, { quoted: m });
      return;
    }

    try {
      mecha.sendReact(m.chat, '🕒', m.key); // Send loading indicator
      const animeUrl = await getRandomAnime();

      if (isValidVideoUrl(animeUrl) && isAppropriateContent(animeUrl)) {
        const caption = `*ASUPAN - GHEAYUBI*\n\nSumber: ${getRandomSource()}\nPublished on: ${getRandomDate()}`;
        
        mecha.sendMessage(
          m.chat,
          {
            video: {
              url: animeUrl,
            },
            mimetype: 'video/mp4',
              caption: caption,
          },
          { quoted: m, ephemeralExpiration: 86400 }
        );
      } else {
        m.reply(`Maaf, terjadi kesalahan saat mengambil video Gheayubi.`);
      }
    } catch (error) {
      console.error('Error fetching anime:', error);
      mecha.sendReact(m.chat, '❌', m.key); // Error indicator
    }
  },
  limit: true,
  premium: true,
  private: true,
};

function isValidVideoUrl(url) {
  return true; // Replace with actual validation logic
}

function isAppropriateContent(url) {
  return true; // Replace with actual content filtering logic
}