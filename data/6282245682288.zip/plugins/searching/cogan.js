async function getRandomAnime() {
  const animeList = [
  'https://files.catbox.moe/968cle.jpg',
'https://files.catbox.moe/ixcgi0.jpg',
'https://files.catbox.moe/0f62j3.jpg',
'https://files.catbox.moe/0jfxjg.jpg',
'https://files.catbox.moe/tfmp8s.jpg',
'https://files.catbox.moe/c4gwwg.jpg',
'https://files.catbox.moe/95qazx.jpg',
'https://files.catbox.moe/lrjzrz.jpg',
'https://files.catbox.moe/ko4lgd.jpg',
'https://files.catbox.moe/35airj.jpg',
'https://files.catbox.moe/udaovp.jpg',
'https://files.catbox.moe/n3at7s.jpg',
'https://files.catbox.moe/x4gfgy.jpg',
'https://files.catbox.moe/8wauyk.jpg',
'https://files.catbox.moe/6oe98l.jpg',
'https://files.catbox.moe/q1wl8l.jpg',
'https://files.catbox.moe/p03zjk.jpg',
'https://files.catbox.moe/nace7w.jpg',
'https://files.catbox.moe/i4we2n.jpg',
'https://files.catbox.moe/14drbu.jpg',
'https://files.catbox.moe/lrjzrz.jpg',
'https://files.catbox.moe/v1ffjw.jpg',
'https://files.catbox.moe/bpoy39.jpg',
'https://files.catbox.moe/nnwpz2.jpg',
'https://files.catbox.moe/ohlkw3.jpg',
'https://files.catbox.moe/sdmder.jpg',
'https://files.catbox.moe/he6uff.jpg',
'https://files.catbox.moe/deak4b.jpg',
'https://files.catbox.moe/rjo8me.jpg',
'https://files.catbox.moe/c7j6cj.jpg',
'https://files.catbox.moe/wyfe1p.jpg',
'https://files.catbox.moe/4h9cin.jpg',
'https://files.catbox.moe/mbg3m4.jpg',
'https://files.catbox.moe/t1h75x.jpg',
'https://files.catbox.moe/6grs6b.jpg',
'https://files.catbox.moe/sqklgs.jpg',
'https://files.catbox.moe/n391ts.jpg',
'https://files.catbox.moe/deg578.jpg',
'https://files.catbox.moe/v4f5d8.jpg',
'https://files.catbox.moe/m0bpqi.jpg',
'https://files.catbox.moe/dth7ck.jpg',
'https://files.catbox.moe/px5jz4.jpg',
'https://files.catbox.moe/iqs35z.jpg',
'https://files.catbox.moe/ie3nwx.jpg',
'https://files.catbox.moe/hc3vec.jpg',
'https://files.catbox.moe/s63hhe.jpg',
  ];

  const randomIndex = Math.floor(Math.random() * animeList.length);
  const randomAnime = animeList[randomIndex];

  return randomAnime;
}

exports.run = {
  usage: ['cogan'], // Change command to 'anime'
  category: 'asupan', // Change category for broader scope
  async: async (m, { func, mecha, users, setting, froms }) => {

    try {
      mecha.sendReact(m.chat, '🕒', m.key);
      const animeUrl = await getRandomAnime();
      // Send the image only if the user is an adult
      mecha.sendMessage(m.chat, {
        image: {
          url: animeUrl,
        },
        mimetype: 'image/jpeg',
      }, { quoted: m, ephemeralExpiration: 86400 });
    } catch (error) {
      console.error('Error fetching anime:', error);
      mecha.sendReact(m.chat, '❌', m.key);
    }
  },
limit: 2,
};