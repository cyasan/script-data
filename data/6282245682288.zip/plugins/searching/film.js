const axios = require("axios");

exports.run = {
  usage: ['film'],
  category: 'searching',
  use: 'judul film',
  async: async (m, { func, mecha }) => {
    if (!m.text) return mecha.reply(m.chat, func.example(m.cmd, 'Inception'), m);

    mecha.sendReact(m.chat, '🕒', m.key); // Tampilkan reaksi loading

    try {
      const apiKey = "742b2d09"; // API Key OMDB
      const url = `http://www.omdbapi.com/?apikey=${apiKey}&t=${encodeURIComponent(m.text)}&plot=full`;

      let { data } = await axios.get(url);

      if (data.Response === "False") return mecha.reply(m.chat, "Film tidak ditemukan. Pastikan judul benar!", m);

      let poster = data.Poster !== "N/A" ? data.Poster : "https://via.placeholder.com/300x450?text=No+Poster";

      let imdbInfo = `乂 *SEARCHING FILM*\n\n`;
      imdbInfo += `- *Judul:* ${data.Title}\n`;
      imdbInfo += `- *Tahun:* ${data.Year}\n`;
      imdbInfo += `- *Rating:* ${data.Rated}\n`;
      imdbInfo += `- *Rilis:* ${data.Released}\n`;
      imdbInfo += `- *Durasi:* ${data.Runtime}\n`;
      imdbInfo += `- *Genre:* ${data.Genre}\n`;
      imdbInfo += `- *Sutradara:* ${data.Director}\n`;
      imdbInfo += `- *Penulis:* ${data.Writer}\n`;
      imdbInfo += `- *Aktor:* ${data.Actors}\n`;
      imdbInfo += `- *Plot:* ${data.Plot}\n`;
      imdbInfo += `- *Bahasa:* ${data.Language}\n`;
      imdbInfo += `- *Negara:* ${data.Country}\n`;
      imdbInfo += `- *Penghargaan:* ${data.Awards}\n`;
      imdbInfo += `- *Box Office:* ${data.BoxOffice || '-'}\n`;
      imdbInfo += `- *Produksi:* ${data.Production || '-'}\n`;
      imdbInfo += `- *IMDb Rating:* ${data.imdbRating}\n`;
      imdbInfo += `- *IMDb Votes:* ${data.imdbVotes}\n`;

      await mecha.sendMessage(m.chat, {
        image: { url: poster },
        caption: imdbInfo
      }, { quoted: m });

      mecha.sendReact(m.chat, '✅', m.key); // Tampilkan reaksi sukses
    } catch (err) {
      mecha.reply(m.chat, "Terjadi kesalahan saat mencari film.", m);
    }
  },
  limit: 5
};