async function getRandomAnime() {
  const animeList = [
  'https://i.pinimg.com/474x/32/39/f9/3239f903389560d013f00c14ac13b051.jpg',
  'https://i.pinimg.com/474x/bc/59/a7/bc59a7e1a4400ca6bd127b64e747610e.jpg',
  'https://i.pinimg.com/originals/79/93/13/7993135a4ec10e3e15a2b6c34148f2d1.jpg',
  'https://i.pinimg.com/474x/8a/78/f0/8a78f0c00bd57db58d6d93e0661cbb9e.jpg',
  'https://i.pinimg.com/originals/aa/1e/2a/aa1e2a7a5ef917eea95418ac30d7c123.jpg',
  'https://i.pinimg.com/474x/4e/24/38/4e24388508d9c074b154153ddfb557ef.jpg',
  'https://i.pinimg.com/originals/5b/5d/8f/5b5d8f85d33a1e6d29410c62934a74d9.jpg',
  'https://i.pinimg.com/originals/fa/e5/93/fae59328dd8f7115ebf37f75833870b0.jpg',
  'https://i.pinimg.com/originals/2e/48/da/2e48da5f0a700cb5a38e16d67fdb321c.jpg',
  'https://i.pinimg.com/originals/84/ca/74/84ca74f8dae935497a16e4ec0050506a.jpg',
  'https://i.pinimg.com/474x/4c/3f/d4/4c3fd4780e4e05a3d6c1236a792f9780.jpg',
  'https://i.pinimg.com/originals/99/04/ff/9904ff7f65768c34eaff7d553ec15fbf.jpg',
  'https://i.pinimg.com/474x/c1/65/ea/c165ea7a8392e8cbce470bb19e3f9e98.jpg',
  'https://i.pinimg.com/originals/7c/d3/9c/7cd39c72fce95c72c6af5f4e6521d449.png',
  'https://i.pinimg.com/originals/9d/8c/83/9d8c83ac0f9034004f1b5707a57ea61c.jpg',
  'https://i.pinimg.com/originals/7a/d9/ac/7ad9acbf22efb94f48d850f850a558b1.jpg',
  'https://i.pinimg.com/474x/dc/82/5d/dc825da9696edc3f1189fa95eeab23b3.jpg',
  'https://i.pinimg.com/originals/61/c4/eb/61c4ebc26a3f3a6a615aec1b06890e88.jpg',
  'https://i.pinimg.com/originals/92/71/fc/9271fc36743b9dcc3f79538e249a3286.jpg',
  'https://i.pinimg.com/originals/30/50/f3/3050f3a895f553f5fc5ae3d37e361206.png',
  'https://i.pinimg.com/originals/50/c5/35/50c5356c9376f17c0f4936f04ead0bee.png',
  'https://i.pinimg.com/originals/ec/f2/7a/ecf27a030e802393bbaae7a88ad8cab8.jpg',
  'https://i.pinimg.com/originals/53/7f/92/537f92e9d6ff74f3393c4f10171f4f8f.jpg',
  'https://i.pinimg.com/originals/ec/8b/e7/ec8be7202ab7d3ab46274206f2250d78.png',
  'https://i.pinimg.com/originals/cd/f2/50/cdf250832867d59c5f61fa5f5408bb77.jpg',
  'https://i.pinimg.com/originals/a2/47/a2/a247a2c95c443820adaa064d610f3100.jpg',
  'https://i.pinimg.com/originals/03/12/94/03129462677b8f64369a0414e70001cc.jpg',
  'https://i.pinimg.com/originals/a6/18/3b/a6183ba2bc05ce580f09261d077e7714.jpg',
  'https://i.pinimg.com/originals/ff/5f/8e/ff5f8ef44ffdc32bfbcf1da74c57508a.jpg',
  'https://i.pinimg.com/originals/73/91/99/739199170653771b2e4a9e97033837c3.jpg',
  'https://i.pinimg.com/474x/8a/d4/12/8ad41235600defa8459b37f0972ee68e.jpg',
  'https://i.pinimg.com/474x/8a/07/85/8a078526f2aeb58b6da4c5de2a5af218.jpg',
  'https://i.pinimg.com/474x/ad/49/56/ad4956ee836bbb04f06e7e0902f3bd7b.jpg',
  'https://i.pinimg.com/originals/ea/7d/d6/ea7dd6bec347e1f831ce50868bc72458.png',
  'https://i.pinimg.com/originals/ed/e0/da/ede0da234f1cc79fae4f48849b481aed.jpg',
  'https://i.pinimg.com/originals/5f/01/fd/5f01fdbf822aa68a0e9338ad7c23c13b.jpg',
  'https://i.pinimg.com/originals/60/47/8b/60478b5cf784d5535f1bf3a3a09d4761.jpg',
  'https://i.pinimg.com/474x/3c/e4/d4/3ce4d41f85f1f40ca216da22b35faac9.jpg',
  'https://i.pinimg.com/564x/84/f4/99/84f499b7ee645c823524b9751226915f.jpg',
  'https://i.pinimg.com/originals/96/df/94/96df941bd5e065fd8518c60530bfc334.jpg',
  'https://i.pinimg.com/originals/39/d0/05/39d005ddf4b7bffc7b0e81bc88d1c586.png',
  'https://i.pinimg.com/originals/8d/a8/43/8da843ed8fe2085b14424119d9be1544.png',
  'https://i.pinimg.com/originals/b2/3a/79/b23a792d44249c847d25710811fb0a3d.jpg',
  'https://i.pinimg.com/originals/18/39/4d/18394de7dedd03eb6d8599a56b4c9740.jpg',
  'https://i.pinimg.com/originals/bb/c9/11/bbc9112520e6c9d0f999f245a6e040e6.jpg',
  'https://i.pinimg.com/736x/26/49/56/2649568bf4b990e30fd8658feb1ed27c.jpg',
  'https://i.pinimg.com/736x/10/93/78/109378abfb41a8cc96ffcb25141a0a09.jpg',
  'https://i.pinimg.com/736x/ac/af/b1/acafb1151cd88c28ca40f490cb9e015c.jpg',
  'https://i.pinimg.com/564x/c8/ab/96/c8ab96c72ba10ff1103a63ad67f8dd35.jpg',
  'https://i.pinimg.com/originals/72/a5/00/72a500ed59662e83f7d9472f21086d7f.jpg',
  'https://i.pinimg.com/originals/77/c0/48/77c048d15eb33e50a3381446b828faac.jpg',
  'https://i.pinimg.com/474x/97/93/ab/9793ab2782f302e79a220a82386767df--el-anime-manga-anime.jpg',
  'https://i.pinimg.com/600x315/d6/c0/52/d6c0524c75b9b5902cd319879f98ed8d.jpg',
  'https://i.pinimg.com/originals/70/70/62/7070621fde305d51a3bf80bf013e8d25.jpg',
  'https://i.pinimg.com/originals/78/87/19/788719dec49e0569194b5762a81dd9ba.jpg',
  'https://i.pinimg.com/474x/1e/b2/c4/1eb2c4228e48ec7208934dde658d88b1.jpg',
  'https://i.pinimg.com/originals/dd/64/5f/dd645fc8cbedad8975cce132c2771e9d.jpg',
  'https://i.pinimg.com/564x/cd/99/62/cd9962355e924135e27a4cbde3eae3ab.jpg',
  'https://i.pinimg.com/originals/2d/a0/1b/2da01b0cc5c8bc667a2b71c049241f14.jpg',
  'https://i.pinimg.com/originals/fa/47/bd/fa47bd5e171e463cd9cc5bd7966dd350.jpg',
  'https://i.pinimg.com/originals/54/dc/8c/54dc8c3504a91c0ad09ae8de40c0013d.jpg',
  'https://i.pinimg.com/originals/8e/dd/d9/8eddd9863967cbac19de2a21518e0b8d.jpg',
  'https://i.pinimg.com/736x/93/e4/4a/93e44a567ed1319039f63c7f842d8351.jpg',
  'https://i.pinimg.com/474x/89/66/a2/8966a227e74c119e041b9dfb3c9fd4ca.jpg',
  'https://i.pinimg.com/originals/48/e4/1c/48e41ce8e76a04a7f6ae27807b292417.jpg',
  'https://i.pinimg.com/originals/2e/4f/c6/2e4fc64d5c95179347e77cf288c78a8a.jpg',
  'https://i.pinimg.com/736x/19/10/09/191009c6db8ac354b65822680fe63709.jpg',
  'https://i.pinimg.com/originals/71/24/98/712498972bfcb5a1983c515e5feccdb2.jpg',
  'https://i.pinimg.com/736x/ae/f8/1d/aef81d5a4be1a16a3b4085468eaef751.jpg',
  'https://i.pinimg.com/736x/e6/20/92/e62092d9291838c73be4d6c4f5d1a8b1.jpg',
  'https://i.pinimg.com/originals/95/ef/72/95ef72704202c0cd1feb3ea6a0477d9d.jpg',
  'https://i.pinimg.com/originals/0e/dd/d0/0eddd016f6b9bd7e5cd90221ecb8af34.jpg',
  'https://i.pinimg.com/736x/d8/e3/61/d8e361a0551692626cea01e4f84dd72a.jpg',
  'https://i.pinimg.com/originals/80/61/3d/80613ddef3818ef12458b803e4e8eb7b.jpg',
  'https://i.pinimg.com/originals/e5/43/63/e5436300f636d70294eb196d5c4f82d4.jpg',
  'https://i.pinimg.com/474x/68/f4/fd/68f4fdb3d5adee8cdd158b8a29743c1f.jpg',
  'https://i.pinimg.com/originals/af/12/3e/af123e1d5e2d8f3b0546d590306c1c23.jpg',
  'https://i.pinimg.com/originals/ec/11/a5/ec11a55a681eaea48a1fc9dd834e63b2.jpg',
  'https://i.pinimg.com/originals/e1/bd/f2/e1bdf2e789cd3c7af47b0755988b11d5.jpg',
  'https://i.pinimg.com/474x/ae/3d/44/ae3d4457094a6a236eb4ef369ca0c016--voice-actor-maid-sama.jpg',
  'https://i.pinimg.com/474x/20/ac/6d/20ac6d17439ce0b85df6daedcd36df6d--maid-sama-misaki.jpg',
  'https://i.pinimg.com/564x/be/6d/2f/be6d2f5848a7bab71550d11e7c516d2b--the-president-maid-sama.jpg',
  'https://i.pinimg.com/originals/4f/ac/a8/4faca8220fd54be802a1b54808497f71.jpg',
  'https://i.pinimg.com/originals/c1/d3/a4/c1d3a4400a4ebe9673d97e4c11c82786.jpg',
  'https://i.pinimg.com/originals/e7/df/14/e7df142c1846b51d58cbde4f175cbb13.gif',
  'https://i.pinimg.com/564x/f7/2c/bf/f72cbfa746937ad56ec693fee658618e.jpg',
  'https://i.pinimg.com/originals/d0/55/17/d05517c44373890ae8e4a8b39c774d14.png',
  'https://i.pinimg.com/originals/f4/35/f6/f435f6279c7fa7793db887371429113f.jpg',
  'https://i.pinimg.com/originals/19/44/b0/1944b05d8614ecda6bf0dc48dac66df7.jpg',
  'https://i.pinimg.com/originals/cf/97/52/cf975225a5f6a5a21262510c96f4c02b.jpg',
  'https://i.pinimg.com/736x/b8/fa/45/b8fa45ce0e97b4b07570068e3ff77bc1--desktop-wallpapers-wallpaper-backgrounds.jpg',
  'https://i.pinimg.com/originals/23/de/88/23de886d06bce36035e6a8ecd15f262e.jpg',
  'https://i.pinimg.com/originals/3d/2f/64/3d2f6417e388126bd6c2a7d1ff0dca62.jpg',
  'https://i.pinimg.com/280x280_RS/ce/ed/ef/ceedef8faa4467502994e3244082c8e8.jpg',
  'https://i.pinimg.com/474x/42/93/14/429314d5da5e867922e287b953dd6029--maid-outfit-maid-sama.jpg',
  'https://i.pinimg.com/originals/d5/d3/be/d5d3beff9d817000c9c1c5002e32aa13.gif',
  'https://i.pinimg.com/originals/5a/21/86/5a21869da69e2593dace73561d634eb4.jpg',
  'https://i.pinimg.com/originals/0c/c5/8f/0cc58fa6341c88e6e3ed779ec2ff3352.jpg',
  'https://i.pinimg.com/originals/63/60/d0/6360d01da52125f987501fc0390f8d50.png',
  'https://i.pinimg.com/736x/4f/3c/e8/4f3ce8ad3107860051c1e938467ffa2b--otaku-problems-maid-sama.jpg'
];

  const randomIndex = Math.floor(Math.random() * animeList.length);
  const randomAnime = animeList[randomIndex];

  return randomAnime;
}

exports.run = {
  usage: ['ayuzawa'], // Change command to 'anime'
  category: 'anime', // Change category for broader scope
  async: async (m, { func, mecha, users, setting, froms }) => {

    try {
      mecha.sendReact(m.chat, '🕒', m.key);
      const animeUrl = await getRandomAnime();

      // Send the image with the caption as part of the message object
      mecha.sendMessage(m.chat, {
        image: {
          url: animeUrl,
        },
        caption: '乂 *AYUZAWA*',
      }, { quoted: m, ephemeralExpiration: 86400 });
    } catch (error) {
      console.error('Error fetching anime:', error);
      mecha.sendReact(m.chat, '❌', m.key);
    }
  },
  limit: true,
};