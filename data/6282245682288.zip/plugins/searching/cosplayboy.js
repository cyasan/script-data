async function getRandomAnime() {
  const animeList = [
'https://files.catbox.moe/yjjtn6.jpg',
'https://files.catbox.moe/w38002.jpg',
'https://files.catbox.moe/vftas2.jpg',
'https://files.catbox.moe/wijpd0.jpg',
'https://files.catbox.moe/cpzo6a.jpg',
'https://files.catbox.moe/ez2c64.jpg',
'https://files.catbox.moe/nehwcm.jpg',
'https://files.catbox.moe/mmeshf.jpg',
'https://files.catbox.moe/h3rq5h.jpg',
'https://files.catbox.moe/ygqlj8.jpg',
  ];

  const randomIndex = Math.floor(Math.random() * animeList.length);
  const randomAnime = animeList[randomIndex];

  return randomAnime;
}

exports.run = {
  usage: ['cosplayboy'],
hidden: ['cpboy'], 
  category: 'asupan', // Change category for broader scope
  async: async (m, { func, mecha, users, setting, froms }) => {

    try {
      mecha.sendReact(m.chat, '🕒', m.key);
      const animeUrl = await getRandomAnime();
      // Send the image only if the user is an adult
      mecha.sendMessage(m.chat, {
        image: {
          url: animeUrl,
        },
        mimetype: 'image/jpeg',
      }, { quoted: m, ephemeralExpiration: 86400 });
    } catch (error) {
      console.error('Error fetching anime:', error);
      mecha.sendReact(m.chat, '❌', m.key);
    }
  },
limit: 2,
};