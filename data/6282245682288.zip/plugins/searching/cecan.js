async function getRandomAnime() {
  const animeList = [
'https://files.catbox.moe/wn5n8o.jpg',
'https://files.catbox.moe/iafq9w.jpg',
'https://files.catbox.moe/kuz07k.jpg',
'https://files.catbox.moe/lo5o75.jpg',
'https://files.catbox.moe/83ubm6.jpg',
'https://files.catbox.moe/yqmdua.jpg',
'https://files.catbox.moe/mon3ab.jpg',
'https://files.catbox.moe/93iil3.jpg',
'https://files.catbox.moe/n9z418.jpg',
'https://files.catbox.moe/5tyz0r.jpg',
'https://files.catbox.moe/v5tkqg.jpg',
'https://files.catbox.moe/hawg6q.jpg',
'https://files.catbox.moe/pyzkmi.jpg',
'https://files.catbox.moe/om64ov.jpg',
'https://files.catbox.moe/9m21i3.jpg',
'https://files.catbox.moe/zx94kc.jpg',
'https://files.catbox.moe/yazvgp.jpg',
'https://files.catbox.moe/0agtdj.jpg',
'https://files.catbox.moe/2m0at4.jpg',
'https://files.catbox.moe/y2ep7b.jpg',
'https://files.catbox.moe/yh5t18.jpg',
'https://files.catbox.moe/o7bojb.jpg',
'https://files.catbox.moe/dkruxb.jpg',
'https://files.catbox.moe/cf2gu5.jpg',
'https://files.catbox.moe/s2icmx.jpg',
'https://files.catbox.moe/oi82l7.jpg',
'https://files.catbox.moe/ptea7r.jpg',
'https://files.catbox.moe/lm2zft.jpg',
'https://files.catbox.moe/cncjkq.jpg',
'https://files.catbox.moe/m0jyeq.jpg',
'https://files.catbox.moe/mplzgt.jpg',
'https://files.catbox.moe/0jzmy4.jpg',
'https://files.catbox.moe/3frkm7.jpg',
'https://files.catbox.moe/ob7s5a.jpg',
'https://files.catbox.moe/60jufb.jpg',
'https://files.catbox.moe/zs23c1.jpg',
'https://files.catbox.moe/hrgn98.jpg',
'https://files.catbox.moe/xho1km.jpg',
'https://files.catbox.moe/g6k0jp.png',
'https://files.catbox.moe/040gi1.jpg',
'https://files.catbox.moe/aqvg23.jpg',
'https://files.catbox.moe/1lwpzl.jpg',
'https://files.catbox.moe/wquuvv.jpg',
'https://files.catbox.moe/l69fo3.jpg',
'https://files.catbox.moe/rv7x94.jpg',
'https://files.catbox.moe/4x44dw.jpg',
'https://files.catbox.moe/j2ovxk.jpg',
'https://files.catbox.moe/p3pe9k.jpg',
'https://files.catbox.moe/lhew4n.jpg',
'https://files.catbox.moe/72iefw.jpg',
  ];

  const randomIndex = Math.floor(Math.random() * animeList.length);
  const randomAnime = animeList[randomIndex];

  return randomAnime;
}

exports.run = {
  usage: ['cecan'], // Change command to 'anime'
  category: 'asupan', // Change category for broader scope
  async: async (m, { func, mecha, users, setting, froms }) => {

    try {
      mecha.sendReact(m.chat, '🕒', m.key);
      const animeUrl = await getRandomAnime();
      // Send the image only if the user is an adult
      mecha.sendMessage(m.chat, {
        image: {
          url: animeUrl,
        },
        mimetype: 'image/jpeg',
      }, { quoted: m, ephemeralExpiration: 86400 });
    } catch (error) {
      console.error('Error fetching anime:', error);
      mecha.sendReact(m.chat, '❌', m.key);
    }
  },
limit: 2,
};