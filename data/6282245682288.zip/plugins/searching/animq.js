const axios = require('axios');
const cheerio = require('cheerio');

async function livechartlatest() {
    return new Promise((resolve, reject) => {
        const abc = "https://www.livechart.me";

        axios.get(abc)
            .then(({ data }) => {
                const $ = cheerio.load(data);
                const catoz = [];

                // Iterasi untuk mendapatkan data anime terbaru
                $('div[class="anime-card"]').each((a, b) => {
                    const o = $(b).find("img").attr("src"); // Gambar poster
                    const g = $(b).find("img").attr("alt"); // Judul anime
                    const x = $(b).find(".poster-container").children(".episode-countdown").text(); // Episode countdown
                    const m = $(b).find('.anime-info').children(".anime-studios").text(); // Studio
                    const h = $(b).find(".anime-synopsis").text(); // Sinopsis
                    const j = $(b).find(".anime-extras").text(); // Info tambahan
                    const w = $(b).find(".anime-info").text(); // Informasi rilis
                    const f = $(b).find(".anime-tags li").map((i, el) => $(el).text()).get().join(" "); // Tags anime
                    const q = "scraper-by catozolala"; // Author (custom)
                    const u = $(b).find(`h3.main-title`).children("a").attr('href'); // URL link anime

                    // Push data anime terbaru ke array
                    catoz.push({
                        author: q,
                        image: o,
                        title: g,
                        eps: x,
                        studio: m,
                        synopsis: h,
                        bintang: j,
                        inforilis: w,
                        tags: f,
                        link: abc + u // Link detail anime
                    });
                });

                resolve(catoz); // Resolusi data hasil scraping
            })
            .catch((error) => {
                console.error('Error fetching data from LiveChart:', error);
                reject('Gagal mengambil data dari LiveChart');
            });
    });
}

exports.run = {
    usage: ['livechartlatest'],
    category: 'anime',
    use: 'query',
    async: async (m, { func, mecha }) => {
        mecha.sendReact(m.chat, "🕒", m.key); // Reaksi loading

        try {
            const data = await livechartlatest();

            if (data.length === 0) {
                return mecha.reply(m.chat, 'Tidak ada anime terbaru yang ditemukan.', m);
            }

            let message = 'Anime Terbaru di LiveChart:\n\n';
            
            data.forEach((anime, index) => {
                message += `${index + 1}. **${anime.title}**\n`;
                message += `   Episode Countdown: ${anime.eps || 'Tidak Tersedia'}\n`;
                message += `   Studio: ${anime.studio || 'Tidak Diketahui'}\n`;
                message += `   Tags: ${anime.tags || 'Tidak Tersedia'}\n`;
                message += `   Synopsis: ${anime.synopsis.slice(0, 100)}...\n`; // Menampilkan potongan sinopsis
                message += `   Link: ${anime.link}\n\n`;
            });

            await mecha.reply(m.chat, message, m);
            mecha.sendReact(m.chat, "✅", m.key); // Reaksi sukses
        } catch (error) {
            console.error("Error fetching anime data:", error);
            mecha.reply(m.chat, "Terjadi kesalahan saat mengambil data anime terbaru.", m);
        }
    },
    premium: false, // Tidak perlu premium
    limit: 5
};