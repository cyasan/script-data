const axios = require('axios');
const cheerio = require('cheerio');

async function listHeroML() {
    try {
        const response = await axios.get('https://liquipedia.net/mobilelegends/Portal:Heroes');
        const $ = cheerio.load(response.data);
        const heroes = [];

        $('.tabs-content .gallerybox').each((i, element) => {
            const heroName = $(element).find('a').attr('title');
            const heroLink = $(element).find('a').attr('href');
            const heroImage = $(element).find('img').attr('src');

            heroes.push({
                name: heroName,
                link: `https://liquipedia.net${heroLink}`,
                image: `https://liquipedia.net${heroImage}`
            });
        });

        return heroes
    } catch (error) {
        return error.message;
    }
}

async function detailHeroML(url) {
    try {
        const response = await axios.get(url);
        const $ = cheerio.load(response.data);

        const heroData = {
            name: $('h1.firstHeading').text().trim(),
            image: 'https://liquipedia.net' + $('.infobox-image img').attr('src'),
            abilities: [],
            lore: $('#mw-content-text p').first().text().trim(),
            baseStats: {},
        };

        $('.infobox-cell-2.infobox-description').each((i, element) => {
            const statName = $(element).text().trim();
            const statValue = $(element).next().text().trim();
            heroData.baseStats[statName] = statValue;
        });

        $('ul.nav[data-component="toc-sidebar-nav"] li.toclevel-1').each((i, element) => {
            const sectionTitle = $(element).find('a .toctext').text();
            const subSections = [];

            $(element).find('ul.nav li.toclevel-2').each((j, subElement) => {
                const subSectionTitle = $(subElement).find('a .toctext').text();
                const subSectionLink = $(subElement).find('a').attr('href');
                subSections.push({
                    title: subSectionTitle,
                    link: subSectionLink
                });
            });

            heroData.abilities.push({
                title: sectionTitle,
                subSections: subSections
            });
        });

        $('.spellcard-wrapper').each((i, element) => {
            const abilityDescription = $(element).find('.spellcard-description').text().trim();

            heroData.abilities.push({
                description: abilityDescription,
            });
        });

        return JSON.stringify(heroData, null, 2)
    } catch (error) {
        return error.message;
    }
};

exports.run = {
    usage: ['listheroml', 'herodetail'],
    use: 'parameter',
    category: 'tools',
    async: async (m, {
        func,
        mecha
    }) => {

        function formatHeroText(hero) {
            let result = `乂 *HERO MOBILE LEGENDS*\n\n`;
            result += `- *Name* : ${hero.name}\n`;
            for (const [key, value] of Object.entries(hero.baseStats)) {
                result += `- *${func.ucword(key.replace(':', ''))}* : ${value.replace('   ', ' or ')}\n`;
            }
            result += `- *Lore* : ${hero.lore}\n`;
            result += `- *Description* :`;
            hero.abilities.forEach(ability => {
                /*if (ability.title) {
                  result += `${ability.title}\n`;
                  ability.subSections.forEach(sub => {
                    result += `- ${sub.title} (${sub.link})\n`;
                  });
                  result += '\n';
                } else */
                if (ability.description) {
                    result += `\n\n${ability.description}`;
                }
            });

            return result;
        }

        switch (m.command) {
            case 'listheroml': {
                mecha.sendReact(m.chat, '🕒', m.key);
                let rows = [];
                let result = await listHeroML();
                for (const [index, item] of result.entries()) {
                    rows.push({
                        title: `${index + 1}. ${item.name}`,
                        id: `${m.prefix}herodetail ${item.link}`
                    })
                }
                let sections = [{
                    title: 'PILIH HERO ML DIBAWAH',
                    rows: rows
                }]
                let buttons = [
                    ['list', 'Click Here ⎙', sections],
                ]
                mecha.sendButton(m.chat, `LIST HERO MOBILE LEGENDS`, `Total ditemukan: ${result.length}`, 'select the list button below.', buttons, m, {
                    expiration: m.expiration
                })
            }
            break
            case 'herodetail': {
                if (!m.text) return m.reply(func.example(m.cmd, 'https://jkt48.com/member/detail/id/250?lang=id'))
                if (!m.args[0].includes('https://liquipedia.net/mobilelegends/')) return m.reply('URL is Invalid!')
                mecha.sendReact(m.chat, '🕒', m.key)
                try {
                    let result = await detailHeroML(m.args[0])
                    let heroObject = JSON.parse(result);
                    let caption = formatHeroText(heroObject);
                    mecha.sendMedia(m.chat, heroObject.image, m, {
                        caption: caption,
                        expiration: m.expiration
                    })
                } catch (error) {
                    console.log(error);
                    m.reply(`Data hero *${m.args[0].replace('https://liquipedia.net/mobilelegends/', '')}* tidak ditemukan.`)
                }
            }
            break
        }
    },
    limit: true
}