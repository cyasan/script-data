async function getRandomAnime() {
  const animeList = [
    'https://files.catbox.moe/lv79xi.mp4',
    'https://files.catbox.moe/vefkg8.mp4',
    'https://files.catbox.moe/wwhiyq.mp4',
    'https://files.catbox.moe/7y0sje.mp4',
    'https://files.catbox.moe/r8h78e.mp4',
    'https://files.catbox.moe/1gaz80.mp4',
    'https://files.catbox.moe/l0yxa6.mp4',
    'https://files.catbox.moe/cfcvhw.mp4',
    'https://files.catbox.moe/mbhjx7.mp4',
    'https://files.catbox.moe/i0v3ha.mp4',
    'https://files.catbox.moe/x87rut.mp4',
    'https://files.catbox.moe/rst410.mp4',
    'https://files.catbox.moe/glb0gm.mp4',
    'https://files.catbox.moe/vio8vh.mp4',
    'https://files.catbox.moe/maqlj7.mp4',
    'https://files.catbox.moe/6usruq.mp4',
    'https://files.catbox.moe/kv6jlu.mp4',
    'https://files.catbox.moe/t84ps7.mp4',
'https://files.catbox.moe/8ism9r.mp4',
'https://files.catbox.moe/d4xs4i.mp4',
'https://files.catbox.moe/xg5ydw.mp4',
'https://files.catbox.moe/idvxs3.mp4',
'https://files.catbox.moe/drfe28.mp4',
'https://files.catbox.moe/1kt5gv.mp4',
'https://files.catbox.moe/7734zh.mp4',
'https://files.catbox.moe/ghw9qe.mp4',
'https://files.catbox.moe/4lefnd.mp4',
'https://files.catbox.moe/jgfj7b.mp4',
'https://files.catbox.moe/gv5lwu.mp4',
  ];

  const randomIndex = Math.floor(Math.random() * animeList.length);
  const randomAnime = animeList[randomIndex];

  return randomAnime;
}

// Helper function to generate random source and date
function getRandomSource() {
  const sources = ['Twitter', 'Telegram', 'Onlyfans'];
  return sources[Math.floor(Math.random() * sources.length)];
}

function getRandomDate() {
  const startDate = new Date('2024-10-13');
  const endDate = new Date('2025-01-06');
  const randomDate = new Date(startDate.getTime() + Math.random() * (endDate - startDate));
  return randomDate.toLocaleDateString('id-ID');
}

exports.run = {
  usage: ['bxbvideo'],
  category: 'asupan',
  async: async (m, { func, mecha, users, setting, froms }) => {
    if (users.age < 28) {
      mecha.sendMessage(m.chat, { text: `Kamu masih di bawah umur untuk menggunakan fitur ini.` }, { quoted: m });
      return;
    }

    try {
      mecha.sendReact(m.chat, '🕒', m.key); // Send loading indicator
      const animeUrl = await getRandomAnime();

      if (isValidVideoUrl(animeUrl) && isAppropriateContent(animeUrl)) {
        const caption = `*BXB - VIDEO*\n\nSumber: ${getRandomSource()}\nPublished on: ${getRandomDate()}`;
        
        const sentMessage = await mecha.sendMessage(
          m.chat,
          {
            video: {
              url: animeUrl,
            },
            mimetype: 'video/mp4',
            caption: caption,
          },
          { quoted: m, ephemeralExpiration: 86400 }
        );

        // Schedule message deletion after 30 minutes
        setTimeout(() => {
          mecha.sendMessage(m.chat, { delete: sentMessage.key });
        }, 40000); // 30 minutes in milliseconds
      } else {
        m.reply(`Maaf, terjadi kesalahan saat mengambil video anime.`);
      }
    } catch (error) {
      console.error('Error fetching anime:', error);
      mecha.sendReact(m.chat, '❌', m.key); // Error indicator
    }
  },
  limit: true,
  premium: true,
  private: true,
};

function isValidVideoUrl(url) {
  return true; // Replace with actual validation logic
}

function isAppropriateContent(url) {
  return true; // Replace with actual content filtering logic
}