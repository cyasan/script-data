async function getRandomAnime() {
  const animeList = [
  "https://media.discordapp.net/attachments/530635618003451904/683209653261303808/yande.re_613351_sample_ass_azur_lane_cameltoe_damao_yu_feet_pantsu_stockings_taihou_azur_lane_thighh.jpg",
  "https://media.discordapp.net/attachments/530635618003451904/683209648664215585/yande.re_612976_sample_4min_ass_azur_lane_cameltoe_dido_azur_lane_erect_nipples_maid_no_bra_pantsu_s.jpg",
  "https://media.discordapp.net/attachments/530635618003451904/683209646592360448/yande.re_612245_sample_animal_ears_ass_chita_ketchup_dress_nekomimi_pantsu_skirt_lift_tail_thighhigh.jpg",
  "https://media.discordapp.net/attachments/530635618003451904/683209641865510953/yande.re_609551_sample_ass_breasts_censored_cosplay_cum_dress_kagami_masara_kkkk12103_nipples_no_bra.jpg",
  "https://media.discordapp.net/attachments/530635618003451904/683076919494836254/021bcgzcnqj41.jpg",
  "https://media.discordapp.net/attachments/530635618003451904/683049635052257371/uhuw5wk9koj41.jpg",
  "https://media.discordapp.net/attachments/530635618003451904/682664131551166516/sample_2a3583974d06d7cdb2879b3704483e49afca1e04.jpg",
  "https://media.discordapp.net/attachments/530635618003451904/682376635600863297/I6KHKiN_d.jpg",
  "https://media.discordapp.net/attachments/530635618003451904/682376627853852729/czUyMXO_d.jpg",
  "https://media.discordapp.net/attachments/530635618003451904/682376348500623390/xivk9in35hh41.jpg",
  "https://media.discordapp.net/attachments/530635618003451904/682011009254424656/o86kietucri41.jpg",
  "https://media.discordapp.net/attachments/530635618003451904/681926896254058761/1rf2m.png",
  "https://media.discordapp.net/attachments/530635618003451904/681790372628004874/ec32416771771cea8a46f077c62fe174.png",
  "https://media.discordapp.net/attachments/530635618003451904/681718857714368585/NV0K3vI_d.jpg",
  "https://media.discordapp.net/attachments/530635618003451904/681501982216814617/w14gz2qk8vi41.jpg",
  "https://media.discordapp.net/attachments/530635618003451904/680513877083160606/se17yezz5ci41.jpg",
  "https://media.discordapp.net/attachments/530635618003451904/680164098704670787/a50311b.jpg",
  "https://media.discordapp.net/attachments/530635618003451904/680058123117002762/z1zzuncdhyh41.jpg",
  "https://media.discordapp.net/attachments/530635618003451904/679872747211587584/9cb04e3.jpg",
  "https://media.discordapp.net/attachments/530635618003451904/679408491005214750/K0aqful_d.jpg",
  "https://media.discordapp.net/attachments/530635618003451904/679408490799955973/SVF1RCC_d.jpg",
  "https://media.discordapp.net/attachments/530635618003451904/678945529714966528/image0.jpg",
  "https://media.discordapp.net/attachments/530635618003451904/678944005433720835/4cwyar9q9ch41.png",
  "https://media.discordapp.net/attachments/530635618003451904/678731683771711519/7a720f4.png",
  "https://media.discordapp.net/attachments/530635618003451904/678731683494756352/427c8bd.jpg",
  "https://media.discordapp.net/attachments/530635618003451904/678731683104555039/a21043d.png",
  "https://media.discordapp.net/attachments/530635618003451904/678731682257436682/7e5de87.jpg",
  "https://konachan.com/sample/1155676c3d40044e9e68cc8c5a8a70e1/Konachan.com%20-%20316708%20sample.jpg",
  "https://konachan.com/sample/d7b1e0f18c3dd52e5698f09ff088255c/Konachan.com%20-%20316687%20sample.jpg",
  "https://konachan.com/sample/5cd6c58baa80681607bd5ae43071f6d2/Konachan.com%20-%20316669%20sample.jpg",
  "https://konachan.com/sample/09fbd31d111262526f98cdd691bc14e1/Konachan.com%20-%20316638%20sample.jpg",
  "https://konachan.com/sample/52730995ccd5136bb6c8524ab7363396/Konachan.com%20-%20316634%20sample.jpg",
  "https://konachan.com/sample/747b76bfb23f7903019da58fb09bea9b/Konachan.com%20-%20316633%20sample.jpg",
  "https://konachan.com/sample/f42af31763ede31e6ed3a5e2b40436e9/Konachan.com%20-%20316632%20sample.jpg",
  "https://konachan.com/sample/b069dbe72d0b4c459ff4ba4aa754f213/Konachan.com%20-%20316618%20sample.jpg",
  "https://konachan.com/sample/0f76bc626106913a8082450826a63a94/Konachan.com%20-%20316609%20sample.jpg",
  "https://konachan.com/sample/3a01a6e8a99193e777cfe76663707f67/Konachan.com%20-%20316606%20sample.jpg",
  "https://konachan.com/sample/143c3a759456379a818b87c4deb22b44/Konachan.com%20-%20316604%20sample.jpg"
];

  const randomIndex = Math.floor(Math.random() * animeList.length);
  return animeList[randomIndex];
}

exports.run = {
  usage: ['ass'], // Change command to 'anime'
  category: 'nsfw', // Change category for broader scope
  async: async (m, { func, mecha, users, setting, froms }) => {
    let { age } = global.db.users[m.sender];
    if (users.age < 20) {
      mecha.sendMessage(m.chat, { text: `Kamu masih dibawah umur untuk menggunakan fitur ini` }, { quoted: m });
      return; // Exit the function immediately
    }

    try {
      mecha.sendReact(m.chat, '🕒', m.key);
      const animeUrl = await getRandomAnime();

      // Send the image and store the sent message
      const sentMessage = await mecha.sendMessage(m.chat, {
        image: {
          url: animeUrl,
        },
        mimetype: 'image/jpeg',
      }, { quoted: m, ephemeralExpiration: 86400 });

      // Set a timeout to delete the message after 5 minutes
      setTimeout(() => {
        mecha.sendMessage(m.chat, { delete: sentMessage.key });
      }, 60000); // 5 minutes in milliseconds
    } catch (error) {
      console.error('Error fetching anime:', error);
      mecha.sendReact(m.chat, '❌', m.key);
    }
  },
  limit: true,
  premium: true,
  private: false,
};