const axios = require("axios");
const cheerio = require("cheerio");

exports.run = {
  usage: ["ffpet"],
  category: "searching",
  use: "nama pet free fire",
  async: async (m, { func, mecha }) => {
    if (!m.text) return mecha.reply(m.chat, func.example(m.cmd, "Panda"), m);

    mecha.sendReact(m.chat, "🕒", m.key); // Reaksi loading

    try {
      // Ambil daftar pet dari situs Free Fire
      const { data } = await axios.get("https://ff.garena.com/id/pets/");
      const $ = cheerio.load(data);
      let pets = [];

      $(".pet-box.pet-box-new").each((i, elem) => {
        let name = $(elem).find(".pet-name").text().trim();
        let talk = $(elem).find(".pet-abstract").text().trim();
        let idMatch = $(elem).find("a").attr("href").match(/\/(\d+)$/);
        let id = idMatch ? idMatch[1] : null;

        if (name && id) pets.push({ name, talk, id });
      });

      let pet = pets.find((p) => p.name.toLowerCase().includes(m.text.toLowerCase()));
      if (!pet) return mecha.reply(m.chat, "Pet tidak ditemukan. Coba nama lain!", m);

      // Ambil detail skill pet
      const { data: skillData } = await axios.get(`https://ff.garena.com/id/pets/${pet.id}`);
      const $$ = cheerio.load(skillData);
      let skillName = $$(".skill-profile-name").text().trim();
      let skillDesc = $$(".skill-introduction").text().trim();

      let caption = `乂 FREE FIRE PET SPECIFICATION\n\n`;
      caption += `- Nama: ${pet.name}\n`;
      caption += `- Deskripsi: ${pet.talk}\n`;
      caption += `- Skill: ${skillName} - ${skillDesc}\n\n`;
      caption += `Data dari Garena Free Fire`;

      mecha.reply(m.chat, caption, m);
      mecha.sendReact(m.chat, "✅", m.key); // Reaksi sukses
    } catch (err) {
      console.error("Error fetching Free Fire pet data:", err);
      mecha.reply(m.chat, "Terjadi kesalahan saat mencari spesifikasi pet Free Fire.", m);
    }
  },
  limit: true,
};