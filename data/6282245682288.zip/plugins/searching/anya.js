async function getRandomAnime() {
  const animeList = [
'https://files.catbox.moe/ynflgh.jpg',
'https://files.catbox.moe/g6p7e5.jpg',
'https://files.catbox.moe/jf2j65.jpg',
'https://files.catbox.moe/oucmni.jpg',
'https://files.catbox.moe/4pcvuj.jpg',
  ];

  const randomIndex = Math.floor(Math.random() * animeList.length);
  const randomAnime = animeList[randomIndex];

  return randomAnime;
}

exports.run = {
  usage: ['anya'], // Change command to 'anime'
  category: 'anime', // Change category for broader scope
  async: async (m, { func, mecha, users, setting, froms }) => {

    try {
      mecha.sendReact(m.chat, '🕒', m.key);
      const animeUrl = await getRandomAnime();

      // Send the image with the caption as part of the message object
      mecha.sendMessage(m.chat, {
        image: {
          url: animeUrl,
        },
        caption: '乂 *ANYA FORGER*',
      }, { quoted: m, ephemeralExpiration: 86400 });
    } catch (error) {
      console.error('Error fetching anime:', error);
      mecha.sendReact(m.chat, '❌', m.key);
    }
  },
  limit: true,
};