const axios = require("axios");
const cheerio = require("cheerio");

exports.run = {
  usage: ["happymod"],
  category: "searching",
  use: "nama aplikasi",
  async: async (m, { func, mecha }) => {
    if (!m.text) return mecha.reply(m.chat, func.example(m.cmd, "WhatsApp"), m);

    mecha.sendReact(m.chat, "🕒", m.key); // Reaksi loading

    try {
      const baseUrl = "https://www.happymod.com/";
      const searchUrl = `${baseUrl}search.html?q=${encodeURIComponent(m.text)}`;
      const { data } = await axios.get(searchUrl, {
        headers: {
          "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, seperti Gecko) Chrome/91.0.4472.124 Safari/537.36",
        },
      });

      const $ = cheerio.load(data);
      let results = [];

      $("div.pdt-app-box").each((i, elem) => {
        const title = $(elem).find("a").text().trim();
        const icon = $(elem).find("img.lazy").attr("data-original");
        const rating = $(elem).find("span").text().trim();
        const link = baseUrl + $(elem).find("a").attr("href");

        if (title && icon && link) {
          results.push({ title, icon, rating, link });
        }
      });

      if (results.length === 0) {
        return mecha.reply(m.chat, "Aplikasi tidak ditemukan. Coba kata kunci lain!", m);
      }

      let app = results[0]; // Ambil hasil pertama
      let caption = `乂 HAPPYMOD SEARCH\n\n`;
      caption += `- Nama Aplikasi: ${app.title}\n`;
      caption += `- Rating: ${app.rating}\n`;
      caption += `- Link: ${app.link}\n\n`;
      caption += `Data dari HappyMod`;

      await mecha.sendMessage(
        m.chat,
        {
          image: { url: app.icon },
          caption,
        },
        { quoted: m }
      );

      mecha.sendReact(m.chat, "✅", m.key); // Reaksi sukses
    } catch (err) {
      console.error("Error fetching HappyMod data:", err);
      mecha.reply(m.chat, "Terjadi kesalahan saat mencari aplikasi di HappyMod.", m);
    }
  },
  limit: true,
premium: true
};