const fs = require('fs');
const path = require('path');
const { ghibliStyle } = require('../../lib/ghibli2.js'); // pastikan path-nya sesuai

exports.run = {
  usage: ['ghibli2'],
  hidden: ['toghibli2'],
  use: 'reply photo',
  category: 'ai',
  async: async (m, { func, mecha, quoted }) => {
    if (!/image\/(jpe?g|png)/.test(quoted?.mime || '')) {
      return m.reply(`Kirim/Reply foto dengan caption ${m.cmd}`);
    }

    mecha.sendReact(m.chat, '⏳', m.key);

    try {
      const imageBuffer = await quoted.download();
      const fileName = func.filename('jpg');
      const filePath = path.join(process.cwd(), 'media', fileName);
      fs.writeFileSync(filePath, imageBuffer);

      const result = await ghibliStyle.generate(filePath);

      fs.unlinkSync(filePath); // hapus file lokal setelah diproses

      if (!result.status) {
        return m.reply(`Gagal: ${result.result.error}`);
      }

      const imageUrl = result.result.image;
      const output = await func.getBuffer(imageUrl);

      await mecha.sendMessage(m.chat, {
        image: output,
        caption: 'Ghibli Style berhasil dibuat dengan scraper ghibli2!'
      }, {
        quoted: m,
        ephemeralExpiration: m.expiration
      });

    } catch (err) {
      console.error(err);
      return m.reply('Terjadi kesalahan saat memproses gambar.');
    }
  },
  premium: true,
  location: 'plugins/ai/jadighibli2.js'
};