const axios = require('axios');

const freebox = {
  defaultRatio: "9:16", // Atau ubah sesuai kebutuhan

  create: async (query) => {
    try {
      const payload = {
        aspectRatio: freebox.defaultRatio,
        slug: "ai-photo-generator",
        userPrompt: query
      };

      const { data } = await axios.post("https://aifreebox.com/api/image-generator", payload);

      // Deteksi NSFW berdasarkan pesan error
      if (data.status === "400" && data.message && data.message.includes("NSFW")) {
        return { nsfw: true };
      }

      return {
        imageLink: data?.imageUrl || data?.image || null,
        prompt: query
      };
    } catch (error) {
      console.error(error.message);
      return null;
    }
  }
};

exports.run = {
  usage: ['freebox'],
  use: 'prompt',
  category: 'ai',
  async: async (m, { func, mecha }) => {
    if (!m.text) return m.reply(func.example(m.cmd, 'a boy with glasses in cityscape'));
    
    mecha.sendReact(m.chat, '🕒', m.key);

    const result = await freebox.create(m.text);

    if (!result) return m.reply('Terjadi kesalahan saat menghubungi server.');
    if (result.nsfw) return m.reply('Konten terdeteksi NSFW dan tidak dapat diproses.');

    if (result.imageLink) {
      mecha.sendMedia(m.chat, result.imageLink, m, {
        caption: `Hasil Freebox:\n\nPrompt: ${m.text}`,
        expiration: m.expiration
      });
    } else {
      m.reply('Gagal membuat gambar.');
    }
  },
  premium: true
};