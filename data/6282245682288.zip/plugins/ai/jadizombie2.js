const axios = require("axios");
const fs = require("fs");
const FormData = require("form-data");

async function toZombie(imageUrl) {
  let { data } = await axios.get(imageUrl, { responseType: "arraybuffer" });
  let formData = new FormData();
  formData.append("photofile", data, { filename: "photo.jpg" });
  formData.append("action", "upload");

  let { data: uploadResponse } = await axios.post("https://makemezombie.com/response.php", formData, {
    headers: { ...formData.getHeaders() },
  });

  let key = uploadResponse.key;
  let result;

  while (true) {
    let checkData = new FormData();
    checkData.append("action", "check");
    checkData.append("image_id", key);

    let { data: response } = await axios.post("https://makemezombie.com/response.php", checkData);
    if (response.ready === "1") {
      result = response;
      break;
    }
  }

  return result;
}

exports.run = {
  usage: ['jadizombie2'],
  hidden: ['tozombie2'],
  use: 'reply photo',
  category: 'ai',
  async: async (m, { func, mecha, quoted }) => {
    if (!quoted || !/image\/(jpe?g|png)/.test(quoted.mime)) {
      return m.reply(`Kirim/Reply foto dengan caption ${m.cmd}`);
    }

    mecha.sendReact(m.chat, '🕒', m.key);

    const mediaPath = await mecha.downloadAndSaveMediaMessage(quoted);
    const mediaUrl = await func.uploadImage(fs.readFileSync(mediaPath));

    const result = await toZombie(mediaUrl);
    const zombieImageUrl = `https://makemezombie.com/zombify/${result.image}`;

    await mecha.sendMedia(m.chat, zombieImageUrl, m, {
      caption: global.mess.ok,
      ephemeralExpiration: m.expiration
    });
  },
  premium: true,
  limit: true
};