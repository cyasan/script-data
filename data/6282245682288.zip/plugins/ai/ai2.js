const axios = require('axios');

exports.run = {
    usage: ['ai2'],
    use: 'question',
    category: 'ai',
    async: async (m, { func, mecha, users }) => {
        const processRequest = async (message, text) => {
            const apiUrl = `https://api.siputzx.my.id/api/ai/gpt3?prompt=${encodeURIComponent(message)}&content=${encodeURIComponent(text)}`;

            try {
                console.log("Mengirim request ke:", apiUrl);
                const response = await axios.get(apiUrl);
                console.log("Respons API:", response.data);

                if (response.data && response.data.data) {
                    return response.data.data; // Mengambil jawaban dari API
                } else {
                    return "Maaf, aku tidak bisa menjawab pertanyaan itu.";
                }
            } catch (error) {
                console.error("Error fetching AI response:", error);
                return "Terjadi kesalahan saat menghubungi AI.";
            }
        };

        if (!m.text) return m.reply(func.example(m.cmd, 'apa itu coding?'));

        mecha.sendReact(m.chat, '🕒', m.key); // Indikator loading

        const message = `Kamu adalah Lexy, Bot WhatsApp dengan kecerdasan buatan AI yang santai, asik, dan menyenangkan. Kamu bisa bercanda, tapi tetap memberikan jawaban yang informatif dan bermanfaat. Jawabanmu tidak terlalu kaku, dan kamu bisa menggunakan bahasa yang lebih ringan serta sedikit humor. Jika ada pertanyaan serius, jawab dengan bijak tanpa kehilangan sisi ramah dan interaktif. Lawan bicaramu adalah ${users.name || 'User'}, jadi pastikan suasana tetap nyaman dan seru!"`;
        
        const replyText = await processRequest(message, m.text);

        mecha.sendReact(m.chat, '✅', m.key); // Indikator selesai
        mecha.reply(m.chat, replyText, m, {
            expiration: m.expiration
        });
    },
    limit: true
};