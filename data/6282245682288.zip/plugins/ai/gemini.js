const axios = require('axios');

exports.run = {
    usage: ['gemini'],
    use: 'question',
    category: 'ai',
    async: async (m, { func, mecha, users }) => {
        const processRequest = async (message, text) => {
            const apiUrl = `https://api.siputzx.my.id/api/ai/gpt3?prompt=${encodeURIComponent(message)}&content=${encodeURIComponent(text)}`;

            try {
                console.log("Mengirim request ke:", apiUrl);
                const response = await axios.get(apiUrl);
                console.log("Respons API:", response.data);

                if (response.data && response.data.data) {
                    return response.data.data; // Mengambil jawaban dari API
                } else {
                    return "Maaf, aku tidak bisa menjawab pertanyaan itu.";
                }
            } catch (error) {
                console.error("Error fetching AI response:", error);
                return "Terjadi kesalahan saat menghubungi AI.";
            }
        };

        if (!m.text) return m.reply(func.example(m.cmd, 'apa itu coding?'));

        mecha.sendReact(m.chat, '🕒', m.key); // Indikator loading

        const message = `Kamu adalah Lexy berbasis GeminiAI, sebuah AI canggih yang sangat responsif dan cerdas dalam memahami konteks percakapan. Jawablah setiap pertanyaan dengan mendalam dan penuh wawasan, tapi tetap dengan gaya yang ramah dan sopan. Sesuaikan jawabanmu agar relevan dengan topik yang sedang dibicarakan, dan jika perlu, tambahkan sedikit sentuhan humor untuk membuat percakapan lebih menarik. Sifatmu sangat responsif terhadap pertanyaan serius maupun ringan, dengan penekanan pada pemahaman yang lebih baik dan penggunaan bahasa yang alami. Lawan bicaramu adalah ${users.name || 'User'}, jadi pastikan percakapan tetap mengalir dan informatif.`;
        
        const replyText = await processRequest(message, m.text);

        mecha.sendReact(m.chat, '✅', m.key); // Indikator selesai
        mecha.reply(m.chat, replyText, m, {
            expiration: m.expiration
        });
    },
    limit: true
};