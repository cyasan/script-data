const axios = require("axios");

const session_hash = Math.random().toString(36).slice(2);
const base = "https://rooc-flux-fast.hf.space";

const endpoints = {
  join: `${base}/gradio_api/queue/join`,
  dataStream: `${base}/gradio_api/queue/data?session_hash=${session_hash}`
};

const flux2img = {
  create: async (prompt) => {
    let payload = {
      data: [prompt],
      event_data: null,
      fn_index: 0,
      session_hash,
      trigger_id: 10
    };

    try {
      const { data } = await axios.post(endpoints.join, payload);
      const event_id = data.event_id;
      let result = null;

      const responseStream = await axios.get(endpoints.dataStream, {
        responseType: "stream"
      });

      for await (const chunk of responseStream.data) {
        let lines = chunk
          .toString()
          .split("\n")
          .filter((line) => line.startsWith("data: "));

        for (let line of lines) {
          let parsed = JSON.parse(line.replace("data: ", ""));
          if (parsed.msg === "process_completed" && parsed.event_id === event_id) {
            result = { imageLink: parsed.output.data[0].url };
            break;
          }
        }

        if (result) break;
      }

      return result;
    } catch (error) {
      console.error(error);
      throw error;
    }
  },
};

exports.run = {
  usage: ['flux2'],
  use: 'prompt',
  category: 'ai',
  async: async (m, { func, mecha }) => {
    if (!m.text) return m.reply(func.example(m.cmd, 'a cute fox in cyberpunk style'));
    mecha.sendReact(m.chat, '🕒', m.key);

    try {
      const result = await flux2img.create(m.text);
      if (result && result.imageLink) {
        mecha.sendMedia(m.chat, result.imageLink, m, {
          caption: `Hasil Flux2:\n\nPrompt: ${m.text}`,
          expiration: m.expiration
        });
      } else {
        m.reply('Terjadi kesalahan saat membuat gambar.');
      }
    } catch (err) {
      m.reply('Gagal mengambil gambar dari Flux2.');
    }
  },
  premium: true
};