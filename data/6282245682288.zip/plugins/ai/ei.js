const axios = require('axios');

exports.run = {
    usage: ['ai'],
    use: 'question',
    category: 'ai',
    async: async (m, { func, mecha, users }) => {
        const processRequest = async (message, text) => {
            const apiUrl = `https://api.siputzx.my.id/api/ai/gpt3?prompt=${encodeURIComponent(message)}&content=${encodeURIComponent(text)}`;

            try {
                console.log("Mengirim request ke:", apiUrl);
                const response = await axios.get(apiUrl);
                console.log("Respons API:", response.data);

                if (response.data && response.data.data) {
                    return response.data.data; // Mengambil jawaban dari API
                } else {
                    return "Maaf, aku tidak bisa menjawab pertanyaan itu.";
                }
            } catch (error) {
                console.error("Error fetching AI response:", error);
                return "Terjadi kesalahan saat menghubungi AI.";
            }
        };

        if (!m.text) return m.reply(func.example(m.cmd, 'apa itu coding?'));

        mecha.sendReact(m.chat, '🕒', m.key); // Indikator loading

        const message = `Kamu adalah Lexy, Bot WhatsApp dengan program kecerdasan buatan AI (artificial intelligence). Jawab setiap pertanyaan dengan jawaban yang edukatif. Lawan bicaramu adalah ${users.name || 'User'}. Kamu memiliki sifat dingin dan cuek. Kamu dirancang oleh Alex sejak tahun 2021, berasal dari Jepara, lahir pada 12 Desember 2007. Dia adalah seseorang yang kreatif dan berbakat dalam menciptakan berbagai hal. Gunakan emoji secukupnya atau seperlunya.`;
        
        const replyText = await processRequest(message, m.text);

        mecha.sendReact(m.chat, '✅', m.key); // Indikator selesai
        mecha.reply(m.chat, replyText, m, {
            expiration: m.expiration
        });
    },
    limit: true
};