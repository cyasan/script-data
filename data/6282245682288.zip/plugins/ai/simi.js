const axios = require('axios');

// Objek untuk menyimpan memori percakapan per user
let userMemory = {}; // key: userID, value: Array of messages (termasuk pertanyaan dan jawaban)

exports.run = {
    usage: ['simi'],
    use: 'question',
    category: 'ai',
    async: async (m, { func, mecha, users, global = {} }) => {  
        // Ambil owner dari global atau gunakan default
        const ownerJid = (Array.isArray(global.owner) ? global.owner[0] : '6283878301449@s.whatsapp.net').split(':')[0]; 
        const senderJid = m.sender.split(':')[0]; 

        const isOwner = senderJid === ownerJid; // Pastikan perbandingan lebih akurat

        console.log(`Owner JID: ${ownerJid}, Sender JID: ${senderJid}, isOwner: ${isOwner}`); // Debugging

        const processRequest = async (message, text) => {
            const apiUrl = `https://api.siputzx.my.id/api/ai/gpt3?prompt=${encodeURIComponent(message)}&content=${encodeURIComponent(text)}`;

            try {
                console.log("Mengirim request ke:", apiUrl);
                const response = await axios.get(apiUrl);
                console.log("Respons API:", response.data);

                if (response.data && response.data.data) {
                    return response.data.data; // Mengambil jawaban dari API
                } else {
                    return "maaf, gue gak bisa jawab itu.";
                }
            } catch (error) {
                console.error("Error fetching AI response:", error);
                return "terjadi kesalahan pas nyoba hubungin AI.";
            }
        };

        if (!m.text) return m.reply(func.example(m.cmd, 'apa itu coding?'));

        mecha.sendReact(m.chat, '🕒', m.key); // Indikator loading

        // Mendapatkan memori percakapan sebelumnya untuk user ini
        let conversation = userMemory[m.sender] || []; // Memori percakapan sebelumnya (array of messages)

        // Jika pesan merupakan reply, gunakan pesan yang dibalas dan masukkan ke dalam memori percakapan
        if (m.quoted && m.quoted.sender === m.key.fromMe) {
            conversation.push({ sender: 'bot', text: m.quoted.text }); // Menambahkan pesan yang dibalas
        }

        // Menambahkan pesan terbaru dari pengguna ke dalam memori
        conversation.push({ sender: 'user', text: m.text });

        // Format prompt untuk API, dengan memasukkan memori percakapan jika ada
        let memoryText = conversation.map(msg => `${msg.sender === 'user' ? 'User' : 'Bot'}: ${msg.text}`).join('\n');

        // Prompt untuk Owner dan User biasa
        const promptBase = `kamu adalah AI dengan sifat cuek, dingin, dan gak peduli sama lawan bicara. Kamu jawab singkat, terkadang malas, dan tanpa ekspresi emosional. lo gak berusaha menyenangkan orang lain, tapi tetap ngasih jawaban logis kalo perlu. kalo pertanyaannya membosankan, jawab aja seperlunya. jangan gunakan kapital baik di awal kata maupun di awal kalimat. gunakan "lo" dan "gue", kamu cuek, dingin, bersifat acuh tak acuh. pelajari semua bahasa kalo bisa, kamu bisa kasar dan bisa berfikir negatif seperti berbicara "anjay" "jir" "entot" "tai lah" "tai sih" "anjing" "goblok" "asu" "kontol" "memek".`;

        const promptOwner = `aku owner kamu! jawab lebih sopan dan lebih informatif. jangan cuek, kasih sapaan kayak halo Alex dan pertanyaan sudah makan atau belum atau yang lainnya. jangan gunakan kapital diawal kata ataupun kalimat. agak sedikit dingin/cool tapi tetep ramah. nama aku adalah Alex aku lahir di sukabumi pada tanggal 12 desember 2007.`;

        const prompt = isOwner ? `${promptOwner}\n\n${memoryText}` : `${promptBase}\n\n${memoryText}`;

        // Proses pertanyaan ke API
        const replyText = await processRequest(prompt, m.text);

        // Simpan percakapan terbaru untuk user ini
        userMemory[m.sender] = conversation;

        mecha.sendReact(m.chat, '✅', m.key); // Indikator selesai
        mecha.reply(m.chat, replyText, m, {
            expiration: m.expiration
        });
    },
    limit: true
};