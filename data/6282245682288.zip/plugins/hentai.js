const axios = require('axios');
const cheerio = require('cheerio');

async function hentai() {
  try {
    const page = Math.floor(Math.random() * 1153);
    const { data } = await axios.get(`https://sfmcompile.club/page/${page}`);
    const $ = cheerio.load(data);
    const hasil = [];

    $('#primary > div > div > ul > li > article').each((_, b) => {
      const videoSrc = $(b).find('source').attr('src') || $(b).find('img').attr('data-src');
      if (videoSrc) {
        hasil.push({
          title: $(b).find('header > h2').text().trim(),
          link: $(b).find('header > h2 > a').attr('href'),
          category: $(b).find('header > div.entry-before-title > span > span').text().replace('in ', '').trim(),
          share_count: $(b).find('header > div.entry-after-title > p > span.entry-shares').text().trim(),
          views_count: $(b).find('header > div.entry-after-title > p > span.entry-views').text().trim(),
          type: $(b).find('source').attr('type') || 'image/jpeg',
          video: videoSrc
        });
      }
    });

    return hasil.length > 0 ? hasil[0] : null;
  } catch (error) {
    console.error('Error fetching hentai:', error);
    return null;
  }
}

exports.run = {
  usage: ['hentai'],
  category: 'nsfw',
  async: async (m, { mecha }) => {
    // React 🕒 sebelum eksekusi
    await mecha.sendMessage(m.chat, { react: { text: '🕒', key: m.key } });

    let result = await hentai();

    if (!result) {
      // React ❌ jika gagal
      await mecha.sendMessage(m.chat, { react: { text: '❌', key: m.key } });
      return mecha.sendMessage(m.chat, { text: 'Maaf, tidak ada konten yang ditemukan.' }, { quoted: m });
    }

    let txt = `*• Title :* ${result.title}
*• Link :* ${result.link}
*• Category :* ${result.category}
*• Share Count :* ${result.share_count}
*• Views Count :* ${result.views_count}
*• Type :* ${result.type}`;

    mecha.sendMessage(m.chat, { 
      video: result.video, 
      caption: txt 
    }, { quoted: m });
  },
  premium: true
};