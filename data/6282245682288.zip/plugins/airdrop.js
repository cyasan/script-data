exports.run = {
  usage: ['addairdrop'],
  use: 'amount',
  category: 'owner',
  async: async (m, { mecha, isOwner }) => {

    let amount = (m.args[0] || '').replace(/[^0-9]/g, ''); // Ambil angka saja
    if (!amount) return mecha.sendMessage(m.chat, { text: 'Masukkan jumlah slot airdrop yang ingin ditambahkan!' }, { quoted: m });

    amount = parseInt(amount);
    if (isNaN(amount) || amount <= 0) return mecha.sendMessage(m.chat, { text: 'Jumlah slot harus berupa angka positif!' }, { quoted: m });

    // Inisialisasi global.airdrop jika belum ada
    if (!global.airdrop) {
      global.airdrop = { slot: 5, lastReset: new Date().toDateString() };
    }

    global.airdrop.slot += amount; // Tambahkan slot

    let teks = `乂 RPG - ADD AIRDROP

- Slot airdrop berhasil ditambahkan sebanyak ${amount} slot!
- Total slot sekarang: ${global.airdrop.slot}`;

    mecha.sendMessage(m.chat, { text: teks }, { quoted: m });
  },
  owner: true
};