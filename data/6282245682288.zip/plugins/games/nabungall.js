// Fungsi untuk format Rupiah, diganti menjadi format dengan simbol $
function formatMoney(amount) {
  return '$' + amount.toLocaleString('id-ID'); // Menggunakan tanda $ dan menghilangkan spasi
}

exports.run = {
  usage: ['nabungall'],
  use: '',
  category: 'rpg',
  async: async (m, { mecha, users }) => {
    let user = global.db.users[m.sender];

    // Cek apakah user ada di database
    if (!user) {
      return mecha.sendMessage(m.chat, { text: 'User tidak ditemukan di database. Pastikan anda sudah terdaftar!' }, { quoted: m });
    }

    // Cek apakah user memiliki ATM
    if (!user.kuli) {
      return mecha.sendMessage(m.chat, { text: `Kamu tidak memiliki ATM. Silahkan buat terlebih dahulu dengan command ${m.prefix}create atm.` }, { quoted: m });
    }

    // Pastikan user memiliki uang untuk ditabung
    if (user.money <= 0) {
      return mecha.sendMessage(m.chat, { text: `Saldo kamu tidak cukup untuk menabung semua uang ke ATM.` }, { quoted: m });
    }

    // Ambil seluruh saldo user.money dan tabungkan ke ATM
    let totalMoney = user.money;
    user.money = 0;
    user.atm = (user.atm || 0) + totalMoney;

    return mecha.sendMessage(m.chat, {
      text: `Berhasil menabung seluruh uang kamu sebesar ${formatMoney(totalMoney)} ke ATM.`
    }, { quoted: m });
  },
  restrict: true,
};