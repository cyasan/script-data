const fetch = require('node-fetch');

exports.run = {
  usage: ['cook'],
  use: 'item,count',
  hidden: ['masak', 'memasak', 'cooking'],
  category: 'rpg',
  async: async (m, { func, mecha, users, setting }) => {
    if (!global.db.users) global.db.users = {};
    let user = global.db.users[m.sender];
    if (!user) {
      return mecha.sendMessage(m.chat, { text: 'User tidak ditemukan di database. Pastikan Anda sudah terdaftar!' }, { quoted: m });
    }

    // Daftar masakan dengan emoji dan bahan yang dibutuhkan
    const recipes = {
      steak: { emoji: '🍝', materials: { sapi: 5, Bawang: 66, Saus: 30 } },
      sate: { emoji: '🍢', materials: { sapi: 5, Bawang: 51, Kemiri: 38 } },
      rendang: { emoji: '🍜', materials: { ayam: 5, sapi: 5, Bawang: 47, Kemiri: 31, Jahe: 30 } },
      kornet: { emoji: '🥣', materials: { kambing: 5, Bawang: 55, Asam: 43, Kemiri: 31 } },
      nugget: { emoji: '🍱', materials: { ayam: 5, babi: 5, Bawang: 59, Kemiri: 42 } },
      bluefin: { emoji: '🍲', materials: { paus: 2, Cabai: 45, Bawang: 76 } },
      seafood: { emoji: '🍛', materials: { udang: 15, kepiting: 10, gurita: 5, kerang: 15, Kemiri: 43, Bawang: 56 } },
      moluska: { emoji: '🥘', materials: { Asam: 33, Bawang: 48, kepiting: 25, Cabai: 50 } },
      sushi: { emoji: '🍣', materials: { gurita: 15, cumi: 15, Kemiri: 33 } },
      squidprawm: { emoji: '🍤', materials: { Bawang: 43, Asam: 22, gurita: 20, kepiting: 10, Kemiri: 30 } }
    };

    const args = m.text.split(/\s+/);
    const dishName = args[0]?.toLowerCase();
    const count = parseInt(args[1], 10) || 1;

    // Jika user hanya mengetik 'cook', tampilkan menu masakan
    if (!dishName) {
      let menu = '乂 *RPG - COOK*\n\n';
      for (const [name, { emoji, materials }] of Object.entries(recipes)) {
        let materialsList = Object.entries(materials)
          .map(([item, qty]) => `> ${item}: ${qty}`)
          .join('\n');
        menu += `- ${emoji} *${name.charAt(0).toUpperCase() + name.slice(1)}*\n${materialsList}\n\n`;
      }
      return mecha.sendMessage(m.chat, { text: menu.trim() }, { quoted: func.fstatus("COOKING")});
    }

    if (!recipes[dishName]) {
      return mecha.sendMessage(m.chat, { text: `Masakan "${dishName}" tidak ditemukan!` }, { quoted: m });
    }

    // Cek apakah bahan cukup
    const requiredMaterials = recipes[dishName].materials;
    for (const [material, qty] of Object.entries(requiredMaterials)) {
      if ((user[material] || 0) < qty * count) {
        return mecha.sendMessage(m.chat, { text: `Bahan *${material}* tidak cukup untuk memasak ${dishName}.\nDibutuhkan: *${qty * count}*\nKamu punya: *${user[material] || 0}*` }, { quoted: m });
      }
    }

    // Kurangi bahan dari inventaris pengguna
    for (const [material, qty] of Object.entries(requiredMaterials)) {
      user[material] -= qty * count;
    }

    // Tambahkan jumlah masakan yang dibuat
    user[dishName] = (user[dishName] || 0) + count;

    // Tambahkan jumlah pengalaman memasak
    user.cook = (user.cook || 0) + 1;

    return mecha.sendMessage(m.chat, { text: `Berhasil memasak *${count} ${recipes[dishName].emoji} ${dishName.charAt(0).toUpperCase() + dishName.slice(1)}*!` }, { quoted: m });
  },
  restrict: true
};