const similarity = require('similarity');
const fetch = require('node-fetch'); // Pastikan fetch di-import
const gamesUrl = 'https://raw.githubusercontent.com/Jabalsurya2105/database/master/games/susunkata.json';
const sensitive = 0.75;
let keyId = {};
let alreadyAnswered = new Set();

exports.run = {
    usage: ['susunkata'],
    hidden: ['skata'],
    category: 'games',
    async: async (m, { mecha, setting, users }) => {
        mecha.susunkata = mecha.susunkata || {};
        if (m.chat in mecha.susunkata) return mecha.reply(m.chat, 'Masih ada soal belum terjawab di chat ini', keyId[m.chat], { expiration: m.expiration });

        let data = await fetch(gamesUrl).then(response => response.json());
        let { soal, jawaban } = data.result.random();
        let hadiah = Math.floor(Math.random() * (3000 - 1000 + 1)) + 1000; // Hadiah acak antara 1000-3000
        let id = Date.now();
        alreadyAnswered.clear();

        let caption = `乂 *GAMES SUSUN KATA*\n\n${soal}\n${users.premium ? '\nPetunjuk: ' + createClue(jawaban) : ''}\nHadiah: $${hadiah} balance\nWaktu: ${setting.gamewaktu} detik`;
        keyId[m.chat] = await mecha.reply(m.chat, caption, m, { expiration: m.expiration });

        mecha.susunkata[m.chat] = {
            id,
            soal,
            jawaban: jawaban.toLowerCase(),
            hadiah,
            nextQuestion: 1,
            timeout: setTimeout(async function() {
                let gameData = mecha.susunkata[m.chat];
                if (gameData.id == id) {
                    mecha.reply(m.chat, `Waktu habis!\n\nJawabannya adalah: ${jawaban}`, keyId[m.chat], { expiration: m.expiration }).then(async () => {
                        if (keyId[m.chat]) {
                            await new Promise(resolve => setTimeout(resolve, 1500));
                            await mecha.sendMessage(m.chat, { delete: keyId[m.chat].key });
                        }
                    });
                    delete mecha.susunkata[m.chat];
                }
            }, setting.gamewaktu * 1000)
        };
    },
    main: async (m, { mecha, setting, users }) => {
        mecha.susunkata = mecha.susunkata || {};
        if ((m.chat in mecha.susunkata) && !m.fromMe && !m.isPrefix) {
            let gameData = mecha.susunkata[m.chat];
            if (similarity(gameData.jawaban, m.budy.toLowerCase()) >= sensitive) {
                if (alreadyAnswered.has(gameData.jawaban)) return mecha.sendReact(m.chat, '🥴', m.key);
                alreadyAnswered.add(gameData.jawaban);

                users.balance += gameData.hadiah;
                users.game.susunkata++;
                gameData.nextQuestion++;

                if (gameData.timeout) clearTimeout(gameData.timeout);
                let data = await fetch(gamesUrl).then(response => response.json());
                let result = data.result.random();
                let hadiah = Math.floor(Math.random() * (3000 - 1000 + 1)) + 1000; // Hadiah acak antara 1000-3000
                let id = Date.now();
                alreadyAnswered.clear();

                let caption = `*LANJUT SOAL KE-${gameData.nextQuestion}*\n\n${result.soal}\n${users.premium ? '\nPetunjuk: ' + createClue(result.jawaban) : ''}\nHadiah: $${hadiah} balance\nWaktu: ${setting.gamewaktu} detik`;
                keyId[m.chat] = await mecha.reply(m.chat, caption, m, { expiration: m.expiration });

                Object.assign(gameData, {
                    id,
                    soal: result.soal,
                    jawaban: result.jawaban.toLowerCase(),
                    hadiah,
                    timeout: setTimeout(function() {
                        if (gameData.id == id) {
                            mecha.reply(m.chat, `Waktu habis!\n\nJawabannya adalah: ${result.jawaban}`, keyId[m.chat], { expiration: m.expiration }).then(async () => {
                                if (keyId[m.chat]) {
                                    await new Promise(resolve => setTimeout(resolve, 1500));
                                    await mecha.sendMessage(m.chat, { delete: keyId[m.chat].key });
                                }
                            });
                            delete mecha.susunkata[m.chat];
                        }
                    }, setting.gamewaktu * 1000)
                });
            } else if (/conversation|extendedTextMessage/.test(m.mtype) && setting.incorrect) {
                await mecha.sendReact(m.chat, '❌', m.key);
            }
        }
    },
    location: 'plugins/games/susunkata.js'
};

/**
 * Fungsi untuk membuat petunjuk jawaban (clue)
 * Mengungkap huruf di posisi genap dan menyembunyikan lainnya dengan '-'
 */
function createClue(word = '') {
    let clue = '';
    for (let i = 0; i < word.length; i++) {
        clue += (i % 2 === 0) ? word[i] : '-';
    }
    return clue;
}