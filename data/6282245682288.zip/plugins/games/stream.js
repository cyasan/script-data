const fs = require('fs'); // Modul untuk menyimpan database

// Fungsi untuk menyimpan database ke file
function saveDatabase() {
  fs.writeFileSync('./database.json', JSON.stringify(global.db, null, 2));
}

exports.run = {
  usage: ['streaming'],
  hidden: ['stream'],
  category: 'rpg',
  async: async (m, { mecha }) => {
    if (!global.db.users) global.db.users = {};

    const userId = m.sender;
    const now = Date.now();
    const cooldownTime = 24 * 60 * 60 * 1000; // 1 hari dalam milidetik

    // Inisialisasi user jika belum ada
    if (!global.db.users[userId]) {
      global.db.users[userId] = {
        ch: '',       // Nama channel
        subs: 0,      // Jumlah subscriber
        view: 0,      // Jumlah viewer
        like: 0,      // Jumlah like
        playbutton: { // Status play button
          silver: false,
          gold: false,
          diamond: false
        },
        laststream: 0 // Waktu terakhir streaming
      };
    }

    let user = global.db.users[userId];

    // Cek apakah user sudah memiliki channel
    if (!user.ch) {
      return mecha.sendMessage(m.chat, { 
        text: 'Kamu belum memiliki akun YouTube. Buat akun dengan .createyt <nama_channel>' 
      }, { quoted: m });
    }

    // Cek cooldown
    if (now - user.laststream < cooldownTime) {
      let remainingTime = cooldownTime - (now - user.laststream);
      let hours = Math.floor(remainingTime / (60 * 60 * 1000));
      let minutes = Math.floor((remainingTime % (60 * 60 * 1000)) / (60 * 1000));
      let seconds = Math.floor((remainingTime % (60 * 1000)) / 1000);

      return mecha.sendMessage(m.chat, {
        text: `Kamu sudah ${m.command} hari ini, mohon tunggu ${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')} untuk ${m.command} kembali.`
      }, { quoted: m });
    }

    // Pastikan objek playbutton ada sebelum mengakses propertinya
    if (!user.playbutton) {
      user.playbutton = {
        silver: false,
        gold: false,
        diamond: false
      };
    }

    // Fungsi mendapatkan angka acak dalam rentang tertentu
    const getRandom = (min, max) => Math.floor(Math.random() * (max - min + 1) + min);

    // Tambahkan jumlah viewer, subscriber, dan like secara acak
    let newSubs = getRandom(5, 50);
    let newViews = getRandom(100, 500);
    let newLikes = getRandom(20, 200);

    // Perbarui database user
    user.subs += newSubs;
    user.view += newViews;
    user.like += newLikes;

    // Perbarui play button
    user.playbutton.silver = user.subs >= 100_000;
    user.playbutton.gold = user.subs >= 1_000_000;
    user.playbutton.diamond = user.subs >= 10_000_000;

    // Simpan waktu streaming terakhir
    user.laststream = now;

    // Simpan database setelah perubahan
    saveDatabase();

    // Format angka (misal: 1.2K, 1.7M)
    const formatNumber = (num) => {
      if (num >= 1_000_000) return (num / 1_000_000).toFixed(1) + 'M';
      if (num >= 1_000) return (num / 1_000).toFixed(1) + 'K';
      return num.toString();
    };

    // Format play button
    let playButtons = [];
    if (user.playbutton.silver) playButtons.push("Silver Play Button");
    if (user.playbutton.gold) playButtons.push("Gold Play Button");
    if (user.playbutton.diamond) playButtons.push("Diamond Play Button");

    let playButtonText = playButtons.length ? `\n\nKamu mendapatkan: ${playButtons.join(', ')}` : '';

    let teks = 
      `乂 RPG - YOUTUBE\n\n` +
      `Kamu streaming dan mendapatkan:\n\n` +
      `Subscriber: +${formatNumber(newSubs)}\n` +
      `Viewer: +${formatNumber(newViews)}\n` +
      `Like: +${formatNumber(newLikes)}\n` +
      playButtonText;

    return mecha.sendMessage(m.chat, { text: teks }, { quoted: m });
  },
  limit: true
};