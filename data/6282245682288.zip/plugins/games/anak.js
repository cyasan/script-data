exports.run = {
usage: ['inventory3'],
hidden: ['inv3'],
use: '',
category: 'rpg',
async: async (m, { func, mecha, setting }) => {
if (!global.db.users) global.db.users = {};
let user = global.db.users[m.sender];

const anak = user.anak || 0;
const sperma = user.ser || 0;

let inventory = `*${user.name.toUpperCase()}*\n\n- Total anak: ${anak}\n- Total sperma: ${sperma}`;

await mecha.sendMessage(m.chat, { text: inventory, contextInfo: { 
externalAdReply: {
title: `乂 INVENTORY`,
body: global.header,
mediaType: 1,
renderLargerThumbnail: false,
thumbnailUrl: setting.cover,
sourceUrl: '',
},
},
}, { quoted: m});
},
};