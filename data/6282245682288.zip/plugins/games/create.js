const fetch = require('node-fetch');

exports.run = {
  usage: ['create'],
  use: 'item,count',
  category: 'rpg',
  async: async (m, { mecha, users, setting }) => {
    if (!global.db.users) global.db.users = {};
    let user = global.db.users[m.sender];
    if (!user) {
      return mecha.sendMessage(m.chat, { text: 'User tidak ditemukan di database. Pastikan Anda sudah terdaftar!' }, { quoted: m });
    }

    const isPremium = user.premium || false;

    const items = {
      sword: { materials: { rock: 50, kayu: 100 }, money: 15000 },
      pickaxe: { materials: { rock: 65, kayu: 120 }, money: 15000 },
      bow: { materials: { rock: 55, kayu: 125, string: 80 }, money: 20000 },
      axe: { materials: { rock: 125, kayu: 150 }, money: 15000 },
      armor: { materials: { iron: 10, string: 50 }, money: 20000 },
      fishingrod: { materials: { kayu: 100, string: 60 }, money: 150000 },
      atm: { materials: {}, money: 100000 },
    };

    const userMoney = user.money || 0;
    const args = m.text.split(/\s+/);
    const itemName = args[0]?.toLowerCase();
    const count = parseInt(args[1], 10) || 1;

    if (!items[itemName] && itemName !== 'hunt') {
      return mecha.sendMessage(m.chat, { text: `Item "${itemName}" tidak ditemukan!` }, { quoted: m });
    }

    // Cek apakah user sudah memiliki ATM
    if (itemName === 'atm' && user.kuli) {
      return mecha.sendMessage(m.chat, { text: 'Kamu sudah memiliki ATM!' }, { quoted: m });
    }

    // [FITUR BARU] PROSES CREATE HUNT
    if (itemName === 'hunt') {
      const requiredItems = ['armor', 'sword', 'bow'];
      let totalMoneyCost = 0;
      let totalMaterials = {};

      for (const item of requiredItems) {
        const multiplier = isPremium ? { material: 3, money: 2 } : { material: 1, money: 1 };
        totalMoneyCost += items[item].money * multiplier.money;

        for (const [material, qty] of Object.entries(items[item].materials)) {
          totalMaterials[material] = (totalMaterials[material] || 0) + qty * multiplier.material;
        }
      }

      if (userMoney < totalMoneyCost) {
        return mecha.sendMessage(m.chat, { text: `Uang kamu tidak cukup untuk membeli perlengkapan berburu!\nDibutuhkan: *$${totalMoneyCost}*\nSaldo kamu: *$${userMoney}*` }, { quoted: m });
      }

      for (const [material, qty] of Object.entries(totalMaterials)) {
        if ((user[material] || 0) < qty) {
          return mecha.sendMessage(m.chat, { text: `Bahan *${material}* tidak cukup!\nDibutuhkan: *${qty}*\nKamu punya: *${user[material] || 0}*` }, { quoted: m });
        }
      }

      user.money -= totalMoneyCost;
      for (const [material, qty] of Object.entries(totalMaterials)) {
        user[material] -= qty;
      }

      for (const item of requiredItems) {
        user[item] = (user[item] || 0) + 1;
      }

      user.durabilitiesSword = (user.durabilitiesSword || 0) + 100;
      user.durabilitiesArmor = (user.durabilitiesArmor || 0) + 100;
      user.durabilitiesBow = (user.durabilitiesBow || 0) + 100;

      return mecha.sendMessage(m.chat, { text: `Berhasil membuat perlengkapan berburu!\n+1 *Armor*\n+1 *Sword*\n+1 *Bow*` }, { quoted: m });
    }

    // Proses pembuatan item biasa
    const foundItem = items[itemName];
    const multiplier = isPremium ? { material: 3, money: 2 } : { material: 1, money: 1 };
    const totalMoneyCost = foundItem.money * count * multiplier.money;

    if (userMoney < totalMoneyCost) {
      return mecha.sendMessage(m.chat, { text: `Uang kamu tidak cukup untuk membuat ${itemName} x${count}.\nDibutuhkan: *$${totalMoneyCost}*\nSaldo kamu: *$${userMoney}*` }, { quoted: m });
    }

    for (const [material, qty] of Object.entries(foundItem.materials)) {
      const requiredQty = qty * count * multiplier.material;
      if ((user[material] || 0) < requiredQty) {
        return mecha.sendMessage(m.chat, { text: `Bahan *${material}* tidak cukup!\nDibutuhkan: *${requiredQty}*\nKamu punya: *${user[material] || 0}*` }, { quoted: m });
      }
    }

    user.money -= totalMoneyCost;
    for (const [material, qty] of Object.entries(foundItem.materials)) {
      user[material] -= qty * count * multiplier.material;
    }

    user[itemName] = (user[itemName] || 0) + count;

    // Tambahkan durabilitas jika item bersangkutan
    const durability = 100;
    if (itemName === 'sword') user.durabilitiesSword = (user.durabilitiesSword || 0) + durability * count;
    if (itemName === 'armor') user.durabilitiesArmor = (user.durabilitiesArmor || 0) + durability * count;
    if (itemName === 'bow') user.durabilitiesBow = (user.durabilitiesBow || 0) + durability * count;
    if (itemName === 'axe') user.durabilitiesAxe = (user.durabilitiesAxe || 0) + durability * count;
    if (itemName === 'pickaxe') user.durabilitiesPickaxe = (user.durabilitiesPickaxe || 0) + durability * count;
    if (itemName === 'fishingrod') user.durabilitiesFishingrod = (user.durabilitiesFishingrod || 0) + durability * count;

    // Tandai bahwa user sudah memiliki ATM
    if (itemName === 'atm') user.kuli = true;

    return mecha.sendMessage(m.chat, { text: `Berhasil membuat *${count} ${itemName.charAt(0).toUpperCase() + itemName.slice(1)}*!` }, { quoted: m });
  },
  restrict: true
};