const fetch = require('node-fetch'); // Pastikan 'node-fetch' sudah terinstal
const cooldown = 172800000; // 2 hari dalam milidetik

// Inisialisasi global.airdrop jika belum ada
if (!global.airdrop) {
  global.airdrop = {
    slot: 5, // Default: 5 slot per hari
    lastReset: new Date().toDateString() // Untuk reset slot harian
  };
}

// Pastikan slot selalu ada
if (typeof global.airdrop.slot !== 'number' || global.airdrop.slot < 0) {
  global.airdrop.slot = 5;
}

exports.run = {
  usage: ['airdrop'],
  category: 'rpg',
  async: async (m, { func, mecha }) => {
    let user = global.db.users[m.sender];

    // Cek apakah user terdaftar
    if (!user) {
      let teks = 'User tidak ditemukan di database. Pastikan anda sudah terdaftar!';
      return mecha.sendMessage(m.chat, { text: teks }, { quoted: m });
    }

    // Inisialisasi `lastairdrop` jika belum ada
    if (!user.lastairdrop) user.lastairdrop = 0;

    // Reset slot jika sudah hari baru
    let today = new Date().toDateString();
    if (global.airdrop.lastReset !== today) {
      global.airdrop.slot = 5; // Reset slot ke 5 setiap hari
      global.airdrop.lastReset = today;
    }

    // Cek slot harian
    if (global.airdrop.slot <= 0) {
      return mecha.sendMessage(m.chat, { text: "Airdrop hari ini sudah habis! Coba lagi besok." }, { quoted: m });
    }

    // Cek cooldown
    if (Date.now() - user.lastairdrop < cooldown) {
      let teks = `Airdrop sudah diambil, coba lagi dalam ${func.msToTime(cooldown - (Date.now() - user.lastairdrop))}.`;
      return mecha.sendMessage(m.chat, { text: teks }, { quoted: m });
    }

    // Update cooldown
    user.lastairdrop = Date.now();

    // Kurangi slot
    global.airdrop.slot--;

    // Tentukan apakah pengguna mendapatkan hadiah atau zonk
    let chance = Math.random();
    let teks;
    let imageUrl;

    if (chance < 0.001) { // 0.2% kemungkinan Legendary
      user.premium = true;
      user.expired.premium = Date.now() + 432000000; // 5 hari premium
      user.limit += 99999;

      teks = `乂 RPG - AIRDROP LEGENDARY

- +5 Day Premium
- Limit: +99999

Selamat! Kamu mendapatkan hadiah LEGENDARY DROP!`;
      imageUrl = 'https://telegra.ph/file/d3bc1d7a97c62d3baaf73.jpg';
    
    } else if (chance < 0.3) { // 30% kemungkinan mendapatkan hadiah biasa
      let rewards = [];

      // Hadiah utama (limit, exp, balance, money)
      let limitReward = Math.floor(Math.random() * 191) + 10; // 10-200
      let expReward = Math.floor(Math.random() * 49001) + 1000; // 1000-50000
      let balanceReward = Math.floor(Math.random() * 49001) + 1000; // 1000-50000
      let moneyReward = Math.floor(Math.random() * 490001) + 10000; // 10000-500000

      // Hadiah makanan (buah langsung)
      let foodRewards = ['apel', 'jeruk', 'pisang', 'mangga', 'anggur'];
      let foodReceived = {};

      for (let food of foodRewards) {
        foodReceived[food] = Math.floor(Math.random() * 491) + 10; // 10-500
        user[food] = (user[food] || 0) + foodReceived[food]; // Tambahkan buah
        rewards.push(`- ${food}: +${foodReceived[food]}`);
      }

      // Update inventaris pengguna
      user.limit += limitReward;
      user.exp += expReward;
      user.balance += balanceReward;
      user.money += moneyReward;
      global.db.users[m.sender] = user; // Simpan perubahan ke database

      // Format teks hadiah
      teks = `乂 RPG - AIRDROP BERHASIL

- Limit: +${limitReward}
- EXP: +${expReward}
- Balance: +${balanceReward}
- Money: +${moneyReward}

${rewards.join('\n')}

Semua hadiah telah ditambahkan ke inventarismu.`;
      imageUrl = 'https://telegra.ph/file/d3bc1d7a97c62d3baaf73.jpg';
    
    } else { // 70% kemungkinan zonk
      teks = `乂 RPG - AIRDROP ZONK

Sayang sekali, kamu tidak mendapatkan apa-apa kali ini.
Coba lagi di lain waktu.`;
      imageUrl = 'https://telegra.ph/file/60437ce6d807b605adf5e.jpg';
    }

    // Ambil gambar sebagai buffer
    let thumbnailBuffer = await fetch(imageUrl).then(res => res.buffer());

    // Kirim pesan dengan externalAdReply
    mecha.sendMessage(m.chat, {
      text: teks,
      contextInfo: {
        externalAdReply: {
          title: "RPG - AIRDROP",
          body: global.footer,
          mediaUrl: '',
          sourceUrl: '',
          mediaType: 1,
          renderLargerThumbnail: true,
          thumbnail: thumbnailBuffer,
        }
      }
    }, { quoted: m });
  },
  limit: true,
  restrict: true,
};