const cooldown = 1800000; // 30 menit dalam milidetik

exports.run = {
  usage: ['berdagang'],
  hidden: ['trade'],
  use: 'mention or reply',
  category: 'rpg',
  async: async (m, { mecha, users }) => {
    // Ambil data user yang mengirim pesan
    let sender = global.db.users[m.sender];
    if (!sender) {
      return mecha.sendMessage(m.chat, { text: 'User tidak ditemukan dalam database. Pastikan Anda sudah terdaftar!' }, { quoted: m });
    }

    // Menangani mention atau reply (target user)
    let who = m.mentionedJid && m.mentionedJid[0] 
      ? m.mentionedJid[0] 
      : (m.quoted && m.quoted.sender ? m.quoted.sender : null);

    // Cek apakah ada target yang disebut atau dibalas
    if (!who) {
      return mecha.sendMessage(m.chat, { 
        text: `Mention atau reply seseorang untuk Berdagang`, 
        contextInfo: { mentionedJid: [m.sender] } 
      }, { quoted: m });
    }

    // Ambil data user yang disebutkan atau dibalas
    let targetUser = global.db.users[who];
    if (!targetUser) {
      return mecha.sendMessage(m.chat, { 
        text: 'User yang disebutkan atau dibalas tidak ditemukan dalam database.', 
        contextInfo: { mentionedJid: [who] }
      }, { quoted: m });
    }

    // Cek apakah kedua pengguna memiliki modal yang cukup untuk berdagang
    if (sender.balance < 10000) {
      return mecha.sendMessage(m.chat, { 
        text: `Balance kamu tidak mencukupi untuk berdagang.\nMinimal balance adalah $10.000.\n> Balance kamu: ${formatMoney(sender.balance)}`, 
        contextInfo: { mentionedJid: [m.sender] }
      }, { quoted: m });
    }

    if (targetUser.balance < 10000) {
      return mecha.sendMessage(m.chat, { 
        text: `Balance @${who.split('@')[0]} tidak mencukupi untuk berdagang.\nMinimal balance adalah $10.000.\n> Balance @${who.split('@')[0]}: ${formatMoney(targetUser.balance)}`, 
        contextInfo: { mentionedJid: [who] }
      }, { quoted: m });
    }

    // Periksa cooldown untuk pengirim
    if (Date.now() - sender.lastTrade < cooldown) {
      return mecha.sendMessage(m.chat, { 
        text: `Kamu sudah berdagang, mohon tunggu *${formatCooldown(cooldown - (Date.now() - sender.lastTrade))}* untuk bisa *berdagang* lagi.`,
        contextInfo: { mentionedJid: [m.sender] }
      }, { quoted: m });
    }

    // Set waktu perdagangan untuk pengirim
    sender.lastTrade = Date.now();

    // Keduanya memenuhi syarat untuk berdagang
    const tradeItems = ['Ikan', 'Sayur mayur', 'Buah buahan', 'Snack', 'Minuman'];
    const randomItem = tradeItems[Math.floor(Math.random() * tradeItems.length)];

    // Menentukan total uang yang diperoleh (dalam rentang 25.000 - 50.000) dan menggandakannya
    const totalMoney = Math.floor(Math.random() * (50000 - 25000 + 1)) + 25000;
    const totalMoneyDoubled = totalMoney * 2;

    // Mengurangi modal dari kedua pengguna
    sender.balance -= 10000;
    targetUser.balance -= 10000;

    // Kirim pesan awal
    await mecha.sendMessage(m.chat, { 
      text: `乂 *RPG BERDAGANG*\n\n@${m.sender.split('@')[0]} dan @${who.split('@')[0]} sedang berdagang...`,
      contextInfo: { mentionedJid: [m.sender, who] } 
    }, { quoted: m });

    // Tunggu 20 detik sebelum mengirimkan hasil
    await new Promise(resolve => setTimeout(resolve, 20000));

    // Update saldo pengguna setelah berdagang
    sender.balance += totalMoneyDoubled;
    targetUser.balance += totalMoneyDoubled;

    // Kirim pesan hasil perdagangan
    return mecha.sendMessage(m.chat, { 
      text: `乂 *RPG BERDAGANG*\n\n@${m.sender.split('@')[0]} dan @${who.split('@')[0]} berhasil berdagang ${randomItem}!\n\nKalian mendapatkan balance sebanyak: ${formatMoney(totalMoneyDoubled)}`,
      contextInfo: { mentionedJid: [m.sender, who] }
    }, { quoted: m });
  },
  limit: true,
  group: true,
};

// Fungsi untuk format uang
function formatMoney(amount) {
  return '$' + amount.toLocaleString('id-ID');
}

// Fungsi untuk format cooldown dalam bentuk HH:MM:SS
function formatCooldown(ms) {
  const hours = Math.floor(ms / 3600000);
  const minutes = Math.floor((ms % 3600000) / 60000);
  const seconds = Math.floor((ms % 60000) / 1000);
  return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
}