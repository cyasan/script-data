const adventurePlaces = [
  { name: "Tundra", rewards: ["magnetit", "hematit", "dolomit", "platinum", "jamur"] },
  { name: "Pantai", rewards: ["mutiara", "driftwood", "granit", "kelp", "seaweed"] },
  { name: "Mountain", rewards: ["perak", "kulitular", "kulitbuaya", "fosilhewan", "fosiltumbuhan"] },
  { name: "Hutan Mangrove", rewards: ["mangrove", "kulitikan", "kaktuslaut", "kulitpenyu", "batupasir"] },
  { name: "Desert", rewards: ["mineral", "fosil", "permata", "logam", "artefak"] },
  { name: "Tropical Forest", rewards: ["saranglebah", "batualam", "kulitkayu", "rubi", "zamrud"] },
  { name: "Boreal Forest", rewards: ["kronium", "nikel", "kuarsa", "batuakik", "birch"] },
  { name: "Savannah", rewards: ["amethyst", "citrine", "feldspar", "kalsit", "dolomit"] }
]

// Fungsi untuk memformat nama item
const formatItemName = (item) => {
  return item
    .replace(/kulitular/g, "Kulit Ular")
    .replace(/kulitbuaya/g, "Kulit Buaya")
    .replace(/fosilhewan/g, "Fosil Hewan")
    .replace(/fosiltumbuhan/g, "Fosil Tumbuhan")
    .replace(/kulitikan/g, "Kulit Ikan")
    .replace(/kaktuslaut/g, "Kaktus Laut")
    .replace(/kulitpenyu/g, "Kulit Penyu")
    .replace(/batupasir/g, "Batu Pasir")
    .replace(/saranglebah/g, "Sarang Lebah")
    .replace(/batualam/g, "Batu Alam")
    .replace(/kulitkayu/g, "Kulit Kayu")
    .replace(/batuakik/g, "Batu Akik")
    .replace(/([a-z])([A-Z])/g, "$1 $2") // Memisahkan camelCase jika ada
    .replace(/^./, (str) => str.toUpperCase()) // Huruf pertama kapital
}

exports.run = {
  usage: ['inventory2'],
  hidden: ['inv2'],
  category: 'rpg',
  async: async (m, { func, mecha, setting, users }) => {
    let user = global.db.users[m.sender]

    if (!user) {
      return mecha.sendMessage(m.chat, { text: 'User tidak ditemukan di database. Pastikan Anda sudah terdaftar!' }, { quoted: m })
    }

    let level = user.level || 1
    const expRequired = 10 * Math.pow(level, 2) + 50 * level + 100

    let inventoryMessage = `乂 RPG - INVENTORY\n\n` +
      `*Stamina:* ${user.stamina} / 100\n` +
      `*Money:* $${user.money.toLocaleString('en-US')}\n` +
      `*Exp:* ${user.exp || 0} / ${expRequired}\n` +
      `*Role:* ${user.role}\n\n`

    let hasItems = false

    adventurePlaces.forEach(({ name, rewards }) => {
      let placeItems = rewards
        .map(item => ({ item, amount: user[item] || 0 }))
        .filter(({ amount }) => amount > 0)

      if (placeItems.length > 0) {
        hasItems = true
        inventoryMessage += `*${name.toUpperCase()}*\n`
        inventoryMessage += placeItems.map(({ item, amount }) => `- ${formatItemName(item)}: ${amount}`).join("\n") + "\n\n"
      }
    })

    if (!hasItems) {
      inventoryMessage += "_Inventory kosong. Mulailah berpetualang untuk mendapatkan item!_\n"
    }

    // Mendapatkan profil pengguna
    let profilePicture = setting.cover // Gunakan setting.cover sebagai default
    try {
      let pp = await mecha.profilePictureUrl(m.sender, 'image')
      if (pp) profilePicture = pp
    } catch (err) { }

    await mecha.sendMessage(m.chat, {
      text: inventoryMessage,
      contextInfo: {
        externalAdReply: {
          title: `INVENTORY - ${m.pushname.toUpperCase()}`,
          body: global.header,
          mediaType: 1,
          thumbnailUrl: profilePicture,
          sourceUrl: '',
          renderLargerThumbnail: true
        }
      }
    }, { quoted: m })
  },
  restrict: true
}