exports.run = {
  usage: ['gudang'],
  hidden: ['buah', 'sayur'],
  category: 'rpg',
  async: async (m, { func, mecha, users, setting, froms }) => {
    const user = global.db.users[m.sender];
    const { 
      pisang, anggur, mangga, jeruk, apel, 
      bibitanggur, bibitapel, bibitpisang, bibitmangga, bibitjeruk,
      wortel, kentang, tomat, kubis, terong, labu,
      bibitwortel, bibitkentang, bibittomat, bibitkubis, bibitterong, bibitlabu
    } = user;

    const gudangInfo = `*HASIL PANEN BUAH*
    🍌 = *[ ${pisang} ]* Buah Pisang
    🍇 = *[ ${anggur} ]* Buah Anggur
    🥭 = *[ ${mangga} ]* Buah Mangga
    🍊 = *[ ${jeruk} ]* Buah Jeruk
    🍎 = *[ ${apel} ]* Buah Apel    

*HASIL PANEN SAYUR*
    🥕 = *[ ${wortel} ]* Wortel
    🥔 = *[ ${kentang} ]* Kentang
    🍅 = *[ ${tomat} ]* Tomat
    🥬 = *[ ${kubis} ]* Kubis
    🍆 = *[ ${terong} ]* Terong
    🎃 = *[ ${labu} ]* Labu

*BIBIT BUAH*
    🌾 = *[ ${bibitpisang} ]* Bibit Pisang
    🌾 = *[ ${bibitanggur} ]* Bibit Anggur
    🌾 = *[ ${bibitmangga} ]* Bibit Mangga
    🌾 = *[ ${bibitjeruk} ]* Bibit Jeruk
    🌾 = *[ ${bibitapel} ]* Bibit Apel    

*BIBIT SAYUR*
    🌱 = *[ ${bibitwortel} ]* Bibit Wortel
    🌱 = *[ ${bibitkentang} ]* Bibit Kentang
    🌱 = *[ ${bibittomat} ]* Bibit Tomat
    🌱 = *[ ${bibitkubis} ]* Bibit Kubis
    🌱 = *[ ${bibitterong} ]* Bibit Terong
    🌱 = *[ ${bibitlabu} ]* Bibit Labu

> Ketik: ${m.prefix}sell item,count untuk menjual buah atau sayur.
> Contoh: ${m.prefix}sell pisang 50`;

    const messageOptions = {
      text: gudangInfo,
      contextInfo: {
        externalAdReply: {
          title: '乂 G U D A N G',
          body: global.header,
          thumbnailUrl: 'https://files.catbox.moe/qvla2i.jpg',
          sourceUrl: '', // Ganti dengan URL yang sesuai jika diperlukan
          mediaType: 1,
          renderLargeThumbnail: true
        }
      }
    };

    mecha.sendMessage(m.chat, messageOptions, { quoted: m });
  },
  restrict: true,
};