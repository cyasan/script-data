const { createCanvas, loadImage } = require('canvas');
const fs = require('fs');

function formatMoney(amount) {
  return '$' + amount.toLocaleString('id-ID');
}

exports.run = {
  usage: ['buy'],
  use: 'item,count',
  category: 'rpg',
  async: async (m, { func, mecha, users, setting }) => {
    if (!global.db.users) global.db.users = {};
    let user = global.db.users[m.sender];

    if (!user) {
      return mecha.sendMessage(m.chat, { text: 'User tidak ditemukan di database. Pastikan Anda sudah terdaftar!' }, { quoted: m });
    }

    const items = {
Bumbu: {
    Bawang: { price: 300, icon: '🧄' },
    Kemiri: { price: 500, icon: '🌰' },
    Jahe: { price: 800, icon: '🫚' },
    Asam: { price: 400, icon: '🍋' },
    Cabai: { price: 700, icon: '🌶️' },
    Saus: { price: 350, icon: '🍾' },
},
      Ternak: {
        Ayam: { price: 2000, icon: '🐓' },
        Babi: { price: 5000, icon: '🐖' },
        Babihutan: { price: 10000, icon: '🐗' },
        Banteng: { price: 20000, icon: '🐂' },
        Kambing: { price: 15000, icon: '🐐' },
        Kerbau: { price: 30000, icon: '🐃' },
        Panda: { price: 50000, icon: '🐼' },
        Sapi: { price: 50000, icon: '🐄' },
        Monyet: { price: 25000, icon: '🐒' },
      },
      Buah: {
        Anggur: { price: 200, icon: '🍇' },
        Apel: { price: 500, icon: '🍎' },
        Jeruk: { price: 1000, icon: '🍊' },
        Mangga: { price: 1500, icon: '🥭' },
        Pisang: { price: 3000, icon: '🍌' },
      },
      Sayur: {
        Wortel: { price: 750, icon: '🥕' },
        Labu: { price: 750, icon: '🎃' },
        Kubis: { price: 750, icon: '🥬' },
        Terong: { price: 750, icon: '🍆' },
        Kentang: { price: 1000, icon: '🥔' },
        Tomat: { price: 1000, icon: '🍅' },
      },
      Tambang: {
        Rock: { price: 8000, icon: '🪨' },
        Diamond: { price: 100000, icon: '💎' },
        Emerald: { price: 90000, icon: '🟢' },
        Gold: { price: 70000, icon: '🥇' },
        Iron: { price: 60000, icon: '⛏️' },
      },
      Seafood: {
        Tongkol: { price: 3000, icon: '🐟' },
        Buntal: { price: 5000, icon: '🐡' },
        Pausmini: { price: 8000, icon: '🐋' },
        Udang: { price: 4000, icon: '🦐' },
        Gurita: { price: 7000, icon: '🐙' },
        Nila: { price: 3500, icon: '🐠' },
        Cumi: { price: 6000, icon: '🦑' },
        Langka: { price: 12000, icon: '🐳' },
        Kepiting: { price: 5000, icon: '🦀' },
        Kerang: { price: 3000, icon: '🐚' },
      },
    };

    if (!m.text) {
      let teks = ``;

      for (const [category, categoryItems] of Object.entries(items)) {
        teks += `*${category.toUpperCase()}*\n\`\`\`\n`;
        teks += `No. | Nama Item          | Harga    \n`;
        teks += `--------------------------------\n`;

        let index = 1;
        Object.entries(categoryItems).forEach(([itemName, item]) => {
          let numberFormatted = index.toString().padEnd(3);
          let itemFormatted = `${item.icon} ${itemName}`.padEnd(20);
          let priceFormatted = formatMoney(item.price).padStart(8);

          teks += `${numberFormatted} | ${itemFormatted} | ${priceFormatted}\n`;
          index++;
        });

        teks += `--------------------------------\n\`\`\`\n`;
      }

      teks += `> Contoh: ${m.prefix + m.command} Wortel 1\n> Uang kamu: *${formatMoney(user.money)}*`;

      return mecha.sendMessage(m.chat, { text: teks }, { quoted: func.fstatus("STORE - BUY") });
    }

    const [itemNameRaw, countRaw] = m.text.split(' ').map((v) => v.trim());
    const itemName = itemNameRaw.charAt(0).toUpperCase() + itemNameRaw.slice(1).toLowerCase();
    const count = parseInt(countRaw) || 1;

    if (count <= 0) {
      return mecha.sendMessage(m.chat, { text: 'Jumlah item harus lebih dari 0.' }, { quoted: m });
    }

    let foundItem;
    let category;

    for (const [cat, categoryItems] of Object.entries(items)) {
      if (categoryItems[itemName]) {
        foundItem = categoryItems[itemName];
        category = cat;
        break;
      }
    }

    if (!foundItem) {
      return mecha.sendMessage(m.chat, { text: `Item "${itemName}" tidak ditemukan!` }, { quoted: m });
    }

    const totalPrice = foundItem.price * count;

    if (user.money < totalPrice) {
      return mecha.sendMessage(m.chat, { 
        text: `Uang kamu tidak cukup untuk membeli ${count} ${itemName}.\n` +
          `> Total uang kamu: *${formatMoney(user.money)}*\n> Dibutuhkan: *${formatMoney(totalPrice)}*`
      }, { quoted: m });
    }

    user.money -= totalPrice;
    user[itemName] = (user[itemName] || 0) + count;

    let teks = `乂 *TRANSACTION - BUY*\n\n` +
           `- *Product* : ${foundItem.icon} ${itemName}\n` +
           `- *Count* : ${count}\n` +
           `- *Price* : ${formatMoney(foundItem.price)}\n` +
           `- *Total* : ${formatMoney(totalPrice)}\n` +
           `- *Status* : Success ✅`;

mecha.relayMessage(m.chat, {
    requestPaymentMessage: {
        currencyCodeIso4217: 'USD',
        amount1000: `${totalPrice}000`,
        requestFrom: m.sender,
        noteMessage: {
            extendedTextMessage: {
                text: teks,
                contextInfo: {
                    externalAdReply: {
                        showAdAttribution: true,
                    }
                }
            }
        }
    }
}, { quoted: m });
  },
  restrict: true,
};

async function createTransactionImage(username, text) {
  const canvas = createCanvas(800, 600);
  const ctx = canvas.getContext('2d');

  // Background color
  ctx.fillStyle = '#f0f0f0';
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  // Text color and font
  ctx.fillStyle = '#000';
  ctx.font = '30px Arial';

  // Draw username
  ctx.fillText(`Username: ${username}`, 50, 50);

  // Draw transaction text
  const lines = text.split('\n');
  let y = 100;
  lines.forEach(line => {
    ctx.fillText(line, 50, y);
    y += 40;
  });

  // Pastikan folder "sampah" ada
  if (!fs.existsSync('./sampah')) {
    fs.mkdirSync('./sampah', { recursive: true });
  }

  // Save the image to "sampah" folder
  const imagePath = `./sampah/transaction_${Date.now()}.png`;
  const buffer = canvas.toBuffer('image/png');
  fs.writeFileSync(imagePath, buffer);

  return imagePath;
}