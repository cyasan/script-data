const minMoneySteal = 1000; // Minimum money stolen
const maxMoneySteal = 50000; // Maximum money stolen
const cooldownTime = 15 * 60 * 1000; // 15 minutes in milliseconds

exports.run = {
  usage: ['rampok'],
  use: 'mention or reply',
  category: 'rpg',
  async: async (m, { mecha, users }) => {
    let sender = global.db.users[m.sender];

    // Check cooldown
    if (Date.now() - sender.lastRampok < cooldownTime) {
      const remainingTime = cooldownTime - (Date.now() - sender.lastRampok);
      const hours = String(Math.floor(remainingTime / (60 * 60 * 1000))).padStart(2, '0');
      const minutes = String(Math.floor((remainingTime % (60 * 60 * 1000)) / (60 * 1000))).padStart(2, '0');
      const seconds = String(Math.floor((remainingTime % (60 * 1000)) / 1000)).padStart(2, '0');
      return mecha.sendMessage(
        m.chat,
        { text: `Kamu sudah merampok baru-baru ini! Tunggu *${hours}:${minutes}:${seconds}* sebelum mencoba lagi.` },
        { quoted: m }
      );
    }

    // Determine target from reply or mention
    let who = m.mentionedJid && m.mentionedJid[0] 
      ? m.mentionedJid[0] 
      : m.quoted && m.quoted.sender 
      ? m.quoted.sender 
      : null;

    if (!who) {
      return mecha.sendMessage(
        m.chat,
        { text: 'Mention atau reply chat target.' },
        { quoted: m }
      );
    }

    // Check if the target user exists in the database
    if (!global.db.users[who]) {
      return mecha.sendMessage(
        m.chat,
        { text: 'User yang kamu tuju tidak ditemukan di database. Pastikan kamu dan pengguna target sudah terdaftar!' },
        { quoted: m }
      );
    }

    let receiver = global.db.users[who];

    // Prevent robbing the bot
    if (who === mecha.user.jid && !sender.premium) {
      return mecha.sendMessage(m.chat, { text: 'Hanya user premium yang bisa merampok bot!' }, { quoted: m });
    }

    // Prevent robbing the owner
    if (global.owner && global.owner.includes(who) && !sender.premium) {
      return mecha.sendMessage(m.chat, { text: 'Hanya user premium yang bisa merampok owner!' }, { quoted: m });
    }

    // Prevent robbing yourself
    if (who === m.sender) {
      return mecha.sendMessage(
        m.chat,
        { text: 'Tidak bisa merampok diri sendiri!' },
        { quoted: m }
      );
    }

    // Check if the sender has enough balance to rob
    if (sender.balance < 1000) {
      return mecha.sendMessage(
        m.chat,
        { text: 'Kamu tidak memiliki cukup balance untuk merampok. Pastikan kamu memiliki setidaknya 1000 balance.' },
        { quoted: m }
      );
    }

    // Check if the target has less than 10,000 balance
    if (receiver.balance < 10000) {
      return mecha.sendMessage(
        m.chat,
        { text: `Target terlalu miskin, balance dia hanya *${receiver.balance}*.` },
        { quoted: m }
      );
    }

    // Calculate stolen money
    let moneyStolen = Math.floor(Math.random() * (maxMoneySteal - minMoneySteal + 1)) + minMoneySteal;

    // Apply multiplier if robbing owner or bot as a premium user
    if ((who === mecha.user.jid || (global.owner && global.owner.includes(who))) && sender.premium) {
      moneyStolen *= 10;
    }

    sender.balance += moneyStolen; // Add money to sender's account
    receiver.balance -= moneyStolen; // Subtract money from receiver's account
    sender.lastRampok = Date.now(); // Update cooldown

    // Send success message
    await mecha.sendMessage(
      m.chat,
      { 
        text: `Kamu merampok @${who.split('@')[0]} sebanyak $${moneyStolen} balance.`,
        contextInfo: { mentionedJid: [who] } // Ensure mentionedJid is correct
      },
      { quoted: m }
    );
  },
  limit: true,
  group: true,
};