const cooldown = 1800000; // 30 menit

exports.run = {
  usage: ['ngocok', 'colmek'],
  use: 'mention or reply',
  category: 'rpg',
  async: async (m, { mecha, users }) => {
    const sender = global.db.users[m.sender];
    if (!sender) {
      return mecha.sendMessage(m.chat, { text: 'Kamu belum terdaftar di database.' }, { quoted: m });
    }

    const gender = sender.gender;
    const command = m.command || (m.text?.split(' ')[0]?.slice(1) ?? '');
    const prefix = m.prefix || '/';

    // Validasi gender berdasarkan perintah
    if (command === 'ngocok' && gender !== 'Laki-laki') {
      return mecha.sendMessage(m.chat, {
        text: `Fitur ini tidak tersedia karena kamu adalah ${gender || 'tidak diketahui'}.\nFitur yang tersedia: *${prefix}colmek*`
      }, { quoted: m });
    }

    if (command === 'colmek' && gender !== 'Perempuan') {
      return mecha.sendMessage(m.chat, {
        text: `Fitur ini tidak tersedia karena kamu adalah ${gender || 'tidak diketahui'}.\nFitur yang tersedia: *${prefix}ngocok*`
      }, { quoted: m });
    }

    const who = m.mentionedJid?.[0] || (m.quoted?.sender || null);

    // Kalau sendiri
    if (!who) {
      const totalAnak = Math.floor(Math.random() * 250) + 1;
      sender.ser = (sender.ser || 0) + totalAnak;

      await mecha.sendMessage(m.chat, {
        text: `@${m.sender.split('@')[0]} sedang ${command}...`,
        contextInfo: { mentionedJid: [m.sender] }
      }, { quoted: m });

      await new Promise(r => setTimeout(r, 20000));

      return mecha.sendMessage(m.chat, {
        text: `@${m.sender.split('@')[0]} telah ${command} dan mendapatkan ${totalAnak} sperma.`,
        contextInfo: { mentionedJid: [m.sender] }
      }, { quoted: m });
    }

    const targetUser = global.db.users[who];
    if (!targetUser) {
      return mecha.sendMessage(m.chat, { text: 'User yang disebutkan belum terdaftar di database.' }, { quoted: m });
    }

    const targetGender = targetUser.gender;

    // Jika gender berbeda, arahkan ke /ewe
    if ((gender === 'Laki-laki' && targetGender === 'Perempuan') ||
        (gender === 'Perempuan' && targetGender === 'Laki-laki')) {
      return mecha.sendMessage(m.chat, {
        text: `Fitur ini tidak cocok karena kalian adalah ${gender} dan ${targetGender}.\nGunakan *${prefix}ewe*`
      }, { quoted: m });
    }

    const totalAnak = Math.floor(Math.random() * 500) + 2;

    sender.ser = (sender.ser || 0) + totalAnak;
    targetUser.ser = (targetUser.ser || 0) + totalAnak;

    await mecha.sendMessage(m.chat, {
      text: `@${m.sender.split('@')[0]} dan @${who.split('@')[0]} sedang ${command} bersama...`,
      contextInfo: { mentionedJid: [m.sender, who] }
    }, { quoted: m });

    await new Promise(r => setTimeout(r, 20000));

    return mecha.sendMessage(m.chat, {
      text: `@${m.sender.split('@')[0]} dan @${who.split('@')[0]} telah selesai ${command} dan mendapatkan ${totalAnak} sperma.`,
      contextInfo: { mentionedJid: [m.sender, who] }
    }, { quoted: m });
  },
  limit: true,
};