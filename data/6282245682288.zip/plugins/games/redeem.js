exports.run = {
  usage: ['redeem'],
  category: 'rpg',
  async: async (m, { mecha, users, setting, args = [] }) => {
    if (!global.db.users) global.db.users = {};
    if (!global.db.redeem) global.db.redeem = { slots: 5, lastUpdate: Date.now(), daily: [] };
    if (!global.db.codes) global.db.codes = { '10351212': true }; // Inisialisasi kode pertama (ALEX1212 -> 10351212)

    const maxSlots = 10;
    const user = global.db.users[m.sender];
    if (!user) {
      return mecha.sendMessage(m.chat, { text: 'User tidak ditemukan di database. Pastikan Anda sudah terdaftar!' }, { quoted: m });
    }

    const now = Date.now();
    const oneDay = 24 * 60 * 60 * 1000;
    const today = new Date().toISOString().split('T')[0];

    if (now - global.db.redeem.lastUpdate >= oneDay) {
      const daysPassed = Math.floor((now - global.db.redeem.lastUpdate) / oneDay);
      global.db.redeem.slots = Math.min(maxSlots, global.db.redeem.slots + daysPassed);
      global.db.redeem.lastUpdate += daysPassed * oneDay;
    }

    if (!global.db.redeem[today]) global.db.redeem[today] = [];

    if (!global.owner.includes(m.sender) && global.db.redeem[today].includes(m.sender)) {
      return mecha.sendMessage(m.chat, { text: 'Kamu sudah melakukan redeem hari ini. Coba lagi besok!' }, { quoted: m });
    }

    if (!global.owner.includes(m.sender) && global.db.redeem.slots <= 0) {
      return mecha.sendMessage(m.chat, { text: 'Kuota redeem hari ini sudah habis. Coba lagi besok!' }, { quoted: m });
    }

    const rewards = {
      limit: 15,
      balance: 35000,
      money: 150000,
      exp: 1320,
    };

    let code = (args[0] || '').toUpperCase(); // Ambil kode dan ubah jadi huruf besar
    code = convertCode(code); // Konversi kode ALEX/LEXY ke angka

    let multiplier = 1;

    if (code) {
      if (global.db.codes[code]) {
        multiplier = 3;
        delete global.db.codes[code];

        const newCode = generateCode();
        global.db.codes[newCode] = true;
        const creationDate = new Date().toLocaleString();
        const messageToOwner = `New code for redeem\n\n- Code: ${newCode}\n- Create: ${creationDate}`;
        mecha.sendMessage(global.owner, { text: messageToOwner });
      } else {
        return mecha.sendMessage(m.chat, { text: 'Kode tidak valid atau sudah hangus!' }, { quoted: m });
      }
    }

    user.limit = (user.limit || 0) + rewards.limit * multiplier;
    user.balance = (user.balance || 0) + rewards.balance * multiplier;
    user.money = (user.money || 0) + rewards.money * multiplier;
    user.exp = (user.exp || 0) + rewards.exp * multiplier;

    if (!global.owner.includes(m.sender)) {
      global.db.redeem[today].push(m.sender);
      global.db.redeem.slots--;
    }

    return mecha.sendMessage(m.chat, {
      text: `乂 *REDEEM*\n\n` +
        `- Limit: ${rewards.limit * multiplier}\n` +
        `- Balance: $${(rewards.balance * multiplier).toLocaleString()}\n` +
        `- Money: $${(rewards.money * multiplier).toLocaleString()}\n` +
        `- Exp: ${rewards.exp * multiplier}\n\n` +
        `> Kamu telah berhasil melakukan redeem hadiah hari ini!` +
        (multiplier > 1 ? `\n> Kode "${args[0]}" valid, hadiah dikalikan dengan 3!` : '')
    }, { quoted: m });
  },
  restrict: true,
  limit: true
};

// Fungsi untuk mengonversi kode "ALEX1212" menjadi "10351212"
function convertCode(input) {
  if (input.startsWith('ALEX')) {
    return '1035' + input.slice(4);
  } else if (input.startsWith('LEXY')) {
    return '4579' + input.slice(4);
  }
  return input.replace(/[^0-9]/g, ''); // Jika format salah, hanya ambil angka
}

// Fungsi untuk menghasilkan kode baru (dalam format angka)
function generateCode() {
  const prefixes = ['1035', '4579']; // "ALEX" = 1035, "LEXY" = 4579
  const randomPrefix = prefixes[Math.floor(Math.random() * prefixes.length)];
  const randomNumber = Math.floor(100000 + Math.random() * 900000);
  return randomPrefix + randomNumber;
}