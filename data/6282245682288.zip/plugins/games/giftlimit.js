exports.run = {
  usage: ['giftlimit'],
  hidden: ['gift'],
  use: 'count + reply chat target',
  category: 'games',
  async: async (m, { func, mecha }) => {
    if (m.quoted) {
      if (typeof global.db.users[m.quoted.sender] == 'undefined') 
        return mecha.sendMessage(m.chat, { text: 'User data not found.' }, { quoted: m });
      if (m.quoted.sender == m.sender) 
        return mecha.sendMessage(m.chat, { text: 'Tidak bisa gift ke diri sendiri!' }, { quoted: m });
      if (!m.text) 
        return mecha.sendMessage(m.chat, { text: 'Masukkan jumlah nya!' }, { quoted: m });
      if (isNaN(m.text)) 
        return mecha.sendMessage(m.chat, { text: 'Jumlah harus berupa angka!' }, { quoted: m });
      if (Number(m.text) > 1000) 
        return mecha.sendMessage(m.chat, { text: 'Maksimal 1000 untuk gift limit!' }, { quoted: m });
      if (Number(m.text) < 1) 
        return mecha.sendMessage(m.chat, { text: 'Minimal 1 untuk bisa gift limit!' }, { quoted: m });

      let count = parseInt(m.text.replace(/[^0-9]/g, ''));
      if (global.db.users[m.sender].limit < count && !m.isOwner) 
        return mecha.sendMessage(m.chat, { text: 'Limit lo gak cukup dek.' }, { quoted: m });

      // Kurangi limit pengirim, tambahkan ke target
      global.db.users[m.sender].limit -= count;
      global.db.users[m.quoted.sender].limit += count;

      // Kirim pesan sukses dengan menggunakan contextInfo untuk mention target
      mecha.sendMessage(
        m.chat, 
        { 
          text: `Sukses gift limit sebanyak *${count}* kepada @${m.quoted.sender.split('@')[0]}`, 
          contextInfo: { mentionedJid: [m.quoted.sender] }
        }, 
        { quoted: m }
      );
    } else {
      // Jika tidak ada reply pesan
      mecha.sendMessage(
        m.chat, 
        { text: `Gunakan dengan cara ${m.prefix + m.command} jumlah dan reply pesan target` }, 
        { quoted: m }
      );
    }
  },
  group: true
};