const { createCanvas, loadImage } = require('canvas');
const fs = require('fs');
const path = require('path');

function formatMoney(amount) {
  return '$' + amount.toLocaleString('id-ID');
}

exports.run = {
  usage: ['sell'],
  use: 'item,count',
  category: 'rpg',
  async: async (m, { func, mecha, users, setting, froms }) => {
    if (!global.db.users) global.db.users = {};
    let seller = global.db.users[m.sender];

    if (!seller) {
      return mecha.sendMessage(m.chat, { text: "User tidak ditemukan di database. Pastikan Anda sudah terdaftar!" }, { quoted: m });
    }

    const items = {
      bibit: {
        bibitanggur: { price: 1000, icon: '🍇' },
        bibitapel: { price: 1000, icon: '🍎' },
        bibitjeruk: { price: 1000, icon: '🍊' },
        bibitmangga: { price: 1000, icon: '🥭' },
        bibitpisang: { price: 1000, icon: '🍌' },
        bibitwortel: { price: 500, icon: '🥕' },
        bibitlabu: { price: 500, icon: '🎃' },
        bibitkubis: { price: 500, icon: '🥬' },
        bibitterong: { price: 500, icon: '🍆' },
        bibitkentang: { price: 500, icon: '🥔' },
        bibittomat: { price: 500, icon: '🍅' },
      },
      buah: {
        anggur: { price: 1000, icon: '🍇' },
        apel: { price: 1000, icon: '🍎' },
        jeruk: { price: 1000, icon: '🍊' },
        mangga: { price: 1000, icon: '🥭' },
        pisang: { price: 1000, icon: '🍌' },
      },
      sayur: {
        wortel: { price: 750, icon: '🥕' },
        labu: { price: 750, icon: '🎃' },
        kubis: { price: 750, icon: '🥬' },
        terong: { price: 750, icon: '🍆' },
        kentang: { price: 1000, icon: '🥔' },
        tomat: { price: 1000, icon: '🍅' },
      },
      hewan: {
        banteng: { price: 1000, icon: '🐂' },
        harimau: { price: 1000, icon: '🐅' },
        gajah: { price: 1000, icon: '🐘' },
        kambing: { price: 1000, icon: '🐐' },
        panda: { price: 1000, icon: '🐼' },
        buaya: { price: 1000, icon: '🐊' },
        kerbau: { price: 1000, icon: '🐃' },
        sapi: { price: 1000, icon: '🐄' },
        monyet: { price: 1000, icon: '🐒' },
        babi: { price: 1000, icon: '🐖' },
        babihutan: { price: 1000, icon: '🐗' },
        ayam: { price: 1000, icon: '🐓' },
      },
seafood: {
  tongkol: { price: 1000, icon: '🐟' },
  buntal: { price: 1000, icon: '🐡' },
  kepiting: { price: 1000, icon: '🦀' },
  udang: { price: 1000, icon: '🦐' },
  kerang: { price: 1000, icon: '🐚' },
  pausmini: { price: 1000, icon: '🐋' },
  gurita: { price: 1000, icon: '🐙' },
  nila: { price: 1000, icon: '🐠' },
  cumi: { price: 1000, icon: '🦑' },
  langka: { price: 1000, icon: '🐳' },
},
sampah: {
        plastik: { price: 100, icon: '🍶'},
        batu: { price: 100, icon: '🪨' },
        kardus: { price: 100, icon: '📦' },
        kaleng: { price: 100, icon: '🥫' },
        daun: { price: 100, icon: '🍂' },
        trash: { price: 100, icon: '🗑️' },
},
      spaces: {
        meteorit: { price: 100, icon: '☄️' },
        crystal: { price: 100, icon: '💎' },
        metal: { price: 100, icon: '🔩' },
        stardust: { price: 100, icon: '✨' },
        alien_artifact: { price: 100, icon: '🛸' },
        moon_rock: { price: 100, icon: '🌑' },
        unknown_substance: { price: 100, icon: '🧪' },
      }
    };

    const categories = Object.keys(items);

    if (!m.text) {
      let teks = '';

      for (const category of categories) {
        let totalCategoryItems = Object.keys(items[category])
          .reduce((sum, itemName) => sum + (seller[itemName] || 0), 0);

        teks += `*${category.toUpperCase()}*\n\`\`\`\n`;
        teks += `No. | Nama Item            | Harga\n`;
        teks += `----------------------------------\n`;

        let index = 1;
        Object.entries(items[category]).forEach(([itemName, item]) => {
          let numberFormatted = index.toString().padEnd(3);
          let itemFormatted = `${item.icon} ${itemName.replace(/_/g, ' ')}`.padEnd(21);
          let priceFormatted = formatMoney(item.price).padStart(8);

          teks += `${numberFormatted} | ${itemFormatted} | ${priceFormatted}\n`;
          index++;
        });

        teks += `----------------------------------\n\`\`\`\n`;
        teks += `Kamu memiliki *${totalCategoryItems}* ${category}.\n`;
        teks += `> *${m.prefix + m.command} ${category}* untuk menjual semua ${category}.\n\n`;
      }

      teks += `Contoh: ${m.prefix + m.command} wortel 500`;

      return mecha.sendMessage(m.chat, { text: teks }, { quoted: func.fstatus("STORE - SELL") });
    }

    const args = m.text.split(/\s+/);
    const itemToSell = args[0].toLowerCase();

    const sellAll = (category) => {
      let totalProfit = 0;
      let totalItems = 0;

      Object.entries(items[category]).forEach(([itemName, item]) => {
        if (seller[itemName] > 0) {
          totalProfit += seller[itemName] * item.price;
          totalItems += seller[itemName];

          seller.money += seller[itemName] * item.price;
          seller[itemName] = 0;
        }
      });

      if (totalProfit === 0) {
        return mecha.sendMessage(m.chat, { text: `Kamu tidak memiliki ${category} untuk dijual!` }, { quoted: m });
      }

      const teks = `乂 *TRANSACTION - SELL*\n\n` +
        ` + - Product : ALL ${category.toUpperCase()}\n` +
        ` + - Count : ${totalItems}\n` +
        ` + - Total : ${formatMoney(totalProfit)}\n` +
        ` + - Status : Success ✅`;

      mecha.relayMessage(m.chat, {
    requestPaymentMessage: {
        currencyCodeIso4217: 'USD',
        amount1000: `${totalProfit}000`,
        requestFrom: m.sender,
        noteMessage: {
            extendedTextMessage: {
                text: teks,
                contextInfo: {
                    externalAdReply: {
                        showAdAttribution: true,
                    }
                }
            }
        }
    }
}, { quoted: m });

      return;
    };

    if (categories.includes(itemToSell)) {
      return sellAll(itemToSell);
    }

    const sellAmount = parseInt(args[1], 10);

    let itemSell;
    for (const category of categories) {
      if (items[category][itemToSell]) {
        itemSell = items[category][itemToSell];
        break;
      }
    }

    if (!itemSell) {
      return mecha.sendMessage(m.chat, { text: `Item "${itemToSell}" tidak ditemukan!` }, { quoted: m });
    }

    if (isNaN(sellAmount) || sellAmount <= 0) {
      return mecha.sendMessage(m.chat, { text: 'Jumlah harus berupa angka yang valid dan lebih dari 0!' }, { quoted: m });
    }

    if (!seller[itemToSell] || seller[itemToSell] < sellAmount) {
      return mecha.sendMessage(m.chat, { text: `Kamu tidak memiliki cukup *${itemToSell}* untuk dijual!` }, { quoted: m });
    }

    const totalSellPrice = itemSell.price * sellAmount;

    seller.money += totalSellPrice;
    seller[itemToSell] -= sellAmount;

    const teks = `乂 *TRANSAKSI - SELL*\n\n` +
      ` + - Product   : ${itemSell.icon} ${itemToSell.toUpperCase()}\n` +
      ` + - Count : ${sellAmount}\n` +
      ` + - Price : ${formatMoney(itemSell.price)}\n` +
      ` + - Total : ${formatMoney(totalSellPrice)}\n` +
      ` + - Status: Success ✅`;

    mecha.relayMessage(m.chat, {
    requestPaymentMessage: {
        currencyCodeIso4217: 'USD',
        amount1000: `${totalSellPrice}000`,
        requestFrom: m.sender,
        noteMessage: {
            extendedTextMessage: {
                text: teks,
                contextInfo: {
                    externalAdReply: {
                        showAdAttribution: true,
                    }
                }
            }
        }
    }
}, { quoted: m });
  },
  restrict: true
};

async function createTransactionImage(username, text) {
  const canvas = createCanvas(800, 600);
  const ctx = canvas.getContext('2d');

  // Background color
  ctx.fillStyle = '#f0f0f0';
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  // Text color and font
  ctx.fillStyle = '#000';
  ctx.font = '30px Arial';

  // Draw username
  ctx.fillText(`Username: ${username}`, 50, 50);

  // Draw transaction text
  const lines = text.split('\n');
  let y = 100;
  lines.forEach(line => {
    ctx.fillText(line, 50, y);
    y += 40;
  });

 // Pastikan folder "sampah" ada
  if (!fs.existsSync('./sampah')) {
    fs.mkdirSync('./sampah', { recursive: true });
  }

  // Save the image to "sampah" folder
  const imagePath = `./sampah/transaction_${Date.now()}.png`;
  const buffer = canvas.toBuffer('image/png');
  fs.writeFileSync(imagePath, buffer);

  return imagePath;
}