function formatMoney(amount) {
  return '$' + amount.toLocaleString('id-ID'); // Format dengan simbol $
}

function formatTime(milliseconds) {
  const seconds = Math.floor(milliseconds / 1000);
  const hours = Math.floor(seconds / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  const secs = seconds % 60;

  return `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
}

exports.run = {
  usage: ['bansos'],
  category: 'rpg',
  async: async (m, { mecha, users }) => {
    let user = global.db.users[m.sender];
    if (!user) {
      return mecha.sendMessage(m.chat, { text: 'User tidak ditemukan di database. Pastikan Anda sudah terdaftar!' }, { quoted: m });
    }

    // Cek cooldown
    const lastBansosTime = user.lastBansos || 0;
    const cooldownTime = 30 * 60 * 1000; // 30 menit dalam milidetik
    const currentTime = Date.now();

    if (currentTime - lastBansosTime < cooldownTime) {
      const timeLeft = cooldownTime - (currentTime - lastBansosTime);
      const formattedTime = formatTime(timeLeft);
      return mecha.sendMessage(m.chat, { text: `Kamu sudah korupsi Bansos, mohon tunggu ${formattedTime} untuk korupsi Bansos kembali.` }, { quoted: m });
    }

    // Simulasi keberhasilan korupsi
    const isSuccess = Math.random() > 0.5; // 50% kemungkinan sukses atau gagal

    if (isSuccess) {
      // Keberhasilan
      const amount = Math.floor(Math.random() * (500000 - 100000 + 1)) + 100000; // Money antara 100000 dan 500000
      user.balance += amount;

      // Simpan waktu saat bansos berhasil dilakukan
      user.lastBansos = currentTime;

      let teks = `乂 *RPG BANSOS*\n\nKamu berhasil korupsi Dana bansos sebanyak *${formatMoney(amount)}* balance.`;

      return mecha.sendMessage(
        m.chat,
        {
          text: teks,
          contextInfo: {
            externalAdReply: {
              title: 'Kamu Berhasil!',
              body: `Dana bansos berhasil dikorupsi!`,
              mediaType: 2,
              thumbnailUrl: 'https://telegra.ph/file/d31fcc46b09ce7bf236a7.jpg', // Thumbnail berhasil
            },
          },
        },
        { quoted: m }
      );
    } else {
      // Kegagalan
      const loss = Math.floor(Math.random() * (250000 - 50000 + 1)) + 50000; // Money rugi antara 50000 dan 250000
      user.balance -= loss;

      // Simpan waktu saat bansos gagal dilakukan
      user.lastBansos = currentTime;

      let teks = `乂 *RPG BANSOS*\n\nKamu gagal korupsi Dana bansos dan kamu rugi sebanyak *${formatMoney(loss)}* balance.`;

      return mecha.sendMessage(
        m.chat,
        {
          text: teks,
          contextInfo: {
            externalAdReply: {
              title: 'Kamu Gagal!',
              body: `Dana bansos gagal dikorupsi!`,
              mediaType: 2,
              thumbnailUrl: 'https://telegra.ph/file/afcf9a7f4e713591080b5.jpg', // Thumbnail gagal
            },
          },
        },
        { quoted: m }
      );
    }
  },
  limit: true,
  restrict: true
};