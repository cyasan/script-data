exports.run = {
  usage: ['akunyt'],
  use: 'mention atau reply',
  category: 'rpg',
  async: async (m, { mecha, args }) => {
    if (!global.db.users) global.db.users = {};

    // Pastikan args tidak undefined
    args = args || [];

    // Ambil user target (mention/reply) atau default ke pengirim
    let targetId = m.sender;
    
    if (m.quoted) {
      targetId = m.quoted.sender;
    } else if (args.length > 0 && args[0]?.startsWith('@')) {
      targetId = args[0].replace(/[@+]/g, '') + '@s.whatsapp.net';
    }

    // Pastikan user target ada di database
    if (!global.db.users[targetId]) {
      global.db.users[targetId] = {
        playbutton: false,
        subs: 0,
        ch: '',
        view: 0,
        like: 0
      };
    }

    let user = global.db.users[targetId];

    // Fungsi format angka (1.2K, 1.7M)
    const formatNumber = (num) => {
      if (num >= 1_000_000) return (num / 1_000_000).toFixed(1) + 'M';
      if (num >= 1_000) return (num / 1_000).toFixed(1) + 'K';
      return num.toString();
    };

    // Data YouTube pengguna
    const channelName = user.ch || 'Tidak ada';
    const subs = user.subs || 0;
    const views = user.view || 0;
    const likes = user.like || 0;

    // Penentuan play button
    const silver = subs >= 100_000 ? '✅' : '❌';
    const gold = subs >= 1_000_000 ? '✅' : '❌';
    const diamond = subs >= 10_000_000 ? '✅' : '❌';

    const teks = 
      `乂 *AKUN YOUTUBE*\n\n` +
      `- *Streamer:* @${targetId.split('@')[0]}\n` +
      `- *Channel:* ${channelName}\n` +
      `- *Subscriber:* ${formatNumber(subs)}\n` +
      `- *Viewer:* ${formatNumber(views)}\n` +
      `- *Like:* ${formatNumber(likes)}\n\n` +
      `- *Silver playbutton:* ${silver}\n` +
      `- *Gold playbutton:* ${gold}\n` +
      `- *Diamond playbutton:* ${diamond}\n\n` +
      `_Data di atas adalah fake._`;

    return mecha.sendMessage(m.chat, { text: teks, mentions: [targetId] }, { quoted: m });
  }
};