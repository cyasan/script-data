const weeklyCooldown = 604800000; // 7 days in milliseconds (1 week)
const monthlyCooldown = 2592000000; // 30 days in milliseconds (1 month)

exports.run = {
  usage: ['weekly', 'monthly'],
  hidden: ['bonusweekly', 'bonusmonthly'],
  category: 'rpg',
  async: async (m, { func, mecha, users, setting, froms }) => {
    let user = global.db.users[m.sender];

    // Check if user exists
    if (!user) {
      let teks = 'User tidak ditemukan di database. Pastikan anda sudah terdaftar!';
      return mecha.sendMessage(m.chat, { text: teks }, { quoted: m });
    }

    // Check the command used and determine the cooldown
    let cooldown, rewardMultiplier, bonusType;
    if (m.command === 'monthly') {
      cooldown = monthlyCooldown;
      rewardMultiplier = 4; // 4 times the reward for monthly
      bonusType = 'bulanan';
    } else {
      cooldown = weeklyCooldown;
      rewardMultiplier = 1; // No multiplier for weekly
      bonusType = 'mingguan';
    }

    // Check cooldown
    if (Date.now() - user[`last${bonusType}`] < cooldown) {
      let teks = `Kamu sudah mengambil bonus ${bonusType}, mohon tunggu *${func.msToTime(cooldown - (Date.now() - user[`last${bonusType}`]))}* untuk mengambilnya kembali.`;
      return mecha.sendMessage(m.chat, { text: teks }, { quoted: m });
    }

    // Update cooldown
    user[`last${bonusType}`] = Date.now();

    // Define rewards (with multiplier for monthly)
    let limitReward = 20 * rewardMultiplier; // Limit is fixed, multiplied by 4 for monthly
    let balanceReward = (Math.floor(Math.random() * (50000 - 20000 + 1)) + 20000) * rewardMultiplier; // Random between 20000 and 50000, multiplied by 4 for monthly
    let expReward = (Math.floor(Math.random() * (10000 - 5000 + 1)) + 5000) * rewardMultiplier; // Random between 5000 and 10000, multiplied by 4 for monthly
    let moneyReward = (Math.floor(Math.random() * (200000 - 100000 + 1)) + 100000) * rewardMultiplier; // Random between 100000 and 200000, multiplied by 4 for monthly

    // Update user inventory
    user.limit += limitReward;
    user.balance += balanceReward;
    user.exp += expReward;
    user.money += moneyReward;

    // Reply with results
    let teks = `乂 *RPG - BONUS ${bonusType.toUpperCase()}*

+ ${limitReward} Limit
+ ${balanceReward} Balance
+ ${expReward} EXP
+ ${moneyReward} Money

> Bonus ${bonusType}mu sudah ditambahkan ke inventarimu!`;

    mecha.sendMessage(m.chat, { text: teks }, { quoted: m });
  },
  limit: true,
  restrict: true,
};