exports.run = {
   usage: ['antiporn'],
   use: 'on / off',
   category: 'admin tools',
   async: async (m, { func, mecha }) => {
      if (!db.groups[m.chat]) db.groups[m.chat] = {}; // Inisialisasi jika belum ada
      let currentStatus = db.groups[m.chat].antiporn || false;

      if (m.args[0] === 'on') {
         if (currentStatus) {
            return mecha.sendMessage(m.chat, { text: 'Antiporn has been activated previously.' }, { quoted: m });
         }
         db.groups[m.chat].antiporn = true;
         return mecha.sendMessage(m.chat, { text: 'Antiporn has been activated successfully.' }, { quoted: m });

      } else if (m.args[0] === 'off') {
         if (!currentStatus) {
            return mecha.sendMessage(m.chat, { text: 'Antiporn has been inactivated previously.' }, { quoted: m });
         }
         db.groups[m.chat].antiporn = false;
         return mecha.sendMessage(m.chat, { text: 'Antiporn has been inactivated successfully.' }, { quoted: m });

      } else {
         let statusText = currentStatus ? 'active' : 'non-active';
         return m.reply(`*Current status* : ${statusText}\n\n_Example :_ ${m.prefix + m.command} on / off`);
      }
   },
   group: true,
   admin: true,
   botAdmin: true
};