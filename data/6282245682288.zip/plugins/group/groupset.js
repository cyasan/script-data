exports.run = {
   usage: ['groupset'],
   hidden: ['grup', 'gc'],
   use: 'open / close',
   category: 'group',
   async: async (m, { func, mecha }) => {
      let groupMetadata = await mecha.groupMetadata(m.chat);
      let isAnnouncement = groupMetadata.announce;

      if (m.args[0] === 'close') {
         if (isAnnouncement) {
            await mecha.sendMessage(m.chat, { react: { text: '❗', key: m.key } });
            return mecha.sendMessage(m.chat, { text: 'Group is already in `close` mode.' }, { quoted: m });
         }
         await mecha.groupSettingUpdate(m.chat, 'announcement')
            .then((res) => mecha.sendMessage(m.chat, { react: { text: '✅', key: m.key } }))
            .catch((err) => mecha.sendReact(m.chat, '❌', m.key));
      } else if (m.args[0] === 'open') {
         if (!isAnnouncement) {
            await mecha.sendMessage(m.chat, { react: { text: '❗', key: m.key } });
            return mecha.sendMessage(m.chat, { text: 'Group is already in `open` mode.' }, { quoted: m });
         }
         await mecha.groupSettingUpdate(m.chat, 'not_announcement')
            .then((res) => mecha.sendMessage(m.chat, { react: { text: '✅', key: m.key } }))
            .catch((err) => mecha.sendReact(m.chat, '❌', m.key));
      } else {
         mecha.sendMessage(m.chat, { text: func.example(m.cmd, 'open / close') }, { quoted: m });
      }
   },
   group: true,
   admin: true,
   botAdmin: true
};