exports.run = {
  usage: ['kick'],
  hidden: ['tendang'],
  use: 'mention or reply',
  category: 'group',
  async: async (m, { func, mecha, setting }) => {
    if (!m.text && !m.quoted) return m.reply('Mention or Reply chat target.');
    
    let number = isNaN(m.text)
      ? (m.text.startsWith('+') ? m.text.replace(/[()+\s-]/g, '') : m.text.split('@')[1])
      : m.quoted
        ? m.quoted.sender.split('@')[0]
        : m.text;

    if (isNaN(number)) return m.reply('Invalid number.');
    if (number.length > 15) return m.reply('Invalid format.');

    let target = number + '@s.whatsapp.net';
    if ([global.owner, mecha.user.id, ...setting.owner].includes(target)) return m.reply('Access denied.');

    let cek = await mecha.onWhatsApp(target);
    if (!cek || cek.length === 0) return m.reply('Masukkan nomor yang valid dan terdaftar di WhatsApp!');

    try {
      let result = await mecha.groupParticipantsUpdate(m.chat, [target], 'remove');
      for (let i of result) {
        if (i.status == 406) {
          m.reply(`@${target.split('@')[0]} adalah pembuat grup ini!`);
        } else {
          await mecha.reply(
            m.chat,
            `Success kick member @${target.split('@')[0]}`,
            func.fstatus("Lexy verified by WhatsApp"),
            { expiration: 84600 }
          );
        }
      }
    } catch (err) {
      m.reply(func.jsonFormat(err));
    }
  },
  main: async (m, { func, mecha, setting }) => {
    if (!m.isGc || !m.message || !m.message.reactionMessage || m.message.reactionMessage.text !== '🚫') return;

    let key = m.msg.key;
    let isOwner = setting.owner.includes(key.participant);

    if ([global.owner, mecha.user.id].includes(key.participant) || isOwner) 
      return m.reply('Tidak bisa mengeluarkan owner bot.');

    if (m.isBotAdmin && m.isAdmin) {
      try {
        let result = await mecha.groupParticipantsUpdate(m.chat, [key.participant], 'remove');
        for (let i of result) {
          if (i.status == 406) {
            m.reply(`Gagal mengeluarkan @${key.participant.split('@')[0]} karena dia adalah pembuat grup.`);
          } else {
            await mecha.reply(
              m.chat,
              `Successfully kicked @${key.participant.split('@')[0]} from this group`,
              func.fstatus("Lexy verified by WhatsApp"),
              { expiration: 84600 }
            );

            await mecha.sendMessage(key.remoteJid, {
              delete: key
            });
          }
        }
      } catch (err) {
        m.reply(func.jsonFormat(err));
      }
    }
  },
  group: true,
  admin: true,
  botAdmin: true
};