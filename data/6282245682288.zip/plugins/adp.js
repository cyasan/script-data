// Menambahkan konfigurasi panel API global
global.panelApi = {
    domain: 'https://serverpanel.lexczalok.xyz',
    apikey: 'ptla_hn5cxPE8q0KABzmD8IlVhz6BpKdq9y6JuVLQpxsmdjU',
    capikey: 'ptlc_KgbINPomirSTtTOYnSygrn0nMDa0Q2icq8khvpaULzV',
    eggs: '15'
};

exports.run = {
  usage: ['cadmin'],
  hidden: ['adp', 'cadp'],
  use: 'parameter',
  category: 'cpanel',

  async: async (m, { func, mecha }) => {
    let text = m.text || ''; // pastikan text didefinisikan
    let t = text.split(',');
    if (t.length < 2) return mecha.reply(m.chat, `*Format salah!*\nPenggunaan: ${m.prefix + m.command} user,nomer`, m);

    let username = t[0];
    let u = m.quoted ? m.quoted.sender : t[1] ? t[1].replace(/[^0-9]/g, '') + '@s.whatsapp.net' : m.mentionedJid[0];
    let email = username + "@lexy.id";
    if (!u) return;

    let d = (await mecha.onWhatsApp(u.split('@')[0]))[0] || {};
    let randomChars = "1234567890";
    let ulycode = "lexy";
    for (let i = 0; i < 5; i++) {
      ulycode += randomChars.charAt(Math.floor(Math.random() * randomChars.length));
    }
    let password = ulycode;

    let f = await fetch(global.panelApi.domain + "/api/application/users", {
      method: "POST",
      headers: {
        "Accept": "application/json",
        "Content-Type": "application/json",
        "Authorization": "Bearer " + global.panelApi.apikey
      },
      body: JSON.stringify({
        email: email,
        username: username,
        first_name: username,
        last_name: username,
        language: "en",
        root_admin: true,
        password: password
      })
    });

    let data = await f.json();
    if (data.errors) return mecha.reply(m.chat, JSON.stringify(data.errors[0], null, 2), m);

    let user = data.attributes;
    let f2 = await fetch(global.panelApi.domain + "/api/application/nests/5/eggs/" + global.panelApi.eggs, {
      method: "GET",
      headers: {
        "Accept": "application/json",
        "Content-Type": "application/json",
        "Authorization": "Bearer " + global.panelApi.apikey
      }
    });

    mecha.reply(m.chat, "SUCCESS CREATE USER", m);

    let rulvip = `*ADMIN PANEL PURCHASE RULES*\n` +
                 `* Do not delete other people's servers or admins!\n` +
                 `* Data lost/forgot account, Seller will not be responsible!\n` +
                 `* No DDOS server allowed!\n` +
                 `* Domain sharing is prohibited!\n` +
                 `* Warranty can only be claimed once!`;

    let ctf = `Hi @${u.split('@')[0]}, here is your admin panel data\n\n` +
              `USERNAME : ${user.username}\n` +
              `PASSWORD : ${password}\n` +
              `LOGIN : ${global.panelApi.domain}\n\n` +
              `${rulvip}`;

    await mecha.sendMessage(u, {
      text: ctf,
      contextInfo: {
        mentionedJid: [u, m.sender]
      }
    }, {
      quoted: func.fstatus("System Notification")
    });
  },
  owner: true
};