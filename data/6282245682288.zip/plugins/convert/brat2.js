const { createCanvas } = require("canvas");
const Jimp = require("jimp");

async function BratGenerator(teks) {
    let width = 512;
    let height = 512;
    let margin = 30; // Margin lebih besar agar teks lebih rapi
    let wordSpacing = 50;

    let canvas = createCanvas(width, height);
    let ctx = canvas.getContext("2d");

    ctx.fillStyle = "white";
    ctx.fillRect(0, 0, width, height);

    let fontSize = 110; // Ukuran font awal lebih besar
    let lineHeightMultiplier = 1.2; // Jarak antar baris lebih luas

    ctx.textAlign = "left";
    ctx.textBaseline = "top";
    ctx.fillStyle = "black";

    let words = teks.split(" ");
    let lines = [];

    let rebuildLines = () => {
        lines = [];
        let currentLine = "";

        for (let word of words) {
            let testLine = currentLine ? `${currentLine} ${word}` : word;
            let lineWidth =
                ctx.measureText(testLine).width + (currentLine.split(" ").length - 1) * wordSpacing;

            if (lineWidth < width - 2 * margin) {
                currentLine = testLine;
            } else {
                lines.push(currentLine);
                currentLine = word;
            }
        }

        if (currentLine) {
            lines.push(currentLine);
        }
    };

    ctx.font = `${fontSize}px Sans-serif`;
    rebuildLines();

    while (lines.length * fontSize * lineHeightMultiplier > height - 2 * margin) {
        fontSize -= 0.5; // Pengurangan lebih halus agar tetap besar
        ctx.font = `${fontSize}px Sans-serif`;
        rebuildLines();
    }

    let lineHeight = fontSize * lineHeightMultiplier;
    let y = margin;

    for (let line of lines) {
        let wordsInLine = line.split(" ");
        let x = margin;

        for (let word of wordsInLine) {
            ctx.fillText(word, x, y);
            x += ctx.measureText(word).width + wordSpacing;
        }

        y += lineHeight;
    }

    let buffer = canvas.toBuffer("image/png");
    let image = await Jimp.read(buffer);

    image.blur(3);
    let blurredBuffer = await image.getBufferAsync(Jimp.MIME_PNG);

    return blurredBuffer;
}

exports.run = {
    usage: ["brat2"],
    use: "text",
    category: "convert",
    async: async (m, { mecha, packname, author }) => {
        if (!m.args.length && (!m.quoted || !m.quoted.text)) {
            return m.reply("Input atau reply text!");
        }

        let text = m.args.length ? m.args.join(" ") : m.quoted.text;
        let maxLength = 150;

        if (text.length > maxLength) {
            return m.reply(`Maksimum ${maxLength} karakter!`);
        }

        mecha.sendReact(m.chat, "🕒", m.key);

        try {
            let buffer = await BratGenerator(text);
            mecha.sendSticker(m.chat, buffer, m, { packname, author, expiration: m.expiration });
        } catch (error) {
            m.reply(`Terjadi kesalahan saat membuat sticker.\n- ${error.message}`);
        }
    },
    limit: true, // Sesuai permintaan, limit 2
    location: "plugins/convert/brat2.js"
};