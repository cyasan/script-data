const fs = require('fs');

function formatMoney(amount) { 
    return amount.toLocaleString('id-ID');
}

exports.run = {
    usage: ['done'],
    use: 'product,nominal,tujuan',
    category: 'owner',
    async: async (m, { func, mecha, users, setting, qchanel }) => { 
        
        let args = m.text.split(',');
        if (args.length < 3) {
            return mecha.sendMessage(m.chat, { text: 'Format salah! Gunakan: .done product,nominal,tujuan' }, { quoted: m });
        }

        let product = args[0].trim();
        let nominal = parseInt((args[1] || '').replace(/[^0-9]/g, ''), 10);
        let target = args[2].replace(/[^0-9]/g, ''); 

        if (!product || isNaN(nominal) || nominal <= 0 || !target) {
            return mecha.sendMessage(m.chat, { text: 'Format salah atau data tidak valid! Pastikan produk, nominal, dan tujuan benar.' }, { quoted: m });
        }

        // Konversi nomor tujuan agar sesuai format 62xxxxxxxxx
        if (target.startsWith('0')) {
            target = '62' + target.slice(1);
        } else if (target.startsWith('+62')) {
            target = target.replace('+', '');
        }

        let now = new Date();
        let tanggal = now.toLocaleDateString('id-ID', { year: 'numeric', month: 'long', day: 'numeric' });
        let waktu = now.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit', second: '2-digit' });

        let teks = `乂 *TRANSACTION SUCCESSFULLY*\n\n` +
                   `- *Product* : _${product}_\n` +
                   `- *Nominal* : _Rp${formatMoney(nominal)}_\n` +
                   `- *Date* : _${tanggal}_\n` +
                   `- *Time* : _${waktu}_ WIB\n` +
                   `- *Status* : Success ✅\n\n` +
                   `*THANK YOU FOR ORDERING*`;

        mecha.relayMessage(target + '@s.whatsapp.net', {
            requestPaymentMessage: {
                currencyCodeIso4217: 'IDR',
                amount1000: `${nominal}000`,
                requestFrom: m.sender,
                noteMessage: {
                    extendedTextMessage: {
                        text: teks,
                        contextInfo: {
                            externalAdReply: {
                                showAdAttribution: true,
                            }
                        }
                    }
                }
            }
        }, { quoted: qchanel });

        mecha.sendMessage(m.chat, { text: 'Transaksi berhasil dikirim!' }, { quoted: m });
    },
    owner: true
};