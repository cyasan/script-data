/*
* Nama Pengembang: SuryaDev.
* Kontak Whatsapp: wa.me/6285702691440
* Kontak Telegram: t.me/surya_skylark
* Akun Instagram: surya_skylark05
* Catatan: tolong laporkan kepada saya jika anda menemukan ada yang menjual script ini tanpa seizin saya.
*/

const toMs = require('ms');
const func = require('./functions.js');

module.exports = (mecha, update) => {
try {
const msg = update.messages[update.messages.length - 1];
if (!msg.message) return;
if (msg.key && msg.key.remoteJid === 'status@broadcast') return
const isNumber = x => typeof x === 'number' && !isNaN(x)
const from = msg.key.remoteJid;
const bot = mecha.user.id ? mecha.user.id.split(':')[0] + '@s.whatsapp.net' : mecha.user.jid;
const sender = msg.key.fromMe ? bot : (msg.key.participant || msg.key.remoteJid);
const pushname = msg.pushName || '-'
const tekswelcome = 'Hello, +user Thank you for joining the group +group\n\nPlease intro first :\nName :\nAge :\nHome town :'
const teksleft =  'Goodbye +user'
const calender = new Date().toLocaleDateString('id', {
day: 'numeric',
month: 'long',
year: 'numeric'
})

// DATABASE USER
if (sender.endsWith('@s.whatsapp.net')) {
let users = global.db.users[sender]
if (typeof users !== 'object') global.db.users[sender] = {}
if (users) {
if (!('jid' in users)) users.jid = sender
if (!('register' in users)) users.register = false
if (!('name' in users)) users.name = pushname
if (!('gender' in users)) users.gender = ''
if (!isNumber(users.age)) users.age = 0
if (!('sn' in users)) users.sn = ''
if (!('date' in users)) users.date = calender
if (!isNumber(users.limit)) users.limit = 50
if (!isNumber(users.balance)) users.balance = 10000
if (!isNumber(users.afk)) users.afk = 0
if (!('sn' in users)) users.sn = ''
if (!('alasan' in users)) users.alasan = ''
if (!('afkObj' in users)) users.afkObj = {}
if (!('premium' in users)) users.premium = false
if (!('jadibot' in users)) users.jadibot = false
if (!('cooldownEwe' in users)) users.cooldownEwe = {}
if (!('banned' in users)) users.banned = false
if (!isNumber(users.warning)) users.warning = 0
if (!('pasangan' in users)) users.pasangan = { id: '', time: 0 }
if (!('expired' in users)) users.expired = { user: Date.now() + toMs('7d'), premium: 0, jadibot: 0, banned: 0 }
if (!('game' in users)) users.game = { tictactoe: 0, suit: 0, petakbom: 0, tebaklagu: 0, tebakheroml: 0, tebaklogo: 0, tebakgambar: 0, tebakkalimat: 0, tebakkata: 0, tebaklirik: 0, tebakkimia: 0, tebakbendera: 0, tebakanime: 0, kuis: 0, siapakahaku: 0, asahotak: 0, susunkata: 0, caklontong: 0, family100: 0, math: 0, casino: 0 }
if (!isNumber(users.lastunreg)) users.lastunreg = 0
if (!isNumber(users.exp)) users.exp = 0
if (!isNumber(users.level)) users.level = 0
if (!('role' in users)) users.role = 'Bronze'
    if (!isNumber(users.banteng)) users.banteng = 0

if (!isNumber(users.harimau)) users.harimau = 0

if (!isNumber(users.gajah)) users.gajah = 0

if (!isNumber(users.kambing)) users.kambing = 0

if (!isNumber(users.panda)) users.panda = 0

if (!isNumber(users.buaya)) users.buaya = 0

if (!isNumber(users.kerbau)) users.kerbau = 0

if (!isNumber(users.sapi)) users.sapi = 0

if (!isNumber(users.monyet)) users.monyet = 0
    
    if (!isNumber(users.babihutan)) users.babihutan = 0

if (!isNumber(users.babi)) users.babi = 0

if (!isNumber(users.ayam)) users.ayam = 0
    if (!isNumber(users.lastberburu)) users.lastberburu = 0
    if (!isNumber(users.bibitanggur)) users.bibitanggur = 0
if (!isNumber(users.bibitapel)) users.bibitapel = 0
if (!isNumber(users.bibitjeruk)) users.bibitjeruk = 0
if (!isNumber(users.bibitmangga)) users.bibitmangga = 0
if (!isNumber(users.bibitpisang)) users.bibitpisang = 0
if (!isNumber(users.anggur)) users.anggur = 0
if (!isNumber(users.apel)) users.apel = 0
if (!isNumber(users.jeruk)) users.jeruk = 0
if (!isNumber(users.mangga)) users.mangga = 0
if (!isNumber(users.pisang)) users.pisang = 0
if (!isNumber(users.lastberkebon)) users.lastberkebon = 0
if (!isNumber(users.money)) users.money = 100000
    if (!isNumber(users.lastadventure)) users.lastadventure = 0
    if (!isNumber(users.plastik)) users.plastik = 0
if (!isNumber(users.rock)) users.rock = 0
if (!isNumber(users.kardus)) users.kardus = 0
if (!isNumber(users.kaleng)) users.kaleng = 0
if (!isNumber(users.kayu)) users.kayu = 0
if (!isNumber(users.daun)) users.daun = 0
if (!isNumber(users.trash)) users.trash = 0
    if (!isNumber(users.string)) users.string = 0
    if (!isNumber(users.lastNgepet)) users.lastNgepet = 0
    if (!isNumber(users.bow)) users.bow = 0
    if (!isNumber(users.sword)) users.sword = 0
    if (!isNumber(users.arrow)) users.arrow = 0
    if (!isNumber(users.pickaxe)) users.pickaxe = 0
    if (!isNumber(users.axe)) users.axe = 0
    if (!isNumber(users.armor)) users.armor = 0
    if (!isNumber(users.iron)) users.iron = 0
    if (!isNumber(users.gold)) users.gold = 0
    if (!isNumber(users.diamond)) users.diamond = 0
    if (!isNumber(users.emerald)) users.emerald = 0
    if (!isNumber(users.lastmining)) users.lastmining = 0
    if (!isNumber(users.lastdaily)) users.lastdaily = 0
    if (!isNumber(users.lastmingguan)) users.lastmingguan = 0
    if (!isNumber(users.lastbulanan)) users.lastbulanan = 0
    if (!isNumber(users.lastyearly)) users.lastyearly = 0
    if (!isNumber(users.lastRampok)) users.lastRampok = 0
    if (!isNumber(users.stamina)) users.stamina = 0
if (!isNumber(users.durabilitiesBow)) users.durabilitiesBow = 0
    if (!isNumber(users.durabilitiesSword)) users.durabilitiesSword = 0
    if (!isNumber(users.durabilitiesArmor)) users.durabilitiesArmor = 0
    if (!isNumber(users.atm)) users.atm = 0
    if (!isNumber(users.common)) users.common = 0
    if (!isNumber(users.uncommon)) users.uncommon = 0
    if (!isNumber(users.epic)) users.epic = 0
    if (!isNumber(users.legendary)) users.legendary = 0
    if (!isNumber(users.lastSantet)) users.lastSantet = 0
    if (!isNumber(users.relic)) users.relic = 0
    if (!isNumber(users.treasureMap)) users.treasureMap = 0
    if (!isNumber(users.lastBansos)) users.lastBansos = 0
    if (!isNumber(users.lastngepet)) users.lastngepet = 0
    if (!isNumber(users.lastTreasure)) users.lastTreasure = 0
    if (!isNumber(users.anjing)) users.anjing = 0
    if (!isNumber(users.angsa)) users.angsa = 0  
if (!isNumber(users.burung)) users.burung = 0  
if (!isNumber(users.hamster)) users.hamster = 0  
if (!isNumber(users.kadal)) users.kadal = 0  
if (!isNumber(users.kelinci)) users.kelinci = 0  
if (!isNumber(users.kucing)) users.kucing = 0  
if (!isNumber(users.koala)) users.koala = 0  
if (!isNumber(users.landak)) users.landak = 0  
if (!isNumber(users.tupai)) users.tupai = 0
    if (!isNumber(users.anjingLevel)) users.anjingLevel = 0
if (!isNumber(users.angsaLevel)) users.angsaLevel = 0
if (!isNumber(users.burungLevel)) users.burungLevel = 0
if (!isNumber(users.hamsterLevel)) users.hamsterLevel = 0
if (!isNumber(users.kadalLevel)) users.kadalLevel = 0
if (!isNumber(users.kelinciLevel)) users.kelinciLevel = 0
if (!isNumber(users.koalaLevel)) users.koalaLevel = 0
if (!isNumber(users.landakLevel)) users.landakLevel = 0
if (!isNumber(users.tupaiLevel)) users.tupaiLevel = 0
    if (!isNumber(users.lastmulung)) users.lastmulung = 0
    if (!isNumber(users.frostbladeSword)) users.frostbladeSword = 0
if (!isNumber(users.flameproofCloak)) users.flameproofCloak = 0
if (!isNumber(users.shadowAmulet)) users.shadowAmulet = 0
if (!isNumber(users.crystalBow)) users.crystalBow = 0
if (!isNumber(users.phoenixFeather)) users.phoenixFeather = 0
if (!isNumber(users.ringOfEternity)) users.ringOfEternity = 0
if (!isNumber(users.dragonScaleShield)) users.dragonScaleShield = 0
if (!isNumber(users.mysticOrb)) users.mysticOrb = 0
    if (!isNumber(users.lastspaceadventure)) users.lastspaceadventure = 0
if (!isNumber(users.enchantedCompass)) users.enchantedCompass = 0
if (!isNumber(users.staffOfWisdom)) users.staffOfWisdom = 0
    if (!isNumber(users.lastadventure2)) users.lastadventure2 = 0
    if (!isNumber(users.acipmen)) users.acipmen = ''
    if (!isNumber(users.mythic)) users.mythic = 0
if (!isNumber(users.kuli)) users.kuli = 0
    if (!isNumber(users.durabilitiesFishingrod)) users.durabilitiesFhisingrod = 0
    if (!isNumber(users.durabilitiesAxe)) users.durabilitiesAxe = 0
    if (!isNumber(users.durabilitiesPickaxe)) users.durabilitiesPickaxe = 0
    if (!isNumber(users.common)) users.common = 0
if (!isNumber(users.uncommon)) users.uncommon = 0
    if (!isNumber(users.anak)) users.anak = 0
if (!isNumber(users.legendary)) users.legendary = 0
    if (!isNumber(users.invest)) users.invest = 0
    if (!isNumber(users.bibitwortel)) users.bibitwortel = 0
    if (!isNumber(users.magnetit)) users.magnetit = 0
if (!isNumber(users.hematit)) users.hematit = 0
if (!isNumber(users.dolomit)) users.dolomit = 0
if (!isNumber(users.platinum)) users.platinum = 0
if (!isNumber(users.jamur)) users.jamur = 0
if (!isNumber(users.mutiara)) users.mutiara = 0
if (!isNumber(users.driftwood)) users.driftwood = 0
if (!isNumber(users.granit)) users.granit = 0
if (!isNumber(users.kelp)) users.kelp = 0
if (!isNumber(users.seaweed)) users.seaweed = 0
if (!isNumber(users.perak)) users.perak = 0
if (!isNumber(users.kulitular)) users.kulitular = 0
if (!isNumber(users.kulitbuaya)) users.kulitbuaya = 0
if (!isNumber(users.fosilhewan)) users.fosilhewan = 0
if (!isNumber(users.fosiltumbuhan)) users.fosiltumbuhan = 0
if (!isNumber(users.mangrove)) users.mangrove = 0
if (!isNumber(users.kulitikan)) users.kulitikan = 0
if (!isNumber(users.kaktuslaut)) users.kaktuslaut = 0
if (!isNumber(users.kulitpenyu)) users.kulitpenyu = 0
if (!isNumber(users.batupasir)) users.batupasir = 0
if (!isNumber(users.mineral)) users.mineral = 0
if (!isNumber(users.fosil)) users.fosil = 0
if (!isNumber(users.permata)) users.permata = 0
if (!isNumber(users.logam)) users.logam = 0
if (!isNumber(users.artefak)) users.artefak = 0
if (!isNumber(users.saranglebah)) users.saranglebah = 0
if (!isNumber(users.batualam)) users.batualam = 0
if (!isNumber(users.kulitkayu)) users.kulitkayu = 0
if (!isNumber(users.rubi)) users.rubi = 0
if (!isNumber(users.zamrud)) users.zamrud = 0
if (!isNumber(users.kronium)) users.kronium = 0
if (!isNumber(users.nikel)) users.nikel = 0
if (!isNumber(users.kuarsa)) users.kuarsa = 0
if (!isNumber(users.batuakik)) users.batuakik = 0
if (!isNumber(users.birch)) users.birch = 0
if (!isNumber(users.amethyst)) users.amethyst = 0
if (!isNumber(users.citrine)) users.citrine = 0
if (!isNumber(users.feldspar)) users.feldspar = 0
if (!isNumber(users.kalsit)) users.kalsit = 0
if (!isNumber(users.dolomit)) users.dolomit = 0
    if (!isNumber(users.bibitkentang)) users.bibitkentang = 0
    if (!isNumber(users.bibittomat)) users.bibittomat = 0
    if (!isNumber(users.bibitkubis)) users.bibitkubis = 0
    if (!isNumber(users.bibitlabu)) users.bibitlabu = 0
 
    if (!isNumber(users.bibitterong)) users.bibitterong = 0
    if (!isNumber(users.wortel)) users.wortel = 0
    if (!isNumber(users.kentang)) users.kentang = 0
    if (!isNumber(users.tomat)) users.tomat = 0
    if (!isNumber(users.kubis)) users.kubis = 0
    if (!isNumber(users.labu)) users.labu = 0
    if (!isNumber(users.terong)) users.terong = 0
    if (!isNumber(users.ser)) users.ser = 0
if (!isNumber(users.epic)) users.epic = 0
if (!isNumber(users.mythic)) users.mythic = 0

} else {
global.db.users[sender] = {
jid: sender,
register: false,
name: pushname,
gender: '',
sn: '',
age: 0,
date: calender,
limit: 50,
balance: 10000,
afk: 0,
sn: '',
alasan: '',
afkObj: {},
cooldownEwe: {},
premium: false,
jadibot: false,
banned: false,
warning: 0,
pasangan: { id: '', time: 0 },
expired: { user: Date.now() + toMs('7d'), premium: 0, jadibot: 0, banned: 0 },
game: { tictactoe: 0, suit: 0, petakbom: 0, tebaklagu: 0, tebakheroml: 0, tebaklogo: 0, tebakgambar: 0, tebakkalimat: 0, tebakkata: 0, tebaklirik: 0, tebakkimia: 0, tebakbendera: 0, tebakanime: 0, kuis: 0, siapakahaku: 0, asahotak: 0, susunkata: 0, caklontong: 0, family100: 0, math: 0, casino: 0 },
lastunreg: 0,
exp: 0,
level: 0,
role: 'Bronze',
    banteng: 0,
    harimau: 0,
    gajah: 0,
    kambing: 0,
    panda: 0,
    buaya: 0,
    kerbau: 0,
    sapi: 0,
    monyet: 0,
    babi: 0,
    babihutan: 0,
    ayam: 0,
    lastberburu: 0,
    bibitapel: 0,
    apel: 0,
    jeruk: 0,
    anggur: 0,
    pisang: 0,
    mangga: 0,
    wortel: 0,
    terong: 0,
    labu: 0,
    tomat: 0,
    kubis: 0,
    kentang: 0,
bibitjeruk: 0,
bibitanggur: 0,
bibitpisang: 0,
bibitmangga: 0,
    bibitwortel: 0,
    bibitterong: 0,
    bibitlabu: 0,
    bibitkubis: 0,
    bibittomat: 0,
    bibitkentang: 0,
lastadventure: 0,
money: 100000,
    plastik: 0,
rock: 0,
kardus: 0,
kaleng: 0,
kayu: 0,
daun: 0,
trash: 0,
    lastspaceadventure: 0,
    bow: 0,
    sword :0,
    arrow: 0,
    axe: 0,
    pickaxe: 0,
    armor: 0,
    string: 0,
    lastNgepet: 0,
    lastmining: 0,
    iron: 0,
    gold: 0,
    emerald: 0,
    diamond: 0,
    lastdaily: 0,
    lastmingguan: 0,
    lastbulanan: 0,
    lastyearly: 0,
    lastRampok: 0,
    stamina: 0,
    atm: 0,
    common: 0,
    uncommon: 0,
    epic: 0,
    legendary: 0,
    mythic: 0,
    lastBansos: 0,
    lastngepet: 0,
    lastSantet: 0,
    relic: 0,
    anjing: 0,
    angsa: 0,  
    magnetit: 0,
hematit: 0,
dolomit: 0,
platinum: 0,
jamur: 0,
mutiara: 0,
driftwood: 0,
granit: 0,
kelp: 0,
seaweed: 0,
perak: 0,
kulitular: 0,
kulitbuaya: 0,
fosilhewan: 0,
fosiltumbuhan: 0,
mangrove: 0,
kulitikan: 0,
kaktuslaut: 0,
kulitpenyu: 0,
batupasir: 0,
mineral: 0,
fosil: 0,
permata: 0,
logam: 0,
artefak: 0,
saranglebah: 0,
batualam: 0,
kulitkayu: 0,
rubi: 0,
zamrud: 0,
kronium: 0,
nikel: 0,
kuarsa: 0,
batuakik: 0,
birch: 0,
amethyst: 0,
citrine: 0,
feldspar: 0,
kalsit: 0,
dolomit: 0,
burung: 0,  
hamster: 0,  
kadal: 0,  
kelinci: 0,  
kucing: 0,  
koala: 0,  
landak: 0,  
tupai: 0,
kuli: 0,
    invest: 0,
    anjingLevel: 0,
angsaLevel: 0,
burungLevel: 0,
hamsterLevel: 0,
kadalLevel: 0,
kelinciLevel: 0,
koalaLevel: 0,
landakLevel: 0,
tupaiLevel: 0,
    acipmen: {},
    lastmulung: 0,
    treasureMap: 0,
    lastTreasure: 0,
    frostbladeSword: 0,
flameproofCloak: 0,
shadowAmulet: 0,
crystalBow: 0,
phoenixFeather: 0,
ringOfEternity: 0,
dragonScaleShield: 0,
mysticOrb: 0,
    ser: 0,
enchantedCompass: 0,
staffOfWisdom: 0,
    durabilitiesSword: 0,
    durabilitiesFishingrod: 0,
    durabilitiesAxe: 0,
    durabilitiesPickaxe: 0,
    durabilitiesArmor: 0,
    durabilitiesBow: 0,
    lastadventure2: 0,
    common: 0,
    uncommon: 0,
    anak: 0,
    epic: 0,
    legendary: 0,
    mythic: 0,
    durabilities: {
        sword: 0,
        bow: 0,
        armor: 0,
        },
}
}
}

// DATABASE GROUP
if (from.endsWith('@g.us')) {
let groups = global.db.groups[from]
if (typeof groups !== 'object') global.db.groups[from] = {}
if (groups) {
if (!('jid' in groups)) groups.jid = from
if (!('name' in groups)) groups.name = '-'
if (!('tekswelcome' in groups)) groups.tekswelcome = tekswelcome
if (!('teksleft' in groups)) groups.teksleft = teksleft
if (!('welcome' in groups)) groups.welcome = true
if (!('left' in groups)) groups.left = false
if (!('detect' in groups)) groups.detect = false
if (!('mute' in groups)) groups.mute = false
if (!('antitoxic' in groups)) groups.antitoxic = false
if (!('antilink' in groups)) groups.antilink = true
if (!('antivirtex' in groups)) groups.antivirtex = true
if (!('antibot' in groups)) groups.antibot = false
if (!('antiviewonce' in groups)) groups.antiviewonce = false
if (!('antihidetag' in groups)) groups.antihidetag = false
if (!('antidelete' in groups)) groups.antidelete = false
if (!('antiedited' in groups)) groups.antiedited = false
if (!('automatically' in groups)) groups.automatically = false
if (!('antigsmm' in groups)) groups.antigsmm = false
if (!('banned' in groups)) groups.banned = false

if (!isNumber(groups.expired)) groups.expired = Date.now() + toMs('7d')
if (!('sewa' in groups)) groups.sewa = { status: false, expired: 0 }
if (!('absen' in groups)) groups.absen = {};
if (!('list' in groups)) groups.list = [];
if (!('blacklist' in groups)) groups.blacklist = [];
if (!('member' in groups)) groups.member = [];
} else {
global.db.groups[from] = {
jid: from,
name: '-', 
tekswelcome: tekswelcome,
teksleft: teksleft,
welcome: true,
left: false,
detect: false,
mute: false, 
antitoxic: false, 
antilink: true, 
antivirtex: true,
antibot: false,
antiviewonce: false,
antihidetag: false,
antidelete: false,
antiedited: false,
automatically: false,
antigsmm: false,
banned: false,

expired: Date.now() + toMs('7d'),
sewa: { status: false, expired: 0 },
absen: {},
list: [],
blacklist: [],
member: []
}
}
}

// DATABASE SETTING
let settings = global.db.setting
if (typeof settings !== 'object') global.db.setting = {}
if (settings) {
if (!('typefile' in settings)) settings.typefile = 'document'
if (!('prefix' in settings)) settings.prefix = '.'
if (!('multiprefix' in settings)) settings.multiprefix = false
if (!('online' in settings)) settings.online = true
if (!('verify' in settings)) settings.verify = false
if (!('self' in settings)) settings.self = false
if (!('maintenance' in settings)) settings.maintenance = false
if (!('gconly' in settings)) settings.gconly = false
if (!('autosticker' in settings)) settings.autosticker = false
if (!('autoread' in settings)) settings.autoread = true
if (!('autoblockcmd' in settings)) settings.autoblockcmd = false
if (!('anticall' in settings)) settings.anticall = true
if (!('antispam' in settings)) settings.antispam = true
if (!('fakereply' in settings)) settings.fakereply = true
if (!('autolevelup' in settings)) settings.autolevelup = true
if (!('owner' in settings)) settings.owner = [...global.devs]
if (!('packname' in settings)) settings.packname = 'ᴄʀᴇᴀᴛᴇ ʙʏ ᴍᴇᴄʜᴀ ʙᴏᴛ\n\nᴄʀᴇᴀᴛᴇᴅ ᴀᴛ :\n+week, +date\n+time WIB\n\nsewa bot?\n+62 882-0033-21562'
if (!('author' in settings)) settings.author = `\n\n\nMade by ${m.pushName}`
if (!('cover' in settings)) settings.cover = 'https://telegra.ph/file/66ea637e36d49f218e4d1.jpg'
if (!('link' in settings)) settings.link = 'https://whatsapp.com/channel/0029VaU3j0z2ER6liR0MY601'
if (!isNumber(settings.style)) settings.style = 1
if (!isNumber(settings.gamewaktu)) settings.gamewaktu = 60
if (!isNumber(settings.bmin)) settings.bmin = 1000
if (!isNumber(settings.bmax)) settings.bmax = 3000
if (!isNumber(settings.timer)) settings.timer = 1800000
if (!isNumber(settings.limit)) settings.limit = 100
if (!isNumber(settings.hargalimit)) settings.hargalimit = 1350
if (!isNumber(settings.lastreset)) settings.lastreset = Date.now()
if (!isNumber(settings.ctoxic)) settings.ctoxic = 15
if (!('toxic' in settings)) settings.toxic = ['ajg', 'anjink', 'anjg', 'anjk', 'anjim', 'anjing', 'anjrot', 'anying', 'asw', 'autis', 'babi', 'bacod', 'bacot', 'bagong', 'bajingan', 'bangsad', 'bangsat', 'bastard', 'bego', 'bgsd', 'biadab', 'biadap', 'bitch', 'bngst', 'bodoh', 'bokep', 'cocote', 'coli', 'colmek', 'comli', 'dajjal', 'dancok', 'dongo', 'fuck', 'goblog', 'goblok', 'guoblog', 'guoblok', 'henceut', 'idiot', 'jancok', 'jembut', 'jingan', 'kafir', 'kanjut', 'keparat', 'kntl', 'kontol', 'lonte', 'meki', 'memek', 'ngentod', 'ngentot', 'ngewe', 'ngocok', 'ngtd', 'njeng', 'njing', 'njinx', 'pantek', 'pantek', 'peler', 'pepek', 'pler', 'pucek', 'puki', 'pukimak', 'setan', 'silit', 'telaso', 'tempek', 'tete', 'titit', 'toket', 'tolol', 'tomlol']
if (!('blockcmd' in settings)) settings.blockcmd = [];
} else {
global.db.setting = {
typefile: 'document',
prefix: '.',
multiprefix: false,
online: true,
verify: true,
self: false,
maintenance: false,
gconly: false,
autosticker: false,
autoread: true,
autoblockcmd: false,
anticall: true,
antispam: true,
fakereply: true,
autolevelup: true,
owner: [...global.devs],
packname: 'ᴄʀᴇᴀᴛᴇ ʙʏ ᴍᴇᴄʜᴀ ʙᴏᴛ\n\nᴄʀᴇᴀᴛᴇᴅ ᴀᴛ :\n+week, +date\n+time WIB\n\nsewa bot?\n+62 882-0033-21562',
author: `\n\n\nMade by ${m.pushName}`,
cover: 'https://telegra.ph/file/66ea637e36d49f218e4d1.jpg',
link: 'https://whatsapp.com/channel/0029VaU3j0z2ER6liR0MY601',
style: 1,
gamewaktu: 60,
bmin: 1000,
bmax: 3000,
timer: 1800000,
limit: 100,
hargalimit: 1350,
lastreset: Date.now(),
ctoxic: 15,
toxic: ['ajg', 'anjink', 'anjg', 'anjk', 'anjim', 'anjing', 'anjrot', 'anying', 'asw', 'autis', 'babi', 'bacod', 'bacot', 'bagong', 'bajingan', 'bangsad', 'bangsat', 'bastard', 'bego', 'bgsd', 'biadab', 'biadap', 'bitch', 'bngst', 'bodoh', 'bokep', 'cocote', 'coli', 'colmek', 'comli', 'dajjal', 'dancok', 'dongo', 'fuck', 'goblog', 'goblok', 'guoblog', 'guoblok', 'henceut', 'idiot', 'jancok', 'jembut', 'jingan', 'kafir', 'kanjut', 'keparat', 'kntl', 'kontol', 'lonte', 'meki', 'memek', 'ngentod', 'ngentot', 'ngewe', 'ngocok', 'ngtd', 'njeng', 'njing', 'njinx', 'pantek', 'pantek', 'peler', 'pepek', 'pler', 'pucek', 'puki', 'pukimak', 'setan', 'silit', 'telaso', 'tempek', 'tete', 'titit', 'toket', 'tolol', 'tomlol'],
blockcmd: []
}
}

} catch (e) {
console.error(e);
}
}

func.reloadFile(__filename)