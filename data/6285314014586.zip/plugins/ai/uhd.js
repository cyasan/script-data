const axios = require('axios');
const cheerio = require('cheerio');

class uhd {
    async search(query) {
        try {
            const response = await axios.get(`https://www.uhdpaper.com/search?q=${query}&by-date=true`);
            const html = response.data;
            const $ = cheerio.load(html);
            const results = [];

            $('article.post-outer-container').each((index, element) => {
                const title = $(element).find('.snippet-title h2').text().trim();
                const imageUrl = $(element).find('.snippet-title img').attr('src');
                const resolution = $(element).find('.wp_box b').text().trim();
                const link = $(element).find('a').attr('href');

                results.push({ title, imageUrl, resolution, link });
            });

            return results;
        } catch (error) {
            console.error('Error scraping UHDPaper:', error);
            return [];
        }
    }
}

const uhdInstance = new uhd();

exports.run = {
    usage: ["uhd"],
    category: "searching",
    use: "query",
    async: async (m, { mecha, isPrem }) => {
        let text = m.text ? m.text.trim() : "";

        if (!text) {
            return mecha.sendMessage(m.chat, { text: `Masukkan kata kunci untuk mencari wallpaper UHD.\n\n- Contoh : ${m.prefix + m.command} anime` }, { quoted: m });
        }

        mecha.sendReact(m.chat, "🕒", m.key);

        try {
            const results = await uhdInstance.search(text);

            if (results.length === 0) {
                return mecha.sendMessage(m.chat, { text: "Tidak ditemukan wallpaper dengan kata kunci tersebut." }, { quoted: m });
            }

            if (!isPrem) {
                // Untuk Pengguna Non-Premium (1 gambar + daftar hasil lainnya)
                let firstResult = results[0]; 
                let message = `乂 UHD PAPER SEARCH\n\n`;
                message += `- Judul: ${firstResult.title}\n`;
                message += `- Resolusi: ${firstResult.resolution}\n`;
                message += `- Link: ${firstResult.link}\n\n`;
                message += `- Hasil lainnya:\n`;

                results.slice(1, 5).forEach((result, index) => {
                    message += `\n${index + 1}. ${result.title}\n`;
                    message += `- Resolusi: ${result.resolution}\n`;
                    message += `- Link: ${result.link}\n`;
                });

                await mecha.sendMessage(m.chat, {
                    image: { url: firstResult.imageUrl },
                    caption: message,
                }, { quoted: m });

            } else {
                // Untuk Pengguna Premium (10 gambar)
                for (let i = 0; i < Math.min(results.length, 10); i++) {
                    let result = results[i];

                    await new Promise(resolve => setTimeout(resolve, 1000)); // Delay agar tidak dianggap spam

                    let premiumMessage = `乂 UHD PAPER SEARCH\n\n`;
                    premiumMessage += `- Judul: ${result.title}\n`;
                    premiumMessage += `- Resolusi: ${result.resolution}\n`;
                    premiumMessage += `- Link: ${result.link}\n`;

                    await mecha.sendMessage(m.chat, {
                        image: { url: result.imageUrl },
                        caption: premiumMessage,
                    }, { quoted: m });
                }

                await mecha.sendMessage(m.chat, { text: "✅ Successfully sent 10 wallpapers!" }, { quoted: m });
            }

            mecha.sendReact(m.chat, "✅", m.key);

        } catch (err) {
            mecha.sendMessage(m.chat, { text: "Terjadi kesalahan dalam pencarian wallpaper UHD. Coba lagi nanti." }, { quoted: m });
        }
    },
    limit: 5,
};