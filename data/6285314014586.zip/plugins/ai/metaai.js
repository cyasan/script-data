const axios = require('axios');

const headers = {
    'authority': 'labs.writingmate.ai',
    'accept': '*/*',
    'content-type': 'application/json',
    'origin': 'https://labs.writingmate.ai',
    'referer': 'https://labs.writingmate.ai/share/JyVg?__show_banner=false',
    'user-agent': 'Postify/1.0.0',
};

const metaai = async (text) => {
    const data = {
        response_format: {
            type: "json_schema",
            json_schema: {
                name: "text_response",
                strict: true,
                schema: {
                    type: "object",
                    properties: { response: { type: "string" } },
                    required: ["response"],
                    additionalProperties: false
                }
            }
        },
        chatSettings: {
            model: "gpt-4o",
            temperature: 0.7,
            contextLength: 16385,
            includeProfileContext: false,
            includeWorkspaceInstructions: false,
            embeddingsProvider: "openai"
        },
        messages: [{ role: "user", content: text }],
        customModelId: ""
    };

    try {
        const response = await axios.post('https://labs.writingmate.ai/api/chat/public', data, { headers });
        return response.data.response;
    } catch (error) {
        return "Terjadi kesalahan saat mengakses MetaAI. Coba lagi nanti.";
    }
};

exports.run = {
    usage: ["metaai"],
    category: "ai",
    use: "query",
    async: async (m, { mecha }) => {
        let text = m.text ? m.text.trim() : "";

        if (!text) {
            return mecha.sendMessage(m.chat, { text: `Masukkan pertanyaan untuk MetaAI.\n\n_Example :_ ${m.prefix + m.command} Apa itu AI?` }, { quoted: m });
        }

        mecha.sendReact(m.chat, "🕒", m.key);

        try {
            const result = await metaai(text);

            await mecha.sendMessage(m.chat, { text: result }, { quoted: m });

            mecha.sendReact(m.chat, "✅", m.key);
        } catch (err) {
            mecha.sendMessage(m.chat, { text: "Gagal mendapatkan respon dari MetaAI. Silakan coba lagi nanti." }, { quoted: m });
        }
    },
    limit: 5,
};