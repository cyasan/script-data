const fetch = require('node-fetch');

exports.run = {
  usage: ['kalenderhijriah'],
  use: '',
  hidden: ['hijriah'],
  category: 'islamic',
  async: async (m, { mecha }) => {
    try {
      let today = new Date(); // Tanggal hari ini
      let year = today.getFullYear();
      let month = today.getMonth() + 1;
      let day = today.getDate();

      // Mengambil data dari API Kalender Hijriah
      let response = await fetch(`https://api.aladhan.com/v1/gToH?date=${day}-${month}-${year}`);
      let data = await response.json();

      if (data.code === 200) {
        let hijri = data.data.hijri;

        // Properti tambahan
        let holidays = hijri.holidays && hijri.holidays.length > 0 ? hijri.holidays.join(', ') : '-';
        let lunarSighting = data.data.lunarSighting ? 'Ya' : 'Tidak';
        let method = hijri.method || '-';

        let caption = `乂 *KALENDER - HIJRIAH*\n\n`;
        caption += `*Tanggal Masehi:* ${day}-${month}-${year}\n`;
        caption += `*Tanggal Hijriah:* ${hijri.day} ${hijri.month.en} ${hijri.year} H\n\n`;
        caption += `*Hari:* ${hijri.weekday.ar} (${hijri.weekday.en})\n`;
        caption += `*Keterangan Bulan:* ${hijri.month.ar} (${hijri.month.en})\n`;
        caption += `*Hari Istimewa:* ${holidays}\n\n`;
        caption += `*Lunar Sighting (hilal):* ${lunarSighting}\n`;
        caption += `*Method:* ${method}\n\n`;
        caption += `_Kalender Hijriah ini berdasarkan perhitungan dari Aladhan._`;

        mecha.reply(m.chat, caption, m, { expiration: m.expiration });
      } else {
        mecha.reply(m.chat, 'Maaf, terjadi kesalahan dalam mengambil data kalender Hijriah.', m);
      }
    } catch (error) {
      console.error(error);
      mecha.reply(m.chat, 'Terjadi kesalahan. Silakan coba lagi nanti.', m);
    }
  }
};