const { createCanvas, loadImage } = require('canvas');
const moment = require('moment-timezone');
const axios = require('axios');

exports.run = {
    usage: ['kalender', 'calendar'],
    category: 'tools',
    async: async (m, { text, mecha, setting }) => { 
        // Kirim reaksi sebelum eksekusi
        await mecha.sendMessage(m.chat, { react: { text: '🕒', key: m.key } });

        const timezone = 'Asia/Jakarta';
        const currentDate = moment.tz(timezone);
        const currentMonth = currentDate.month();
        const currentYear = currentDate.year();

        const canvasWidth = 1600;
        const canvasHeight = 1600; // Rasio 1:1

        const months = [
            'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
            'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember'
        ];
        let queryMonth = months.findIndex(month => text && month.toLowerCase() === text.toLowerCase());
        if (queryMonth === -1) queryMonth = currentMonth;

        const displayDate = moment.tz(timezone).month(queryMonth).startOf('month');
        const monthName = months[queryMonth];
        const year = currentYear;

        const canvas = createCanvas(canvasWidth, canvasHeight);
        const ctx = canvas.getContext('2d');

        // URL gambar latar belakang dari setting.cover
        const imageUrl = setting.cover || 'https://files.catbox.moe/bi9vkp.jpg'; // Default jika tidak ada setting.cover

        try {
            const response = await axios.get(imageUrl, { responseType: 'arraybuffer' });
            const imageBuffer = Buffer.from(response.data, 'binary');
            const bgImage = await loadImage(imageBuffer);

            // Memotong gambar agar rasio 1:1
            const cropSize = Math.min(bgImage.width, bgImage.height);
            
            // Mengatur transparansi 70% untuk latar belakang
            ctx.globalAlpha = 0.7;
            ctx.drawImage(bgImage, (bgImage.width - cropSize) / 2, (bgImage.height - cropSize) / 2, cropSize, cropSize, 0, 0, canvasWidth, canvasHeight);
            ctx.globalAlpha = 1;
        } catch (error) {
            console.error('Gagal memuat gambar latar belakang:', error);
            ctx.fillStyle = '#1e1e1e';
            ctx.fillRect(0, 0, canvasWidth, canvasHeight);
        }

        const theme = { text: '#ffffff', grid: '#cccccc', accent: '#007bff' };

        ctx.fillStyle = theme.text;
        ctx.font = 'bold 80px Arial';
        ctx.textAlign = 'center';
        ctx.fillText(`${monthName} ${year}`, canvasWidth / 2, 100);

        ctx.strokeStyle = theme.grid;
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.moveTo(100, 120);
        ctx.lineTo(canvasWidth - 100, 120);
        ctx.stroke();

        const dayNames = ['Minggu', 'Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'];
        const cellWidth = canvasWidth / 7;
        const cellHeight = (canvasHeight - 200) / 8;
        ctx.font = 'bold 50px Arial';

        dayNames.forEach((day, i) => {
            ctx.fillStyle = i === 0 ? 'red' : theme.text;
            ctx.fillText(day, cellWidth * i + cellWidth / 2, 180);
        });

        const pasaran = ['Legi', 'Pahing', 'Pon', 'Wage', 'Kliwon'];
        const startDay = displayDate.day();
        const totalDays = displayDate.daysInMonth();
        const pasaranOffset = moment('1900-01-01').diff(displayDate, 'days') % 5;

        let x = startDay;
        let y = 1;

        for (let day = 1; day <= totalDays; day++) {
            const posX = cellWidth * x + cellWidth / 2;
            const posY = 200 + cellHeight * y + 60;

            ctx.fillStyle = theme.text;
            ctx.font = 'bold 45px Arial';
            ctx.fillText(day, posX, posY - 10);

            const pasaranName = pasaran[(day + pasaranOffset) % 5];
            ctx.fillStyle = theme.text;
            ctx.font = 'italic 30px Arial';
            ctx.fillText(pasaranName, posX, posY + 35);

            x++;
            if (x > 6) {
                x = 0;
                y++;
            }
        }

        // Tambahkan watermark "Copyright © 2025 Lexy" di kanan bawah
        ctx.fillStyle = 'rgba(255, 255, 255, 0.8)';
        ctx.font = 'bold 40px Arial';
        ctx.textAlign = 'right';
        ctx.fillText('Copyright © 2025 Lexy', canvasWidth - 50, canvasHeight - 50);

        const buffer = canvas.toBuffer();
        await mecha.sendMessage(m.chat, {
            image: buffer,
            caption: `*- Kalender :* ${monthName} ${year}`,
        }, { quoted: m, ephemeralExpiration: m.expiration });
    },
};