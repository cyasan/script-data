exports.run = {
  main: async (m, { func, mecha, groups }) => {
    try {
      // 1. Validasi parameter
      if (!mecha?.sendMessage) return console.error('Mecha tidak valid');
      if (!m?.chat || !m?.sender) return console.error('Pesan tidak valid');

      // 2. Cek emoji terlarang
      const messageText = m.budy || '';
      const isForbiddenEmoji = messageText.match(/(😹|☠️|💀|😂)/gi);
      const groupInfo = groups?.[m.chat] || {};
      const isSewaActive = groupInfo.sewa?.status || false;

      // 3. Kondisi utama
      if (!m.fromMe && isForbiddenEmoji && !isSewaActive && !m.isOwner) {
        // Simpan key pesan sebelum dihapus
        const originalMessageKey = m.key;

        // 4. Hapus pesan
        try {
          await mecha.sendMessage(m.chat, {
            delete: {
              remoteJid: m.chat,
              fromMe: false,
              id: m.key.id,
              participant: m.sender
            }
          });
          await func.delay(1000);
        } catch (deleteError) {
          console.error('Gagal menghapus pesan:', deleteError);
        }

        // 5. Kirim notifikasi ke owner dengan quote
        if (global.owner) {
          try {
            await mecha.sendMessage(
              global.owner, 
              {
                text: `Pesan dihapus - Emoji alay terdeteksi\n\n- Pengirim: @${m.sender.split('@')[0]}\n- Grup: ${m.chat} (${groups.name})\n- Pesan: ${messageText}`,
                contextInfo: {
                  mentionedJid: [m.sender],
                  stanzaId: originalMessageKey.id,
                  participant: originalMessageKey.participant || m.sender,
                  quotedMessage: {
                    conversation: messageText
                  }
                }
              },
              {
                quoted: {
                  key: originalMessageKey,
                  message: { conversation: messageText }
                }
              }
            );
          } catch (notifyError) {
            console.error('Gagal mengirim notifikasi:', notifyError);
          }
        }
      }
    } catch (error) {
      console.error('Error utama:', error);
    }
  },
  group: true,
  botAdmin: true
};