const axios = require("axios");
const qs = require("querystring");

class AIODownloader {
    async download(url) {
        try {
            if (!url) throw new Error("Masukkan URL video yang ingin diunduh.");

            const { data } = await axios.post(
                "https://anydownloader.com/wp-json/aio-dl/video-data/",
                qs.stringify({ url }),
                {
                    headers: {
                        "Content-Type": "application/x-www-form-urlencoded",
                        "Referer": "https://anydownloader.com/",
                        "Token": "5b64d1dc13a4b859f02bcf9e572b66ea8e419f4b296488b7f32407f386571a0d"
                    }
                }
            );

            if (!data.url) return { error: "Gagal mendapatkan video. URL mungkin tidak didukung." };
            return data;
        } catch (error) {
            return { error: error.message };
        }
    }
}

// **Fitur untuk Bot**
exports.run = {
    usage: ["aio"],
    category: "downloader",
    use: "url",
    async: async (m, { text, mecha }) => {
        if (!text) return mecha.reply(m.chat, "Masukkan URL video yang ingin diunduh.", m);

        mecha.sendReact(m.chat, "🕒", m.key); // Reaksi loading

        try {
            const aio = new AIODownloader();
            const result = await aio.download(text);

            if (result.error) throw new Error(result.error);

            let caption = `乂 AIO DOWNLOADER\n\n`;
            caption += `◦ *Judul:* ${result.title || "Tidak diketahui"}\n`;
            caption += `◦ *Sumber:* ${result.source || "Tidak diketahui"}\n`;
            caption += `◦ *Tipe:* ${result.type || "Tidak diketahui"}\n\n`;
            caption += `Mengunduh video...`;

            // Kirim video langsung ke pengguna
            await mecha.sendMessage(m.chat, {
                video: { url: result.url },
                caption: caption
            }, { quoted: m });

        } catch (err) {
            console.error("Error:", err.message);
            mecha.reply(m.chat, "Gagal mengunduh video. Coba periksa URL atau gunakan sumber lain.", m);
        }

        mecha.sendReact(m.chat, "✅", m.key); // Reaksi sukses
    },
    premium: true
};