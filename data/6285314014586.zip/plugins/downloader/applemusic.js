const fetch = require("node-fetch");
const axios = require("axios");

exports.run = {
  usage: ["applemusic"],
  hidden: ["am"],
  category: "downloader",
  use: "judul lagu",
  async: async (m, { func, mecha, setting }) => {
    if (!m.text) return mecha.reply(m.chat, func.example(m.cmd, "Imagine Dragons"), m);

    mecha.sendReact(m.chat, "🕒", m.key); // Tampilkan reaksi loading

    try {
      const query = encodeURIComponent(m.text);
      const appleApiUrl = `https://itunes.apple.com/search?term=${query}&entity=song&limit=10`;
      
      const { data } = await axios.get(appleApiUrl);
      if (data.resultCount === 0) {
        return mecha.reply(m.chat, "Lagu tidak ditemukan. Coba masukkan judul lain!", m);
      }
      
      let caption = `*A P P L E  M U S I C - S E A R C H I N G*\n\nResult From: \`${m.text}\`\n\n`;
      for (let i = 0; i < data.results.length; i++) {
        const music = data.results[i];
        const title = music.trackName;
        const artist = music.artistName;
        const album = music.collectionName;
        const songUrl = music.trackViewUrl;
        const previewUrl = music.previewUrl || null;
        const duration = music.trackTimeMillis ? `${Math.floor(music.trackTimeMillis / 60000)}:${((music.trackTimeMillis % 60000) / 1000).toFixed(0).padStart(2, '0')}` : "N/A";
        const popularity = music.playCount ? music.playCount : "N/A";
        const cover = music.artworkUrl100.replace("100x100bb", "600x600bb");

        caption += `*${i + 1}.* ${title}\n`;
        caption += `- *Artis:* ${artist}\n`;
        caption += `- *Album:* ${album}\n`;
        caption += `- *Duration:* ${duration}\n`;
        if (popularity !== "N/A") caption += `- *Popularity:* ${popularity}\n`;
        caption += `*Dengarkan di:* ${songUrl}\n\n`;
      }

      let sentMessage = await (setting.fakereply ?  mecha.sendMessageModify(m.chat, caption, m, {
        title: `APPLE MUSIC`,
        body: global.header,
        thumbnail: await (await fetch(data.results[0].artworkUrl100.replace("100x100bb", "600x600bb"))).buffer(),
        largeThumb: true,
        expiration: m.expiration,
      }) : mecha.reply(m.chat, caption, m, { expiration: m.expiration}));

      mecha.sendReact(m.chat, "✅", m.key);
    } catch (err) {
      console.error("Error fetching Apple Music data:", err);
      mecha.reply(m.chat, "Terjadi kesalahan saat mengambil data dari Apple Music.", m);
    }
  },
  premium: true, // Hanya untuk pengguna premium
};