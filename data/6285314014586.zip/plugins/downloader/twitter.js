const axios = require("axios");
const cheerio = require("cheerio");

exports.run = {
  usage: ["twitter"],
  category: "downloader",
  use: "link twitter",
  async: async (m, { func, mecha }) => {
    if (!m.text) return mecha.reply(m.chat, func.example(m.cmd, "https://x.com/username/status/123456789"), m);

    mecha.sendReact(m.chat, "🕒", m.key); // Reaksi loading

    try {
      let twitterUrl = m.text;

      // Panggil API pihak ketiga untuk mendownload video
      const response = await axios.post("https://savetwitter.net/api/ajaxSearch", `q=${encodeURIComponent(twitterUrl)}&lang=en`);
      const $ = cheerio.load(response.data.data);

      let videoThumbnail = $('.tw-video .thumbnail .image-tw img').attr('src');
      let title = $('.tw-middle h3').text().trim();
      let duration = $('.tw-middle p').text().trim();
      let downloads = [];

      $('.dl-action a').each((i, elem) => {
        let quality = $(elem).text().trim();
        let url = $(elem).attr('href');

        if (url) {
          downloads.push({ quality, url });
        }
      });

      if (downloads.length === 0) {
        return mecha.reply(m.chat, "Gagal mendapatkan video dari Twitter. Coba lagi nanti!", m);
      }

      let bestVideo = downloads[0].url; // Pilih kualitas terbaik yang tersedia

      // Kirim video tanpa teks
      await mecha.sendMessage(
        m.chat,
        { video: { url: bestVideo }, mimetype: "video/mp4" },
        { quoted: m }
      );

      mecha.sendReact(m.chat, "✅", m.key); // Reaksi sukses
    } catch (err) {
      console.error("Error fetching Twitter video:", err);
      mecha.reply(m.chat, `Terjadi kesalahan saat mengambil data dari Twitter.\n${err.message}`, m);
    }
  },
  premium: true, // Hanya untuk pengguna premium
};