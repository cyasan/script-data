const axios = require('axios');

function clean(str) {
    const regex = /['"]/g;
    return str.replace(regex, '');
}

async function downloadSpotify(linkk) {
    try {
        const detail = await axios.get('https://spotisongdownloader.to/api/composer/spotify/xsingle_track.php', {
            params: {
                url: linkk
            }
        });
        const { song_name, artist, url } = detail.data;

        const data = new URLSearchParams();
        data.append('song_name', clean(song_name));
        data.append('artist_name', clean(artist));
        data.append('url', url);

        const dlrespon = await axios.post('https://spotisongdownloader.to/api/composer/spotify/wertyuht3456.php', data, {
            headers: {
                'Authority': 'spotisongdownloader.to',
                'Accept': 'application/json, text/javascript, */*; q=0.01',
                'Accept-Language': 'id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7',
                'Cache-Control': 'no-cache',
                'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
                'Origin': 'https://spotisongdownloader.to',
                'Referer': 'https://spotisongdownloader.to/track.php',
                'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36',
                'X-Requested-With': 'XMLHttpRequest'
            }
        });

        return {
            ...detail.data,
            dl: encodeURI(dlrespon.data.dlink)
        };
    } catch (error) {
        console.error('Error:', error);
        return null;
    }
}

exports.run = {
    usage: ["spotifydl2"],
    category: "downloader",
    use: "Spotify link",
    async: async (m, { func, mecha }) => {
        if (!m.text) return mecha.reply(m.chat, func.example(m.cmd, "https://open.spotify.com/track/123456789"), m);

        mecha.sendReact(m.chat, "🕒", m.key);

        try {
            const result = await downloadSpotify(m.text);
            if (!result || !result.dl) {
                return mecha.reply(m.chat, "Failed to fetch data. Make sure the Spotify link is valid!", m);
            }

            let caption = `乂 *SPOTIFY MUSIC DOWNLOADER*\n\n`;
            caption += `- *Title:* ${result.song_name}\n`;
            caption += `- *Artist:* ${result.artist}\n\n`;
            caption += `_Please wait, the audio is being sent..._`;

            const msg = await mecha.sendMessage(m.chat, {
                text: caption,
                contextInfo: {
                    externalAdReply: {
                        title: result.song_name,
                        body: global.header,
                        thumbnailUrl: result.thumbnail || null,
                        sourceUrl: "",
                        mediaType: 1,
                        showAdAttribution: false,
                        renderLargerThumbnail: true,
                    },
                },
            }, { quoted: m });

            await mecha.sendMessage(m.chat, {
                audio: { url: result.dl },
                mimetype: "audio/mp4",
                ptt: false,
            }, { quoted: msg });

            mecha.sendReact(m.chat, "✅", m.key);
        } catch (err) {
            console.error("Error fetching Spotify download:", err);
            mecha.reply(m.chat, "An error occurred while fetching data from Spotify.", m);
        }
    },
    premium: true,
};