const axios = require('axios');
const cheerio = require('cheerio');

class Pinterest {
async getURL(Url) {
try {
const response = await axios.get(Url);
const $ = cheerio.load(response.data);
let contentUrl = '';
const video = $('video').attr('src');
if (video) {
contentUrl = video.replace('hls', '720p').replace('.m3u8', '.mp4');
} else {
const img = $('meta[property="og:image"]').attr('content');
if (img) {
contentUrl = img;
}
}
return contentUrl;
} catch (error) {
console.error('Ошибка:', error.message);
return '';
}
}
async getBuffer(RawUrl) {
try {
const url = await this.getURL(RawUrl);
const response = await axios.get(url, { responseType: 'arraybuffer' });
return response.data;
} catch (error) {
console.error('Ошибка:', error.message);
return null;
}
}
async getUint8ArrayBuffer(RawUrl) {
try {
const url = await this.getURL(RawUrl);
const response = await axios.get(url, { responseType: 'arraybuffer' });
const buffer = Uint8Array.from(response.data);
return buffer;
} catch (error) {
console.error('Error:', error.message);
return null;
}
}
}

exports.run = {
usage: ['pinterestdl'],
hidden: ['pindl'],
use: 'url pinterest',
category: 'downloader',
async: async (m, { func, mecha }) => {
if (!m.text) return m.reply(func.example(m.cmd, 'https://pin.it/j7hCiw8nu'))
if (!m.args[0].includes('https://pin.it/')) return m.reply(global.mess.error.url)
mecha.sendReact(m.chat, '🕒', m.key);
let pindl = new Pinterest;
let result = await pindl.getURL(m.text);
if (!result) return m.reply('Maaf terjadi kesalahan.')
mecha.sendMedia(m.chat, result, m, {
expiration: m.expiration
})
await mecha.sendReact(m.chat, '', m.key)
},
limit: 3
}