const axios = require("axios");
const cheerio = require("cheerio");

class BstationDownloader {
    async download(url, quality = '480P') {
        try {
            let aid = /\/video\/(\d+)/.exec(url)?.[1];

            if (!aid) return {
                status: false,
                message: 'ID Video tidak ditemukan.'
            };

            const appInfo = await axios.get(url).then(res => res.data);
            const $ = cheerio.load(appInfo);
            const title = $('meta[property="og:title"]').attr('content').split('|')[0].trim();
            const locate = $('meta[property="og:locale"]').attr('content');
            const description = $('meta[property="og:description"]').attr('content');
            const type = $('meta[property="og:video:type"]').attr('content');
            const cover = $('meta[property="og:image"]').attr('content');
            const like = $('.interactive__btn.interactive__like .interactive__text').text();
            const views = $('.bstar-meta__tips-left .bstar-meta-text').first().text();

            const response = await axios.get('https://api.bilibili.tv/intl/gateway/web/playurl', {
                params: {
                    's_locale': 'id_ID',
                    'platform': 'web',
                    'aid': aid,
                    'qn': '64',
                    'type': '0',
                    'device': 'wap',
                    'tf': '0',
                    'spm_id': 'bstar-web.ugc-video-detail.0.0',
                    'from_spm_id': 'bstar-web.homepage.trending.all',
                    'fnval': '16',
                    'fnver': '0',
                }
            }).then(res => res.data);

            const video = response.data.playurl.video.map(item => ({
                quality: item.stream_info.desc_words,
                codecs: item.video_resource.codecs,
                size: item.video_resource.size,
                mime: item.video_resource.mime_type,
                url: item.video_resource.url || item.video_resource.backup_url[0]
            }));

            const audio = response.data.playurl.audio_resource.map(item => ({
                size: item.size,
                url: item.url || item.backup_url[0]
            }));

            const selectedVideo = video.find(v => v.quality === quality);
            if (!selectedVideo) {
                throw new Error("Video dengan kualitas yang diminta tidak ditemukan.");
            }

            return {
                status: true,
                data: {
                    title,
                    locate,
                    description,
                    type,
                    cover,
                    views,
                    like,
                    media: {
                        video,
                        audio,
                    }
                }
            };
        } catch (error) {
            return {
                status: false,
                message: error.message || "Terjadi kesalahan."
            };
        }
    }

    async getVideo(url) {
        const headers = {
            'DNT': '1',
            'Origin': 'https://www.bilibili.tv',
            'Referer': 'https://www.bilibili.tv/video/',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36 Edg/126.0.0.0'
        };

        try {
            let buffers = [];
            let start = 0;
            let end = 5 * 1024 * 1024; // 5MB chunks
            let fileSize = 0;

            while (true) {
                const range = `bytes=${start}-${end}`;

                const response = await axios.get(url, {
                    headers: {
                        ...headers,
                        Range: range
                    },
                    responseType: 'arraybuffer'
                });

                if (fileSize === 0) {
                    const contentRange = response.headers['content-range'];
                    if (contentRange) {
                        fileSize = parseInt(contentRange.split('/')[1]);
                    }
                }

                buffers.push(Buffer.from(response.data));

                if (end >= fileSize - 1) {
                    break;
                }

                start = end + 1;
                end = Math.min(start + 5 * 1024 * 1024 - 1, fileSize - 1);
            }

            return Buffer.concat(buffers);
        } catch (error) {
            throw error;
        }
    }
}

// Fitur untuk bot
exports.run = {
    usage: ["bstationdl"],
    hidden: ["bdl"],
    category: "downloader",
    use: "url",
    async: async (m, { text, mecha }) => {
        if (!text) return mecha.reply(m.chat, "Masukkan URL video dari Bstation.", m);

        mecha.sendReact(m.chat, "🕒", m.key); // Reaksi loading

        try {
            const bstation = new BstationDownloader();
            const videoData = await bstation.download(text);

            if (!videoData.status) {
                throw new Error(videoData.message);
            }

            const { title, cover, views, like, media } = videoData.data;
            const videoUrl = media.video[0].url;
            const size = (media.video[0].size / 1024 / 1024).toFixed(2); // Convert ke MB

            let caption = `B S T A T I O N - D O W N L O A D E R\n\n`;
            caption += `Judul: ${title}\n`;
            caption += `Tampilan: ${views}\n`;
            caption += `Suka: ${like}\n`;
            caption += `Ukuran: ${size} MB\n`;
            caption += `Link Video: ${videoUrl}\n\n`;

            await mecha.sendMessage(m.chat, {
                image: { url: cover },
                caption: caption,
            }, { quoted: m });

            mecha.sendReact(m.chat, "✅", m.key); // Reaksi sukses
        } catch (err) {
            console.error("Error:", err.message);
            mecha.reply(m.chat, "Gagal mengunduh video dari Bstation. Coba lagi nanti.", m);
        }
    },
    limit: 3,
};