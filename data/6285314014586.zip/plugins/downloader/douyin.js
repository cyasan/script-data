const axios = require("axios");
const FormData = require("form-data");

class DouyinDownloader {
    async download(url) {
        if (!url) throw new Error("Masukkan URL video Douyin yang ingin diunduh.");

        try {
            const apiURL = "https://savetik.co/api/ajaxSearch";
            const form = new FormData();
            form.append("q", url);
            form.append("lang", "id");
            form.append("cftoken", "");

            const { data } = await axios.post(apiURL, form, {
                headers: { ...form.getHeaders() }
            });

            if (!data.data) throw new Error("Gagal mendapatkan data video.");

            return {
                title: data.desc || "Video Douyin",
                thumbnail: data.cover || "",
                videoUrl: data.medias?.[0]?.url || ""
            };
        } catch (error) {
            return { error: error.message };
        }
    }
}

// **Fitur untuk Bot**
exports.run = {
    usage: ["douyin"],
    category: "downloader",
    use: "url",
    async: async (m, { text, mecha }) => {
        if (!text) return mecha.reply(m.chat, "Masukkan URL video Douyin yang ingin diunduh.", m);

        mecha.sendReact(m.chat, "🕒", m.key); // Reaksi loading

        try {
            const douyin = new DouyinDownloader();
            const result = await douyin.download(text);

            if (result.error) throw new Error(result.error);

            let caption = `乂 DOUYIN DOWNLOADER\n\n`;
            caption += `◦ *Judul:* ${result.title}\n`;
            caption += `◦ *Sumber:* Douyin\n\n`;
            caption += `Mengunduh video...`;

            // Kirim video langsung ke pengguna
            await mecha.sendMessage(m.chat, {
                video: { url: result.videoUrl },
                caption: caption
            }, { quoted: m });

        } catch (err) {
            console.error("Error:", err.message);
            mecha.reply(m.chat, "Gagal mengunduh video. Coba periksa URL atau gunakan sumber lain.", m);
        }

        mecha.sendReact(m.chat, "✅", m.key); // Reaksi sukses
    },
    limit: 3,
};