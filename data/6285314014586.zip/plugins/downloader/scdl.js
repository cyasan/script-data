const axios = require("axios");

exports.run = {
  usage: ['soundcloud'],
  hidden: ['scdl'],
  use: 'link soundcloud',
  category: 'downloader',
  async: async (m, { func, mecha }) => {
    if (!m.text) return m.reply(func.example(m.cmd, 'https://soundcloud.com/user/song-name'));
    if (!m.args[0].includes('soundcloud.com')) return m.reply("❌ URL SoundCloud tidak valid.");

    mecha.sendReact(m.chat, '🕒', m.key);

    try {
      let apiUrl = `https://api.snapinsta.app/api/scdl?url=${encodeURIComponent(m.args[0])}`;
      let response = await axios.get(apiUrl);
      let data = response.data;

      if (!data || !data.download_url) {
        return m.reply("❌ Gagal mengambil audio dari SoundCloud.");
      }

      let txt = `🎵 *SOUNDCLOUD DOWNLOADER*\n\n`;
      txt += `◦ *Title* : ${data.title || "Tidak ada judul"}\n`;
      txt += `◦ *Artist* : ${data.artist || "Unknown"}\n`;

      mecha.sendMessage(m.chat, {
        audio: { url: data.download_url },
        mimetype: 'audio/mp3',
        fileName: `${data.title || "soundcloud_audio"}.mp3`,
        caption: txt
      }, { quoted: m });

    } catch (err) {
      console.error("❌ Error saat mengunduh SoundCloud:", err);
      m.reply("❌ Terjadi kesalahan saat mengunduh audio dari SoundCloud.");
    }
  },
  limit: 2
};