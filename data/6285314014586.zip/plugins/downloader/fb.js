const axios = require("axios");
const cheerio = require("cheerio");

async function Facebook(url) {
    try {
        let { data } = await axios.post(
            "https://getmyfb.com/process",
            `id=${encodeURIComponent(url)}&locale=id`, {
                headers: {
                    "HX-Request": true,
                    "HX-Trigger": "form",
                    "HX-Target": "target",
                    "HX-Current-URL": "https://getmyfb.com/id",
                    "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
                    "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Mobile Safari/537.36",
                    Referer: "https://getmyfb.com/id",
                },
            }
        );

        const $ = cheerio.load(data);
        const caption = $(".results-item-text").text().trim();
        const imageUrl = $(".results-item-image").attr("src");

        let links = [];
        $(".results-list li").each((i, element) => {
            const downloadLink = $(element).find("a").attr("href");
            if (downloadLink) {
                links.push(downloadLink);
            }
        });

        if (links.length === 0) throw new Error("Gagal mendapatkan media!");

        return {
            status: true,
            metadata: {
                title: caption,
                image: imageUrl,
            },
            media: links,
        };
    } catch (error) {
        return {
            status: false,
            message: error.message,
        };
    }
}

exports.run = {
    usage: ["facebook"],
    hidden: ["fbdl", "fb"],
    use: "link facebook",
    category: "downloader",
    async: async (m, { func, mecha }) => {
        if (!m.text) return m.reply(`Masukkan URL!\n\nContoh: *${m.cmd} https://www.facebook.com/watch/?v=123456789*`);
        if (!m.args[0].match(/(?:https?:\/\/(web\.|www\.|m\.)?(facebook|fb)\.(com|watch)\S+)?$/)) return m.reply(global.mess.error.url);
        if (m.args[0].includes('https://l.facebook.com/l.php?u=')) return m.reply(global.mess.error.url);

        mecha.sendReact(m.chat, '🕒', m.key);
        let res = await Facebook(m.args[0]);
        
        if (!res.status) return m.reply(res.message);

        let caption = `*FACEBOOK VIDEO DOWNLOADER*\n\n- *Title* : ${res.metadata.title}`;

        await mecha.sendMedia(m.chat, res.media[0], m, {
            caption: caption,
            expiration: m.expiration
        });
    },
    premium: true,
    limit: true
};