const fetch = require('node-fetch');

exports.run = {
  usage: ['animegif'],
  category: 'anime',
  async: async (m, { func, mecha, setting }) => {
    try {
      let response = await fetch('https://api.betabotz.org/api/sticker/animegif?apikey=ferrhana');
      let data = await response.json();

      if (!data || !data.result || data.result.length === 0) {
        return mecha.sendMessage(m.chat, { text: 'Anime GIF tidak ditemukan!' }, { quoted: m });
      }

      let media = data.result[Math.floor(Math.random() * data.result.length)];

      let packname = global.packname || setting.packname || 'Anime Sticker';
      let author = global.author || setting.author || 'Mecha Bot';

      await mecha.sendSticker(m.chat, media, m, {
        packname: packname,
        author: author,
        expiration: m.expiration
      });

    } catch (error) {
      console.error(error);
      mecha.sendMessage(m.chat, { text: 'Terjadi kesalahan saat mengambil Anime GIF!' }, { quoted: m });
    }
  },
  limit: true
};