const cheerio = require("cheerio");
const axios = require("axios");

async function ceritahantu(query) {
const response = await axios.get(`https://cerita-hantu-nyata.blogspot.com/search?q=${encodeURIComponent(query)}&m=1`);
const $ = cheerio.load(response.data);
const popularPosts = [];
$(".item-content").each((index, element) => {
const post = {};
post.title = $(element).find(".item-title a").text();
post.snippet = $(element).find(".item-snippet").text().trim();
post.image = $(element).find(".item-thumbnail img").attr("src");
post.url = $(element).find(".item-title a").attr("href");
popularPosts.push(post);
});
return popularPosts;
}

exports.run = {
usage: ['ceritahantu', 'ceritahanturead'],
use: 'query',
category: 'searching',
async: async (m, { func, mecha }) => {
switch (m.command) {
case 'ceritahantu':{
if (!m.text) return m.reply(func.example(m.cmd, 'pocong'))
let result = await ceritahantu();
if (result.length == 0) return m.reply('Empty data.')
let rows = []
let body = '```Result from:```' + ' `' + m.text + '`'
for (let [index, data] of result.entries()) {
if (!data.title || !data.snippet || !data.image || !data.url) continue
rows.push({
title: `${index + 1}. ${data.title}`,
description: `${data.snippet}`,
id: `${m.prefix}ceritahanturead ${data.title}||${data.snippet}||${data.image}||${data.url}`
})
}
let sections = [{
title: 'PILIH CERITA HOROR DIBAWAH',
rows: rows
}]
let buttons = [
['list', 'Click Here ⎙', sections],
]
mecha.sendButton(m.chat, `CERITA HANTU SEARCH`, body, 'select the list button below.', buttons, m, {
userJid: m.sender,
expiration: m.expiration
})
}
break
case 'ceritahanturead':{
if (!m.text.split('||')) return mecha.sendReact(m.chat, '❌', m.key)
let [title, snippet, image, url] = m.text.split('||')
let button = [
['url', 'Source Url', url]
]
mecha.sendButton(m.chat, `${title.toUpperCase()}`, `${snippet}`, global.footer, button, m, {
media: image,
userJid: m.sender,
expiration: m.expiration
})
}
break
}
},
limit: true
}