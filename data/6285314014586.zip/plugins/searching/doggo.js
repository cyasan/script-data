async function getRandomAnime() {
  const animeList = [
  "https://i.pinimg.com/originals/a2/ae/34/a2ae34fa0d428115ab6aeb9b99452cbb.jpg",
  "https://i.pinimg.com/236x/37/e8/7b/37e87b7701414142ef6c1a115e928dd7.jpg",
  "https://i.pinimg.com/474x/fe/24/f0/fe24f035f5fc4c3303fc7947871c4cc6.jpg",
  "https://i.pinimg.com/originals/fe/bf/b3/febfb321c53b2d401aea3f96f309f490.jpg",
  "https://i.pinimg.com/originals/34/b0/05/34b005a26c6a4b1bae1169f6118de556.jpg",
  "https://i.pinimg.com/originals/30/33/cf/3033cf31b0d1632d5011320261d47fd2.jpg",
  "https://i.pinimg.com/originals/64/db/79/64db79d49edb0f484f51d2ceaf3e4891.jpg",
  "https://i.pinimg.com/736x/5a/0f/ab/5a0fabae97527d788b517777fbd1d511.jpg",
  "https://i.pinimg.com/originals/96/6d/e6/966de6e479f97a56a9e6c54c82c1d2ab.jpg",
  "https://i.pinimg.com/564x/ac/79/3e/ac793e78e6b263b122f86e89e263b2c0.jpg",
  "https://i.pinimg.com/736x/1b/33/6c/1b336c44f5671cd73050b564bd879a59.jpg",
  "https://i.pinimg.com/736x/69/09/5c/69095c047bdd8bac99f1ec3196acfc32.jpg",
  "https://i.pinimg.com/236x/af/27/a2/af27a2f28612100e28cbaf8e380c7abb.jpg",
  "https://i.pinimg.com/736x/62/9a/51/629a5126184dea92cbf088f013c9d462.jpg",
  "https://i.pinimg.com/236x/37/66/ac/3766ac6253f6bef294c7607320f62ee9--anjing-muscular-system.jpg",
  "https://i.pinimg.com/originals/61/9d/78/619d785f0c4219476ef05c4e17291244.jpg",
  "https://i.pinimg.com/736x/1d/5e/42/1d5e42d863d7bdc204645b66c9369ceb.jpg",
  "https://i.pinimg.com/474x/0e/b3/95/0eb395409bd9820a5785cfda7991a904.jpg",
  "https://i.pinimg.com/564x/11/49/b0/1149b0aea40d170ccb7252604303fa88.jpg",
  "https://i.pinimg.com/originals/93/ac/c2/93acc2dad5d8b365d738e4529677b242.jpg",
  "https://i.pinimg.com/564x/ce/ba/07/ceba07ea6aa46692cef645080f0a7aeb.jpg",
  "https://i.pinimg.com/474x/70/f4/c4/70f4c4889b8577ced2e02b2aea767596.jpg",
  "https://i.pinimg.com/originals/cf/50/b1/cf50b145d51dc702b428fa4e12cd4c25.jpg",
  "https://i.pinimg.com/originals/ce/b2/8b/ceb28bf5d7a4a9960f6033dac1f1889c.jpg",
  "https://i.pinimg.com/originals/14/2b/ed/142bed516badfa4dc1bed264cf51519e.jpg",
  "https://i.pinimg.com/originals/6f/d6/b1/6fd6b11f3d82a24c3dfeac514347b241.jpg",
  "https://i.pinimg.com/originals/79/75/bc/7975bc5a2632b6f46dc1066dde1f96e6.jpg",
  "https://i.pinimg.com/originals/36/1f/c2/361fc20f3049e2348039f780b7b23a0d.jpg",
  "https://i.pinimg.com/originals/03/10/1e/03101efb41def949dfb83331a498b99a.jpg",
  "https://i.pinimg.com/474x/a7/5c/ce/a75cce02f6fa6af1167d880aa2cfe36e.jpg",
  "https://i.pinimg.com/originals/e1/19/06/e11906d303e516882ccd2c636b32973e.jpg",
  "https://i.pinimg.com/474x/05/c5/5d/05c55d72136688fb8d6dc32bc36a0729--chihuahua-puppies-chihuahua-love.jpg",
  "https://i.pinimg.com/originals/33/9f/01/339f01aacb67d5c6455ec232ffa52e00.jpg",
  "https://i.pinimg.com/originals/f6/14/76/f61476d687cc688d0189492ca10bfb45.jpg",
  "https://i.pinimg.com/736x/7b/84/48/7b844851b22866a017294ceb00b34f73.jpg",
  "https://i.pinimg.com/originals/dc/81/f6/dc81f67ea498a4c0d15887c266f17158.jpg",
  "https://i.pinimg.com/originals/7d/1f/2b/7d1f2be91a6025556e9b5402a2f9f581.jpg",
  "https://i.pinimg.com/originals/b8/ae/11/b8ae119be45c9f80de19bde2b4c87bad.jpg",
  "https://i.pinimg.com/736x/5d/75/85/5d7585d41aed019da6d3e67086a4bdef.jpg",
  "https://i.pinimg.com/736x/8f/1a/7d/8f1a7d115f465c9305d84c20c21fa0b5.jpg",
  "https://i.pinimg.com/736x/7c/8c/3f/7c8c3f736dd484d9ac875eab56bf1fac.jpg",
  "https://i.pinimg.com/736x/5f/ed/c9/5fedc982f0d20869841a47501f3ecfd4.jpg",
  "https://i.pinimg.com/originals/7f/21/e1/7f21e16d3266551a8eccb19b6f02df77.jpg",
  "https://i.pinimg.com/originals/1d/6d/cb/1d6dcba2ac30e045756f5a018ff9f713.jpg",
  "https://i.pinimg.com/564x/e5/d3/11/e5d3111b1201296a9386f05d46f61d53.jpg",
  "https://i.pinimg.com/236x/1c/d4/8a/1cd48abb2763a6a05ff58f0368b47807.jpg",
  "https://i.pinimg.com/200x150/a1/c5/05/a1c5056129deb917a5bb861739d33b9e.jpg",
  "https://i.pinimg.com/originals/94/b9/ba/94b9ba0def03acd38fd1423e17ccc15b.jpg"
];

  const randomIndex = Math.floor(Math.random() * animeList.length);
  return animeList[randomIndex];
}

exports.run = {
  usage: ["doggo"],
  category: "random",
  async: async (m, { mecha }) => {
    try {
      mecha.sendReact(m.chat, "🕒", m.key);
      const animeUrl = await getRandomAnime();

      mecha.sendMessage(
        m.chat,
        {
          image: { url: animeUrl },
          caption: "乂 *DOGGO*",
        },
        { quoted: m, ephemeralExpiration: 86400 }
      );
    } catch (error) {
      console.error("Error fetching anime:", error);
      mecha.sendReact(m.chat, "❌", m.key);
    }
  },
  limit: true,
};