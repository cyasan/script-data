const fetch = require('node-fetch');

exports.run = {
usage: ['asupan', 'asupan-bocil', 'asupan-gheayubi', 'asupan-hijaber', 'asupan-rikagusriani', 'asupan-santuy', 'asupan-ukhti', 'asupan-tiktok'],
category: 'asupan',
async: async (m, { func, mecha }) => {
if (m.command === 'asupan') {
let rows = [
{
title: `Asupan Bocil`,
id: `${m.prefix}asupan-bocil`
},
{
title: `Asupan Gheayubi`,
id: `${m.prefix}asupan-gheayubi`
},
{
title: `Asupan Hijaber`,
id: `${m.prefix}asupan-hijaber`
},
{
title: `Asupan Rikagusriani`,
id: `${m.prefix}asupan-rikagusriani`
},
{
title: `Asupan Santuy`,
id: `${m.prefix}asupan-santuy`
},
{
title: `Asupan Ukhti`,
id: `${m.prefix}asupan-ukhti`
},
{
title: `Asupan Tiktok`,
id: `${m.prefix}asupan-tiktok`
},
]
let sections = [{
title: `PILIH ASUPAN DIBAWAH`, 
highlight_label: 'Populer Asupan',
rows: rows
}]
let buttons = [
['list', 'Click Here ⎙', sections]
]
return mecha.sendButton(m.chat, 'A S U P A N', 'Select the list button below.', global.footer, buttons, m, {
userJid: m.sender,
expiration: m.expiration
})
} else {
let asupanUrl;
if (/asupan-bocil/.test(m.command)) asupanUrl = 'asupan-bocil';
if (/asupan-gheayubi/.test(m.command)) asupanUrl = 'asupan-gheayubi';
if (/asupan-hijaber/.test(m.command)) asupanUrl = 'asupan-hijaber';
if (/asupan-rikagusriani/.test(m.command)) asupanUrl = 'asupan-rikagusriani';
if (/asupan-santuy/.test(m.command)) asupanUrl = 'asupan-santuy';
if (/asupan-ukhti/.test(m.command)) asupanUrl = 'asupan-ukhti';
if (/asupan-tiktok/.test(m.command)) asupanUrl = 'asupan-tiktok';
mecha.sendReact(m.chat, '🕒', m.key)
let asupan = await fetch(`https://raw.githubusercontent.com/Jabalsurya2105/database/master/asupan/${asupanUrl}.json`).then(response => response.json())
let result = asupan.random()
let button = [
['button', 'Next Video', m.cmd],
['button', 'Delete Video', `${m.prefix}delete`],
]
mecha.sendButton(m.chat, '', 'Nih Asupan nya..', 'click the button for the next video', button, m, {
media: result,
userJid: m.sender,
expiration: m.expiration
})
}
},
premium: true,
limit: 3
}