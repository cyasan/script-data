const axios = require('axios');
const cheerio = require('cheerio');

function gifsSearch(query) {
  return new Promise(async (resolve, reject) => {
    try {
      const searchUrl = `https://tenor.com/search/${encodeURIComponent(query)}-gifs`;
      const { data } = await axios.get(searchUrl, {
        headers: {
          "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
        }
      });

      const $ = cheerio.load(data);
      const results = [];

      $("figure.UniversalGifListItem").each((i, el) => {
        const $el = $(el);
        const img = $el.find("img");
        const gifUrl = img.attr("src");
        const alt = img.attr("alt") || "No description";
        const detailPath = $el.find("a").first().attr("href");

        if (gifUrl && gifUrl.endsWith('.gif') && detailPath) {
          results.push({
            gif: gifUrl,
            alt,
            link: "https://tenor.com" + detailPath
          });
        }
      });

      resolve(results);
    } catch (err) {
      console.error("GIF search error:", err);
      reject(err);
    }
  });
}

exports.run = {
  usage: ['gifsearch'],
  hidden: ['gif'],
  use: 'query',
  category: 'searching',
  async: async (m, { func, mecha }) => {
    if (!m.text) return m.reply(func.example(m.cmd, 'angry cat'));
    
    mecha.sendReact(m.chat, '🕒', m.key);

    const gifs = await gifsSearch(m.text);
    if (!gifs.length) return m.reply('Tidak ditemukan hasil GIF untuk pencarian itu.');

    const selected = gifs[Math.floor(Math.random() * gifs.length)];
    let caption = `乂  *GIF SEARCH*\n\n`
    caption += `◦  *Deskripsi* : ${selected.alt}\n`;
    caption += `◦  *Link* : ${selected.link}`;

    mecha.sendFile(m.chat, selected.gif, 'gif.gif', caption, m);
  },
  premium: false,
  limit: true
};