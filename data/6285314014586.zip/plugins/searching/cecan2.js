async function getRandomAnime() {
  const animeList = [
'https://files.catbox.moe/d7sihl.mp4',
'https://files.catbox.moe/i12xz7.mp4',
'https://files.catbox.moe/0rj6a8.mp4',
'https://files.catbox.moe/suv3um.mp4',
'https://files.catbox.moe/ikicno.mp4',
'https://files.catbox.moe/0w2p4q.mp4',
'https://files.catbox.moe/yasrqd.mp4',
'https://files.catbox.moe/dco91f.mp4',
'https://files.catbox.moe/nv3wdn.mp4',
'https://files.catbox.moe/ysq51m.mp4',
'https://files.catbox.moe/re2sza.mp4',
'https://files.catbox.moe/9cfgdo.mp4',
'https://files.catbox.moe/ulzyyz.mp4',
'https://files.catbox.moe/k93bdp.mp4',
  ];

  const randomIndex = Math.floor(Math.random() * animeList.length);
  const randomAnime = animeList[randomIndex];

  return randomAnime;
}

exports.run = {
  usage: ['cecan2'], // Use a more descriptive command name
  category: 'asupan', // More appropriate category
  async: async (m, { func, mecha, users, setting, froms }) => {

    try {
      mecha.sendReact(m.chat, '🕒', m.key); // Send a loading indicator
      const animeUrl = await getRandomAnime();

      // Send the video only if the URL is valid and appropriate (consider adding content filtering)
      if (isValidVideoUrl(animeUrl) && isAppropriateContent(animeUrl)) {
        mecha.sendMessage(m.chat, {
          video: {
            url: animeUrl,
          },
          mimetype: 'video/mp4', // Assuming MP4 format, adjust if needed
        }, { quoted: m, ephemeralExpiration: 86400 }); // Send the video ephemerally
      } else {
        m.reply(`Maaf, terjadi kesalahan saat mengambil video anime.`); // Informative error message
      }
    } catch (error) {
      console.error('Error fetching anime:', error);
      mecha.sendReact(m.chat, '❌', m.key); // Send an error indicator
    }
  },
  limit: 2, // Consider adjusting rate limits based on usage patterns
  premium: true, // Adjust premium status as needed
};

// Helper functions (optional, depending on complexity)
function isValidVideoUrl(url) {
  // Implement logic to validate video URL format and existence
  return true; // Replace with actual validation logic
}

function isAppropriateContent(url) {
  // Implement logic to filter out inappropriate content
  return true; // Replace with actual content filtering logic
}