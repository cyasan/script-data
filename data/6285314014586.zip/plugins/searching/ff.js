const axios = require("axios");
const cheerio = require("cheerio");

exports.run = {
  usage: ["ffchar"],
  category: "searching",
  use: "nama karakter Free Fire",
  async: async (m, { func, mecha }) => {
    if (!m.text) return mecha.reply(m.chat, func.example(m.cmd, "Alok"), m);

    mecha.sendReact(m.chat, "🕒", m.key);

    try {
      // Ambil daftar karakter dari situs Free Fire
      const { data } = await axios.get("https://ff.garena.com/id/chars/");
      const $ = cheerio.load(data);
      let results = [];

      $(".char-box.char-box-new").each((i, elem) => {
        let name = $(elem).find(".char-item-name").text().trim();
        let desc = $(elem).find(".char-item-desc").text().trim();
        let idMatch = $(elem).find("a").attr("href").match(/\/(\d+)$/);
        let id = idMatch ? idMatch[1] : null;

        if (name && id) results.push({ name, desc, id });
      });

      // Cari karakter berdasarkan input user
      let chara = results.find((c) => c.name.toLowerCase() === m.text.toLowerCase());
      if (!chara) return mecha.reply(m.chat, "Karakter tidak ditemukan. Coba nama lain!", m);

      // Ambil detail skill karakter berdasarkan ID
      const { data: skillData } = await axios.get(`https://ff.garena.com/id/chars/${chara.id}`);
      const $$ = cheerio.load(skillData);
      let skillTitle = $$(".skill-profile-title").text().trim();
      let skillDesc = $$(".skill-introduction").text().trim();

      // Buat pesan hasil pencarian
      let caption = `*乂 FREE FIRE CHARACTER SEARCH*\n\n`;
      caption += `- *Nama:* ${chara.name}\n`;
      caption += `- *Deskripsi:* ${chara.desc}\n`;
      caption += `- *Skill:* ${skillTitle} - ${skillDesc}\n\n`;
      caption += `_Data dari Garena Free Fire_`;

      mecha.reply(m.chat, caption, m);
      mecha.sendReact(m.chat, "✅", m.key);
    } catch (err) {
      console.error("Error fetching Free Fire character data:", err);
      mecha.reply(m.chat, "Terjadi kesalahan saat mencari karakter Free Fire.", m);
    }
  },
  limit: true,
};