exports.run = {
  usage: ['mining'],
  category: 'rpg',
  async: async (m, { func, mecha, users, setting, froms }) => {
    const user = global.db.users[m.sender] || {};

    // Pastikan data default
    user.lastmining = user.lastmining || 0;
    user.iron = user.iron || 0;
    user.gold = user.gold || 0;
    user.emerald = user.emerald || 0;
    user.diamond = user.diamond || 0;
    user.stamina = user.stamina || 100;  
    user.durabilitiesPickaxe = user.durabilitiesPickaxe || 0;

    // Cek apakah stamina cukup
    if (user.stamina < 70) {
      return mecha.sendMessage(m.chat, {
        text: `Stamina kamu kurang dari 70. Silakan isi stamina terlebih dahulu dengan perintah: *${m.prefix}heal*`
      }, { quoted: m });
    }

    // Periksa apakah user memiliki pickaxe
    if (!user.pickaxe || user.pickaxe <= 0 || user.durabilitiesPickaxe <= 0) {
      return mecha.sendMessage(m.chat, {
        text: `Kamu tidak memiliki *Pickaxe* untuk menambang.\nSilakan buat Pickaxe terlebih dahulu dengan perintah:\n *${m.prefix}create pickaxe 1*`
      }, { quoted: m });
    }

    // Cooldown mining
    const cooldownFree = 600000; // 10 menit
    const cooldownPremium = 300000; // 5 menit
    const cooldown = user.premium ? cooldownPremium : cooldownFree;

    if (Date.now() - user.lastmining < cooldown) {
      const remaining = cooldown - (Date.now() - user.lastmining);
      return mecha.sendMessage(m.chat, {
        text: `Kamu sudah menambang, tunggu *${func.msToTime(remaining)}* lagi untuk menambang kembali!`
      }, { quoted: m });
    }

    // Tandai waktu terakhir menambang
    user.lastmining = Date.now();

    // Kirim pesan awal tanpa externalAdReply
    await mecha.sendMessage(m.chat, { text: `_Mulai menambang..._` }, { quoted: m });

    // Tunggu 10 detik sebelum mengirim hasil
    await new Promise(resolve => setTimeout(resolve, 10000));

    // Hadiah berdasarkan status premium
    const rewards = {
      iron: Math.floor(Math.random() * (user.premium ? 61 : 31)),  
      gold: Math.floor(Math.random() * (user.premium ? 41 : 21)),  
    };

    rewards.emerald = Math.floor(Math.random() * Math.max(rewards.iron / 2, 1));  
    rewards.diamond = Math.floor(Math.random() * Math.max(rewards.emerald, 1));  

    // Tambahkan hadiah ke data user
    user.iron += rewards.iron;
    user.gold += rewards.gold;
    user.emerald += rewards.emerald;
    user.diamond += rewards.diamond;

    // Kurangi stamina setelah mining
    user.stamina -= 5;
    user.durabilitiesPickaxe -= 5;

    // Format hasil mining
    const resultMessage = `乂 *RPG - MINING*

Stamina: *${user.stamina}* / 100
Durabilitas Pickaxe: *${user.durabilitiesPickaxe}*

  > *Iron*: ${rewards.iron}
  > *Gold*: ${rewards.gold}
  > *Emerald*: ${rewards.emerald}
  > *Diamond*: ${rewards.diamond}

> Gunakan *${m.prefix}inventory* untuk melihat koleksi hasil tambangmu!`;

    // Kirim hasil mining dengan externalAdReply
    await mecha.sendMessage(m.chat, {
      text: resultMessage,
      contextInfo: {
        externalAdReply: {
          title: "M E N A M B A N G",
          body: global.header,
          thumbnailUrl: "https://files.catbox.moe/wk3r2v.jpg",
          sourceUrl: "",
          renderLargerThumbnail: true,
          mediaType: 1
        }
      }
    }, { quoted: m });
  },
  limit: true,
  restrict: true,
};