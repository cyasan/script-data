// Fungsi untuk format uang dengan simbol $
function formatMoney(amount) {
  return '$' + amount.toLocaleString('id-ID');
}

exports.run = {
  usage: ['investasi'],
  hidden: ['invest', 'invs'],
  use: 'amount',
  category: 'rpg',
  async: async (m, { mecha, args, users, setting }) => {
    let user = global.db.users[m.sender];

    // Cek apakah user ada di database
    if (!user) {
      return mecha.sendMessage(m.chat, { text: 'Kamu belum terdaftar dalam database!' }, { quoted: m });
    }

    // Ambil jumlah uang yang akan diinvestasikan
    let amount = (m.args[0] || '').replace(/[^0-9]/g, ''); // Sama seperti nabung

    if (!amount || isNaN(amount) || amount <= 0) {
      return mecha.sendMessage(m.chat, { text: 'Masukkan jumlah uang yang valid untuk diinvestasikan!' }, { quoted: m });
    }

    amount = parseInt(amount, 10); // Pastikan angka menjadi integer

    // Cek apakah user memiliki uang cukup
    if (user.money < amount) {
      return mecha.sendMessage(m.chat, { text: `Uang kamu tidak cukup! Saat ini kamu hanya memiliki ${formatMoney(user.money)}` }, { quoted: m });
    }

    // Mengurangi uang dari saldo pengguna untuk diinvestasikan
    user.money -= amount;
    user.invest = (user.invest || 0) + amount;

    // Tentukan apakah investasi untung atau rugi (50% peluang)
    let isProfit = Math.random() < 0.5; // 50% kesempatan untung, 50% kesempatan rugi

    // Hitung keuntungan atau kerugian
    let profitMultiplier = isProfit ? 1.5 : 0.5; // Jika untung: 1.5x, jika rugi: 0.5x
    let finalAmount = Math.floor(amount * profitMultiplier);
    let resultMessage = isProfit 
      ? `Investasi kamu sukses! Modal ${formatMoney(amount)} berkembang menjadi ${formatMoney(finalAmount)} setelah 24 jam.` 
      : `Investasi kamu mengalami kerugian! Modal ${formatMoney(amount)} berkurang menjadi ${formatMoney(finalAmount)} setelah 24 jam.`; 

    // Simulasi hasil investasi setelah 24 jam
    setTimeout(() => {
      user.money += finalAmount;
      return mecha.sendMessage(m.chat, { 
        text: `乂 *RPG - INVESTASI*\n\nHasil Investasi:\n\n${resultMessage}\n\nTotal uang kamu sekarang: ${formatMoney(user.money)}` 
      }, { quoted: m });
    }, 86400000); // 24 jam dalam milidetik

    return mecha.sendMessage(m.chat, { 
      text: `Kamu telah menginvestasikan ${formatMoney(amount)}! Tunggu 24 jam untuk melihat hasilnya...` 
    }, { quoted: m });
  },
 restrict: true
};