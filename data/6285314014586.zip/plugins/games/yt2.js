let database = {};

exports.run = {
  usage: ['createyt'],
  hidden: ['buatyt'],
  use: 'name',
  category: 'rpg',
  async: async (m, { mecha }) => {
    if (!global.db.users) global.db.users = {};

    let sender = m.sender;
    let user = global.db.users[sender] || {}; // Pastikan user tidak undefined

    // Cek apakah user sudah memiliki channel YouTube
    if (user.ch) {
      return mecha.reply(m.chat, `Kamu sudah memiliki channel YouTube: *${user.ch}*`, m);
    }

    let channelName = m.text.trim();
    if (!channelName) {
      database[sender] = Date.now();
      return mecha.reply(m.chat, `Silakan ketik nama channel YouTube yang ingin dibuat...`, m);
    }

    // Simpan data channel tanpa menghapus data sebelumnya
    user.ch = channelName;
    user.subs = user.subs || 0;
    user.view = user.view || 0;
    user.like = user.like || 0;
    user.playbutton = user.playbutton || {
      silver: false,
      gold: false,
      diamond: false
    };
    user.laststream = user.laststream || 0;

    // Simpan kembali user ke database
    global.db.users[sender] = user;

    // Kirim laporan ke owner
    let reportMessage = `*New Account Created*\n\n` +
                        `📢 *Account:* YouTube\n` +
                        `📺 *Channel:* ${channelName}\n` +
                        `👤 *User:* @${sender.split('@')[0]}`;

    if (Array.isArray(global.owner)) {
      global.owner.forEach(ownerId => {
        mecha.sendMessage(ownerId + '@s.whatsapp.net', { 
          text: reportMessage, 
          contextInfo: { mentionedJid: [sender] } 
        });
      });
    } else if (typeof global.owner === 'string') {
      mecha.sendMessage(global.owner + '@s.whatsapp.net', { 
        text: reportMessage, 
        contextInfo: { mentionedJid: [sender] } 
      });
    }

    return mecha.reply(m.chat, `Channel YouTube berhasil dibuat dengan nama: *${channelName}*`, m);
  },

  limit: false
};