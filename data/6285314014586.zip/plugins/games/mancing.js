exports.run = {
  usage: ['mancing'],
  hidden: ['fishing'],
  category: 'rpg',
  async: async (m, { func, mecha, users, setting, froms }) => {
    let user = global.db.users[m.sender];

    // Cek apakah user ada di database
    if (!user) {
      return mecha.sendMessage(
        m.chat,
        { text: 'User tidak ditemukan di database. Pastikan anda sudah terdaftar!' },
        { quoted: m }
      );
    }

    // Cek stamina
    if (user.stamina < 70) {
      return mecha.sendMessage(
        m.chat,
        { text: `Stamina kamu kurang dari 70. Silahkan isi stamina terlebih dahulu dengan command: ${m.prefix}heal.` },
        { quoted: m }
      );
    }

    // Cek alat pancing dan durabilitasnya
    if (!user.fishingrod || user.fishingrod <= 0 || user.durabilitiesFishingrod <= 0) {
      if (user.durabilitiesFishingrod <= 0) user.fishingrod = 0; // Hapus alat pancing jika durabilitas habis
      return mecha.sendMessage(
        m.chat,
        {
          text: `Kamu tidak memiliki *Fishing Rod* untuk memancing.\nSilahkan buat terlebih dahulu dengan command:\n${m.prefix}create fishingrod 1`
        },
        { quoted: m }
      );
    }

    // Cooldown
    const cooldownPremium = 10 * 60 * 1000; // 10 menit
    const cooldownFree = 30 * 60 * 1000; // 30 menit
    const cooldown = user.premium ? cooldownPremium : cooldownFree;

    if (Date.now() - user.lastmancing < cooldown) {
      const remainingTime = cooldown - (Date.now() - user.lastmancing);
      return mecha.sendMessage(
        m.chat,
        { text: `Kamu sudah memancing. Tunggu *${func.msToTime(remainingTime)}* lagi untuk memancing kembali.` },
        { quoted: m }
      );
    }

    // Tandai waktu terakhir memancing
    user.lastmancing = Date.now();

    // Kirim pesan awal memancing
    await mecha.sendMessage(
      m.chat,
      { text: '_Mancing dimulai..._' },
      { quoted: m }
    );

    // Tunggu 10 detik sebelum mengirim hasil
    await new Promise(resolve => setTimeout(resolve, 10000));

    // Jenis ikan dan emoji
    const fishTypes = [
      { name: 'tongkol', emoji: '🐟' },
      { name: 'buntal', emoji: '🐡' },
      { name: 'pausmini', emoji: '🐋' },
      { name: 'udang', emoji: '🦐' },
      { name: 'gurita', emoji: '🐙' },
      { name: 'nila', emoji: '🐠' },
      { name: 'cumi', emoji: '🦑' },
      { name: 'langka', emoji: '🐳' },
      { name: 'kepiting', emoji: '🦀' },
      { name: 'kerang', emoji: '🐚' }
    ];

    // Generate jumlah ikan secara acak
    let rewards = fishTypes.map(fish => ({
      ...fish,
      amount: Math.floor(Math.random() * 10) * (user.premium ? 5 : 1)
    }));

    // Tambahkan ke database
    rewards.forEach(({ name, amount }) => {
      user[name] = (user[name] || 0) + amount;
    });

    // Kurangi durabilitas alat pancing dan stamina
    user.durabilitiesFishingrod -= 5;
    if (user.durabilitiesFishingrod <= 0) user.fishingrod = 0; // Hapus alat pancing jika durabilitas habis
    user.stamina -= 3;

    // Format hasil memancing dalam dua kolom
    const formattedResults = rewards
      .reduce((rows, { emoji, name, amount }, index) => {
        const rowIndex = Math.floor(index / 2);
        if (!rows[rowIndex]) rows[rowIndex] = [];
        rows[rowIndex].push(`${emoji} ${name.charAt(0).toUpperCase() + name.slice(1)} = ${amount}`);
        return rows;
      }, [])
      .map(row => row.join('        '))
      .join('\n');

    // Hasil memancing dengan externalAdReply
    const resultMessage = `乂 *RPG - MANCING*\n\n${formattedResults}\n\n> Ketik: ${m.prefix}aquarium untuk melihat hasilnya.`;
    return mecha.sendMessage(
      m.chat,
      {
        text: resultMessage,
        contextInfo: {
          externalAdReply: {
            title: 'M E M A N C I N G',
            body: global.header,
            mediaType: 1,
            renderLargerThumbnail: true,
            thumbnailUrl: 'https://files.catbox.moe/ybbelt.jpg'
          }
        }
      },
      { quoted: m }
    );
  },
  limit: true,
  restrict: true
};