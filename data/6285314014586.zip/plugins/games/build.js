exports.run = {
  usage: ['build'],
  use: 'option',
  category: 'rpg',
  async: async (m, { mecha, users, prefix }) => {
    let user = global.db.users[m.sender];
    if (!user) {
      return mecha.sendMessage(m.chat, { text: 'User tidak ditemukan di database. Pastikan Anda sudah terdaftar!' }, { quoted: m });
    }

    // Daftar bangunan dan biaya
    const buildings = [
      { name: 'rumahsakit', cost: { money: 15000000000, order: 'orderDokter', wood: 5000 }, message: 'Rumah Sakit' },
      { name: 'restoran', cost: { money: 12000000000, order: 'orderChef', wood: 2500 }, message: 'Restoran' },
      { name: 'sekolah', cost: { money: 10000000000, order: 'orderGuru', wood: 2000 }, message: 'Sekolah' },
      { name: 'hotel', cost: { money: 7000000000, order: 'orderKuli', wood: 2000 }, message: 'Hotel' },
      { name: 'bengkel', cost: { money: 2000000000, order: 'orderMontir', wood: 2000 }, message: 'Bengkel' },
    ];

    // Mengambil nomor bangunan yang dipilih dari args
    let option = (m.args[0] || '').replace(/[^\d]/g, ''); // Menghapus semua karakter selain angka
    option = parseInt(option);

    if (!option || option < 1 || option > buildings.length) {
      return mecha.sendMessage(m.chat, {
        text: `Pilih bangunan yang ingin dibangun dengan nomor urut:\n\n乂 RPG - BUILDING\n\n` + buildings.map((building, index) => `${index + 1}. ${building.message}`).join('\n')
      }, { quoted: m });
    }

    let building = buildings[option - 1];

    // Mengecek apakah pengguna sudah memiliki bangunan
    if (user[building.name] && user[building.name] > 0) {
      return mecha.sendMessage(m.chat, { text: `Kamu sudah memiliki ${building.message}!` }, { quoted: m });
    }

    // Mengecek apakah pengguna memiliki cukup sumber daya untuk membangun
    if (user.money < building.cost.money) {
      return mecha.sendMessage(m.chat, { text: `Kamu tidak cukup uang untuk membangun ${building.message}. Dibutuhkan ${building.cost.money.toLocaleString('en-US')} money.` }, { quoted: m });
    }

    if (user[building.cost.order] < 250) {
      return mecha.sendMessage(m.chat, { text: `Kamu tidak memiliki cukup order ${building.cost.order.replace('order', '')}. Dibutuhkan 250 order untuk membangun ${building.message}.` }, { quoted: m });
    }

    if (user.kayu < building.cost.wood) {
      return mecha.sendMessage(m.chat, { text: `Kamu tidak memiliki cukup kayu. Dibutuhkan ${building.cost.wood} kayu untuk membangun ${building.message}.` }, { quoted: m });
    }

    // Mengurangi sumber daya pengguna dan menambahkan bangunan
    user.money -= building.cost.money;
    user[building.cost.order] -= 250;
    user.kayu -= building.cost.wood;

    // Menambahkan bangunan ke database pengguna
    user[building.name] = 1;

    // Mendapatkan tanggal sekarang
    const today = new Date();
    const dateString = today.toLocaleDateString('id-ID', {
      weekday: 'long', year: 'numeric', month: 'long', day: 'numeric'
    });

    // Mengirimkan pesan keberhasilan dengan mention
    return mecha.sendMessage(m.chat, {
      text: `乂 RPG - BUILDING\n\nBangunan berhasil dibuat.\nModel: ${building.message}\nTanggal: ${dateString}\nOwner: @${m.sender.split('@')[0]}\nPegawai: -`,
      contextInfo: {
        mentionedJid: [m.sender] // Mention user yang membangun
      }
    }, { quoted: m });
  },

  restrict: true
};