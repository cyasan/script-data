// Fungsi untuk format uang dengan simbol $
function formatMoney(amount) {
  return '$' + amount.toLocaleString('id-ID');
}

exports.run = {
  usage: ['exptomoney'],
  hidden: ['e2m'],
  use: 'amount',
  category: 'rpg',
  async: async (m, { mecha }) => {
    let user = global.db.users[m.sender];

    // Cek apakah user ada di database
    if (!user) {
      return mecha.sendMessage(m.chat, { text: 'User tidak ditemukan di database. Pastikan anda sudah terdaftar!' }, { quoted: m });
    }

    // Ambil jumlah exp yang ingin ditukar
    let amount = (m.args[0] || '').replace(/[^0-9]/g, ''); 

    if (!amount || isNaN(amount) || amount <= 0) {
      return mecha.sendMessage(m.chat, { text: 'Jumlah exp yang ingin ditukar harus berupa angka yang valid dan lebih dari 0.' }, { quoted: m });
    }

    amount = parseInt(amount, 10);

    // Cek apakah user memiliki cukup exp
    if (user.exp < amount) {
      return mecha.sendMessage(m.chat, { text: `Exp kamu tidak mencukupi untuk menukar ${formatMoney(amount)} exp.` }, { quoted: m });
    }

    // Hitung money yang didapat (1.000 exp = 25.000 money)
    let moneyGained = Math.floor(amount / 1000) * 25000;

    if (moneyGained <= 0) {
      return mecha.sendMessage(m.chat, { text: 'Minimal exp yang bisa ditukar adalah 1000 exp (25.000 money).' }, { quoted: m });
    }

    // Kurangi exp dan tambahkan ke money
    user.exp -= amount;
    user.money = (user.money || 0) + moneyGained;

    return mecha.sendMessage(m.chat, {
      text: `Berhasil menukar exp ke money.\n\n` +
            `Total exp yang ditukar: ${formatMoney(amount)}\n` +
            `Total money yang didapat: ${formatMoney(moneyGained)}`
    }, { quoted: m });
  },
  restrict: true,
};