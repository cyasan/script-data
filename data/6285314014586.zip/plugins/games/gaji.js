exports.run = {
  usage: ['gajian'],
  hidden: ['gaji'],
  category: 'rpg',
  async: async (m, { mecha, users, prefix }) => {
    let user = global.db.users[m.sender];
    if (!user) {
      return mecha.sendMessage(m.chat, { text: 'User tidak ditemukan di database. Pastikan Anda sudah terdaftar!' }, { quoted: m });
    }

    // Cek cooldown 5 hari (dalam milidetik)
    const now = new Date();
    const lastClaim = user.lastGaji || 0;
    const cooldown = 5 * 24 * 60 * 60 * 1000; // 5 hari dalam milidetik
    const timeLeft = cooldown - (now - lastClaim);

    if (timeLeft > 0) {
      // Konversi waktu tersisa ke format DD:HH:MM:SS
      let seconds = Math.floor(timeLeft / 1000);
      let days = Math.floor(seconds / (24 * 3600));
      seconds %= 24 * 3600;
      let hours = Math.floor(seconds / 3600);
      seconds %= 3600;
      let minutes = Math.floor(seconds / 60);
      seconds %= 60;

      let timeString = [];
      if (days > 0) timeString.push(`${days}D`);
      if (hours > 0) timeString.push(`${hours}H`);
      if (minutes > 0) timeString.push(`${minutes}M`);
      if (seconds > 0) timeString.push(`${seconds}S`);

      return mecha.sendMessage(m.chat, { text: `Kamu sudah mengambil gaji. Tunggu ${timeString.join(':')} lagi.` }, { quoted: m });
    }

    // Daftar bangunan dan pengali gaji
    const buildings = [
      { name: 'Rumah Sakit', key: 'rumahsakit', multiplier: 15, min: 10000000, max: 15000000 },
      { name: 'Restoran', key: 'restoran', multiplier: 12, min: 5000000, max: 10000000 },
      { name: 'Sekolah', key: 'sekolah', multiplier: 10, min: 3000000, max: 7000000 },
      { name: 'Hotel', key: 'hotel', multiplier: 7, min: 2000000, max: 5000000 },
      { name: 'Bengkel', key: 'bengkel', multiplier: 2, min: 500000, max: 2000000 }
    ];

    // Multiplier jika user adalah premium
    const premiumMultiplier = user.premium ? 2 : 1;

    // Mengecek bangunan yang dimiliki
    let gajiDetail = [];
    let totalGaji = 0;

    buildings.forEach(building => {
      if (user[building.key] && user[building.key] > 0) {
        let gajiBangunan = Math.floor(Math.random() * (building.max - building.min + 1) + building.min);
        gajiBangunan *= premiumMultiplier; // Jika user premium, gaji dikalikan 2
        gajiDetail.push(`${building.name}: $${gajiBangunan.toLocaleString('en-US')}`);
        totalGaji += gajiBangunan;
      }
    });

    // Jika tidak ada bangunan yang memenuhi syarat
    if (gajiDetail.length === 0) {
      return mecha.sendMessage(m.chat, { text: 'Kamu tidak memiliki bangunan yang memenuhi syarat untuk gajian.' }, { quoted: m });
    }

    // Menambahkan uang ke user
    user.money += totalGaji;
    user.lastGaji = now.getTime();

    // Mengirim pesan hasil gajian
    await mecha.sendMessage(m.chat, {
      text: `乂 RPG - GAJIAN\n\nDetail Gaji:\n${gajiDetail.join('\n')}\n\nTotal Gaji Diterima: $${totalGaji.toLocaleString('en-US')}\nTotal Saldo: $${user.money.toLocaleString('en-US')}${user.premium ? '\n(Anda mendapatkan bonus premium x2)' : ''}`,
      contextInfo: {
        mentionedJid: [m.sender]
      }
    }, { quoted: m });
  },
  restrict: true
};