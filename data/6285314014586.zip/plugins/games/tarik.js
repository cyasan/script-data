// Fungsi untuk format Rupiah, diganti menjadi format dengan simbol $
function formatMoney(amount) {
  return '$' + amount.toLocaleString('id-ID'); // Menggunakan tanda $ dan menghilangkan spasi
}

exports.run = {
  usage: ['tarik'],
  use: 'count',
  category: 'rpg',
  async: async (m, { mecha, users }) => {
    let user = global.db.users[m.sender];

    // Cek apakah user ada di database
    if (!user) {
      return mecha.sendMessage(m.chat, { text: 'User tidak ditemukan di database. Pastikan anda sudah terdaftar!' }, { quoted: m });
    }

    // Cek apakah user memiliki ATM
    if (!user.kuli) {
      return mecha.sendMessage(m.chat, { text: `Kamu tidak memiliki ATM. Silahkan buat terlebih dahulu dengan command ${m.prefix}create atm` }, { quoted: m });
    }

    // Ambil jumlah yang akan ditarik (menggunakan amount)
    let amount = (m.args[0] || '').replace(/[^0-9]/g, ''); // Hanya ambil angka dari input

    if (!amount || isNaN(amount) || amount <= 0) {
      return mecha.sendMessage(m.chat, { text: 'Jumlah yang ingin ditarik harus berupa angka yang valid dan lebih dari 0!' }, { quoted: m });
    }

    amount = parseInt(amount, 10); // Pastikan amount menjadi integer

    // Cek apakah user memiliki cukup saldo di ATM
    if (user.atm < amount) {
      return mecha.sendMessage(m.chat, { text: `Saldo ATM kamu tidak mencukupi untuk menarik sebesar ${formatMoney(amount)}.` }, { quoted: m });
    }

    // Kurangi uang dari saldo ATM dan tambahkan ke saldo uang
    user.atm -= amount;
    user.money = (user.money || 0) + amount;

    return mecha.sendMessage(m.chat, {
      text: `Berhasil menarik uang sebanyak ${formatMoney(amount)}\n> Sisa saldo ATM kamu: ${formatMoney(user.atm)}`
    }, { quoted: m });
  },
  restrict: true,
};