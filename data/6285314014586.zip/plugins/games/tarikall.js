// Fungsi untuk format Rupiah, diganti menjadi format dengan simbol $
function formatMoney(amount) {
  return '$' + amount.toLocaleString('id-ID'); // Menggunakan tanda $ dan menghilangkan spasi
}

exports.run = {
  usage: ['tarikall'],
  use: '',
  category: 'rpg',
  async: async (m, { mecha, users }) => {
    let user = global.db.users[m.sender];

    // Cek apakah user ada di database
    if (!user) {
      return mecha.sendMessage(m.chat, { text: 'User tidak ditemukan di database. Pastikan anda sudah terdaftar!' }, { quoted: m });
    }

    // Cek apakah user memiliki ATM
    if (!user.kuli) {
      return mecha.sendMessage(m.chat, { text: `Kamu tidak memiliki ATM. Silahkan buat terlebih dahulu dengan command ${m.prefix}create atm.` }, { quoted: m });
    }

    // Pastikan user memiliki saldo di ATM
    if (user.atm <= 0) {
      return mecha.sendMessage(m.chat, { text: `Saldo ATM kamu tidak cukup untuk menarik semua uang ke saldo kamu.` }, { quoted: m });
    }

    // Ambil seluruh saldo user.atm dan tarik ke saldo uang
    let totalAtm = user.atm;
    user.atm = 0;
    user.money = (user.money || 0) + totalAtm;

    return mecha.sendMessage(m.chat, {
      text: `Berhasil menarik seluruh uang kamu sebesar ${formatMoney(totalAtm)} dari ATM.`
    }, { quoted: m });
  },
  restrict: true,
};