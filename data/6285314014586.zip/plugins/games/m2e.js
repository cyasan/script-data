// Fungsi untuk format uang dengan simbol $
function formatMoney(amount) {
  return '$' + amount.toLocaleString('id-ID');
}

exports.run = {
  usage: ['moneytoexp'],
  hidden: ['m2e'],
  use: 'amount',
  category: 'rpg',
  async: async (m, { mecha }) => {
    let user = global.db.users[m.sender];

    // Cek apakah user ada di database
    if (!user) {
      return mecha.sendMessage(m.chat, { text: 'User tidak ditemukan di database. Pastikan anda sudah terdaftar!' }, { quoted: m });
    }

    // Ambil jumlah money yang ingin ditukar
    let amount = (m.args[0] || '').replace(/[^0-9]/g, ''); 

    if (!amount || isNaN(amount) || amount <= 0) {
      return mecha.sendMessage(m.chat, { text: 'Jumlah money yang ingin ditukar harus berupa angka yang valid dan lebih dari 0.' }, { quoted: m });
    }

    amount = parseInt(amount, 10);

    // Cek apakah user memiliki cukup money
    if (user.money < amount) {
      return mecha.sendMessage(m.chat, { text: `Money kamu tidak mencukupi untuk menukar ${formatMoney(amount)}.` }, { quoted: m });
    }

    // Hitung exp yang didapat (50.000 money = 1.000 exp)
    let expGained = Math.floor(amount / 50000) * 1000;

    if (expGained <= 0) {
      return mecha.sendMessage(m.chat, { text: 'Minimal money yang bisa ditukar adalah 50.000 money (1.000 exp).' }, { quoted: m });
    }

    // Kurangi money dan tambahkan ke exp
    user.money -= amount;
    user.exp = (user.exp || 0) + expGained;

    return mecha.sendMessage(m.chat, {
      text: `Berhasil menukar money ke exp.\n\n` +
            `Total money yang ditukar: ${formatMoney(amount)}\n` +
            `Total exp yang didapat: ${formatMoney(expGained)}`
    }, { quoted: m });
  },
  restrict: true,
};