// Fungsi untuk format uang dengan simbol $
function formatMoney(amount) {
  return '$' + amount.toLocaleString('id-ID'); // Format dengan tanda $
}

exports.run = {
  usage: ['moneytobalance'],
  hidden: ['m2b'],
  use: 'amount',
  category: 'rpg',
  async: async (m, { mecha }) => {
    let user = global.db.users[m.sender];

    // Cek apakah user ada di database
    if (!user) {
      return mecha.sendMessage(m.chat, { text: 'User tidak ditemukan di database. Pastikan anda sudah terdaftar!' }, { quoted: m });
    }

    // Ambil jumlah money yang ingin ditukar
    let amount = (m.args[0] || '').replace(/[^0-9]/g, ''); // Hanya ambil angka dari input

    if (!amount || isNaN(amount) || amount <= 0) {
      return mecha.sendMessage(m.chat, { text: 'Jumlah money yang ingin ditukar harus berupa angka yang valid dan lebih dari 0!' }, { quoted: m });
    }

    amount = parseInt(amount, 10); // Pastikan amount menjadi integer

    // Cek apakah user memiliki cukup money
    if (user.money < amount) {
      return mecha.sendMessage(m.chat, { text: `Saldo kamu tidak mencukupi untuk menukar ${formatMoney(amount)}.` }, { quoted: m });
    }

    // Hitung balance yang didapat (1000 balance = 50000 money)
    let balanceGained = Math.floor(amount / 50000) * 1000;

    if (balanceGained <= 0) {
      return mecha.sendMessage(m.chat, { text: 'Minimal money yang bisa ditukar adalah $50000 (1000 balance).' }, { quoted: m });
    }

    // Kurangi money dan tambahkan ke balance
    user.money -= amount;
    user.balance = (user.balance || 0) + balanceGained;

    return mecha.sendMessage(m.chat, {
      text: `*Berhasil menukar money ke balance!*\n\n` +
            `*Total money yang ditukar:* ${formatMoney(amount)}\n` +
            `*Total balance yang didapat:* ${formatMoney(balanceGained)}`
    }, { quoted: m });
  },
  restrict: true,
};