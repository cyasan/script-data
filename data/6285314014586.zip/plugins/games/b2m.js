// Fungsi untuk format uang dengan simbol $
function formatMoney(amount) {
  return '$' + amount.toLocaleString('id-ID'); // Format dengan tanda $
}

exports.run = {
  usage: ['balancetomoney'],
  hidden: ['b2m'],
  use: 'amount',
  category: 'rpg',
  async: async (m, { mecha }) => {
    let user = global.db.users[m.sender];

    // Cek apakah user ada di database
    if (!user) {
      return mecha.sendMessage(m.chat, { text: 'User tidak ditemukan di database. Pastikan anda sudah terdaftar!' }, { quoted: m });
    }

    // Ambil jumlah balance yang ingin ditukar
    let amount = (m.args[0] || '').replace(/[^0-9]/g, ''); // Hanya ambil angka dari input

    if (!amount || isNaN(amount) || amount <= 0) {
      return mecha.sendMessage(m.chat, { text: 'Jumlah balance yang ingin ditukar harus berupa angka yang valid dan lebih dari 0!' }, { quoted: m });
    }

    amount = parseInt(amount, 10); // Pastikan amount menjadi integer

    // Cek apakah user memiliki cukup balance
    if (user.balance < amount) {
      return mecha.sendMessage(m.chat, { text: `Balance kamu tidak mencukupi untuk menukar ${formatMoney(amount)} balance.` }, { quoted: m });
    }

    // Hitung money yang didapat (1.000 balance = 50.000 money)
    let moneyGained = Math.floor(amount / 1000) * 50000;

    if (moneyGained <= 0) {
      return mecha.sendMessage(m.chat, { text: 'Minimal balance yang bisa ditukar adalah 1000 balance (50.000 money).' }, { quoted: m });
    }

    // Kurangi balance dan tambahkan ke money
    user.balance -= amount;
    user.money = (user.money || 0) + moneyGained;

    return mecha.sendMessage(m.chat, {
      text: `*Berhasil menukar balance ke money!*\n\n` +
            `*Total balance yang ditukar:* ${formatMoney(amount)}\n` +
            `*Total money yang didapat:* ${formatMoney(moneyGained)}`
    }, { quoted: m });
  },
  restrict: true,
};