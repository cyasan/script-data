const { createCanvas } = require('canvas');

exports.run = {
  usage: ['heal'],
  category: 'rpg',
  async: async (m, { mecha, users }) => {
    let user = global.db.users[m.sender];

    // Cek apakah user ada di database
    if (!user) {
      return mecha.sendMessage(
        m.chat,
        { text: 'User tidak ditemukan di database. Pastikan Anda sudah terdaftar!' },
        { quoted: m }
      );
    }

    // Biaya per satu poin stamina
    const healCostPerPoint = 1000;

    // Batas maksimum stamina
    const maxStamina = 100;

    // Hitung stamina yang perlu diisi
    const staminaNeeded = maxStamina - user.stamina;

    // Jika stamina sudah penuh
    if (staminaNeeded <= 0) {
      return mecha.sendMessage(
        m.chat,
        { text: 'Stamina kamu sudah penuh. Tidak perlu melakukan *heal* lagi!' },
        { quoted: m }
      );
    }

    // Total biaya untuk mengisi stamina
    const totalCost = healCostPerPoint * staminaNeeded;

    // Cek apakah user memiliki uang yang cukup
    if (user.money < totalCost) {
      return mecha.sendMessage(
        m.chat,
        {
          text: `Uang kamu tidak cukup! Kamu membutuhkan $${totalCost} untuk mengisi penuh stamina.\n` +
            `Saldo saat ini: $${user.money}.`
        },
        { quoted: m }
      );
    }

    // Simpan stamina awal sebelum heal
    const staminaAwal = user.stamina;

    // Lakukan heal
    user.stamina = maxStamina; // Penuhi stamina hingga maksimum
    user.money -= totalCost; // Kurangi uang pengguna

    // Buat canvas
    const canvas = createCanvas(300, 100);
    const ctx = canvas.getContext('2d');

    // Isi latar belakang dengan warna hitam
    ctx.fillStyle = '#000000';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Tambahkan teks stamina
    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 40px Arial';
    ctx.fillText(`${staminaAwal}`, 30, 65);

    ctx.fillText('=>', 120, 65);

    ctx.fillStyle = '#00ff00';
    ctx.fillText('100', 200, 65);

    // Simpan gambar ke buffer
    const buffer = canvas.toBuffer();

    // Kirim pesan dengan gambar
    const msg = await mecha.sendMessage(
      m.chat,
      {
        image: buffer,
        caption: `乂 *HEAL*\n\n` +
          `Stamina berhasil diisi.\n` +
          `Stamina: ${user.stamina} / ${maxStamina}\n` +
          `Biaya: $${totalCost}`
      },
      { quoted: m }
    );

    // **Hapus pesan setelah 1 menit**
    setTimeout(() => {
      mecha.sendMessage(m.chat, { delete: msg.key });
    }, 60000); // 1 menit (60.000 ms)
  }
};