exports.run = {
usage: ['listsw'],
hidden: ['botsw'],
use: 'number',
category: 'special',
async: async (m, { func, mecha }) => {
mecha.storyData = mecha.storyData ? mecha.storyData : {};

const data = global.db.story || [];
if (data.length === 0) {
return await mecha.sendteks(m.chat, `Tidak ada cerita yang tersedia saat ini. Silakan tambahkan cerita dengan mengirim gambar, video, atau pesan suara.`, m, { mentions: [m.sender] });
}

const formatMessage = (obj, index) => {
const { mtype, sender, caption } = obj;
const messageType = convertMessageType(mtype);
let text = `*${index + 1}.* ${messageType.toUpperCase()} - @${sender.split('@')[0]}`;
if (caption) text += `\n${caption}`;
return text + '\n';
};

const formattedMessages = data.map(formatMessage).join('\n');

let { key } = await mecha.sendteks(m.chat, `Daftar Story:\n\n${formattedMessages}\nBalas pesan ini dengan nomor cerita yang ingin ditampilkan.`, m, { mentions: mecha.ments(formattedMessages) });
mecha.storyData[m.chat] = {
data, 
key, 
timeout: setTimeout(() => {
mecha.sendMessage(m.chat, { delete: key }); 
delete mecha.storyData[m.chat];
}, 60 * 1000)
};
},
main: async (m, { func, mecha }) => {
mecha.storyData = mecha.storyData ? mecha.storyData : {};
if (m.isBot || !(m.chat in mecha.storyData)) return;

if (!mecha.storyData[m.chat]) return;
const { data, key } = mecha.storyData[m.chat];
if (!m.quoted || m.quoted.id !== key.id || !m.budy) return;
const index = parseInt(m.budy.trim());

if (isNaN(index) || index < 1 || index > data.length) {
await mecha.sendteks(m.chat, 'Masukkan nomor story yang valid.', m);
} else {
const story = data[index - 1];
const msg = story.msg.message[story.mtype];
if (story.mtype === 'imageMessage') {
let buffer = await mecha.downloadM(msg, story.mtype.replace(/Message/i, ''));
await mecha.sendMessage(m.chat, {image: buffer, caption: story.caption, mentions: [m.sender]}, {quoted: story.msg, ephemeralExpiration: m.expiration});
} else if (story.mtype === 'videoMessage') {
let buffer = await mecha.downloadM(msg, story.mtype.replace(/Message/i, ''));
await mecha.sendMessage(m.chat, {video: buffer, caption: story.caption, mentions: [m.sender]}, {quoted: story.msg, ephemeralExpiration: m.expiration});
} else if (story.mtype === 'audioMessage') {
let buffer = await mecha.downloadM(msg, story.mtype.replace(/Message/i, ''));
await mecha.sendMessage(m.chat, {audio: buffer, mimetype: 'audio/mpeg', ptt: true}, {quoted: story.msg, ephemeralExpiration: m.expiration});
} else if (story.mtype === 'extendedTextMessage') {
await mecha.sendMessage(m.chat, {text: story.caption, mentions: [m.sender]}, {quoted: story.msg, ephemeralExpiration: m.expiration});
}
clearTimeout(mecha.storyData[m.chat].timeout);
//delete mecha.storyData[m.chat];
}
},
owner: true
}

function convertMessageType(messageType) {
const messageTypes = {
'videoMessage': 'video',
'imageMessage': 'gambar',
'audioMessage': 'vn',
'extendedTextMessage': 'teks',
};
return messageTypes[messageType] || 'unknown';
}