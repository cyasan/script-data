// Plugin setemail
exports.run = {
  usage: ['setemail'],
  use: 'email',
  category: 'owner',
  async: async (m, { mecha, prefix }) => {
    // Pastikan pengguna sedang merespons pesan user yang ingin diganti email-nya
    if (!m.quoted || !m.quoted.sender) {
      return mecha.reply(m.chat, 'Silakan reply pesan user yang ingin diubah email-nya.', m);
    }

    // Ambil user yang sedang di-reply
    let user = global.db.users[m.quoted.sender];

    // Cek apakah user yang di-reply ada dalam database
    if (!user) {
      return mecha.reply(m.chat, 'User yang Anda reply tidak ditemukan di database.', m);
    }

    // Ambil email yang dimasukkan
    let emailBaru = m.text.replace(`${prefix}setemail`, '').trim();

    // Validasi format email menggunakan regex
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(emailBaru)) {
      return mecha.reply(m.chat, 'Silakan masukkan email yang valid.', m);
    }

    // Ganti email user dengan email baru
    user.email = emailBaru;

    // Simpan perubahan email ke database
    global.db.users[m.quoted.sender] = user;

    // Kirimkan konfirmasi perubahan email
    mecha.reply(m.chat, `Berhasil mengubah email menjadi: ${emailBaru}`, m);
  },
  owner: true, // Hanya owner yang dapat mengakses fitur ini
};