exports.run = {
    usage: ['setgroup'],
    hidden: ['tutupgrup', 'bukagrup'],
    use: 'open / close + id_grup | alasan',
    category: 'owner',
    async: async (m, { func, mecha, text = '' }) => { // Pastikan text memiliki default string kosong

        if (!m.args[0] || !m.args[1]) {
            return mecha.sendMessage(m.chat, { 
                text: `Masukkan perintah dengan format yang benar!\n\nContoh:\n${m.prefix + m.command} open 111736183728382737@g.us | Grup dibuka untuk diskusi.` 
            }, { quoted: m });
        }

        let action = m.args[0].toLowerCase();
        let groupId = m.args[1];
        let reason = text.includes('|') ? text.split('|')[1].trim() : ''; // Mencegah error jika '|' tidak ada

        if (!['open', 'close'].includes(action)) {
            return mecha.sendMessage(m.chat, { 
                text: `Gunakan "open" atau "close" sebagai perintah pertama!\n\nContoh:\n${m.prefix + m.command} open 111736183728382737@g.us | Grup dibuka untuk diskusi.` 
            }, { quoted: m });
        }

        let metadata = await mecha.groupMetadata(groupId).catch(() => null);
        if (!metadata) {
            return mecha.sendMessage(m.chat, { 
                text: 'Gagal mendapatkan informasi grup. Pastikan bot ada di grup tersebut dan ID grup benar!' 
            }, { quoted: m });
        }

        let isAnnouncement = metadata.announce;

        if (action === 'close') {
            if (isAnnouncement) {
                return mecha.sendMessage(m.chat, { text: 'Grup sudah dalam mode close.' }, { quoted: m });
            }
            await mecha.groupSettingUpdate(groupId, 'announcement')
                .then(async () => {
                    mecha.sendReact(m.chat, '✅', m.key);
                    let message = `Bot telah menutup grup atas perintah owner.`;
                    if (reason) message += `\n\nAlasan: ${reason}`;
                    await mecha.sendMessage(groupId, { text: message }, { quoted: func.fstatus("System Notification") });
                })
                .catch(() => mecha.sendReact(m.chat, '❌', m.key));
        } else if (action === 'open') {
            if (!isAnnouncement) {
                return mecha.sendMessage(m.chat, { text: 'Grup sudah dalam mode open.' }, { quoted: m });
            }
            await mecha.groupSettingUpdate(groupId, 'not_announcement')
                .then(async () => {
                    mecha.sendReact(m.chat, '✅', m.key);
                    let message = `Bot telah membuka grup atas perintah owner.`;
                    if (reason) message += `\n\nAlasan: ${reason}`;
                    await mecha.sendMessage(groupId, { text: message }, { quoted: func.fstatus("System Notification") });
                })
                .catch(() => mecha.sendReact(m.chat, '❌', m.key));
        }
    },
    private: true,
    owner: true,
    boAdmin: true
};