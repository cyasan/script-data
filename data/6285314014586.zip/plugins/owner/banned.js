const toMs = require('ms');

exports.run = {
  usage: ['banned'],
  hidden: ['ban'],
  use: 'mention, reply, atau groupid|durasi',
  category: 'owner',
  async: async (m, { func, mecha, froms, setting, comand, isOwner }) => {
    const [text1, text2] = m.text.split('|');

    // Banned semua member grup (tanpa harus bot join grup)
    if (text1?.endsWith('@g.us')) {
      let members = [];
      try {
        let metadata = await mecha.groupMetadata(text1.trim());
        members = metadata.participants.map(p => p.id);
      } catch {
        // Kalau bot gak ada di grup, pakai list cadangan (harus disiapkan manual)
        if (global.db.groupMembers?.[text1.trim()]) {
          members = global.db.groupMembers[text1.trim()];
        } else {
          return mecha.reply(m.chat, `Bot tidak ada di grup tersebut dan tidak ada data anggota tersimpan.\n\nKamu bisa menyimpan daftar member manual ke: \n*global.db.groupMembers["${text1.trim()}"] = ["628xxxx@s.whatsapp.net", ...]*`, m);
        }
      }

      let durasi = text2 ? Date.now() + toMs(text2) : 'PERMANENT';
      let sukses = 0;
      let gagal = 0;
      for (const id of members) {
        if (!global.db.users[id]) continue;
        if (global.db.users[id].banned) {
          gagal++;
          continue;
        }
        global.db.users[id].banned = true;
        global.db.users[id].expired.banned = durasi;
        sukses++;
      }
      return mecha.reply(m.chat, `Berhasil banned *${sukses}* member.\nGagal: ${gagal}`, m);
    }

    // Banned via reply
    if (m.quoted) {
      let user = global.db.users[m.quoted.sender];
      let expire = m.text ? Date.now() + toMs(m.text) : 'PERMANENT';
      if (!user) return mecha.reply(m.chat, 'User data not found.', m);
      if (user.banned) return mecha.reply(m.chat, 'Target already banned.', m);
      user.banned = true;
      user.expired.banned = expire;
      return mecha.reply(m.chat, `Berhasil banned @${m.quoted.sender.split('@')[0]}`, m, {
        mentions: [m.quoted.sender]
      });
    }

    // Banned via nomor
    if (text1) {
      let number = isNaN(text1)
        ? text1.startsWith('+')
          ? text1.replace(/[()+\s-]/g, '')
          : text1.split('@')[1]
        : text1;
      if (isNaN(number)) return mecha.reply(m.chat, 'Nomor tidak valid.', m);
      if (number.length > 15) return mecha.reply(m.chat, 'Format tidak valid.', m);
      let ban = number.replace(/[^0-9]/g, '') + '@s.whatsapp.net';
      let user = global.db.users[ban];
      let expire = text2 ? Date.now() + toMs(text2) : 'PERMANENT';
      if (!user) return mecha.reply(m.chat, 'User data not found.', m);
      if (user.banned) return mecha.reply(m.chat, 'Target already banned.', m);
      user.banned = true;
      user.expired.banned = expire;
      return mecha.reply(m.chat, `Berhasil banned *${user.name || ban.split('@')[0]}*`, m);
    }

    return mecha.reply(m.chat, 'Mention, reply target, atau masukkan ID grup.', m);
  },
  owner: true,
};