exports.run = {
    usage: ['vca', 'vcv'],
    use: 'mention or reply',
    category: 'owner',
    async: async (m, {
        func,
        mecha,
        froms
    }) => {
        if (m.quoted || m.text) {
            await mecha.offerCall(froms, {
                isVideo: /^vcv$/.test(m.command) ? true : false,
                callOutCome: Date.now()
            });
            await mecha.sendReact(m.chat, '✅', m.key);
        } else m.reply('Mention or Reply chat target.')
    },
    owner: true
}