// plugin setgender
exports.run = {
  usage: ['setgender'],
  use: 'L/P',
  category: 'owner',
  async: async (m, { func, mecha, users, setting, froms, prefix }) => {

    // Pastikan pengguna sedang merespons pesan user yang ingin diganti gender-nya
    if (!m.quoted || !m.quoted.sender) {
      return mecha.reply(m.chat, 'Silakan reply pesan user yang ingin diubah gender-nya.', m);
    }

    // Ambil user yang sedang di-reply
    let user = global.db.users[m.quoted.sender];

    // Cek apakah user yang di-reply ada dalam database
    if (!user) {
      return mecha.reply(m.chat, 'User yang Anda reply tidak ditemukan di database.', m);
    }

    // Ambil gender yang ingin diubah
    let genderBaru = m.text.replace(`${prefix}setgender`, '').trim().toUpperCase();

    // Validasi gender yang dimasukkan (L untuk laki-laki, P untuk perempuan)
    if (genderBaru !== 'L' && genderBaru !== 'P') {
      return mecha.reply(m.chat, 'Silakan masukkan gender yang valid: L untuk Laki-laki, P untuk Perempuan.', m);
    }

    // Tentukan gender berdasarkan input
    let genderText = genderBaru === 'L' ? 'Laki-laki' : 'Perempuan';

    // Ganti gender user dengan gender baru
    user.gender = genderText;

    // Simpan perubahan gender ke database
    global.db.users[m.quoted.sender] = user;

    // Kirimkan konfirmasi perubahan gender
    mecha.reply(m.chat, `Successfully changed gender to: ${genderText}`, m);
  },
  owner: true, // Hanya owner yang dapat mengakses fitur ini
};