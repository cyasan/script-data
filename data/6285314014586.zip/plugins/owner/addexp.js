exports.run = {
    usage: ['addexp'],
    use: 'mention or reply',
    category: 'owner',
    async: async (m, { func, mecha, froms, setting }) => {
        if (m.quoted) {
            if (!m.text) {
                return mecha.sendMessage(m.chat, { 
                    text: 'Input nominal exp-nya.' 
                }, { quoted: m });
            }
            let nominal = m.text.replace(/[^0-9]/g, '');
            if (isNaN(nominal)) {
                return mecha.sendMessage(m.chat, { 
                    text: 'Nominal harus berupa angka.' 
                }, { quoted: m });
            }
            if (Number(nominal) >= 9999999999999999) {
                return mecha.sendMessage(m.chat, { 
                    text: 'Kebanyakan!' 
                }, { quoted: m });
            }
            let count = nominal.length > 0 ? Math.min(9999999999999999, Math.max(parseInt(nominal), 1)) : Math.min(1);
            if (count < 100) {
                return mecha.sendMessage(m.chat, { 
                    text: 'Minimal 100 exp.' 
                }, { quoted: m });
            }
            let user = global.db.users[m.quoted.sender];
            if (typeof user == 'undefined') {
                return mecha.sendMessage(m.chat, { 
                    text: 'User data not found.' 
                }, { quoted: m });
            }
            user.exp += count;
            return mecha.sendMessage(m.chat, { 
                text: `Successfully added ${count.toLocaleString()} exp to @${m.quoted.sender.replace(/@.+/, '')}`, 
                mentions: [m.quoted.sender] 
            }, { quoted: m });
        } else if (m.text) {
            const [target, amount] = m.text.split('|');
            if (!(target && amount)) {
                return mecha.sendMessage(m.chat, { 
                    text: `Contoh : ${m.cmd} 62895415497664|10000` 
                }, { quoted: m });
            }
            let number = isNaN(target) ? (target.startsWith('+') ? target.replace(/[()+\s-]/g, '') : target.split('@')[1]) : target;
            if (isNaN(number)) {
                return mecha.sendMessage(m.chat, { 
                    text: 'Invalid number.' 
                }, { quoted: m });
            }
            if (number.length > 15) {
                return mecha.sendMessage(m.chat, { 
                    text: 'Invalid format.' 
                }, { quoted: m });
            }
            let usernya = target.replace(/[^0-9]/g, '') + '@s.whatsapp.net';
            let user = global.db.users[usernya];
            let nominal = amount.replace(/[^0-9]/g, '');
            if (typeof user == 'undefined') {
                return mecha.sendMessage(m.chat, { 
                    text: 'User data not found.' 
                }, { quoted: m });
            }
            if (isNaN(nominal)) {
                return mecha.sendMessage(m.chat, { 
                    text: 'Nominal harus berupa angka.' 
                }, { quoted: m });
            }
            if (Number(nominal) >= 9999999999999999) {
                return mecha.sendMessage(m.chat, { 
                    text: 'Kebanyakan!' 
                }, { quoted: m });
            }
            let count = nominal.length > 0 ? Math.min(9999999999999999, Math.max(parseInt(nominal), 1)) : Math.min(1);
            if (count < 100) {
                return mecha.sendMessage(m.chat, { 
                    text: 'Minimal 100 exp.' 
                }, { quoted: m });
            }
            user.exp += count;
            return mecha.sendMessage(m.chat, { 
                text: `Successfully added ${count.toLocaleString()} exp to @${usernya.replace(/@.+/, '')}`, 
                mentions: [usernya] 
            }, { quoted: m });
        } else {
            return mecha.sendMessage(m.chat, { 
                text: 'Mention or Reply chat target.' 
            }, { quoted: m });
        }
    },
    owner: true
};