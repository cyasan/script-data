exports.run = {
  usage: ['kickbyid'],
  use: '<groupid> <nomor>',
  category: 'owner',
  async: async (m, { func, mecha }) => {
    if (!m.text.includes(' ')) return m.reply('Format salah!\nGunakan: `.kickbyid [groupid] [nomor]`');

    const [groupId, numberRaw] = m.text.trim().split(' ');
    if (!groupId || !numberRaw) return m.reply('Pastikan memasukkan *group ID* dan *nomor*.');
    if (!groupId.endsWith('@g.us')) return m.reply('Group ID tidak valid.');
    
    const number = numberRaw.replace(/[^0-9]/g, '');
    if (!number) return m.reply('Nomor tidak valid.');

    const jid = number + '@s.whatsapp.net';
    const tag = jid.split('@')[0];

    try {
      const res = await mecha.groupParticipantsUpdate(groupId, [jid], 'remove');

      for (let r of res) {
        if (r.status == 406) {
          m.reply(`Gagal! @${tag} adalah pembuat grup.`, { mentions: [jid] });
        } else if (r.status == 200) {
          await mecha.sendMessage(groupId, {
            text: `Bot telah mengeluarkan @${tag}`,
            mentions: [jid]
          }, { quoted: func.fstatus("System Notice")});

          m.reply(`Berhasil mengeluarkan @${tag} dari grup *${groupId}*`, {
            mentions: [jid],
            quoted: m
          });
        } else {
          m.reply(`Gagal mengeluarkan @${tag}. Status: ${r.status}`);
        }
      }
    } catch (e) {
      m.reply('Terjadi kesalahan:\n' + e.message);
    }
  },
  owner: true
};