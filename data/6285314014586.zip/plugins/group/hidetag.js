exports.run = {
  usage: ['hidetag'],
  hidden: ['h'],
  use: 'text',
  category: 'group',
  async: async (m, { func, mecha }) => {
    let users = global.db?.users?.[m.sender] || {}; // Mengambil data pengguna dari database global
    let isOwner = (global.owner || []).includes(m.sender) || m.sender === mecha.user.jid;
    
    let statusText = isOwner
      ? func.fstatus("Lexy verified by WhatsApp")
      : func.fstatus(`Hidetag from ${users.name || "Unknown User"}`);

    mecha.sendMessage(m.chat, {
      text: `${m.quoted ? m.quoted.text : m.text ? m.text : ''}`,
      mentions: m.members.map(x => x.id)
    }, { quoted: statusText, ephemeralExpiration: m.expiration });
  },
  group: true,
  admin: true
};