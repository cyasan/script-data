const PhoneNum = require("awesome-phonenumber");

exports.run = {
    usage: ["groupcountry"],
    hidden: ["country", "region"],
    category: "group",
    async: async (m, { mecha }) => {
        let regionNames = new Intl.DisplayNames(["en"], { type: "region" });
        let data = m.metadata;
        let participants = data.participants;

        let countryMembers = {};
        for (let participant of participants) {
            let phoneNumber = "+" + participant.id.split("@")[0];
            let regionCode = PhoneNum(phoneNumber).getRegionCode("internasional");
            let country = regionNames.of(regionCode) || "Unknown";
            let flag = regionCode ? getCountryFlag(regionCode) : "🏳"; // Default: bendera putih jika tidak diketahui

            if (!countryMembers[country]) countryMembers[country] = { total: 0, flag };
            countryMembers[country].total++;
        }

        let totalSum = participants.length;
        let totalRegion = Object.keys(countryMembers).length;

        let countryList = Object.entries(countryMembers)
            .map(([name, { total, flag }]) => `${flag} *${name}*: ${total} anggota`)
            .join("\n");

        let caption = `乂 GROUP COUNTRY CHECKER\n\n`;
        caption += `◦ *Total Anggota*: ${totalSum}\n`;
        caption += `◦ *Total Negara*: ${totalRegion}\n\n`;
        caption += `◦ *List Negara:*\n${countryList || "Tidak ada data negara yang ditemukan."}`;

        return mecha.sendMessage(m.chat, { text: caption }, { quoted: m });
    },
    group: true,
};

// Fungsi untuk mendapatkan emoji bendera dari kode negara
function getCountryFlag(regionCode) {
    return regionCode
        .toUpperCase()
        .split("")
        .map((char) => String.fromCodePoint(0x1F1A5 + char.charCodeAt(0)))
        .join("");
}