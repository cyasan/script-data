const axios = require("axios");

exports.run = {
    usage: ["brat3"],
    use: "text",
    category: "convert",
    async: async (m, { mecha, packname, author }) => {
        if (!m.args.length && (!m.quoted || !m.quoted.text)) {
            return m.reply("Input atau reply text!");
        }

        let text = m.args.length ? m.args.join(" ") : m.quoted.text;
        let maxLength = 150;

        if (text.length > maxLength) {
            return m.reply(`Maksimum ${maxLength} karakter!`);
        }

        let styles = ["style1", "style2", "style3", "style4", "style5"]; // Gaya acak
        let randomStyle = styles[Math.floor(Math.random() * styles.length)];

        mecha.sendReact(m.chat, "🕒", m.key);

        try {
            let url = `https://fastrestapis.fasturl.link/tool/furbrat?text=${encodeURIComponent(text)}&style=${randomStyle}&mode=center`;
            let response = await axios.get(url, { responseType: "arraybuffer" });

            mecha.sendSticker(m.chat, response.data, m, { packname, author, expiration: m.expiration });
        } catch (error) {
            m.reply(`Terjadi kesalahan saat membuat sticker.\n- ${error.message}`);
        }
    },
    limit: 2,
    location: "plugins/convert/brat3.js"
};